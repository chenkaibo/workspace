/**
 * Created by 17726 on 2017/3/7.
 */
'use strict';
window.onload = function ()
{
    //window.parent.menuOperFun();
    safetyRoleObjectElem("#safetyRoleId");
    top.d3.select("#leftDivId").classed("no-display",false);
};
var OwnerDataArr = [],modIndex;
/*
 * 获取界面元素
 * */
function safetyRoleObjectElem(contain)
{
    window.focus();
    window.sessionStorage.ux_pagePath = "dbSafetyRole,main";
    d3.select("#mainContainDiv").remove();
    d3.select(contain)
        .append("div")
        .attr({
            'id':'mainContainDiv',
            'class':'siteList-content db-manage-div'
        });
    d3.select(".siteList-content")
        .append("div")
        .attr({
            'id':'toolbar',
            'class':'toolbar box'
        });

    d3.select(".siteList-content #toolbar")
        .append("button")
        .attr({
            'id':'newSafetyRoleBtn',
            'class':'btn btn-default admitClick bounceIn disabledElem'
        })
        .on("click",function(){
            createSafetyRoleElem();
        })
        .html("新&nbsp;&nbsp;建");
    d3.select(".siteList-content #toolbar")
        .append("button")
        .attr({
            'id':'delSafetyRoleInfo',
            'class':'disabledElem delBtnClass',
            'disabled':'disabled',
            'onClick':'delSafetyRoleInfo()'
        })
        .html("删&nbsp;&nbsp;除");
    var operTypeSelect = d3.select(".siteList-content #toolbar")
        .append("select")
        .attr({
            'class':'select-type select-disabled',
            'disabled':'disabled',
            'id':'opterSelectItem'
        });
    var optionItem = ['操作类型','Rename'];
    for(var k = 0;k < optionItem.length; k++)
    {
        if(k == 0)
        {
            operTypeSelect.append("option")
                .attr({
                    'name':optionItem[k],
                    'selected':'selected',
                    'class':'title-option option all'
                })
                .html(optionItem[k]);
        }else{
            operTypeSelect.append("option")
                .attr({
                    'class':'option all',
                    'name':optionItem[k]
                })
                .html(optionItem[k]);
        }
    }
    d3.select(".siteList-content #toolbar")
        .append("button")
        .attr({
            "class":"disabledElem delBtnClass",
            "disabled":"disabled",
            "id":"executeBtnId"
        })
        .on("click",function(){
            var opterStr = d3.select("#opterSelectItem")[0][0].value;
            if(opterStr == "操作类型")
            {
                uxAlert("请正确选择需要执行的操作！");
                return;
            }
            executeOper(opterStr);
        })
        .html("执&nbsp;&nbsp;行");
    d3.select(".siteList-content")
        .append("div")
        .attr("id","safetyRoleQuery");
    d3.select("#safetyRoleQuery").append("span")
        .html("角色名：");
    d3.select("#safetyRoleQuery").append("input")
        .attr("id","querySafetyRoleName")
        .style("color","#57D1F7");
    d3.select("#safetyRoleQuery").append("button")
        .attr("class","searchSite-btn searchSite btn btn-bg-color")
        .on("click",function(){
            querySafetyRoleObj();
        });

    d3.select(".siteList-content")
        .append("div")
        .attr("class","safetyRole-table-div")
        .append("table")
        .attr("id","safetyRoleTableId")
        .attr("color","#57D1F7");

    reqInitTableData();
}
/****************************执行操作函数处理区***********************************/

function executeOper()
{
    //d3.select("#executeBtnId").classed("white",true);
    var className;
    var ids = getIdSelections("safetyRoleTableId");

    executeInfoElem("#mainContainDiv",ids[0].safetyRoleName);
    if(d3.select("#dialogRenameRole").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgRenameRole').fadeIn(300);
    $('#dialogRenameRole').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function executeInfoElem(contain,safetyRoleName)
{
    d3.select("#dialogBgRenameRole").remove();
    d3.select("#dialogRenameRole").remove();
    var pupUpItem = "Rename角色";
    d3.select(contain).append("div")
        .attr("id","dialogBgRenameRole");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogRenameRole");
    var editFrom = outPage.append("div")
        .attr("id","renameFromSafetyRole");

    editFrom.append("span")
        .attr({
            "class":"rename-safetyRole-title"
        })
        .html(pupUpItem);
    editFrom.append("span")
        .attr({
            "id":"renameItemSpanSafetyRole",
            "class":"renameSafetyRoleTitle"
        })
        .html(safetyRoleName);
    var selectTypeDiv = d3.select("#dialogRenameRole").append("div").attr({"class":"select-oper-typeRole editUl"});
    selectTypeDiv.append("span")
        .attr({
            "class":"rename-safetyRole-span"
        })
        .html("请输入新角色名:");
    selectTypeDiv.append("input")
        .attr({
            'id':'newRoleName',
            'class':'ipt rename-safetyRole',
            "placeholder":"字母开头，字母,数字,特殊字符组成，小于64位"
        })
        .on('blur',function(){
            var roleName = d3.select(this)[0][0].value;
            if(instanceName(roleName) && roleName.length < 65 && roleName.length > 0)
            {
                d3.select(this)[0][0].nextSibling.innerHTML = "";
            }else{
                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>字母开头，特殊字符可以包括下划线，长度不超过64！</span>";
            }
        });
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });
    var editFromDivBtn = d3.select("#dialogRenameRole").append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop dialog-renamebtn-div")
        .append("button")
        .attr("id","sureBtnSafetyRole")
        .on("click",function(){
            renameDealFun(safetyRoleName);
        })
        .attr("class","btn btn-default admitClick")
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnSafetyRole")
        .on("click",function(){
            d3.select("#dialogRenameRole").classed("bounceIn",false);
            $('#dialogBgRenameRole').fadeOut(300,function(){
                $('#dialogRenameRole').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#executeBtnId").classed("admitClick",true);
            d3.select("#executeBtnId").classed("white",false);
        })
        .html("取&nbsp;&nbsp;消");
}
function renameDealFun(oldRoleName)
{
    var newRoleName = d3.select("#newRoleName")[0][0].value;
    var roleNameFlag = false;
    if(instanceName(newRoleName) && newRoleName.length < 65 && newRoleName.length > 0)
    {
        roleNameFlag = true;
    }else{
        roleNameFlag = false;
    }
    if(!roleNameFlag)
    {
        uxAlert("请输入正确的角色名！");
        return;
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"exceRoleOp","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            opType:"rename",
            oldName:oldRoleName,
            newName:newRoleName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_safetyRoleInterface.ajaxRequest(false,jsonDataStr,exceRoleOperCallback);
}

function exceRoleOperCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        reqInitTableData();
        var selectItem = d3.select("#opterSelectItem");
        selectItem[0][0].selectedIndex = 0;
        selectItem[0][0].options[selectItem[0][0].selectedIndex].innerHTML = "操作类型";
        d3.select('#delSafetyRoleInfo').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
        d3.select('#executeBtnId').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
        d3.select('#opterSelectItem').classed("select-disabled",true).attr("disabled",true);
        uxAlert("执行操作成功！");
    }else{
        uxAlert("执行操作失败！");
    }
    d3.select("#executeBtnId").classed("white",false);
    d3.select("#dialogRenameRole").classed("bounceIn",false);
    $('#dialogBgRenameRole').fadeOut(300,function(){
        $('#dialogRenameRole').addClass('bounceOutUp').fadeOut();
    });
}
/******************************数据库表格实现************************************/
function initSafetyRoleTable()
{
    var par = [{field: 'checkBox' , radio: true ,align: 'center' },
        {field: 'index' ,title: '序&nbsp;&nbsp;&nbsp;&nbsp;号' ,align: 'center',formatter:function(value,row,index){
            return index+1;
        }},
        {field: 'safetyRoleName' ,title: '角色名' ,align: 'center' },
        {field: 'systemRoot' ,title: '系统权限' ,align: 'center' },
        {field: 'roleId' , title: '角色ID' ,align: 'center' },
        {field: 'operate' , title: '操&nbsp;&nbsp作' ,align: 'center' , formatter:function(value,row,index){
            var par = row.safetyRoleName + "," + row.systemRootArray + "," + index;
            var modifRoleOper = '<a title = "修改">' + '<button id = "modifBtn'+ index +'" class = "modifPsw bounceIn" onclick = "modfiSafetyRoleInfo(\''+ par+ '\')"'+'></button>' + '</a>';
            return modifRoleOper;
        }}
    ];
    $('#safetyRoleTableId').bootstrapTable({
        classes:"table table-no-bordered",
        //toolbar:"#toolbar",
        height:606,
        columns: par,
        idField:"index",
    });
}

function reqInitTableData()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"getAllRoleList","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_safetyRoleInterface.ajaxRequest(false,jsonDataStr,reqInitTableDataCallback);
}
function reqInitTableDataCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        initSafetyRoleTable();
        listenSafetyRoleTable();
        var data = getRoleNewJson(JSON.parse(retJsonStr.data));
        $("#safetyRoleTableId").bootstrapTable('load',data);
    }else{
        uxAlert("角色列表初始化失败！");
    }
}
//重组数据格式
function getRoleNewJson(data)
{
    var newJson = [];
    for(var i = 0;i < data.length;i++)
    {
        var info = {};
        info.safetyRoleName = data[i].rolname;
        var root = [];
        if(data[i].rolsuper){
            root.push("超级管理员")
        }
        if(data[i].rolcreatedb){
            root.push("创建数据库")
        }
        if(data[i].rolcreaterole){
            root.push("创建角色")
        }
        info.systemRoot = root.join(",");
        info.roleId = data[i].oid;
        info.systemRootArray = [data[i].rolsuper,data[i].rolcreatedb,data[i].rolcreaterole];
        newJson.push(info);
    }
    return newJson;
}
    /******************************新建角色**************************************/
function createSafetyRoleElem()
{
    var className;
    d3.select("#newSafetyRoleBtn").classed("white",true);
    createSafetyRoleDataInfoElem("#mainContainDiv");
    if(d3.select("#dialogSafetyRole").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgSafetyRole').fadeIn(300);
    $('#dialogSafetyRole').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function createSafetyRoleDataInfoElem(contain)
{
    d3.select("#dialogBgSafetyRole").remove();
    d3.select("#dialogSafetyRole").remove();
    d3.select("#dialogBgModSafetyRole").remove();
    d3.select("#dialogModSafetyRole").remove();
    var pupUpItem = "新建角色";
    var roleTitle = ["基本信息"];
    var popUpInputArray = ["角色名"];
    d3.select(contain).append("div")
        .attr("id","dialogBgSafetyRole");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogSafetyRole");
    var editFrom = outPage.append("div")
        .attr("id","editFromSafetyRole");
    outPage.append("div")
        .attr({
            "id":"createItemSpanSafetyRole",
            "class":"createSafetyRoleTitle"
        })
        .html(pupUpItem);

    var editTileUl = editFrom.append("ul")
        .attr("class","roleTitle").append("li")
        .html(roleTitle);
    var editFormWrap = editFrom.append("div")
        .attr("class","createEditFormWrapRole");
    for(var i = 0;i < roleTitle.length;i++){
        editFormWrap.append("div")
            .attr({
                "class":"editFormCon",
                "id":"editFormCon"+i
            })
    }
    var editFormUl = d3.select("#editFormCon0")
        .append("ul")
        .attr("class","createInfos");
    for(var i = 0;i < popUpInputArray.length;i++)
    {
        var editFromLi = editFormUl.append("li")
            .attr({
                "class":"editUl",
                "id":"roleFormIpt" + i
            });
        editFromLi.append("label")
            .attr({
                "class":"editFromLiSpanRole",
                "for":"input"+i
            })
            .html(popUpInputArray[i]);
        editFromLi.append("input").attr({
            'class':'ipt2',
            'id':'input' + i
        });
        if(i == 0){
            d3.select("#input0").attr("placeholder","字母开头，字母,数字,特殊字符组成，小于64位")
                .on('blur',function(){
                var roleName = d3.select(this)[0][0].value;
                if(instanceName(roleName) && roleName.length < 65 && roleName.length > 0)
                {
                    d3.select(this)[0][0].nextSibling.innerHTML = "";
                }else{
                    d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>字母开头，特殊字符可以包括下划线，长度不超过64！</span>";
                }
            })
        };
    };
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });

    d3.select("#expDateValue").on("click",function(e){
        actionDatePicker("expDateValue",false,"bottom",e)
    });
    d3.select("#editFormCon0")
        .append("div")
        .attr("class","systemRoot")
        .html("系统权限：");
    var systemRole = ["超级管理员","创建数据库","创建角色"];
    var systemRoot = d3.select(".systemRoot")
    for(var i = 0;i < 3 ; i++){
        systemRoot.append("input")
            .attr({
                "type":"checkbox",
                "id":"systemRole"+i
            });
        systemRoot.append("lable")
            .attr("for","systemRole"+i)
            .html(systemRole[i]);
    }

    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop dialog-btnRole-div")
        .append("button")
        .attr("id","sureBtnSafetyRole")
        .attr("class","btn btn-default admitClick")
        .on("click",function(){
            createSafetyRoleData();
        })
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnSafetyRole")
        .on("click",function(){
            d3.select("#dialogSafetyRole").classed("bounceIn",false);
            $('#dialogBgSafetyRole').fadeOut(300,function(){
                $('#dialogSafetyRole').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#getSafetyRoleBtnId").classed("admitClick",true);
            d3.select("#newSafetyRoleBtn").classed("white",false);
        })
        .html("取&nbsp;&nbsp;消");
}
function createSafetyRoleData(){
    var rolename = d3.select("#input" + 0)[0][0].value;
    var sureRoleFlag = false;
    if(instanceName(rolename) && nameValue.length < 65 && rolename.length > 0)
    {
        sureRoleFlag = true;
    }else{
        sureRoleFlag = false;
    }
    if(sureRoleFlag && (rolename == ""))
    {
        uxAlert("请输入正确新建角色信息！");
        return;
    }
    var formDataArray = d3.selectAll(".systemRoot input[type = checkbox]");
    var superUserFlag = (formDataArray[0][0].checked == false) ? (0):(1);
    var createDbFlag = (formDataArray[0][1].checked == false) ? (0):(1);
    var createRoleFlag = (formDataArray[0][2].checked == false) ? (0):(1);
    var jsonDataObj = {
        ip: "",
        port: "",
        router: "dbopt",
        request: {"mainRequest": "createRole", "subRequest": "", "ssubRequest": ""},
        data: {
            webusername: window.sessionStorage.ux_curUserName,
            instid: window.sessionStorage.ux_currentChoiceInsId,
            dbname: window.sessionStorage.ux_currentChoiceDataName,
            roleName: rolename,
            superUser: superUserFlag,
            createDb: createDbFlag,
            createRole: createRoleFlag
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_safetyRoleInterface.ajaxRequest(false,jsonDataStr,newSafetyRoleCallback);
}
function newSafetyRoleCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        reqInitTableData();
        uxAlert("新建角色成功！");
    }else{
        uxAlert("新建角色失败！");
    }
    d3.select("#dialogSafetyRole").classed("bounceIn",false);
    $('#dialogBgSafetyRole').fadeOut(300,function(){
        $('#dialogSafetyRole').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#newSafetyRoleBtn").classed("white",false);
}

/*****************************删除操作***************************************/
function delSafetyRoleInfo()
{
    d3.select("#delSafetyRoleInfo").classed("admitClick",false);
    uxConfirm("是否确认删除该角色？",function(rst)
    {
        if(!rst)
        {
            d3.select("#delSafetyRoleInfo").classed("admitClick",true);
            return;
        }
        var ids = getIdSelections("safetyRoleTableId");
        console.info(ids);
        var delRoleName = ids[0].safetyRoleName;
        var jsonDataObj = {
            ip      :"",
            port    :"",
            router  :"dbopt",
            request :{"mainRequest":"deleteRole","subRequest":"","ssubRequest":""},
            data    :{
                webusername : window.sessionStorage.ux_curUserName,
                instid : window.sessionStorage.ux_currentChoiceInsId,
                dbname : window.sessionStorage.ux_currentChoiceDataName,
                safetyRoleName:delRoleName
            }
        };
        var jsonDataStr = JSON.stringify(jsonDataObj);
        ux_safetyRoleInterface.ajaxRequest(false,jsonDataStr,delSafetyRoleInfoCallback);
    });
}
function delSafetyRoleInfoCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode = "success"){
        reqInitTableData();
        uxAlert("删除角色成功！");
    }else{
        uxAlert("删除角色失败！");
    }
    d3.select("#delSafetyRoleInfo").classed("delBtnClass",true);
}
/*****************************查询操作*****************************************/
function querySafetyRoleObj()
{
    var safetyRoleName = d3.select("#querySafetyRoleName")[0][0].value;
    if(safetyRoleName == "")
    {
        reqInitTableData();
        return;
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"searchRoleInfo","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            roleName:safetyRoleName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);

    ux_safetyRoleInterface.ajaxRequest(false,jsonDataStr,querySafetyRoleObjCallback);
}
function querySafetyRoleObjCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        var data = getRoleNewJson(JSON.parse(retJsonStr.data));
        $("#safetyRoleTableId").bootstrapTable('load',data);
    }else{
        uxAlert("查询角色失败！");
    }
}
/****************************修改操作****************************************/
function modfiSafetyRoleInfo(str)
{
    var className;
    var itemArray = str.split(",");
    var selectRoleName = itemArray[0];
    var systemRoot = [itemArray[1],itemArray[2],itemArray[3]];
    modIndex = parseInt(itemArray[4]);
    d3.select("#modifBtn" + modIndex).classed("modifPsw-white",true);
    modifSafetyRoleInfoElem("#mainContainDiv",selectRoleName,systemRoot,itemArray[3]);
    if(d3.select("#dialogModSafetyRole").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgModSafetyRole').fadeIn(300);
    $('#dialogModSafetyRole').removeAttr('class').addClass('animated '+className+'').fadeIn();
}
function modifSafetyRoleInfoElem(contain,modSafetyRoleName,systemRootArr)
{
    d3.select("#dialogBgSafetyRole").remove();
    d3.select("#dialogSafetyRole").remove();
    d3.select("#dialogBgModSafetyRole").remove();
    d3.select("#dialogModSafetyRole").remove();
    var pupUpItem = "修改角色";
    var rolename = "角色名";
    var roleTitle = ["基本信息"];
    var popUpInputArray = ["角色名"];
    d3.select(contain).append("div")
        .attr("id","dialogBgModSafetyRole");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogModSafetyRole");
    var editFrom = outPage.append("div")
        .attr("id","editFromSafetyRole");
    editFrom.append("span")
        .attr({
            "class":"modifyTitle"
        })
        .html(pupUpItem);
    editFrom.append("span")
        .attr({
            "id":"modSpanSafetyRole",
            "class":"modifyTitle"
        })
        .html(modSafetyRoleName);
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos");

    var editTileUl = editFrom.append("ul")
        .attr("class","roleTitle").append("li")
        .html(roleTitle);

    var editFormWrap = editFrom.append("div")
        .attr("class","modifyEditFormWrapRole");
    editFormWrap.append("span")
        .attr("class","rolename")
        .html(rolename+"  :  ");
    editFormWrap.append("span")
        .attr({
            "id":"modItemSpanSafetyRole",
            "class":"modifyRole"
        })
        .html(modSafetyRoleName);
    for(var i = 0;i < roleTitle.length;i++){
        editFormWrap.append("div")
            .attr({
                "class":"editFormCon",
                "id":"editFormCon"+i
            })
    };
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });

    d3.select("#expDateValue").on("click",function(e){
        actionDatePicker("expDateValue",false,"bottom",e)
    });
    d3.select("#editFormCon0")
        .append("div")
        .attr("class","systemRoot1")
        .html("系统权限：");
    var systemRole = ["超级管理员","创建数据库","创建角色"];
    var systemRoot1 = d3.select(".systemRoot1");
    for(var i = 0;i < 3 ; i++){
        systemRoot1.append("input")
            .attr({
                "type":"checkbox",
                "id":"systemRole"+i
            });
        systemRoot1.append("lable")
            .attr("for","systemRole"+i)
            .html(systemRole[i]);
    }
    d3.select(".systemRoot1").selectAll("input[type = 'checkbox']").each(function(d,i){
        if(systemRootArr[i] == "false")
        {
            d3.select(this)[0][0].checked = false;
        }else{
            d3.select(this)[0][0].checked = true;
        }
    });
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop .dialog-modbtn-div")
        .append("button")
        .attr("id","sureBtnSafetyRole")
        .attr("class","btn btn-default admitClick")
        .on("click",function(){
            modifySafetyRoleDataInfoFun(modSafetyRoleName);
        })
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnSafetyRole")
        .on("click",function(){
            d3.select("#dialogModSafetyRole").classed("bounceIn",false);
            $('#dialogBgModSafetyRole').fadeOut(300,function(){
                $('#dialogModSafetyRole').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#modifBtn").classed("admitClick",true);
            d3.select("#modifBtn" + modIndex).classed("modifPsw-white",false);
        })
        .html("取&nbsp;&nbsp;消");
}
function modifySafetyRoleDataInfoFun(roleName){
    var formDataArray = d3.selectAll(".systemRoot1 input[type = checkbox]");
    var superUserFlag = (formDataArray[0][0].checked == false) ? (0):(1);
    var createDbFlag = (formDataArray[0][1].checked == false) ? (0):(1);
    var createRoleFlag = (formDataArray[0][2].checked == false) ? (0):(1);
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"modifyRole","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            roleName:roleName,
            superUser:superUserFlag,
            createDb:createDbFlag,
            createRole:createRoleFlag
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_safetyRoleInterface.ajaxRequest(false,jsonDataStr,modifSafetyRoleCallback);
}
function modifSafetyRoleCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        reqInitTableData();
        uxAlert("修改角色成功！");
    }else{
        uxAlert("修改角色失败！");
    }
    d3.select("#dialogModSafetyRole").classed("bounceIn",false);
    $('#dialogBgModSafetyRole').fadeOut(300,function(){
        $('#dialogModSafetyRole').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#modifBtn" + modIndex).classed("modifPsw-white",false);
}
function listenSafetyRoleTable()
{
    var $table = $("#safetyRoleTableId");
    $table.on('check.bs.table page-change.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table', function (arg) {
        var selected = $("#safetyRoleTableId").bootstrapTable('getSelections');
        if (selected.length > 0) {
            d3.select('#delSafetyRoleInfo').classed("delBtnClass",false).classed("btn admitClick",true).attr("disabled",null);
            d3.select('#opterSelectItem').classed("select-disabled",false).attr("disabled",null);
            d3.select('#executeBtnId').classed("delBtnClass",false).classed("btn admitClick",true).attr("disabled",null);
        }
        else {
            d3.select('#delSafetyRoleInfo').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
            d3.select('#executeBtnId').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
            d3.select('#opterSelectItem').classed("select-disabled",true).attr("disabled",true);
        }
    });
}