/**
 * 时间插件生成主函数
 */
function timeSelect() {
    var container = d3.select("#mainContainDiv")
        .append("div")
        .attr("class","data-picker-con")
        .on("click",function(e){
            stopEvent(d3.event);
        });
    var date_time = container.append('div').attr('id', 'date_time')
        .attr('class', 'needHide date-picker-div');

    var myDate = new Date();
    var nowYear = myDate.getFullYear();
    var nowMonth = myDate.getMonth() + 1;

    /**生成年的选择器**/
    var yearSelect = date_time
        .append('select')
        .attr({
            'id': 'yearSelect',
            "class":"picker-year"
        })
        .on('change', function () {
            d3.select('#day-num-table').remove();
            var value = d3.select(this).property("value");
            nowYear = parseInt(value.replace('year', ''));
            daysAdd("day-num-table", nowYear, nowMonth);
            d3.select('#day-num-table').style({
                "display": "inline-block"
            });
        });
    /**生成月的选择器**/
    var monthSelect = date_time
        .append('select')
        .attr({
            'id': 'monthSelect',
            "class":"picker-month"
        })
        .on('change', function () {
            d3.select('#day-num-table').remove();
            var value = d3.select(this).property("value");
            nowMonth = parseInt(value.replace('month', ''));
            daysAdd('day-num-table', nowYear, nowMonth);
            d3.select('#day-num-table').style({
                "display": "inline-block"
            });
        });

    /**给年的select插入option**/
    //for (var i = (nowYear - 30); i < (nowYear + 30); i++) {
    for (var i = nowYear; i < (nowYear + 30); i++) {
        yearSelect.append('option')
            .attr('value', 'year' + i)
            .attr('id','year' + i)
            .text(i + '年');
    }
    d3.select('#year' + nowYear).attr('selected', 'true');//选中当前年
    /**给月的select插入option**/
    //for (var i = 1; i < 13; i++) {
    for (var i = nowMonth; i < 13; i++) {
        monthSelect.append('option')
            .attr('value', function(){
                if(i<10){
                    return 'month0' + i
                }else[]
                return 'month' + i
            })
            .attr('id', 'month' + i)
            .text(i + '月');
    }
    d3.select('#month' + nowMonth).attr('selected', 'true');//选中当前月

    /**生成week**/
    var weeks = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
    var table = date_time.append('table').attr({
        'id': 'date_timetable',
        'class': 'table week-table',
        'width': '100%'
    });
    var table_tr = table.append('tr');
    for (var i = 1; i <= 7; i++) {
        table_tr.append('td')
            .attr('class', 'tableFont')
            .html(weeks[i - 1]);
    }
    daysAdd('day-num-table', nowYear, nowMonth);

    /**生成时间选择器的容器**/
    var hourMin = container.append('div').attr('id', 'time-picker-div')
        .attr('class', 'needHide hour-picker');

    /**生成小时选择器的div**/
    var date_time4 = hourMin.append('div').attr('id', 'hour-div')
        .on('mousewheel', function (e) {
            if (parseInt(d3.select('#hour-scroll').style('top').replace('px', '')) >= 0
                && parseInt(d3.select('#hour-scroll').style('top').replace('px', '')) <= 179) {
                e = e || window.event;
                var temTop = parseInt(d3.select('#hour-scroll').style('top').replace('px', ''));
                if (e.wheelDelta > 0) {
                    if (temTop > 5) {
                        d3.select('#hour-scroll').style('top', (temTop - 5) + 'px');
                    } else {
                        d3.select('#hour-scroll').style('top', '1px');
                    }
                    var beginNum = parseInt(temTop / 11.625);
                    for (var i = 0; i < 9; i++) {
                        if ((i + beginNum) <= 9) {
                            d3.select('#hour' + i).html(0 + '' + (i + beginNum));
                        } else {
                            d3.select('#hour' + i).html(i + beginNum);
                        }
                    }
                    console.log('up');
                } else {
                    if (temTop < 175) {
                        d3.select('#hour-scroll').style('top', (temTop + 5) + 'px');
                    } else {
                        d3.select('#hour-scroll').style('top', '175px');
                    }
                    var beginNum = parseInt(temTop / 11.625);
                    for (var i = 0; i < 9; i++) {
                        if ((i + beginNum) <= 9) {
                            d3.select('#hour' + i).html(0 + '' + (i + beginNum));
                        } else {
                            d3.select('#hour' + i).html(i + beginNum);
                        }
                    }
                    console.log('down');
                }
            }
        });
    /**生成分钟的选择器的div**/
    var date_time5 = hourMin.append('div').attr('id', 'minu-div')
        .on('mousewheel', function (e) {
            if (parseInt(d3.select('#minu-scroll').style('top').replace('px', '')) >= 0
                && parseInt(d3.select('#minu-scroll').style('top').replace('px', '')) <= 179) {
                e = e || window.event;
                var temTop = parseInt(d3.select('#minu-scroll').style('top').replace('px', ''));
                if (e.wheelDelta > 0) {
                    if (temTop > 5) {
                        d3.select('#minu-scroll').style('top', (temTop - 5) + 'px');
                    } else {
                        d3.select('#minu-scroll').style('top', '1px');
                    }
                    var beginNum = parseInt(temTop / 3.419);
                    for (var i = 0; i < 9; i++) {
                        if ((i + beginNum) <=9) {
                            d3.select('#minute' + i).html(0 + '' + (i + beginNum));
                        } else {
                            d3.select('#minute' + i).html(i + beginNum);
                        }
                    }
                    console.log('up');
                } else {
                    if (temTop < 175) {
                        d3.select('#minu-scroll').style('top', (temTop + 5) + 'px');
                    } else {
                        d3.select('#minu-scroll').style('top', '175px');
                    }
                    var beginNum = parseInt(temTop /3.419);
                    for (var i = 0; i < 9; i++) {
                        if ((i + beginNum) <= 9) {
                            d3.select('#minute' + i).html(0 + '' + (i + beginNum));
                        } else {
                            d3.select('#minute' + i).html(i + beginNum);
                        }
                    }
                    console.log('down');
                }
            }
        });
    /**给小时添加数字内容**/
    date_time4
        .append('div')
        .attr({
            'id': 'hour-scroll',
            "class":"hour-scroll"
        })
    /**给分钟添加数字内容**/
    date_time5
        .append('div')
        .attr({
            'id': 'minu-scroll',
            "class":"minu-scroll"
        })

    for (var i = 0; i < 9; i++) {
        date_time4
            .append('div')
            .attr({
                'id': 'hour' + i,
                "class":"hour-num"
            })
            .style({
                'top': 23 * i + 'px'
            }).html(0 + '' + i);
    }
    /**给分钟添加点击事件**/
    for (var i = 0; i < 9; i++) {
        date_time5
            .append('div')
            .attr({'id': 'minute' + i,"class":"minu-num"})
            .style({
                'top': 23 * i + 'px'
            }).html(0 + '' + i);
    }

}

/**公告变量，方便给日期选择器中的天再次绑定点击事件**/
var date_picker_id = "";
var input_flag = "";
/**
 * 时间插件的点击动作函数
 * @param id -- 点击的input框的id
 * @param flag -- 如果为true，则生成时和分的选择器，否则只有日期的选择器
 * @param direction -- 时间轴生成的方向，暂时只有top和bottom两个方向
 */
function actionDatePicker(id,flag,direction){
    var this_value = d3.select("#"+id)[0][0].value;

    var date_year = this_value.split(" ")[0].split("-")[0];
    var date_month = this_value.split(" ")[0].split("-")[1];
    var date_day = this_value.split(" ")[0].split("-")[2];

    selectedDate(d3.select("#yearSelect").selectAll("option")[0],date_year);
    selectedDate(d3.select("#monthSelect").selectAll("option")[0],date_month);

    d3.select("#day-num-table").selectAll(".day-num")[0].forEach(function(d,i){
        d3.select(d).classed("clicked-day",false);
        if(d.id.indexOf(date_day) > 0 ){
            d3.select(d).classed("clicked-day",true);
        }
    });

    /**点击空白处,隐藏时间选择器**/
    document.onclick = function(){
        d3.select(".data-picker-con").style("display","none");
    };

    date_picker_id = id;
    input_flag = flag;
    var myDate = new Date();
    var clickNum2 = 0;
    var clickNum3 = 0;
    var nowHour = myDate.getHours();
    var nowMinute = myDate.getMinutes();

    /**选择小时时的点击事件**/
    d3.selectAll(".hour-num").on("click",function(){
        d3.selectAll(".hour-num").classed("clicked-time",false);
        d3.select(this).classed("clicked-time",true);
        nowHour = d3.select(this).html();
        var temValue = d3.select('#' + id).property('value').split(" ")[0];
        d3.select('#' + id).property('value', (temValue + ' ' + nowHour + ':' + nowMinute));
        clickNum2++;
        if (clickNum2 > 0 && clickNum3 > 0) {
            d3.select('.data-picker-con').style({
                "display": "none"
            });
            clickNum2 = 0;
            clickNum3 = 0;
        }
        var onchange = new Event("onchange");//注册名称为onchange的事件
        d3.select('#' + date_picker_id)[0][0].dispatchEvent(onchange);//给input框设置onchange事件
    });

    /**选择分钟时的点击事件**/
    d3.selectAll(".minu-num").on("click",function(e){
        d3.selectAll(".minu-num").classed("clicked-time",false);
        d3.select(this).classed("clicked-time",true);
        nowMinute = d3.select(this).html();
        var temValue = d3.select('#' + id).property('value').split(" ")[0];
        d3.select('#' + id).property('value', (temValue + ' ' + nowHour + ':' + nowMinute));
        clickNum3++;
        if (clickNum2 > 0 && clickNum3 > 0) {
            d3.select('.data-picker-con').style({
                "display": "none"
            });
            clickNum2 = 0;
            clickNum3 = 0;
        }
        var onchange = new Event("onchange");//注册名称为onchange的事件
        d3.select('#' + date_picker_id)[0][0].dispatchEvent(onchange);//给input框设置onchange事件
    });
    d3.selectAll(".day-num").on("click",function(){
        dayClick(this);
    });

    /**点击input框，弹出时间选择器**/
    if (d3.select('.data-picker-con').style('display') == "none") {
        /**给时间弹出框定位**/
        var offsetLeft = d3.select("#"+id)[0][0].getBoundingClientRect().left;
        var offsetTop = d3.select("#"+id)[0][0].getBoundingClientRect().top;
        var input_height = parseInt(d3.select("#"+id)[0][0].offsetHeight );
        var posY = "";
        var posX = offsetLeft +"px";
        if(direction == "top"){
            posY = offsetTop - 220 + "px";
        }else{
            posY = offsetTop + input_height + 5 + "px";
        }

        if(!flag){
            d3.select("#time-picker-div").style("display","none");
        }else{
            d3.select("#time-picker-div").style("display","inline-block");
        }

        d3.select('.data-picker-con').style({
            "display": "inline-block",
            "top":posY,
            "left":posX,
            "width":function(){
                if(flag){
                    return "342px"
                }else{
                    return "258px"
                }
            },
            "height":"214px"
        });

    } else {
        d3.select('.data-picker-con').style({
            "display": "none"
        });
    }
    stopEvent(d3.event);
}

function selectedDate(dateArr,date_year){
    dateArr.forEach(function(d,i){
        d.removeAttribute("selected");
        if(d.value.indexOf(date_year) > 0 ){
            d.setAttribute("selected","selected");
        }
    });
}


function dayClick(this_){
    var onchange = new Event("onchange");//注册名称为onchange的事件

    var mon_value = d3.select("#monthSelect").property("value");
    var nowMonth = mon_value.replace('month', '');

    var year_value = d3.select("#yearSelect").property("value");
    var nowYear = parseInt(year_value.replace('year', ''));

    d3.selectAll(".day-num").classed("clicked-day",false);
    d3.select(this_).classed("clicked-day",true);
    var input_value_now = "";
    var day_num = parseInt(d3.select(this_).text().trim());
    if(day_num <= 9){
        day_num = "0"+day_num;
    }
    if(input_flag){
        var temValue = d3.select('#' + date_picker_id).property('value').split(" ")[1];
        input_value_now = nowYear + '-' + nowMonth + '-' + day_num + ' ' + temValue;
    }else{
        input_value_now = nowYear + '-' + nowMonth + '-' + day_num;
    }

    d3.select("#"+date_picker_id).property("value","");
    d3.select('#' + date_picker_id).property('value', input_value_now);

    if(!input_flag){
        d3.select('.data-picker-con')
            .style("display","none");
    }
    //var onchange = new Event("onchange");//注册名称为onchange的事件
    d3.select('#' + date_picker_id)[0][0].dispatchEvent(onchange);//给input框设置onchange事件
}

function daysAdd(id, nowYear, nowMonth) {
    d3.select('#date_time').append('table').attr({
        'id': id,
        'class': 'table day-num-table',
        'width': '100%'
    });
    var nowWeek = new Date(nowYear, nowMonth - 1, 1).getDay();
    var daysArror = [[], [], [], [], [], []];
    dayArrorInf(id, nowYear, daysArror, nowWeek, nowMonth);
}

function isLeapYear(year) {
    var isLeapYear;
    if (((year % 4) == 0) && ((year % 100) != 0) || ((year % 400) == 0)) {
        isLeapYear = 1;
    } else {
        isLeapYear = 0;
    }
    return isLeapYear;
}

function dayArrorInf(id, nowYear, daysArror, nowWeek, nowMonth) {
    if (isLeapYear(nowYear)) {
        if (nowMonth == 2) {
            //闰年2月
            dayArrorAdd(daysArror, nowWeek, 31, 29);
            daysDraw(d3.select('#' + id),  daysArror, nowYear, nowMonth);
        } else if (nowMonth == 1 || nowMonth == 3 || nowMonth == 5 || nowMonth == 7 || nowMonth == 8 || nowMonth == 10 || nowMonth == 12) {
            if (nowMonth == 1 || nowMonth == 8) {
                //闰年1,8月
                dayArrorAdd(daysArror, nowWeek, 31, 31);
                daysDraw(d3.select('#' + id),  daysArror, nowYear, nowMonth);
            } else if (nowMonth == 3) {
                dayArrorAdd(daysArror, nowWeek, 29, 31);
                daysDraw(d3.select('#' + id),  daysArror, nowYear, nowMonth);
            } else {
                //闰年剩下大月
                dayArrorAdd(daysArror, nowWeek, 30, 31);
                daysDraw(d3.select('#' + id), daysArror, nowYear, nowMonth);
            }
        } else {
            //闰年小月
            dayArrorAdd(daysArror, nowWeek, 31, 30);
            daysDraw(d3.select('#' + id), daysArror, nowYear, nowMonth);
        }
        return nowWeek;
    } else {
        if (nowMonth == 2) {
            //平年2月
            dayArrorAdd(daysArror, nowWeek, 31, 28);
            daysDraw(d3.select('#' + id), daysArror, nowYear, nowMonth);
        } else if (nowMonth == 1 || nowMonth == 3 || nowMonth == 5 || nowMonth == 7 || nowMonth == 8 || nowMonth == 10 || nowMonth == 12) {
            if (nowMonth == 1 || nowMonth == 8) {
                //平年1,8月
                dayArrorAdd(daysArror, nowWeek, 31, 31);
                daysDraw(d3.select('#' + id), daysArror, nowYear, nowMonth);
            } else if (nowMonth == 3) {
                dayArrorAdd(daysArror, nowWeek, 28, 31);
                daysDraw(d3.select('#' + id), daysArror, nowYear, nowMonth);
            } else {
                //平年剩下大月
                dayArrorAdd(daysArror, nowWeek, 30, 31);
                daysDraw(d3.select('#' + id), daysArror, nowYear, nowMonth);
            }
        } else {
            //平年小月
            dayArrorAdd(daysArror, nowWeek, 31, 30);
            daysDraw(d3.select('#' + id), daysArror, nowYear, nowMonth);
        }
    }
}

function dayArrorAdd(daysArror, nowWeek, lastMonthNum, thisMonthNum) {
    var days = 1;
    var temNowWeek = (lastMonthNum + 1) - nowWeek;
    for (var i = 0; i < nowWeek; i++) {
        daysArror[0].push(temNowWeek++);
    }
    for (var i = nowWeek; i < 7; i++) {
        daysArror[0].push(days++);
    }
    var flag1, flag2;
    for (var i = 1; i < 6; i++) {
        for (var j = 0; j < 7; j++) {
            if (days <= thisMonthNum) {
                daysArror[i].push(days++);
                flag1 = i;
                flag2 = j;
            }
        }
    }
    days = 1;
    if (flag1 == 4) {
        for (var i = (flag2 + 1); i < 7; i++) {
            daysArror[4].push(days++);
        }
        for (var i = 0; i < 7; i++) {
            daysArror[5].push(days++);
        }
    } else if (flag1 == 5) {
        for (var j = flag2; j < 7; j++) {
            daysArror[5].push(days++);
        }
    } else {
        for (var i = 4; i <= 5; i++) {
            for (var j = 0; j < 7; j++) {
                daysArror[i].push(days++);
            }
        }
    }
}
/*-----------liyaning---------*/
function expDate(daysArror){
    var currentData = new Date();
    var date = currentData.getDate();
    var arr = [];
    for(var i = 0; i < 6; i++){
        for(var j = 0; j < 7; j++){
            if(daysArror[i][j] == date){
                arr.push(i);
                arr.push(j);
                return arr;
            }
        }
    }
}
/*-------------liyaning--------------*/

function daysDraw(container, daysArror, nowYear, nowMonth) {
    var l = expDate(daysArror)[0];
    var k = expDate(daysArror)[1];
    console.log("l = "+l+";k = "+k);
    for (var i = 1; i <= 6; i++) {
        var table_tr = container.append('tr').attr("class","day-num-tr");
        for (var j = 1; j <= 7; j++) {
            var temTd = table_tr.append('td')
                .attr({
                    "class":"day-num"
                })
                .html(daysArror[i - 1][j - 1]);
            if (((i <= 1) && (daysArror[i - 1][j - 1] > 20)) || ((i <= 2)&&(j <= 4)) || ((i > 4) && (daysArror[i - 1][j - 1] < 15))) {
                temTd.classed("no-data",true)
            } else {
                temTd.classed("no-data",false);
                temTd.attr('id', 'td' + daysArror[i - 1][j - 1]);
                temTd.on("click", function () {
                    if(date_picker_id != ""){
                        dayClick(this);
                    }
                })
            }
        }
    }
}
/**
 * 阻止事件冒泡。判断浏览器类型，ie向下冒泡，火狐向上冒泡
 * @param e
 */
function stopEvent(e) {
    if (e && e.stopPropagation)
        e.stopPropagation()
    else
        window.event.cancelBubble=true
    //e = e || window.event;
    //if (e && e.stopPropagation){
    //    e.stopPropagation();
    //} else {
    //    e.cancelBubble = true;
    //}
}


