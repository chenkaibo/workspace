/**
 * Created by zhigao.yang on 2017/1/19 0019.
 */

var dbOpt = require('../common/dbopt');
var api = require('../common/api');
var sysDbMgr = (function ()
{
    var _instantiated;
    function sysDbOpt()
    {
        var _dbOpt = new dbOpt();
        return{
            insertHeartbeatInfo : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlInsert = "INSERT INTO tbl_siteinfo(id, sitename, "+
                    "ip, port, type, clsnum, clsinfo, dfsnum,dfsinfo,"+
                    "firsttm,state,latesttm) VALUES ($1,$2,$3,$4,$5,$6,$7,"+
                    "$8,$9,$10,$11,$12);";
                var listValues = new Array();
                listValues[0] = values.id;
                listValues[1] = values.sitename;
                listValues[2] = values.ip;
                listValues[3] = values.port;
                listValues[4] = values.type;
                listValues[5] = values.clsnum;
                listValues[6] = values.clsinfo;
                listValues[7] = values.dfsnum;
                listValues[8] = values.dfsinfo;
                listValues[9] = values.firsttm;
                listValues[10] = values.state;
                listValues[11] = values.latesttm;

                _dbOpt.execSql(sqlInsert, listValues, function(error)
                {
                    callback(error);
                });

                return 1;
            },
            updateHeartbeatInfo : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "UPDATE tbl_siteinfo SET sitename = $1," +
                    "ip=$2,port=$3,type=$4,clsnum=$5,clsinfo=$6,"+
                    "dfsnum=$7,dfsinfo=$8,state=$9,latesttm=$10"
                    + "WHERE id = $11";

                var sqlValue = new Array();
                sqlValue[0] = values.sitename;
                sqlValue[1] = values.ip;
                sqlValue[2] = values.port;
                sqlValue[3] = values.type;
                sqlValue[4] = values.clsnum;
                sqlValue[5] = values.clsinfo;
                sqlValue[6] = values.dfsnum;
                sqlValue[7] = values.dfsinfo;
                //sqlValue[8] = values.firsttm;
                sqlValue[8] = values.state;
                sqlValue[9] = values.latesttm;
                sqlValue[10] = values.id;

                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            updateHeartbeatInfoState : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "update tbl_siteinfo set clsnum = $1,clsinfo = $2,dfsnum = $3,dfsinfo = $4,state = $5 where id = $6;";
                var sqlValue = new Array();
                sqlValue[0] = values.clsnum;
                sqlValue[1] = values.clsinfo;
                sqlValue[2] = values.dfsnum;
                sqlValue[3] = values.dfsinfo;
                sqlValue[4] = values.state;
                sqlValue[5] = values.id;

                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            deleteHeartbeatInfo: function(value, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "DELETE FROM tbl_siteinfo WHERE id = $1;";
                var sqlValue = [value];
                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            queryHeartbeatInfo : function(value, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "SELECT * FROM tbl_siteinfo WHERE id = $1;";
                var sqlValue = [value];

                _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
                {
                    if(error)
                    {
                        callback(error);
                        return;
                    }
                    if(count == 0){
                        callback(error,0,[]);
                        return;
                    }
                    callback(error,count,rst);
                });
            },
            queryAllHeartbeatInfo : function(callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "SELECT * FROM tbl_siteinfo;";
                var sqlValue = [];

                _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
                {
                    if(error)
                    {
                        callback(error);
                        return;
                    }
                    if(count == 0){
                        callback(error,[]);
                        return;
                    }
                    callback(error,count,rst);
                });
            },
            updateTableValue : function(tblName,field,fieldValue,cond,condValue,callback){
                var sqlText = "update " + tblName + " set " + field + " = $1 where " + cond + " = $2;";
                var sqlValue = [fieldValue,condValue];
                _dbOpt.execSql(sqlText,sqlValue,function(rst){
                    callback(rst);
                })
            },
            queryDbTableMgr : function(data, callback){
                if(typeof callback != "function"){
                    return 1;
                }
                _dbOpt.querySql(data.sqlText, data.sqlValue, function (error, count, rst) {
                    if (error) {
                        callback(true, error);
                        return;
                    }
                    if (count == 0) {
                        callback(false, []);
                        return;
                    }
                    callback(false, rst);
                });
            },
            updateDbTableMgr : function(data, callback){
                if(typeof callback != "function"){
                    return 1;
                }
                _dbOpt.execSql(data.sqlText, data.sqlValue, function (error) {
                    callback(error);
                });
            }
        };
    }

    return{
        getInstance: function ()
        {
            if (_instantiated === undefined)
            {
                _instantiated = new sysDbOpt();
            }
            return _instantiated;
        }
    };
})();
exports.sysDbMgr = sysDbMgr;

var instanceDbMgr = (function ()
{
    var _instantiated;
    function sysDbOpt()
    {
        var _dbOpt = new dbOpt();
        return{
            insertInstanceRecord : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlInsert = "INSERT INTO tbl_instance(id, clsname, aliasname,"+
                    "clspath, type, port, state, siteid, dfsid,voluname,"+
                    "version,inittm,updatetm,dfsurl,dfsdb) VALUES ($1,$2,$3,$4,$5,$6,$7,"+
                    "$8,$9,$10,$11,$12,$13,$14,$15);";
                var listValues = new Array();
                listValues[0] = values.id;
                listValues[1] = values.clsname;
                listValues[2] = values.clsname;
                listValues[3] = values.clspath;
                listValues[4] = values.type;
                listValues[5] = values.port;
                listValues[6] = values.state;
                listValues[7] = values.siteid;
                listValues[8] = values.dfsid;
                listValues[9] = values.voluname;
                listValues[10] = values.version;
                listValues[11] = values.inittm;
                listValues[12] = values.updatetm;
                listValues[13] = values.dfsurl;
                listValues[14] = values.dfsdb;

                _dbOpt.execSql(sqlInsert, listValues, function(error)
                {
                    callback(error);
                });

                return 1;
            },
            updateInstanceRecord : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "UPDATE tbl_instance SET clsname = $1," +
                    "clspath=$2,type=$3,port=$4,state=$5,siteid=$6,"+
                    "voluname=$7,version=$8,inittm=$9,updatetm=$10,dfsurl=$11,dfsdb=$12,dfsid=$13 WHERE id = $14;";
                var sqlValue = new Array();
                sqlValue[0] = values.clsname;
                sqlValue[1] = values.clspath;
                sqlValue[2] = values.type;
                sqlValue[3] = values.port;
                sqlValue[4] = values.state;
                sqlValue[5] = values.siteid;
                sqlValue[6] = values.voluname;
                sqlValue[7] = values.version;
                sqlValue[8] = values.inittm;
                sqlValue[9] = values.updatetm;
                sqlValue[10] = values.dfsurl;
                sqlValue[11] = values.dfsdb;
                sqlValue[12] = values.dfsid;
                sqlValue[13] = values.id;

                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            updateHeartbeatInfoState : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "UPDATE tbl_instance SET state = $1 WHERE id = $2";
                var sqlValue = new Array();
                sqlValue[0] = values.state;
                sqlValue[1] = values.id;

                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            deleteInstanceRecord : function(value, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "DELETE FROM tbl_instance WHERE id = $1;";
                var sqlValue = [value];
                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            queryInstanceRecord : function(value, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "SELECT * FROM tbl_instance WHERE id = $1;";
                var sqlValue = [value];

                _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
                {
                    if(error)
                    {
                        callback(error);
                        return;
                    }
                    if(count == 0){
                        callback(error,count,[]);
                        return;
                    }
                    callback(error,count,rst);
                });
            },
            queryAllInstanceRecord : function(callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "SELECT * FROM tbl_instance;";
                var sqlValue = [];

                _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
                {
                    if(error)
                    {
                        callback(error);
                        return;
                    }
                    if(count == 0){
                        callback(error,count,[]);
                        return;
                    }
                    callback(error,count,rst);
                });
            },

        };
    }

    return{
        getInstance: function ()
        {
            if (_instantiated === undefined)
            {
                _instantiated = new sysDbOpt();
            }
            return _instantiated;
        }
    };
})();
exports.instanceDbMgr = instanceDbMgr;


var dfsDbMgr = (function ()
{
    var _instantiated;
    function sysDbOpt()
    {
        var _dbOpt = new dbOpt();
        return{
            insertDfsRecord : function(values, callback)
            {
                if(typeof callback !== "function")
                {

                    return 0;
                }
                var sqlInsert = "INSERT INTO tbl_dfslist(id, dfsname,aliasname,"+
                    "dfspath, siteid, type, state, inittm, latesttm, mrcid"+
                    ") VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10);";
                var listValues = new Array();
                listValues[0] = values.id;
                listValues[1] = values.dfsname;
                listValues[2] = values.dfsname;
                listValues[3] = values.dfspath;
                listValues[4] = values.siteid;
                listValues[5] = values.type;
                listValues[6] = values.state;
                listValues[7] = values.inittm;
                listValues[8] = values.latesttm;
                listValues[9] = values.mrcid;

                _dbOpt.execSql(sqlInsert, listValues, function(error)
                {
                    callback(error);
                });

                return 1;
            },
            insertDirRecord : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlInsert = "INSERT INTO tbl_dirlist(id, dfsid,"+
                    "siteid, dirname, ip, port, state, dirid,maintype,"+
                    "cfgpath,inittm,latesttm,httpport) VALUES ($1,$2,$3,$4,$5,$6,"+
                    "$7,$8,$9,$10,$11,$12,$13);";
                var listValues = new Array();
                listValues[0] = values.id;
                listValues[1] = values.dfsid;
                listValues[2] = values.siteid;
                listValues[3] = values.dirname;
                listValues[4] = values.ip;
                listValues[5] = values.port;
                listValues[6] = values.state;
                listValues[7] = values.dirid;
                listValues[8] = values.maintype;
                listValues[9] = values.cfgpath;
                listValues[10] = values.inittm;
                listValues[11] = values.latesttm;
                listValues[12] = values.httpport;
                console.log("----------------"+JSON.stringify(listValues));
                _dbOpt.execSql(sqlInsert, listValues, function(error)
                {
                    callback(error);
                });

                return 1;
            },
            insertMrcRecord : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlInsert = "INSERT INTO tbl_mrclist(id, dfsid,siteid,"+
                    "mrcname, ip, port,state,dirip1,dirport1,dirip2,dirport2,"+
                    "dirip3,dirport3,dirip4,dirport4,dirip5,dirport5,dirip6,dirport6,"+
                    "maintype,cfgpath,inittm,latesttm,httpport) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,"+
                    "$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24);";
                var listValues = new Array();
                listValues[0] = values.id;
                listValues[1] = values.dfsid;
                listValues[2] = values.siteid;
                listValues[3] = values.mrcname;
                listValues[4] = values.ip;
                listValues[5] = values.port;
                listValues[6] = values.state;
                listValues[7] = values.dirip1;
                listValues[8] = values.dirport1;
                listValues[9] = values.dirip2;
                listValues[10] = values.dirport2;
                listValues[11] = values.dirip3;
                listValues[12] = values.dirport3;
                listValues[13] = values.dirip4;
                listValues[14] = values.dirport4;
                listValues[15] = values.dirip5;
                listValues[16] = values.dirport5;
                listValues[17] = values.dirip6;
                listValues[18] = values.dirport6;
                listValues[19] = values.maintype;
                listValues[20] = values.cfgpath;
                listValues[21] = values.inittm;
                listValues[22] = values.latesttm;
                listValues[23] = values.httpport;

                _dbOpt.execSql(sqlInsert, listValues, function(error)
                {
                    callback(error);
                });

                return 1;
            },
            insertOsdRecord : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlInsert = "INSERT INTO tbl_osdlist(id, dfsid,siteid,"+
                    "osdname, ip, port,state,dirip1,dirport1,dirip2,dirport2,"+
                    "dirip3,dirport3,dirip4,dirport4,dirip5,dirport5,dirip6,dirport6,"+
                    "maintype,cfgpath,inittm,latesttm,httpport) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,"+
                    "$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24);";
                var listValues = new Array();
                listValues[0] = values.id;
                listValues[1] = values.dfsid;
                listValues[2] = values.siteid;
                listValues[3] = values.osdname;
                listValues[4] = values.ip;
                listValues[5] = values.port;
                listValues[6] = values.state;
                listValues[7] = values.dirip1;
                listValues[8] = values.dirport1;
                listValues[9] = values.dirip2;
                listValues[10] = values.dirport2;
                listValues[11] = values.dirip3;
                listValues[12] = values.dirport3;
                listValues[13] = values.dirip4;
                listValues[14] = values.dirport4;
                listValues[15] = values.dirip5;
                listValues[16] = values.dirport5;
                listValues[17] = values.dirip6;
                listValues[18] = values.dirport6;
                listValues[19] = values.maintype;
                listValues[20] = values.cfgpath;
                listValues[21] = values.inittm;
                listValues[22] = values.latesttm;
                listValues[23] = values.httpport;

                _dbOpt.execSql(sqlInsert, listValues, function(error)
                {
                    callback(error);
                });

                return 1;
            },
            updateDfsRecord : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "UPDATE tbl_dfslist SET dfsname = $1," +
                    "dfspath=$2,siteid=$3,type=$4,state=$5,inittm=$6,latesttm=$7,mrcid=$8 "
                    + "WHERE id = $9";
                var sqlValue = new Array();
                sqlValue[0] = values.dfsname;
                sqlValue[1] = values.dfspath;
                sqlValue[2] = values.siteid;
                sqlValue[3] = values.type;
                sqlValue[4] = values.state;
                sqlValue[5] = values.inittm;
                sqlValue[6] = values.latesttm;
                sqlValue[7] = values.mrcid;
                sqlValue[8] = values.id;

                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            updateDirRecord : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "UPDATE tbl_dirlist SET dfsid = $1," +
                    "siteid=$2,dirname=$3,ip=$4,port=$5,state=$6,dirid=$7,"+
                    "maintype=$8,cfgpath=$9,inittm=$10,latesttm=$11,httpport=$12 WHERE id = $13;";
                var sqlValue = new Array();
                sqlValue[0] = values.dfsid;
                sqlValue[1] = values.siteid;
                sqlValue[2] = values.dirname;
                sqlValue[3] = values.ip;
                sqlValue[4] = values.port;
                sqlValue[5] = values.state;
                sqlValue[6] = values.dirid;
                sqlValue[7] = values.maintype;
                sqlValue[8] = values.cfgpath;
                sqlValue[9] = values.inittm;
                sqlValue[10] = values.latesttm;
                sqlValue[11] = values.httpport;
                sqlValue[12] = values.id;

                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            updateMrcRecord : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "UPDATE tbl_mrclist SET httpport=$1,siteid=$2,mrcname=$3,ip=$4,"+
                    "port=$5,state=$6,dirip1=$7,dirport1=$8,dirip2=$9,dirport2=$10,dirip3=$11,"+
                    "dirport3=$12,dirip4=$13,dirport4=$14,dirip5=$15,dirport5=$16,dirip6=$17,"+
                    "dirport6=$18,maintype=$19,cfgpath=$20,inittm=$21,latesttm=$22 WHERE id = $23;";

                var sqlValue = new Array();
                sqlValue[0] = values.httpport;
                sqlValue[1] = values.siteid;
                sqlValue[2] = values.mrcname;
                sqlValue[3] = values.ip;
                sqlValue[4] = values.port;
                sqlValue[5] = values.state;
                sqlValue[6] = values.dirip1;
                sqlValue[7] = values.dirport1;
                sqlValue[8] = values.dirip2;
                sqlValue[9] = values.dirport2;
                sqlValue[10] = values.dirip3;
                sqlValue[11] = values.dirport3;
                sqlValue[12] = values.dirip4;
                sqlValue[13] = values.dirport4;
                sqlValue[14] = values.dirip5;
                sqlValue[15] = values.dirport5;
                sqlValue[16] = values.dirip6;
                sqlValue[17] = values.dirport6;
                sqlValue[18] = values.maintype;
                sqlValue[19] = values.cfgpath;
                sqlValue[20] = values.inittm;
                sqlValue[21] = values.latesttm;
                sqlValue[22] = values.id;

                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            updateOsdRecord : function(values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }

                var sqlText = "UPDATE tbl_osdlist SET dfsid = $1," +
                    "siteid=$2,osdname=$3,ip=$4,port=$5,state=$6,dirip1=$7,"+
                    "dirport1=$8,dirip2=$9,dirport2=$10,dirip3=$11,dirport3=$12,"+
                    "dirip4=$13,dirport4=$14,dirip5=$15,dirport5=$16,dirip6=$17,"+
                    "dirport6=$18,maintype=$19,cfgpath=$20,inittm=$21,latesttm=$22," +
                    "httpport=$23 WHERE id = $24;";

                var sqlValue = new Array();
                sqlValue[0] = values.dfsid;
                sqlValue[1] = values.siteid;
                sqlValue[2] = values.osdname;
                sqlValue[3] = values.ip;
                sqlValue[4] = values.port;
                sqlValue[5] = values.state;
                sqlValue[6] = values.dirip1;
                sqlValue[7] = values.dirport1;
                sqlValue[8] = values.dirip2;
                sqlValue[9] = values.dirport2;
                sqlValue[10] = values.dirip3;
                sqlValue[11] = values.dirport3;
                sqlValue[12] = values.dirip4;
                sqlValue[13] = values.dirport4;
                sqlValue[14] = values.dirip5;
                sqlValue[15] = values.dirport5;
                sqlValue[16] = values.dirip6;
                sqlValue[17] = values.dirport6;
                sqlValue[18] = values.maintype;
                sqlValue[19] = values.cfgpath;
                sqlValue[20] = values.inittm;
                sqlValue[21] = values.latesttm;
                sqlValue[22] = values.httpport;
                sqlValue[23] = values.id;

                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            updateDfsState : function(table, filed, values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "UPDATE " + table + " SET state = $1 WHERE id = $2;";
                var sqlValue = new Array();
                sqlValue[0] = values.state;
                sqlValue[1] = values.id;

                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },

            updateFieldRecord : function(table, field, values, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "UPDATE "+ table + " SET "+ field + " = $1 WHERE id = $2;";
                var sqlValue = new Array();
                sqlValue[0] = values.dfsid;
                sqlValue[1] = values.id;


                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            deleteDfsRecord : function(value, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "DELETE FROM tbl_dfslist WHERE id = $1;";
                var sqlValue = [value];
                _dbOpt.execSql(sqlText,sqlValue,function(error)
                {
                    callback(error);
                });
                return 1;
            },
            queryRecord : function(table, field, value, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "SELECT * FROM "+ table +" WHERE " + field + " = $1;";

                var sqlValue = new Array();
                sqlValue[0] = value;

                _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
                {
                    if(error)
                    {
                        callback(error);
                        return;
                    }
                    if(count == 0){
                        callback(error,0,[]);
                        return;
                    }
                    callback(error, count, rst);
                });
            },
            queryAllRecord : function(table, callback)
            {
                if(typeof callback !== "function")
                {
                    return 0;
                }
                var sqlText = "SELECT * FROM "+ table + ";";
                var sqlValue = [];

                _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
                {
                    if(error)
                    {
                        callback(error);
                        return;
                    }
                    if(count == 0){
                        callback(error, 0, []);
                        return;
                    }
                    callback(error, count, rst);
                });
            },

        };
    }

    return{
        getInstance: function ()
        {
            if (_instantiated === undefined)
            {
                _instantiated = new sysDbOpt();
            }
            return _instantiated;
        }
    };
})();

exports.dfsDbMgr = dfsDbMgr;


















/*
 unit test
 */
if(0){
    if(0)
    {
        function insertDfsInfoTest()
        {
            var dfsListJson = {
                'id': 'asdfadsfadfadf',
                'dfsname':'111111',
                'dfspath':'/home/uxdb/ngdb',
                'siteid':0,
                'type':2,
                'state':1,
                'inittm':0,
                'latesttm':0
            }
            console.log("dfs list info error!");
            dfsListJson.inittm = new Date().toLocaleString();
            dfsListJson.latesttm = new Date().toLocaleString();
            dfsDbMgr.getInstance().insertDfsRecord(dfsListJson,function(error){
                if(error){
                    console.log("insert dfs info failed!");
                }else{
                    console.log("insert dfs info success!");
                }
            });
        }
    }

    if(0) {
        function updateDfsInfoTest() {
            var dfsListJson = {
                'id': 'asdfadsfadfadf',
                'dfsname': '2222',
                'dfspath': '/home/uxdb/',
                'siteid': 1,
                'type': 3,
                'state': 0,
                'inittm': 0,
                'latesttm': 0
            }
            console.log("dfs list info error!");
            dfsListJson.inittm = new Date().toLocaleString();
            dfsListJson.latesttm = new Date().toLocaleString();
            dfsDbMgr.getInstance().updateDfsRecord(dfsListJson, function (error) {
                if (error) {
                    console.log("update dfs info failed!")
                    console.log(error.detail);
                } else {
                    console.log("update dfs info success!");
                }
            })
        }
    }

    if(0)
    {
        function queryDfsInfoTest()
        {
            var table = "tbl_dfslist";
            var value = "asdfadsfadfadf";
            dfsDbMgr.getInstance().queryRecord(table, value, function(error,rst){
                if(error){
                    console.log("query dfs info failed!");
                    console.log(error.detail);
                }else{
                    console.log("query dfs info success!");
                    console.log("dfs info"+JSON.stringify(rst));
                }
            });
        }
    }

    if(0)
    {
        function delDfsRecordTest()
        {
            var dfsId = "asdfadsfadfadf";
            dfsDbMgr.getInstance().deleteDfsRecord(dfsId,function(error){
                if(error){
                    console.log("delete dfs record failed!");
                    console.log(error.detail);
                }else{
                    console.log("delete dfs record success!");
                }
            })
        }
    }

    //insertDfsInfoTest();
    //updateDfsInfoTest();
    //queryDfsInfoTest();
    //delDfsRecordTest();

    var instanceJson = {
        'id':'asdfasdfasdfasdf',
        'clsname':'sdfsdfsf',
        'clspath':'/home/uxdb/ngdb/',
        'type':3,
        'port':36000,
        'state':0,
        'siteid':'fffffffff',
        'dfsid':0,
        'voluname':'demo',
        'version':'v1.0.1',
        'inittm':'',
        'updatetm':''
    }

    instanceJson.inittm = new Date().toLocaleString();
    instanceJson.updatetm = new Date().toLocaleString();

    var updateInstanceJson = {
        'id':'asdfasdfasdfasdf',
        'clsname':'sfdfssf',
        'clspath':'/home/ngdb/',
        'type':3,
        'port':36000,
        'state':0,
        'siteid':'3333333ffffffff',
        'dfsid':'sf',
        'voluname':'demo',
        'version':'ver1.1',
        'inittm':'',
        'updatetm':''
    }

    updateInstanceJson.inittm = new Date().toLocaleString();
    updateInstanceJson.updatetm = new Date().toLocaleString();
    if(0)
    {
        function insertInstanceTest()
        {
            instanceDbMgr.getInstance().insertInstanceRecord(instanceJson,function(error){
                if(error){
                    console.log("insert instance info failed!");
                    console.log(error.detail);
                }else{
                    console.log("insert instance info success!");
                }
            });
        }
    }

    if(0)
    {
        function updateInstanceTest()
        {
            instanceDbMgr.getInstance().updateInstanceRecord(updateInstanceJson,function(error){
                if(error){
                    console.log("update instance info failed!");
                    console.log(error.detail);
                }else{
                    console.log("update instance info success!");
                }
            });
        }
    }

    if(0)
    {
        var value = "asdfasdfasdfasdf";
        instanceDbMgr.getInstance().queryInstanceRecord(value, function(error,count,rst){
            if(error){
                console.log("query instance info failed!");
                console.log(error.detail);
            }else{
                console.log("query instance info success!");
                console.log("dfs info"+JSON.stringify(rst));
            }
        });
    }

    //insertInstanceTest();
    //updateInstanceTest();
}

if(0)
{
    function updateDfsInfo(dfsJson, id){
        var dfsInfo = 'sfsfsdf';
        var dfsMd5 = api.createmd5(dfsInfo);
        var dfsListJson = {
            'id':dfsMd5,
            'dfsname':'aasdfaf',
            'dfspath':'/home/',
            'siteid':'asdf',
            'type':2,
            'state':1,
            'inittm':0,
            'latesttm':0
        }

        var d = new Date();
        var currentTm = d.getTime();
        dfsListJson.inittm = currentTm;
        dfsListJson.latesttm = currentTm;

        for(var i = 0; i < dfsJson.dir_modules.length; ++i)
        {
            var ipInfo = dfsJson.dir_modules[i].ip + ":"+ dfsJson.dir_modules[i].port;
            var dirMd5 = api.createmd5(ipInfo);
            var dirJson = {
                'id':dirMd5,
                'dfsid':'sf',
                'siteid':'sdf',
                'dirname':dfsJson.dir_modules[i].uuid,
                'ip':dfsJson.dir_modules[i].ip,
                'port':dfsJson.dir_modules[i].listen_port,
                'state':dfsJson.dir_modules[i].module_status,
                'dirid':'',
                'maintype':0,
                'cfgpath':dfsJson.dir_modules[i].config_file,
                'inittm':0,
                'latesttm':currentTm
            }
            var tableName = "tbl_dirlist";
            dfsDbMgr.getInstance().queryRecord(tableName,dirMd5,function(error,count, rst){
                if(error)
                {
                    console.log("query dir info error!");
                    console.log(error.detail);
                }

                if(0 == count)
                {
                    dfsDbMgr.getInstance().insertDirRecord(dirJson, function(error){
                        if(error)
                        {
                            console.log("insert dir info error!\n");
                        }
                    });
                }
                else
                {
                    dfsDbMgr.getInstance().updateDirRecord(dirJson, function(error){
                        if(error)
                        {
                            console.log("update dir info error!\n");
                            console.log(error.detail);
                        }
                    });
                }
            });
        }


        for(var j = 0; j < dfsJson.mrc_modules.length; ++j)
        {
            var ipInfo = dfsJson.mrc_modules[j].ip + ":"+ dfsJson.mrc_modules[j].port;
            var mrcMd5 = api.createmd5(ipInfo);
            var mrcJson = {
                'id':mrcMd5,
                'dfsid':0,
                'siteid':0,
                'mrcname':dfsJson.mrc_modules[j].uuid,
                'ip':dfsJson.mrc_modules[j].ip,
                'port':dfsJson.mrc_modules[j].listen_port,
                'state':dfsJson.mrc_modules[j].module_status,
                'dirip1':dfsJson.mrc_modules[j].ref_dir[0].ip,
                'dirport1':dfsJson.mrc_modules[j].ref_dir[0].port,
                'dirip2':dfsJson.mrc_modules[j].ref_dir[1].ip,
                'dirport2':dfsJson.mrc_modules[j].ref_dir[1].port,
                'dirip3':dfsJson.mrc_modules[j].ref_dir[2].ip,
                'dirport3':dfsJson.mrc_modules[j].ref_dir[2].port,
                'dirip4':dfsJson.mrc_modules[j].ref_dir[3].ip,
                'dirport4':dfsJson.mrc_modules[j].ref_dir[3].port,
                'dirip5':dfsJson.mrc_modules[j].ref_dir[4].ip,
                'dirport5':dfsJson.mrc_modules[j].ref_dir[4].port,
                'dirip6':dfsJson.mrc_modules[j].ref_dir[5].ip,
                'dirport6':dfsJson.mrc_modules[j].ref_dir[5].port,
                'maintype':0,
                'cfgpath':dfsJson.mrc_modules[j].config_file,
                'inittm':0,
                'latesttm':currentTm
            }

            dfsDbMgr.getInstance().queryRecord('tbl_mrclist',mrcMd5,function(error,count,rst){
                if(error)
                {
                    console.log("query mrc info error!");
                    console.log(error.detail);
                }

                if(0 == count)
                {
                    dfsDbMgr.getInstance().insertMrcRecord(mrcJson, function(error){
                        if(error)
                        {
                            console.log("insert mrc info error!");
                            console.log(error.detail);
                        }
                    });
                }
                else
                {
                    dfsDbMgr.getInstance().updateMrcRecord(mrcJson, function(error){
                       if(error)
                       {
                           console.log("update mrc info error!");
                           console.log(error.detail);
                       }
                    });
                }
            });
        }

        for(var k = 0; k < dfsJson.osd_modules.length; ++k)
        {
            var ipInfo = dfsJson.osd_modules[k].ip + ":"+ dfsJson.osd_modules[k].port;
            var osdMd5 = api.createmd5(ipInfo);

            var osdJson = {
                'id':osdMd5,
                'dfsid':0,
                'siteid':0,
                'osdname':dfsJson.osd_modules[k].uuid,
                'ip':dfsJson.osd_modules[k].ip,
                'port':dfsJson.osd_modules[k].listen_port,
                'state':dfsJson.osd_modules[k].module_status,
                'dirip1':dfsJson.osd_modules[k].ref_dir[0].ip,
                'dirport1':dfsJson.osd_modules[k].ref_dir[0].port,
                'dirip2':dfsJson.osd_modules[k].ref_dir[1].ip,
                'dirport2':dfsJson.osd_modules[k].ref_dir[1].port,
                'dirip3':dfsJson.osd_modules[k].ref_dir[2].ip,
                'dirport3':dfsJson.osd_modules[k].ref_dir[2].port,
                'dirip4':dfsJson.osd_modules[k].ref_dir[3].ip,
                'dirport4':dfsJson.osd_modules[k].ref_dir[3].port,
                'dirip5':dfsJson.osd_modules[k].ref_dir[4].ip,
                'dirport5':dfsJson.osd_modules[k].ref_dir[4].port,
                'dirip6':dfsJson.osd_modules[k].ref_dir[5].ip,
                'dirport6':dfsJson.osd_modules[k].ref_dir[5].port,
                'maintype':0,
                'cfgpath':dfsJson.mrc_modules[k].config_file,
                'inittm':0,
                'latesttm':currentTm
            }

            dfsDbMgr.getInstance().queryRecord('tbl_osdlist',osdMd5,function(error,count, rst){
                if(error)
                {
                    console.log("query osd info error!");
                    console.log(error.detail);
                }

                if(0 == count)
                {
                    dfsDbMgr.getInstance().insertOsdRecord(osdJson, function(error){
                        if(error)
                        {
                            console.log("insert osd info error!\n");
                            console.log(error.detail);
                        }
                    });
                }
                else
                {
                    dfsDbMgr.getInstance().updateOsdRecord(osdJson, function(error){
                        if(error)
                        {
                            console.log("update osd info error!\n");
                            console.log(error.detail);
                        }
                    });
                }
            });
        }
        var md = "asdfadsfadfadf";
        var table = "tbl_dfslist";
        dfsDbMgr.getInstance().queryRecord(table, dfsMd5, function(error,count,rst){
            if(error)
            {
                console.log("query dfs info error!");
                console.log(error.detail);
                console.log("query dfs info error end!");
            }
            console.log("dfs info:" +  JSON.stringify(rst));

            if(0 == count)
            {
                dfsDbMgr.getInstance().insertDfsRecord(dfsListJson, function(error){
                    if(error)
                    {
                        console.log("insert dfs info failed!\n");
                        console.log(error.detail);
                    }
                });
            }
            else if(1 == count)
            {
                dfsDbMgr.getInstance().updateDfsRecord(dfsListJson, function(error){

                    if(error)
                    {
                        console.log("update dfs info failed!\n");
                        console.log(error.detail);
                    }
                });
            }
            else
            {
                console.log("dfs info error!\n");
            }
        });
    }

    var dfsjson = {
        'dfs_name':'fasdf',
        'dfs_path':'/home/ixdb',
        'dir_modules':[{
            'ip':'192.168.1.220',
            'uuid':'sfsfsfs',
            'config_file':'dirconfig.properties',
            'listen_port':32638,
            'http_port':30638,
            'module_status':1,
            'ref_dir':[{'ip':'192.168.1.220','port':'32638'}]
        }],
        'mrc_modules':[{
            'ip':'192.168.1.220',
            'uuid':'sfsfsfs',
            'config_file':'mrcconfig.properties',
            'listen_port':32636,
            'http_port':30636,
            'module_status':1,
            'ref_dir':[{'ip':'192.168.1.220','port':'32638'},
                {'ip':'192.168.1.219','port':'32638'},
                {'ip':'192.168.1.218','port':'32638'},
                {'ip':'192.168.1.217','port':'32638'},
                {'ip':'192.168.1.216','port':'32638'},
                {'ip':'192.168.1.215','port':'32638'}]
        }],
        'osd_modules':[{
            'ip':'192.168.1.220',
            'uuid':'sfsfsfs',
            'config_file':'osdconfig.properties',
            'listen_port':32640,
            'http_port':30640,
            'module_status':1,
            'ref_dir':[{'ip':'192.168.1.220','port':'32638'},
                {'ip':'192.168.1.219','port':'32638'},
                {'ip':'192.168.1.218','port':'32638'},
                {'ip':'192.168.1.217','port':'32638'},
                {'ip':'192.168.1.216','port':'32638'},
                {'ip':'192.168.1.215','port':'32638'}]
        }]
    }
    var md5 = 'e8062152b97cf2d30751a04cbeba6f06';
    updateDfsInfo(dfsjson, md5);
}