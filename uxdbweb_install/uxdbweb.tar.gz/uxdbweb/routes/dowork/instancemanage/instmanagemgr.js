var protocolMgr = require('../../protocolunit/protocolmgr');
var myDbOpt = require('../../common/dbopt');
var dbmanageMgr = (function () {
    var _inst;
    var instmanageOpt = function () {
        return {
            enumInstListMgr: enumInstListMgr,
            queryInstanceMgr: queryInstanceMgr,
            getInstFromAgentMgr: getInstFromAgentMgr,
            enumDbListMgr: enumDbListMgr,
            optInstMgr: optInstMgr,
            updateDbTableMgr: updateDbTableMgr,
            queryDbTableMgr: queryDbTableMgr,
            execDbTableMgr: execDbTableMgr,
            createInstanceMgr: createInstanceMgr,
            getCreateInstStateMgr: getCreateInstStateMgr,
            deleteInstanceMgr: deleteInstanceMgr,
            updateDbByDetailInfoMgr: updateDbByDetailInfoMgr,
            getStateFromLocalDbMgr: getStateFromLocalDbMgr,
            getInstStateFromAgentMgr: getInstStateFromAgentMgr,
            getDFSStateFromAgentMgr: getDFSStateFromAgentMgr,
            getInstanceConfigListMgr: getInstanceConfigListMgr,
            setInstanceConfigMgr: setInstanceConfigMgr,
            modifyAliasnameMgr:modifyAliasnameMgr
        }
    }
    return {
        getInstance: function () {
            if (_inst === undefined) {
                _inst = new instmanageOpt();
            }
            return _inst;
        }
    }
})();
module.exports = dbmanageMgr;

function enumInstListMgr(reqDb, callback) {

    if (typeof callback !== "function") {
        return 0;
    }

    var sqlText = "SELECT * FROM tbl_instance ORDER BY clsname;";
    var sqlValue = [];
    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(sqlText, sqlValue, function (error, count, rst) {
        if (error) {
            callback(error);
            return;
        }
        if (count == 0) {
            callback(error, []);
            return;
        }
        callback(error, rst);
    });
    return 0;
}
function queryInstanceMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }
    var sqlText = "select * from tbl_instance where 1=1";
    var sqlValue = [];
    var num = 1;
    if (reqDb.insNameFlag == 1) {
        sqlText += " and clsname like $" + (num++);
        sqlValue.push("%" + reqDb.insName + "%");
    }
    if (reqDb.insTypeFlag == 1) {
        sqlText += " and type = $" + (num++);
        sqlValue.push(reqDb.insType);
    }
    if (reqDb.insStatusFlag == 1) {
        sqlText += " and state = $" + (num++);
        sqlValue.push(reqDb.insStatus);
    }
    if (reqDb.instIdFlag == 1) {
        sqlText += " and id = $" + (num++);
        sqlValue.push(reqDb.insId);
    }
    sqlText += " ORDER BY clsname;";
    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
        if (isErr) {
            callback(true);
            return;
        }
        if (count == 0) {
            callback(false, []);
            return;
        }
        callback(false, rst);
    })
}
function getInstFromAgentMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }
    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 1,
        'dbnum': 1,
        'data': reqDb.data
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}
function getInstStateFromAgentMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    //test data
    //var data = {
    //    dfsName:'dfsNameValue',
    //    dfsState:0,
    //    instState:0
    //}
    //callback(false,data);
    //return;


    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 5,
        'dbnum': 1,
        'data': reqDb.data
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}

function getDFSStateFromAgentMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    //test data
    //var data = {
    //    dfsName:'dfsNameValue',
    //    dfsState:0,
    //    instState:0
    //}
    //callback(false,data);
    //return;


    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 6,
        'dbnum': 1,
        'data': reqDb.data
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}

function createInstanceMgr(reqDb, callback) {

    //unit test
    //var obj = {
    //    data: {
    //        retcode: 0
    //    }
    //}
    //callback(false, obj);
    //return;

    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 3,
        'subcmd': 5,
        'dbnum': 1,
        'data': reqDb.data
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        callback(isErr, resJson);
    });
    return 0;
}
function getCreateInstStateMgr(reqDb, callback) {

    //unit test
    //var obj = {
    //    data: {
    //        retcode: 0,
    //        progress: []
    //    }
    //}
    //for(var i=0;i<20;i++){
    //    var str = "helloworld" + i;
    //    obj.data.progress.push(str);
    //}
    //callback(false, obj);
    //return;

    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 9,
        'dbnum': 1,
        'data': reqDb.data
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}
function deleteInstanceMgr(reqDb, callback) {
    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 3,
        'subcmd': 11,
        'dbnum': 1,
        'data': reqDb.data
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}

function getInstanceConfigListMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    //test data
    //var resJson = {
    //    retcode: 0,
    //    dfsurl: "testdfsurl",
    //    dfsdb: "testdfsdb",
    //    cfgname: "testcfgname",
    //    tarray: []
    //}
    //var num = 0;
    //for (var i = 0; i < 5; i++) {
    //    var dataObj = {};
    //    dataObj.pclass = "testpclass" + i;
    //    dataObj.parray = [];
    //    for (var j = 0; j < 2; j++) {
    //        num++;
    //        var dataObj2 = {
    //            pname: "testname" + num,
    //            pvalue: "testvalue" + num,
    //            description: "testscription" + num,
    //            ismodify: "testismodify" + num,
    //            ptype: "testtype" + num,
    //            vlist: ["on", "off", "partition"],
    //        };
    //        dataObj.parray.push(dataObj2);
    //    }
    //    resJson.tarray.push(dataObj);
    //}
    //var obj = {data: resJson};
    //callback(false, obj);
    //return;

    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 10,
        'dbnum': 1,
        'data': reqDb.data
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}
function setInstanceConfigMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    //test data
    //var resJson = {
    //    data: {
    //        retcode: 0,
    //    }
    //}
    //callback(false, resJson);
    //return;

    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 3,
        'subcmd': 13,
        'dbnum': 1,
        'data': reqDb.data
    }

    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}

function enumDbListMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    //test data
    //var dataJson = [];
    //for(var i=0;i<10;i++){
    //    var dataValue = {};
    //    dataValue.dbname = "uxdb"+i;
    //    dataJson.push(dataValue);
    //}
    //callback(false,dataJson);
    //return;

    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 8,
        'dbnum': 1,
        'data': reqDb.data
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}
function optInstMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    //test data
    //var dataObj = {
    //    data:{
    //        DFSStatus:1,
    //        instanStatus:reqDb.opertype
    //    }
    //}
    //callback(false,dataObj);
    //return;

    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 3,
        'subcmd': (reqDb.opertype == 1 ? 1 : 2), //1:开启实例，2关闭实例
        'dbnum': 1,
        'data': reqDb.data
    }
    console.log("send cmd:" + JSON.stringify(reqJson));
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}

function updateDbTableMgr(data, callback) {
    if (typeof callback !== "function") {
        return 0;
    }
    var _dbOpt = new myDbOpt();
    _dbOpt.execSql(data.sqlText, data.sqlValue, function (error) {
        if (error) {
            callback(error);
            return;
        }
        callback(false);
    });
    return 0;
}
function updateDbByDetailInfoMgr(tableName, field, condField, dataValue, callback) {
    if (typeof callback !== "function") {
        return 0;
    }
    var sqlText = "update " + tableName + " set " + field + " = $1 where " + condField + " = $2;";
    var sqlValue = dataValue;
    var _dbOpt = new myDbOpt();
    _dbOpt.execSql(sqlText, sqlValue, function (error) {
        if (error) {
            callback(error);
            return;
        }
        callback(false);
    });
    return 1;
}

function queryDbTableMgr(data, callback) {
    if (typeof callback !== "function") {
        return 0;
    }
    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(data.sqlText, data.sqlValue, function (error, count, rst) {
        if (error) {
            callback(true, error);
            return;
        }
        if (count == 0) {
            callback(false, []);
            return;
        }
        callback(false, rst);
    });
    return 0;
}
function execDbTableMgr(data, callback) {
    if (typeof callback !== "function") {
        return 0;
    }
    var _dbOpt = new myDbOpt();
    _dbOpt.execSql(data.sqlText, data.sqlValue, function (error, rst) {
        if (error) {
            callback(true, error);
            return;
        }
        callback(false);
    });
    return 0;
}

function getStateFromLocalDbMgr(reqDb, callback) {
    if (typeof callback !== "function") {
        return 0;
    }
    var sqlText, sqlValue;
    if (reqDb.data.type == 1) {  //local instance
        sqlText = "select state as inststate from tbl_instance where id = $1;";
    } else {
        sqlText = "select a.state as inststate,b.state as dfsstate,b.aliasname,b.dfspath from tbl_instance a inner join tbl_dfslist b on a.dfsid=b.id where a.id = $1;";
    }
    sqlValue = [reqDb.data.instid];

    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(sqlText, sqlValue, function (error, count, rst) {
        if (error || count == 0) {
            callback(true);
            return;
        }
        callback(false, rst);
    });
    return 0;
}
function modifyAliasnameMgr(reqDb,callback) {
    if (typeof callback !== "function"){
        return 0;
    };
    var sqlData={
        sqlText : "update tbl_instance set aliasname=$1 where id=$2 ",
        sqlValue : [reqDb.aliasname,reqDb.instid]
    };
    var _dbOpt = new myDbOpt();
    _dbOpt.execSql(sqlData.sqlText,sqlData.sqlValue,function (error) {
        if (error) {
            callback(true);
            return;
        }
        callback(false);
    });
}