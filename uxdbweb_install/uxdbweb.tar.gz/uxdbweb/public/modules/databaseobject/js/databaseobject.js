'use strict';
window.onload = function ()
{
    //window.parent.menuOperFun();
    top.d3.select("#leftDivId").classed("no-display",false);
    dataBaseObjectElem("#dataBaseObjId");
};
/*
* 获取界面元素
* */
var ownerArray,modIndex;
function dataBaseObjectElem(contain)
{
    window.focus();
    window.sessionStorage.ux_pagePath = "databaseobject,main";
    changePath("数据库管理->数据库对象->数据库:" + window.sessionStorage.ux_currentChoiceDataName + "");
    d3.select("#mainContainDiv").remove();
    var dbObjElem = d3.select(contain)
        .append("div")
        .attr({
            'id':'mainContainDiv',
            'class':'siteList-content db-manage-div'
        });
    dbObjElem.append("div")
        .attr({
            'id':'toolbar',
            'class':'toolbar box'
        });

    //d3.select(".siteList-content #toolbar")
    dbObjElem.select("#toolbar").append("button")
        .attr({
            'id':'newDatabaseBtn',
            'class':'btn btn-default admitClick bounceIn disabledElem'
        })
        .on("click",function(){
            d3.select(this).classed("admitClick",false);
            reqOwnerData();
            createDatabaseElem();
        })
        .html("新&nbsp;&nbsp;建");
    dbObjElem.select("#toolbar")
        .append("button")
        .attr({
            'id':'delDatabaseInfo',
            'class':'disabledElem delBtnClass',
            'disabled':'disabled',
            'onClick':'delDataBaseInfo()'
        })
        .html("删&nbsp;&nbsp;除");
    var operTypeSelect = dbObjElem.select("#toolbar")
        .append("select")
        .attr({
            'class':'select-type',
            'id':'opterSelectItem'
        });
    var optionItem = ['操作类型','Analysis','Clean-up','RebuildIndex','Rename'];
    for(var k = 0;k < optionItem.length; k++)
    {
        if(k == 0)
        {
            operTypeSelect.append("option")
                .attr({
                    'name':optionItem[k],
                    'selected':'selected',
                    'class':'title-option option-all title-flag'
                })
                .html(optionItem[k]);
        }else{
            operTypeSelect.append("option")
                .attr({
                    'class':'option-all option-data-item',
                    'name':optionItem[k]
                })
                .html(optionItem[k]);
        }

    }
    d3.selectAll('.option-data-item')[0][2].disabled = true;
    d3.selectAll('.option-data-item')[0][3].disabled = true;
    d3.selectAll('.option-data-item').classed("select-disabled",function(d,i){return ((i == 2 || i == 3) ? (true):(false))});
    dbObjElem.select("#toolbar")
        .append("button")
        .attr({
            "class":"btn admitClick",
            //'disabled':'disabled',
            "id":"executeBtnId"
        })
        .on("click",function(){
            var opterStr = d3.select("#opterSelectItem")[0][0].value;
            d3.select("#executeBtnId").classed("admitClick",false);
            if(opterStr == "操作类型")
            {
                d3.select("#executeBtnId").classed("admitClick",true);
                uxAlert("请正确选择需要执行的操作！");
                return;
            }
            executeOper(opterStr);
        })
        .html("执&nbsp;&nbsp;行");
    dbObjElem
        .append("div")
        .attr("id","dataBaseQuery");
    d3.select("#dataBaseQuery").append("span")
        .html("数据库名：");
    d3.select("#dataBaseQuery").append("input")
        .attr("id","queryDatabaseName")
        .style("color","#57D1F7");
    d3.select("#dataBaseQuery").append("button")
        .attr("class","searchSite-btn searchSite btn btn-bg-color")
        .on("click",function(){
            queryDatabaseObj();
        });
    dbObjElem
        .append("div")
        .attr("class","database-table-div")
        .append("table")
        .attr("id","databaseTableId")
        .attr("color","#57D1F7");
    reqInitTableData();
}
/****************************执行操作函数处理区***********************************/
function executeOper(opterStr)
{
    switch (opterStr)
    {
        case "Analysis":analysisFun();break;
        case "Clean-up":clearUpFun();break;
        case "RebuildIndex":rebuildIndexFun();break;
        //case "RightsManager":rightsManageFun();break;
        case "Rename": renameFun();break;
        default :break;
    }
}
function clearUpFun()
{
    var className;
    //var ids = getIdSelections("databaseTableId");
    clearUpFunElem("#mainContainDiv",window.sessionStorage.ux_currentChoiceDataName);
    if(d3.select("#dialogClear").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgClear').fadeIn(300);
    $('#dialogClear').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function clearUpFunElem(contain,databaseName)
{
    d3.select("#dialogBgClear").remove();
    d3.select("#dialogClear").remove();
    var pupUpItem = "Clean-up数据库";
    d3.select(contain).append("div")
        .attr("id","dialogBgClear");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogClear");
    var editFrom = outPage.append("div")
        .attr("id","clearFromDatabase");
    editFrom.append("span")
        .attr({
            "class":"clear-database-title"
        })
        .html(pupUpItem);
    editFrom.append("span")
        .attr({
            "id":"clearItemSpanDatabase",
            "class":"databaseTitle"
        })
        .html(databaseName);
    var selectTypeDiv = d3.select("#dialogClear").append("div").attr({"class":"select-oper-type"});
    selectTypeDiv.append("span")
        .attr({
            "class":"clear-database-span"
        })
        .html("请选择类型：");
    var choiceElem = selectTypeDiv.append("select")
        .attr({
            'id':'clearUpSelect',
            'class':'ipt encodeSelectStye oper-type-item'
        });
    var choiceTypeItem = ['FULL','FREEZE','FULL FREEZE'];
    for(var k = 0;k <choiceTypeItem.length; k++)
    {
        choiceElem.append("option")
            .html(choiceTypeItem[k]);
    }
    var editFromDivBtn = d3.select("#dialogClear").append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop clear-up-btn-div")
        .append("button")
        .on("click",function(){
            uxConfirm("是否确认执行该操作？",function(rst){
                if(rst)
                {
                    clearUpDealFun();
                }else{
                    d3.select("#dialogClear").classed("bounceIn",false);
                    $('#dialogBgClear').fadeOut(300,function(){
                        $('#dialogClear').addClass('bounceOutUp').fadeOut();
                    });
                    d3.select("#executeBtnId").classed("admitClick",true);
                    //d3.select("#getDatabaseBtnId").classed("admitClick",true);
                }
            });
        })
        .attr("class","btn btn-default admitClick")
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnDatabase")
        .on("click",function(){
            d3.select("#dialogClear").classed("bounceIn",false);
            $('#dialogBgClear').fadeOut(300,function(){
                $('#dialogClear').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#executeBtnId").classed("admitClick",true);
        })
        .html("取&nbsp;&nbsp;消");
}
function clearUpDealFun()
{
    var CleanupOperStr  = trim(d3.select("#clearUpSelect")[0][0].value);
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"exceDatabaseOp","subRequest":"","ssubRequest":""},
        data    :{
            webusername: window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname:window.sessionStorage.ux_currentChoiceDataName,
            opType:"Clean-up",
            Cleanup:CleanupOperStr,
            reidxDbName :"",
            oldDbName:"",
            newDbName:""
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_databaseObjInterface.ajaxRequest(false,jsonDataStr,exceDatabaseOperCallback);
}
function exceDatabaseOperCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        reqInitTableData();
        var selectItem = d3.select("#opterSelectItem");
        selectItem[0][0].selectedIndex = 0;
        selectItem[0][0].options[selectItem[0][0].selectedIndex].innerHTML = "操作类型";
        d3.selectAll('.option-data-item')[0][2].disabled = true;
        d3.selectAll('.option-data-item')[0][3].disabled = true;
        d3.selectAll('.option-data-item').classed("select-disabled",function(d,i){return ((i == 2 || i == 3) ? (true):(false))});
        uxAlert("执行操作成功！");
    }else{
        uxAlert("执行操作失败！");
    }
    d3.select("#dialogClear").classed("bounceIn",false);
    $('#dialogBgClear').fadeOut(300,function(){
        $('#dialogClear').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#executeBtnId").classed("admitClick",true);
}
function renameFun()
{
    var className;
    var ids = getIdSelections("databaseTableId");
    renameFunElem("#mainContainDiv",ids[0].name);
    if(d3.select("#dialogClear").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgClear').fadeIn(300);
    $('#dialogClear').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function renameFunElem(contain,databaseName)
{
    d3.select("#dialogBgClear").remove();
    d3.select("#dialogClear").remove();
    var pupUpItem = "Rename数据库";
    d3.select(contain).append("div")
        .attr("id","dialogBgClear");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogClear");
    var editFrom = outPage.append("div")
        .attr("id","clearFromDatabase");
    editFrom.append("span")
        .attr({
            "class":"clear-database-title"
        })
        .html(pupUpItem);
    editFrom.append("span")
        .attr({
            "id":"renameItemSpanDatabase",
            "class":"databaseTitle"
        })
        .html(databaseName);
    var selectTypeDiv = d3.select("#dialogClear").append("div").attr({"class":"select-oper-type"});
    selectTypeDiv.append("span")
        .attr({
            "class":"clear-database-span"
        })
        .html("请输入数据库名：");
    selectTypeDiv.append("input")
        .attr({
            'id':'newDataName',
            'class':'ipt rename-database',
            'placeholder':'字母开头、特殊字符，长度不超过64！'
        })
        .on("blur",function(){
            var nameValue = d3.select(this)[0][0].value;
            if(instanceName(nameValue) && nameValue.length < 65 && nameValue.length > 0)
            {
                d3.select(this)[0][0].nextSibling.innerHTML = "";
            }else{
                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='error-rename-tip'>字母开头，特殊字符可以包括下划线，长度不超过64！</span>";
            }
        });
    selectTypeDiv.append("span").attr({
        'id':'errorSpan' + 0
    });
    var editFromDivBtn = d3.select("#dialogClear").append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop rename-btn-div")
        .append("button")
        //.attr("id","sureBtnDatabase")
        .on("click",function(){
            var nameValue = d3.select(this)[0][0].value;
            var flag = false;
            if(instanceName(nameValue) && nameValue.length < 65 && nameValue.length > 0 && nameValue != "")
            {
                flag = true;
            }else{
                flag = false;
            }
            if(!flag)
            {
                uxAlert("请输入正确的数据库名信息！");
                return;
            }
            uxConfirm("是否确认执行该操作？",function(rst){
                if(rst)
                {
                    renameDealFun();
                }else{
                    d3.select("#dialogClear").classed("bounceIn",false);
                    $('#dialogBgClear').fadeOut(300,function(){
                        $('#dialogClear').addClass('bounceOutUp').fadeOut();
                    });
                    d3.select("#executeBtnId").classed("admitClick",true);
                }
            });
        })
        .attr("class","btn btn-default admitClick")
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnDatabase")
        .on("click",function(){
            d3.select("#dialogClear").classed("bounceIn",false);
            $('#dialogBgClear').fadeOut(300,function(){
                $('#dialogClear').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#executeBtnId").classed("admitClick",true);
        })
        .html("取&nbsp;&nbsp;消");
}
function renameDealFun()
{
    var oldDbName  = d3.select("#renameItemSpanDatabase")[0][0].innerHTML;
    var newDbName  = trim(d3.select("#newDataName")[0][0].value);
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"exceDatabaseOp","subRequest":"","ssubRequest":""},
        data    :{
            webusername: window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname:window.sessionStorage.ux_currentChoiceDataName,
            opType:"Rename",
            Cleanup:"",
            reidxDbName :"",
            oldDbName:oldDbName,
            newDbName:newDbName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_databaseObjInterface.ajaxRequest(false,jsonDataStr,exceDatabaseOperCallback);
}
function analysisFun()
{
    uxConfirm("是否确认执行该操作？",function(rst){
        if(rst)
        {
            analysisDealFun();
        }else{
            d3.select("#dialogClear").classed("bounceIn",false);
            $('#dialogBgClear').fadeOut(300,function(){
                $('#dialogClear').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#executeBtnId").classed("admitClick",true);
        }
    });
}
function analysisDealFun()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"exceDatabaseOp","subRequest":"","ssubRequest":""},
        data    :{
            webusername: window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname:window.sessionStorage.ux_currentChoiceDataName,
            opType:"Analysis",
            Cleanup:"",
            reidxDbName :"",
            oldDbName:"",
            newDbName:""
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_databaseObjInterface.ajaxRequest(false,jsonDataStr,exceDatabaseOperCallback);
}
function rebuildIndexFun()
{
    uxConfirm("是否确认执行该操作？",function(rst){
        if(rst)
        {
            rebuildIndexDealFun();
            d3.select("#executeBtnId").classed("admitClick",true);
        }else{
            d3.select("#dialogClear").classed("bounceIn",false);
            $('#dialogBgClear').fadeOut(300,function(){
                $('#dialogClear').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#executeBtnId").classed("admitClick",true);
        }
    });
}
function rebuildIndexDealFun()
{
    var ids = getIdSelections("databaseTableId");
    var databaseName = ids[0].name;
    if(databaseName != trim(window.sessionStorage.ux_currentChoiceDataName))
    {
        uxAlert("该操作只针对于当前连接数据库，请重新选择！");
        d3.select("#executeBtnId").classed("admitClick",true);
        return;
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"exceDatabaseOp","subRequest":"","ssubRequest":""},
        data    :{
            webusername: window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname:window.sessionStorage.ux_currentChoiceDataName,
            opType:"RebuildIndex",
            Cleanup:"",
            reidxDbName :databaseName,
            oldDbName:"",
            newDbName:""
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_databaseObjInterface.ajaxRequest(false,jsonDataStr,exceDatabaseOperCallback);
}
/******************************数据库表格实现************************************/
function initDatabaseTable()
{
    var par = [{field: 'checkBox' , radio: true ,align: 'center' },
        {field: 'index' ,title: '序&nbsp;&nbsp;&nbsp;&nbsp;号' ,align: 'center',formatter:function(value,row,index){
            return (index + 1);
        }},
        {field: 'name' ,title: '数据库名' ,align: 'center'},
        {field: 'encoding' ,title: '编&nbsp;&nbsp;&nbsp;&nbsp;码' ,align: 'center' },
        //{field: 'patternId' , title: '模式ID' ,align: 'center' },
        {field: 'owner' , title: '所有者' ,align: 'center' },
        {field: 'operate' , title: '操&nbsp;&nbsp作' ,align: 'center' , formatter:function(value,row,index){
            var par = row.name + ","+row.owner+ ","+row.encoding+"," + index;
            var modifUserPwdOper = '<a title = "修改">' + '<button id = "modifBtn'+ index +'" class = "modifPsw bounceIn" onclick = "modfiDatabaseInfo(\''+ par+ '\')"'+'></button>' + '</a>';
            return modifUserPwdOper;
        }}
    ];
    $('#databaseTableId').bootstrapTable({
        classes:"table table-no-bordered",
        //toolbar:"#toolbar",
        height:606,
        columns: par,
        idField:"index",
    });
}
function reqInitTableData()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"getAllDatabaseList","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_databaseObjInterface.ajaxRequest(false,jsonDataStr,reqInitTableDataCallback);
}
function reqInitTableDataCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        initDatabaseTable();
        listenDataBaseObjTable();
        var selectItem = d3.select("#opterSelectItem");
        selectItem[0][0].selectedIndex = 0;
        selectItem[0][0].options[selectItem[0][0].selectedIndex].innerHTML = "操作类型";
        d3.selectAll('.option-data-item')[0][2].disabled = true;
        d3.selectAll('.option-data-item')[0][3].disabled = true;
        d3.selectAll('.option-data-item').classed("select-disabled",function(d,i){return ((i == 2 || i == 3) ? (true):(false))});
        d3.select('#delDatabaseInfo').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
        $("#databaseTableId").bootstrapTable('load',retJsonStr.data);
    }else{
        if(retJsonStr.desc == "connect_out")
        {
            uxAlert("数据库已断开，请重新连接！",true);
        }else{
            uxAlert("数据库对象获取失败！");
        }
    }
}
/******************************新建数据库**************************************/
function createDatabaseElem()
{
    var className;
    createDatabaseDataInfoElem("#mainContainDiv");
    d3.select("#sureBtnDatabase").attr({'onclick':'createDatabaseFun()'});
    if(d3.select("#dialogDatabase").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgDatabase').fadeIn(300);
    $('#dialogDatabase').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function createDatabaseDataInfoElem(contain)
{
    d3.select("#dialogBgDatabase").remove();
    d3.select("#dialogDatabase").remove();
    d3.select("#dialogBgModDatabase").remove();
    d3.select("#dialogModDatabase").remove();
    var pupUpItem = "新建数据库";
    var popUpInputArray = ["数据库名","编&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码","所&nbsp;&nbsp;有&nbsp;&nbsp;者"];
    d3.select(contain).append("div")
        .attr("id","dialogBgDatabase");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogDatabase");
    var editFrom = outPage.append("div")
        .attr("id","editFromDatabase");
     editFrom.append("span")
        .attr({
            "id":"ItemSpanDatabase",
            "class":"databaseTitle"
        })
        .html(pupUpItem);
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos");
    for(var i = 0;i < popUpInputArray.length;i++)
    {
        var editFromLi = editFormUl.append("li")
            .attr({
                "class":"editUl",
                "id":"editUlId" + i
            });
        editFromLi.append("label").append("span")
            .attr("class","editFromLiSpan")
            .html(popUpInputArray[i]);
        if(i == 0)
        {
            editFromLi.append("input").attr({
                'class':'ipt',
                'id':'input' + i,
                'type':'text',
                'placeholder':'字母开头、特殊字符，长度不超过64！'
              })
                .on("blur",function(){
                var nameValue = d3.select(this)[0][0].value;
                if(instanceName(nameValue) && nameValue.length < 65 && nameValue.length > 0)
                {
                    d3.select(this)[0][0].nextSibling.innerHTML = "";
                }else{
                    d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>字母开头，特殊字符可以包括下划线，长度不超过64！</span>";
                }
            });
        }else if(i == 2){
            var ownerOptionElem = editFromLi.append("select")
                .attr({
                    'id':"input" + i,
                    'class':'encodeSelectStye owner-select-class'
                });
            for(var k = 0;k<ownerArray.length; k++)
            {
                ownerOptionElem.append("option")
                    .html(ownerArray[k].username)
            }
        }else{
            d3.json("../common/js/encoding.json",function(error,json){
                if(error)
                {
                    uxAlert("编码文件读取失败！");
                }else{
                    var selectEncode = d3.select("#editUlId1").append("select")
                        .attr({
                            "id":"encodeSelect",
                            "class":'encodeSelectStye'
                        });
                    for(var k = 0;k < json.encodeData.length; k++)
                    {
                        selectEncode.append("option")
                            .attr({
                                "id":'encodeOption' + k
                            })
                            .html(json.encodeData[k].encodeText);
                    }
                }
            })
        }
    }
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop dialog-btn-div")
        .append("button")
        .attr("id","sureBtnDatabase")
        .attr("class","btn btn-default admitClick")// nextBtn
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnDatabase")
        .on("click",function(){
            d3.select("#dialogDatabase").classed("bounceIn",false);
            $('#dialogBgDatabase').fadeOut(300,function(){
                $('#dialogDatabase').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#newDatabaseBtn").classed("admitClick",true);
        })
        .html("取&nbsp;&nbsp;消");
}
function createDatabaseFun()
{
    var dbnewName = d3.select("#input0")[0][0].value;
    var owner = d3.select("#input2")[0][0].value;
    var encod = d3.select("#encodeSelect")[0][0].value;
    var encoding = encod.substring(encod.indexOf("（") + 1,encod.indexOf("）"));
    var isSureFlag;
    if(instanceName(dbnewName) && dbnewName.length < 65 && dbnewName.length > 0)
    {
        isSureFlag = true;
    }else{
        isSureFlag = false;
    }
    if(!isSureFlag)
    {
       uxAlert("请正确输入新建的数据库信息！");
        return;
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"createDatabase","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            owner : owner,
            dbnewName : dbnewName,
            encoding : encoding
    }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_databaseObjInterface.ajaxRequest(false,jsonDataStr,createDatabaseFunCallback);
}
function createDatabaseFunCallback(retJson)
{
   var retJsonStr = JSON.parse(retJson);
   if(retJsonStr.rstcode == "success")
   {
       reqInitTableData();
       uxAlert("新建数据库成功！");
   }else{
       uxAlert("新建数据库失败！");
   }
    d3.select("#dialogDatabase").classed("bounceIn",false);
    $('#dialogBgDatabase').fadeOut(300,function(){
        $('#dialogDatabase').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#newDatabaseBtn").classed("admitClick",true);
    d3.select("#newDatabaseBtn").classed("admitClick",true);
}
/*****************************删除操作***************************************/
function delDataBaseInfo()
{
    d3.select("#delDatabaseInfo").classed("admitClick",false);
    uxConfirm("是否确认删除该数据库？",function(rst)
    {
        //点击取消
        if(!rst)
        {
            d3.select("#delDatabaseInfo").classed("admitClick",true);
            return;
        }
        var ids = getIdSelections("databaseTableId");
        var jsonDataObj = {
            ip      :"",
            port    :"",
            router  :"dbopt",
            request :{"mainRequest":"deleteDatabase","subRequest":"","ssubRequest":""},
            data    :{
                webusername : window.sessionStorage.ux_curUserName,
                instid : window.sessionStorage.ux_currentChoiceInsId,
                dbname : window.sessionStorage.ux_currentChoiceDataName,
                delDbName : ids[0].name
            }
        };
        var jsonDataStr = JSON.stringify(jsonDataObj);
        ux_databaseObjInterface.ajaxRequest(false,jsonDataStr,delDataBaseInfoCallback);
    });
}
function delDataBaseInfoCallback(retJson)
{
   var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        reqInitTableData();
        changeButtonStatus("databaseTableId","delDatabaseInfo");
        uxAlert("删除数据库成功！");
    }else{
        uxAlert("删除数据库失败！");
        d3.select("#delDatabaseInfo").classed("admitClick",true);
    }
}
/*****************************查询操作*****************************************/
function queryDatabaseObj()
{
    var searchName = trim(d3.select("#queryDatabaseName")[0][0].value);
    if(searchName == "")
    {
        reqInitTableData();
        return;
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"searchDatabaseInfo","subRequest":"","ssubRequest":""},
        data    :{
            webusername: window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            searchName:searchName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_databaseObjInterface.ajaxRequest(false,jsonDataStr,queryDatabaseObjCallback);
}
function queryDatabaseObjCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        var data = getNewQueryData(JSON.parse(retJsonStr.data));
        $("#databaseTableId").bootstrapTable('load',data);
    }else{
        if(retJsonStr.desc == "connect_out")
        {
            uxAlert("数据库已断开，请重新连接！",true);
        }else{
            uxAlert("数据库对象查询失败！");
        }
    }
}
function getNewQueryData(retJsonData)
{
    var retJson = [];
    for(var k = 0;k<retJsonData.length; k++)
    {
        var info = {};
        info.name = retJsonData[k].name;
        info.owner = retJsonData[k].owner;
        info.encoding = retJsonData[k].encoding;
        retJson.push(info);
    }
    return retJson;
}
/****************************修改操作****************************************/
function modfiDatabaseInfo(str)
{
    reqOwnerData();
    var className;
    var itemArray = str.split(",");
    var selectDataName = itemArray[0];
    modIndex = parseInt(itemArray[3]);
    d3.select("#modifBtn" + modIndex).classed("modifPsw-white",true);
    modifDatabaseInfoElem("#mainContainDiv",selectDataName,itemArray[1],itemArray[2]);
    d3.select("#dialogModDatabase").style("height","310px");
    if(d3.select("#dialogModDatabase").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgModDatabase').fadeIn(300);
    $('#dialogModDatabase').removeAttr('class').addClass('animated '+className+'').fadeIn();
}
function modifDatabaseInfoElem(contain,modDatabaseName,owner,encode)
{
    d3.select("#dialogBgDatabase").remove();
    d3.select("#dialogDatabase").remove();
    d3.select("#dialogBgModDatabase").remove();
    d3.select("#dialogModDatabase").remove();
    var pupUpItem = "修改数据库";
    var popUpInputArray = ["数据库名","编&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码","所&nbsp;&nbsp;有&nbsp;&nbsp;者"];
    d3.select(contain).append("div")
        .attr("id","dialogBgModDatabase");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogModDatabase");
    var editFrom = outPage.append("div")
        .attr("id","editFromDatabase");
    editFrom.append("span")
        .attr({
            "class":"databaseTitle"
        })
        .html(pupUpItem);
    editFrom.append("span")
        .attr({
            "id":"modItemSpanDatabase",
            "class":"databaseTitle"
        })
        .html(modDatabaseName);
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos");
    for(var i = 0;i < popUpInputArray.length;i++)
    {
        var editFromLi = editFormUl.append("li")
            .attr({
                "class":"editUl",
                "id":"editUlId" + i
            });
        editFromLi.append("label").append("span")
            .attr("class","editFromLiSpan")
            .html(popUpInputArray[i]);
        if(i == 2)
        {
            var ownerOptionElem = editFromLi.append("select")
                .attr({
                    'id':"input" + i,
                    'class':'encodeSelectStye owner-select-class'
                });
            for(var k = 0;k<ownerArray.length; k++)
            {
                ownerOptionElem.append("option")
                    .html(ownerArray[k].username)
            }
            var selectObj = d3.select("#input2");
            for(var m = 0; m < ownerArray.length; m++)
            {
                if(owner == ownerArray[m].username)
                {
                    selectObj[0][0].selectedIndex = m;
                    break;
                }
            }
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = owner;
        }else if(i == 1){
            d3.json("../common/js/encoding.json",function(error,json){
                if(error)
                {
                    uxAlert("编码文件读取失败！");
                }else{
                    var selectEncode = d3.select("#editUlId1").append("select")
                        .attr({
                            "id":"encodeSelect",
                            "class":'encodeSelectStye'
                        });
                    for(var k = 0;k < json.encodeData.length; k++)
                    {
                        selectEncode.append("option")
                            .attr({
                                "id":'encodeOption' + k
                            })
                            .html(json.encodeData[k].encodeText);
                    }
                }
                var selectObj = d3.select("#encodeSelect");
                var j = 0;
                for( ;j < json.encodeData.length ; j++)
                {
                    if(encode == json.encodeData[j].encodeFlag)
                    {
                        selectObj[0][0].selectedIndex = j;
                        break;
                    }
                }
                selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = json.encodeData[j].encodeText;
            })
        }else{
            editFromLi.append("input").attr({
                'class':'ipt',
                'id':'input' + i,
                'type':'text'
            });
        }
    }
    d3.select("#input0")[0][0].value = modDatabaseName;
    d3.select("#input0")[0][0].disabled = true;
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop dialog-btn-div")
        .append("button")
        .attr("id","sureBtnDatabase")
        .attr("class","btn btn-default admitClick")
        .on("click",function(){
            modfiDatabaseInfoFun(modDatabaseName);
        })
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnDatabase")
        .on("click",function(){
            d3.select("#dialogModDatabase").classed("bounceIn",false);
            $('#dialogBgModDatabase').fadeOut(300,function(){
                $('#dialogModDatabase').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#modifBtn" + modIndex).classed("modifPsw-white",false);
        })
        .html("取&nbsp;&nbsp;消");
}
function modfiDatabaseInfoFun(dataBaseName)
{
    var newOwner = d3.select("#input2")[0][0].value;
    /*
    * 修改数据库发送数据
    * */
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"modifyDatabase","subRequest":"","ssubRequest":""},
        data    :{
            webusername: window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            modDbName:dataBaseName,
            newOwner:newOwner
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_databaseObjInterface.ajaxRequest(false,jsonDataStr,modfiDatabaseInfoFunCallback);
}
function modfiDatabaseInfoFunCallback(retJson)
{
    /*
     * 修改数据库回调数据
     * */
    var retJsonObj = JSON.parse(retJson);
    if(retJsonObj.rstcode == "success")
    {
        reqInitTableData();
        uxAlert("修改数据库成功！");
    }else{
        uxAlert("修改数据库失败！");
    }
    d3.select("#dialogModDatabase").classed("bounceIn",false);
    $('#dialogBgModDatabase').fadeOut(300,function(){
        $('#dialogModDatabase').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#modifBtn" + modIndex).classed("modifPsw-white",false);
}
/*************************辅助函数*****************************************/
function reqOwnerData()
{
    ownerArray = [];
    /*
     * 获取界面所有者数据
     * */
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"getAllUserList","subRequest":"","ssubRequest":""},
        data    :{
            'webusername': window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_databaseObjInterface.ajaxRequest(false,jsonDataStr,reqOwnerDataCallback);
}
function reqOwnerDataCallback(retJson)
{
    /*
     * 返回界面所有者数据
     * */
    var retJsonObj = JSON.parse(retJson);
    if(retJsonObj.rstcode == "success")
    {
        ownerArray = JSON.parse(retJsonObj.data);
    }
}
function listenDataBaseObjTable()
{
    var $table = $("#databaseTableId");
    $table.on('check.bs.table page-change.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table', function (arg) {
        var selected = $("#databaseTableId").bootstrapTable('getSelections');
        if (selected.length > 0) {
            d3.select('#delDatabaseInfo').classed("delBtnClass",false).classed("btn admitClick",true).attr("disabled",null);
            d3.selectAll('.option-data-item')[0][2].disabled = false;
            d3.selectAll('.option-data-item')[0][3].disabled = false;
            d3.selectAll('.option-data-item').classed("select-disabled",function(d,i){return ((i == 2 || i == 3) ? (false):(false))});
        }
        else {
            d3.select('#delDatabaseInfo').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
            d3.selectAll('.option-data-item')[0][2].disabled = true;
            d3.selectAll('.option-data-item')[0][3].disabled = true;
            d3.selectAll('.option-data-item').classed("select-disabled",function(d,i){return ((i == 2 || i == 3) ? (true):(false))});
        }
    });
}