
var g_uxchildFrame;
var parameterData;
function uxKeyDown(e)
{
    if(typeof  window.addEventListener == "undefined" &&  typeof window.attachEvent == "undefined")
    {
        return false;
    }
    var ev =e ? e:event;
    var uxframe = g_uxchildFrame || 'mainDivId';
    var pagePathArray = window.sessionStorage.ux_pagePath.split(",");
    if(window.addEventListener)
    {
        if(ev.keyCode == 116)
        {
            switch(pagePathArray[0])
            {
                case "userManage":
                    top.d3.select("#mainDivId").attr("src","modules/user/webusermanage.html");
                    break;
                case "dbManage":
                    if(pagePathArray[1] == "main")
                    {
                        getDatabaseElem("#databaseBodyId");
                    }
                    break;
                case "monitor":
                    if(pagePathArray[1] == "dfsMonitor")
                    {
                        dfsMonitoringElem("#dfsMonitoringId");
                    }else if(pagePathArray[1] == "insMonitor")
                    {
                        getInstantMonitorElem("#insMonitor");
                    }
                    break;
                case "instanManage":
                    if(pagePathArray[1] == "main")
                    {
                        getInstanceList("#instanaceBodyId");
                    }else if(pagePathArray[1] == "insOper")
                    {
                        instanceOperElem(parameterData,true);
                    }else if(pagePathArray[1] == "insConfiguration")
                    {
                        getConfigureInstanElem(parameterData);
                    }
                    break;
                case "dbSafetyUser":
                    if(pagePathArray[1] == "main")
                    {
                        safetyUserObjectElem("#safetyUserId");
                    }
                    break;
                case "dbSafetyRole":
                    if(pagePathArray[1] == "main")
                    {
                        safetyRoleObjectElem("#safetyRoleId");
                    }
                    break;
                case "databaseobject":
                    if(pagePathArray[1] == "main")
                    {
                        dataBaseObjectElem("#dataBaseObjId");
                    }
                    break;
                case "dfsManage":
                    if(pagePathArray[1] == "dfsList")
                    {
                        getDfsList("#dfsBodyId");
                    }else if(pagePathArray[1] == "dfsHandle")
                    {
                        getDfsHandle(parameterData);
                    }else if(pagePathArray[1] == "DirConfig")
                    {
                        getDirHandle(parameterData);
                    }else if(pagePathArray[1] == "mrcConfig")
                    {
                        getMrcHandle(parameterData);
                    }else if(pagePathArray[1] == "osdConfig")
                    {
                        getOsdHandle(parameterData);
                    }
                    break;
                default :break;
            }
            ev.preventDefault();
            return false;
        }
    }
    else
    {
        if(ev.keyCode == 116)
        {
            switch(pagePathArray[0])
            {
                case "userManage":
                    top.d3.select("#mainDivId").attr("src","modules/user/webusermanage.html");
                    break;
                case "dbManage":
                    //top.d3.select("#mainDivId").attr("src","modules/dbmanage/dbmanager.html");
                    if(pagePathArray[1] == "main")
                    {
                        getDatabaseElem("#databaseBodyId");
                    }
                    break;
                case "instanManage":
                    //top.d3.select("#mainDivId").attr("src","modules/instancemanage/instancemanage.html");
                    if(pagePathArray[1] == "main")
                    {
                        getInstanceList("#instanaceBodyId");
                    }else if(pagePathArray[1] == "insOper")
                    {
                        instanceOperElem(parameterData);
                    }else if(pagePathArray[1] == "insConfiguration")
                    {
                        getConfigureInstanElem(parameterData);
                    }
                    break;
                case "dbSafetyUser":
                    if(pagePathArray[1] == "main")
                    {
                        safetyRoleObjectElem("#safetyUserId");
                    }
                    break;
                case "dbSafetyRole":
                    if(pagePathArray[1] == "main")
                    {
                        safetyRoleObjectElem("#safetyRoleId");
                    }
                    break;
                case "databaseobject":
                    //top.d3.select("#mainDivId").attr("src","modules/instancemanage/instancemanage.html");
                    if(pagePathArray[1] == "main")
                    {
                        dataBaseObjectElem("#dataBaseObjId");
                    }
                    break;
                case "dfsManage":
                    //top.d3.select("#mainDivId").attr("src","modules/instancemanage/instancemanage.html");
                    if(pagePathArray[1] == "main")
                    {
                        getDfsList("#dfsBodyId");
                    }else if(pagePathArray[1] == "dfsHandle")
                    {
                        getDfsHandle(parameterData);
                    }else if(pagePathArray[1] == "DirConfig")
                    {
                        getDirHandle(parameterData);
                    }else if(pagePathArray[1] == "mrcConfig")
                    {
                        getMrcHandle(parameterData);
                    }else if(pagePathArray[1] == "osdConfig")
                    {
                        getOsdHandle(parameterData);
                    }
                    break;
                default :break;
            }
            ev.keyCode = 0;
            ev.returnValue = false;
            return false;
        }
    }
}

function setUXFrame(frameName)
{
    if(frameName == "")
    {
        return;
    }
    g_uxchildFrame = frameName;
}
function setParameterData(data)
{
    parameterData = data;
}
//frame onkeydown
$(document).ready(function()
{
    document.onkeydown = uxKeyDown;
    for(var i=0; i< parent.frames.length;i++)
    {
        if(typeof document.addEventListener != "undefined")
        {
            parent.frames[i].document.addEventListener("keydown",uxKeyDown,true);
        }
        else
        {
            parent.frames[i].document.attachEvent("onkeydown",uxKeyDown);
        }
    }
});
