'use strict';
function changePath(pathStr)
{
    window.sessionStorage.ux_currentPosition = pathStr;
    top.d3.select("#currentPositionSpan")[0][0].innerText = window.sessionStorage.ux_currentPosition;
}
/*
 * 去左右空格
 * */
function trim(s)
{
    return s.replace(/(^\s*)|(\s*$)/g, "");
}

/*
 * 选择框显示
 * */
function checkBoxFun(idNum)
{
    var checkBoxSelectItem ="selectElemId" + idNum;
    var checkBoxSelect = "checkboxId" + idNum;
    var checkitemArray = d3.select("#" + checkBoxSelectItem);
    var checkBoxArray = d3.select("#" + checkBoxSelect);
    if(checkBoxArray[0][0].checked)
    {
        if(checkitemArray[0][0] != null)
        {
            checkitemArray[0][0].disabled = false;
        }
    }else{
        if(checkitemArray[0][0] != null)
        {
            if(checkitemArray[0][0].type == "text")
            {
                checkitemArray[0][0].value = "";
            }
            checkitemArray[0][0].disabled = true;
        }
    }
}

/*
* 顶部菜单栏数据
* */
//var choiceDataBase;
function refashTopMenu(instanceAndDatabaseInfo)
{
    window.sessionStorage.ux_intanceAndData = JSON.stringify(instanceAndDatabaseInfo);
    top.d3.select("#topContainDiv").remove();
    var dataArray;
    var currentDatabase = window.sessionStorage.ux_databaseConnection;
    if(currentDatabase)
    {
        dataArray = window.parent.getTopMenuData(1);
    }else{
        dataArray = window.parent.getTopMenuData(0);
    }

    /*登录成功后，进入的界面没有左侧菜单栏，也没有连接数据库*/
    window.parent.getTopMenu(dataArray);
    addDatabaseElem(instanceAndDatabaseInfo);
}
/*
* 显示顶部数据选择菜单
* */
var insAndDatabaseI,insAndDatabaseJ;
function addDatabaseElem(choiceDataBaseData)
{
    if(top.d3.select("#topMenuLi4") != "")
    {
        var selectDatabase = top.d3.select("#topMenuLi4").select("ul");
        for(var i = 0;i < choiceDataBaseData.length; i++)
        {
            var selectItem = selectDatabase.append("li")
                .attr("class","topMenuId");
            selectItem.append("h3")
                .attr({
                    "id":"instanceId" + i
                })
                .html(choiceDataBaseData[i].instancename);
            var selectItemUlElem = selectItem.append("ul")
                .attr("class","databaseUlClass no-display")
                .style("right","-174px");
            for(var k = 0; k<choiceDataBaseData[i].dbarr.length; k++)
            {
                selectItemUlElem.append("li")
                    .append("h3")
                    .attr({
                        "id":"instanceId" + i,
                        "onClick":"setDatabaseId(" + i + "," + k + ")"
                    })
                    .html(choiceDataBaseData[i].dbarr[k]);
            }
        }
    }else{

    }
}

function setDatabaseId(indexI,indexJ)
{
    var instanceAndData = window.sessionStorage.ux_intanceAndData;
    var instanceAndDataJson = JSON.parse(instanceAndData);
    window.sessionStorage.ux_currentChoiceInsId = instanceAndDataJson[indexI].instanceid;
    window.sessionStorage.ux_currentChoiceDataName = instanceAndDataJson[indexI].dbarr[indexJ];
    d3.select("#mainDivId").attr("src","modules/dbmanage/dbmanager.html");
}
/*
 * 顶部菜单栏的连接操作
 * */
function liEvent(indexI,indexJ)
{
    top.d3.select("#noDataBg")
        .style({
            "display":"none",
            "z-index":"0"
        });
    var data = topMenuDataJson.topMenuData[indexI].data[indexJ].name;
    if(data == "webUserMan")
    {
        d3.select("#mainDivId").attr("src","modules/user/webusermanage.html");
    }else if(data == "insMan")
    {
        d3.select("#mainDivId").attr("src","modules/instancemanage/instancemanage.html");
    }else if(data == "DFSMan")
    {
        d3.select("#mainDivId").attr("src","modules/dfsmanage/dfsmanage.html");
    }else if(data == "homePage")
    {
        d3.select("#mainDivId").attr("src","modules/dbmanage/dbmanager.html");
    }else if(data == "DFSMonitor")
    {
        d3.select("#mainDivId").attr("src","modules/dfsmonitoring/dfsmonitoring.html");
    }else if(data == "InstanceMonitor")
    {
        d3.select("#mainDivId").attr("src","modules/instancemonitoring/instancemonitoring.html");
    }
}
function liLeftEvent(indexI,indexJ)
{
    if(leftMenuItem[indexI].data.length > 0)
    {
        var data = leftMenuItem[indexI].data[indexJ].name;
    }
    if(indexI == 0 && indexJ == 0)
    {
        d3.select("#mainDivId").attr("src","modules/dbmanage/dbmanager.html");
    }else if(data == "database")
    {
        d3.select("#mainDivId").attr("src","modules/databaseobject/databaseobject.html");
    }else if(data == "user")
    {
        d3.select("#mainDivId").attr("src","modules/safety/safetyuser.html");
    } else if(data == "role")
    {
        d3.select("#mainDivId").attr("src","modules/safety/safetyrole.html");
    }
}