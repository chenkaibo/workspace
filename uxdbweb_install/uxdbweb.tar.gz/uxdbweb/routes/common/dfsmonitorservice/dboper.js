/**
 * Created by Administrator on 2017/3/14.
 */
var myDbOpt = require("../dbopt");
//sampling frequency default 30s
var _collectionNum = (3600/30);
var _dbOpt;

//setCollectNum
exports.setCollectNum = function(collectNum){
    if(isNaN(collectNum)){
      console.log("is not number !");
      return false;
    }
    _collectionNum = collectNum;
    return true;
};



//database operation
exports.DFSDBOper = function(){
    var _inst;

    function getDIRList(callback){
        if(typeof callback != "function"){
            return;
        }

        //var sqlText = "select a.dfsid as dfsid,a.dirname as dirname, a.ip as dirip,a.httpport as dirport from tbl_dirlist a " +
        //    "left join tbl_dfslist b on (a.dfsid = b.id) where b.state = '1' and a.state = '1';";
        var sqlText = "select a.dfsid as dfsid,a.dirname as dirname, a.ip as dirip,a.httpport as dirport from tbl_dirlist a " +
            "left join tbl_dfslist b on (a.dfsid = b.id) ;";
        var sqlValue = [];
        _dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
            if (isErr || count == 0) {
                callback(isErr, []);
                return;
            }
            callback(null,rst);

        });
    }

    return{
        getInstance: function()
        {
            if(_inst === undefined)
            {
                if(_dbOpt === undefined){
                    _dbOpt = new myDbOpt();
                }
                _inst = {
                    "getDIRList":getDIRList

                };
            }
            return _inst;
        }
    }
};


exports.DIRDBOper  = function(){
    var _inst;
    function addDIR(data,callback){
        if(data === undefined || typeof callback == "undefined"){
           return;
        }
        var sqlInsert = "INSERT INTO tbl_dfs_dir " +
            "(dfsid,name,address,connectnum,requestnum,modules,status) VALUES ($1,$2,$3,$4,$5,$6,$7);";
        var sqlValue = new Array();
        sqlValue.push(data.dfsid);
        sqlValue.push(data.name);
        sqlValue.push(data.address);
        var connectNum = new Array();
        connectNum.push(data.clientConnects);
        sqlValue.push(JSON.stringify(connectNum));
        var memReqNum = new Array();
        memReqNum.push(data.memReqNum);
        sqlValue.push(JSON.stringify(memReqNum));
        sqlValue.push(data.modules);
        sqlValue.push(1);

        _dbOpt.execSql(sqlInsert,sqlValue,function(error)
        {
            callback(error);
        });
    }
    function storeDIR(data,callback){
        if(data === undefined || typeof callback == "undefined"){
            return;
        }
        searchDIR(data,function(error,rst){
            if(error){
                callback(error);
                return;
            }
            if(rst.length > 0){
                //update
                updateDIR(rst[0],data,function(updateRet){
                    callback(updateRet);
                });
            }else{
                //add
                addDIR(data,function(addRet){
                   callback(addRet);

                });

            }

        });
    }
    function updateDIR(oldData,newData,callback){
        if(oldData === undefined || newData === undefined || typeof callback == "undefined"){
            return;
        }
        var oldConnectNum = JSON.parse(oldData.connectnum);
        if(Number(oldData.status) <= 0){
            oldConnectNum = new Array();
        }
        if( oldConnectNum.length >= _collectionNum){
            oldConnectNum.shift();
        }
        oldConnectNum.push(newData.clientConnects);
        var connectNum = oldConnectNum;

        var oldRequestNum = JSON.parse(oldData.requestnum);
        if(Number(oldData.status) <= 0){
            oldRequestNum = new Array();
        }

        if(oldRequestNum.length >= _collectionNum){
            oldRequestNum.shift();
        }
        oldRequestNum.push(newData.memReqNum);
        var requestNum = oldRequestNum;

        var sqlText = "UPDATE tbl_dfs_dir SET connectnum = $3,requestnum = $4,modules = $5,status = $6"+" WHERE dfsid = $1 and address = $2;";
        var sqlValue = new Array();
        sqlValue.push(newData.dfsid);
        sqlValue.push(newData.address);
        sqlValue.push(JSON.stringify(connectNum));
        sqlValue.push(JSON.stringify(requestNum));
        sqlValue.push(newData.modules);
        sqlValue.push(1);


        _dbOpt.execSql(sqlText,sqlValue,function(error)
        {
            callback(error);
        });

    }
    function searchDIR(data,callback){

        if(data === undefined || typeof callback == "undefined"){
            return;
        }
        var sqlText = "SELECT * FROM tbl_dfs_dir ";
        var sqlValue = [];
        if(typeof data.address == "undefined" || typeof data.dfsid == "undefined" ){
            callback("error");
            return;
        }
        sqlText += "WHERE dfsid = $1 and address = $2;";
        sqlValue.push(data.dfsid);
        sqlValue.push(data.address);
        _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
        {
            if(error)
            {
                callback(error);
                return;
            }
            if(count == 0){
                callback(error,[]);
                return;
            }
            callback(error,rst);
        });
    }


    function modifyStatus(dfsid,address,status,callback){
        if(isNaN(status) || dfsid == "" || address == "" || typeof callback == "undefined"){
            return;
        }
        var data = {"dfsid":dfsid,"address":address};
        searchDIR(data,function(err,rst){
            if(err){
                callback(err);
                return;
            }
            if(rst.length == 0){
                callback(null);
                return;
            }

            var sqlText = "UPDATE tbl_dfs_dir SET status = $3 "+" WHERE dfsid = $1 and address = $2;";
            var sqlValue = new Array();
            sqlValue.push(dfsid);
            sqlValue.push(address);
            sqlValue.push(status);
            _dbOpt.execSql(sqlText,sqlValue,function(error)
            {
                callback(error);
            });
        });

    }

    function emptyTable(callback){
        if(typeof  callback == "undefined"){
            return;
        }
        var sqlText = "delete from  tbl_dfs_dir ;";
        var sqlValue = new Array();
        _dbOpt.execSql(sqlText,sqlValue,function(error)
        {
            callback(error);
        });
    }

    function getDataByDFSID(dfsid,callback){
        if(typeof dfsid != "string"  ||  typeof callback == "undefined"){
            return;
        }

        var sqlText = "SELECT * FROM tbl_dfs_dir ";
        var sqlValue = [];
        sqlText += "WHERE dfsid = $1 and status = 1;";
        sqlValue.push(dfsid);
        _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
        {
            if(error)
            {
                callback(error);
                return;
            }
            if(count == 0){
                callback(error,[]);
                return;
            }
            callback(error,rst);
        });
    }



    return{
        getInstance: function()
        {
            if(_inst === undefined)
            {
                if(_dbOpt === undefined){
                    _dbOpt = new myDbOpt();
                }
                _inst = {
                    "addDIR":addDIR,
                    "updateDIR":updateDIR,
                    "storeDIR":storeDIR,
                    "searchDIR":searchDIR,
                    "modifyStatus":modifyStatus,
                    "emptyTable":emptyTable,
                    "getDataByDFSID":getDataByDFSID
                };
            }
            return _inst;
        }
    }

};


exports.MRCDBOper = function(){

    var _inst;
    function addMRC(data,callback){
        if(data === undefined || typeof callback == "undefined"){
            return;
        }
        var sqlInsert = "INSERT INTO tbl_dfs_mrc " +
            "(dfsid,name,address,load,totalram,usedram,ramusage,connectnum,volumes,status) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10);";
        var sqlValue = new Array();
        sqlValue.push(data.dfsid);
        sqlValue.push(data.name);
        sqlValue.push(data.address);
        sqlValue.push(data.load);
        sqlValue.push(data.totalRAM);
        sqlValue.push(data.usedRAM);
        var RAMUsage = new Array();
        RAMUsage.push(data.RAMUsage);
        sqlValue.push(JSON.stringify(RAMUsage));
        var connectNum =  new Array();
        connectNum.push(data.clientConnects);
        sqlValue.push(JSON.stringify(connectNum));
        sqlValue.push(data.volumes);
        sqlValue.push(1);


        _dbOpt.execSql(sqlInsert,sqlValue,function(error)
        {
            callback(error);
        });
    }
    function storeMRC(data,callback){
        if(data === undefined || typeof callback == "undefined"){
            return;
        }
        searchMRC(data,function(error,rst){
            if(error){
                callback(error);
                return;
            }
            if(rst.length > 0){
                //update
                updateMRC(rst[0],data,function(updateRet){
                    callback(updateRet);
                });
            }else{
                //add
                addMRC(data,function(addRet){
                    callback(addRet);

                });

            }

        });
    }
    function updateMRC(oldData,newData,callback){
        if(oldData === undefined || newData === undefined || typeof callback == "undefined"){
            return;
        }

        //RAMUsage
        var oldRAMUsage = JSON.parse(oldData.ramusage);
        if(Number(oldData.status) <= 0){
            oldRAMUsage = new Array();
        }

        if(oldRAMUsage.length >= _collectionNum){
            oldRAMUsage.shift();
        }
        oldRAMUsage.push(newData.RAMUsage);
        var RAMUsage = oldRAMUsage;

        //connectNum
        var oldConnectNum = JSON.parse(oldData.connectnum);
        if(Number(oldData.status) <= 0){
            oldConnectNum = new Array();
        }

        if( oldConnectNum.length >= _collectionNum){
            oldConnectNum.shift();
        }
        oldConnectNum.push(newData.clientConnects);
        var connectNum = oldConnectNum;

        var sqlText = "UPDATE tbl_dfs_mrc "+
            "SET load = $3,totalram = $4,usedram = $5,ramusage = $6,connectnum = $7,volumes = $8 ,status = $9"+ " WHERE dfsid = $1 and address = $2;";
        var sqlValue = new Array();
        sqlValue.push(newData.dfsid);
        sqlValue.push(newData.address);
        sqlValue.push(newData.load);
        sqlValue.push(newData.totalRAM);
        sqlValue.push(newData.usedRAM);
        sqlValue.push(JSON.stringify(RAMUsage));
        sqlValue.push(JSON.stringify(connectNum));
        sqlValue.push(newData.volumes);
        sqlValue.push(1);

        _dbOpt.execSql(sqlText,sqlValue,function(error)
        {
            callback(error);
        });

    }
    function searchMRC(data,callback){

        if(data === undefined || typeof callback == "undefined"){
            return;
        }
        var sqlText = "SELECT * FROM tbl_dfs_mrc ";
        var sqlValue = [];
        if(typeof data.name != "undefined"){
            sqlText += "WHERE dfsid = $1 and address = $2;";
            sqlValue.push(data.dfsid);
            sqlValue.push(data.address);
        }
        _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
        {
            if(error)
            {
                callback(error);
                return;
            }
            if(count == 0){
                callback(error,[]);
                return;
            }
            callback(error,rst);
        });
    }

    function modifyStatus(dfsid,address,status,callback){
        if(isNaN(status) || address == "" || dfsid == "" || typeof callback == "undefined"){
            return;
        }
        var data = {"address":address};
        searchMRC(data,function(err,rst){
            if(err){
                callback(err);
                return;
            }
            if(rst.length == 0){
                callback(null);
                return;
            }

            var sqlText = "UPDATE tbl_dfs_mrc SET status = $3 "+" WHERE dfsid = $1 and address = $2;";
            var sqlValue = new Array();
            sqlValue.push(dfsid);
            sqlValue.push(address);
            sqlValue.push(status);
            _dbOpt.execSql(sqlText,sqlValue,function(error)
            {
                callback(error);
            });
        });
    }

    function emptyTable(callback){
        if(typeof  callback == "undefined"){
            return;
        }
        var sqlText = "delete from  tbl_dfs_mrc ;";
        var sqlValue = new Array();
        _dbOpt.execSql(sqlText,sqlValue,function(error)
        {
            callback(error);
        });
    }

    function getDataByDFSID(dfsid,callback){
        if(typeof dfsid != "string"  ||  typeof callback == "undefined"){
            return;
        }

        var sqlText = "SELECT * FROM tbl_dfs_mrc ";
        var sqlValue = [];
        sqlText += "WHERE dfsid = $1 and status = 1;";
        sqlValue.push(dfsid);
        _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
        {
            if(error)
            {
                callback(error);
                return;
            }
            if(count == 0){
                callback(error,[]);
                return;
            }
            callback(error,rst);
        });
    }

    return{
        getInstance: function()
        {
            if(_inst === undefined)
            {
                if(_dbOpt === undefined){
                    _dbOpt = new myDbOpt();
                }
                _inst = {
                    "addMRC":addMRC,
                    "updateMRC":updateMRC,
                    "storeMRC":storeMRC,
                    "searchMRC":searchMRC,
                    "modifyStatus":modifyStatus,
                    "emptyTable":emptyTable,
                    "getDataByDFSID":getDataByDFSID
                };
            }
            return _inst;
        }
    }
};

exports.OSDDBOper = function(){
    var _inst;
    function addOSD(data,callback){
        if(data === undefined || typeof callback == "undefined"){
            return;
        }
        var sqlInsert = "INSERT INTO tbl_dfs_osd " +
            "(dfsid,name,address,load,totalram,usedram,ramusage,connectnum,totaldisk,freedisk,diskusage,status) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12);";
        var sqlValue = new Array();
        sqlValue.push(data.dfsid);
        sqlValue.push(data.name);
        sqlValue.push(data.address);
        sqlValue.push(data.load);
        sqlValue.push(data.totalRAM);
        sqlValue.push(data.usedRAM);
        var RAMUsage = new Array();
        RAMUsage.push(data.RAMUsage);
        sqlValue.push(JSON.stringify(RAMUsage));
        var connectNum = new Array();
        connectNum.push(data.clientConnects);
        sqlValue.push(JSON.stringify(connectNum));
        sqlValue.push(data.totalDisk);
        sqlValue.push(data.freeDisk);
        sqlValue.push(data.diskUsage);
        sqlValue.push(1);

        _dbOpt.execSql(sqlInsert,sqlValue,function(error)
        {
            callback(error);
        });
    }

    function storeOSD(data,callback){
        if(data === undefined || typeof callback == "undefined"){
            return;
        }
        searchOSD(data,function(error,rst){
            if(error){
                callback(error);
                return;
            }
            if(rst.length > 0){
                //update
                updateOSD(rst[0],data,function(updateRet){
                    callback(updateRet);
                });
            }else{
                //add
                addOSD(data,function(addRet){
                    callback(addRet);

                });

            }

        });
    }
    function updateOSD(oldData,newData,callback){
        if(oldData === undefined || newData === undefined || typeof callback == "undefined"){
            return;
        }

        //RAMUsage
        var oldRAMUsage = JSON.parse(oldData.ramusage);
        if(Number(oldData.status) <= 0){
            oldRAMUsage = new Array();
        }

        if(oldRAMUsage.length >= _collectionNum){
            oldRAMUsage.shift();
        }
        oldRAMUsage.push(newData.RAMUsage);
        var RAMUsage = oldRAMUsage;
        //connectNum
        var oldConnectNum = JSON.parse(oldData.connectnum);
        if(Number(oldData.status) <= 0){
            oldConnectNum = new Array();
        }
        if( oldConnectNum.length >= _collectionNum){
            oldConnectNum.shift();
        }
        oldConnectNum.push(newData.clientConnects);
        var connectNum = oldConnectNum;

        var sqlText = "UPDATE tbl_dfs_osd "+
            "SET load = $3,totalram = $4,usedram = $5,ramusage = $6,connectnum = $7,totaldisk = $8,freedisk = $9, diskusage = $10, status = $11"+
            "WHERE dfsid = $1 and address = $2;";
        var sqlValue = new Array();
        sqlValue.push(newData.dfsid);
        sqlValue.push(newData.address);
        sqlValue.push(newData.load);
        sqlValue.push(newData.totalRAM);
        sqlValue.push(newData.usedRAM);
        sqlValue.push(JSON.stringify(RAMUsage));
        sqlValue.push(JSON.stringify(connectNum));
        sqlValue.push(newData.totalDisk);
        sqlValue.push(newData.freeDisk);
        sqlValue.push(newData.diskUsage);
        sqlValue.push(1);

        _dbOpt.execSql(sqlText,sqlValue,function(error)
        {
            callback(error);
        });

    }
    function searchOSD(data,callback){

        if(data === undefined || typeof callback == "undefined"){
            return;
        }
        var sqlText = "SELECT * FROM tbl_dfs_osd ";
        var sqlValue = [];
        if(typeof data.dfsid != "undefined" && typeof data.address != "undefined"){
            sqlText += "WHERE dfsid = $1 and address = $2;";
            sqlValue.push(data.dfsid);
            sqlValue.push(data.address);
        }
        _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
        {
            if(error)
            {
                callback(error);
                return;
            }
            if(count == 0){
                callback(error,[]);
                return;
            }
            callback(error,rst);
        });
    }

    function modifyStatus(dfsid,address,status,callback){
        if(isNaN(status) || address == "" ||  dfsid == ""|| typeof callback == "undefined"){
            return;
        }
        var data = {"address":address};
        searchOSD(data,function(err,rst){
            if(err){
                callback(err);
                return;
            }
            if(rst.length == 0){
                callback(null);
                return;
            }

            var sqlText = "UPDATE tbl_dfs_osd SET status = $3 "+" WHERE dfsid = $1 and address = $2;";
            var sqlValue = new Array();
            sqlValue.push(dfsid);
            sqlValue.push(address);
            sqlValue.push(status);
            _dbOpt.execSql(sqlText,sqlValue,function(error)
            {
                callback(error);
            });
        });
    }

    function emptyTable(callback){
        if(typeof  callback == "undefined"){
            return;
        }
        var sqlText = "delete from  tbl_dfs_osd ;";
        var sqlValue = new Array();
        _dbOpt.execSql(sqlText,sqlValue,function(error)
        {
            callback(error);
        });
    }


    function getDataByDFSID(dfsid,callback){
        if(typeof dfsid != "string"  ||  typeof callback == "undefined"){
            return;
        }

        var sqlText = "SELECT * FROM tbl_dfs_osd ";
        var sqlValue = [];
        sqlText += "WHERE dfsid = $1 and status = 1;";
        sqlValue.push(dfsid);
        _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
        {
            if(error)
            {
                callback(error);
                return;
            }
            if(count == 0){
                callback(error,[]);
                return;
            }
            callback(error,rst);
        });
    }

    return{
        getInstance: function()
        {
            if(_inst === undefined)
            {
                if(_dbOpt === undefined){
                    _dbOpt = new myDbOpt();
                }
                _inst = {
                    "addOSD":addOSD,
                    "updateOSD":updateOSD,
                    "storeOSD":storeOSD,
                    "searchOSD":searchOSD,
                    "modifyStatus":modifyStatus,
                    "emptyTable":emptyTable,
                    "getDataByDFSID":getDataByDFSID
                };
            }
            return _inst;
        }
    }
};

