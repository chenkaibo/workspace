var protocolMgr = require('../../protocolunit/protocolmgr');
var myDbOpt = require('../../common/dbopt');
var dfsmanageMgr = (function () {
    var _inst;
    var dfsmanageOpt = function () {
        return {
            enumDFSListMgr: enumDFSListMgr,
            queryDFSMgr: queryDFSMgr,
            getDFSFromAgent: getDFSFromAgent,
            getDFSStateFromLocalDbMgr: getDFSStateFromLocalDbMgr,
            getDFSStateMgr: getDFSStateMgr,
            optDFSMgr: optDFSMgr,
            getOptDFSStateMgr: getOptDFSStateMgr,
            enumVolumeListMgr: enumVolumeListMgr,
            enumDIRListMgr: enumDIRListMgr,
            enumMRCListMgr: enumMRCListMgr,
            enumOSDListMgr: enumOSDListMgr,
            queryDbTableMgr: queryDbTableMgr,
            getDirMrcOsdConfigListMgr: getDirMrcOsdConfigListMgr,
            setDirMrcOsdConfigMgr: setDirMrcOsdConfigMgr,
            createVolume: createVolume,
            deleteVolume: deleteVolume,
            deleteDFS: deleteDFS,
            getVolumePathMgr: getVolumePathMgr,
            updateDbTableMgr: updateDbTableMgr,
            updateDbByDetailInfoMgr: updateDbByDetailInfoMgr,
            modifyAliasnameMgr: modifyAliasnameMgr
        }
    }
    return {
        getInstance: function () {
            if (_inst === undefined) {
                _inst = new dfsmanageOpt();
            }
            return _inst;
        }
    }
})();
module.exports = dfsmanageMgr;
function queryDbTableMgr(data, callback) {
    if (typeof callback !== "function") {
        return 0;
    }
    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(data.sqlText, data.sqlValue, function (error, count, rst) {
        if (error) {
            callback(true, error);
            return;
        }
        if (count == 0) {
            callback(false, []);
            return;
        }
        callback(false, rst);
    });
    return 0;
}
function enumDFSListMgr(reqDb, callback) {

    if (typeof callback !== "function") {
        return 0;
    }

    var sqlText = "SELECT * FROM tbl_dfslist ORDER BY aliasname;";
    var sqlValue = [];
    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(sqlText, sqlValue, function (error, count, rst) {
        if (error) {
            callback(error);
            return;
        }
        if (count == 0) {
            callback(error, []);
            return;
        }
        callback(error, rst);
    });
    return 0;
}
function queryDFSMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }
    var sqlText = "select * from tbl_dfslist where 1=1";
    var sqlValue = [];
    var num = 1;
    if (reqDb.dfsNameFlag == 1) {
        sqlText += " and dfsname like $" + (num++);
        sqlValue.push("%" + reqDb.dfsName + "%");
    }
    if (reqDb.dfsStatusFlag == 1) {
        sqlText += " and state = $" + (num++);
        sqlValue.push(reqDb.dfsStatus);
    }
    sqlText += ";";
    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
        if (isErr) {
            callback(true);
            return;
        }
        if (count == 0) {
            callback(false, []);
            return;
        }
        callback(false, rst);
    })
}
function getDFSFromAgent(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }
    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 3,
        'dbnum': 1,
        'data': reqDb.data
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}
function getDFSStateFromLocalDbMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }
    var sqlText = "SELECT state FROM tbl_dfslist where id = $1;";
    var sqlValue = [reqDb.dfsid];
    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(sqlText, sqlValue, function (error, count, rst) {
        if (error) {
            callback(error);
            return;
        }
        if (count == 0) {
            callback(error, []);
            return;
        }
        callback(error, rst);
    });
    return 0;
}
function getDFSStateMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }


    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 6,
        'dbnum': 1,
        'data': reqDb.data
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}
function optDFSMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }


    //test data
    //var dataObj = {
    //    data:{
    //        DFSStatus:reqDb.opertype,
    //        instanStatus:0
    //    }
    //}
    //callback(false,dataObj);
    //return;


    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'asyn',
        'maincmd': 3,
        'subcmd': (reqDb.opertype == 1 ? 3 : 4),//3:启动，4:停止
        'dbnum': 1,
        'data': reqDb.data
    }
    console.log("send cmd:" + JSON.stringify(reqJson));
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        callback(isErr, resJson);
    });
    return 0;
}
function getOptDFSStateMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }


    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': (reqDb.opertype == 1 ? 12 : 13),//12:启动进度，13:停止进度
        'dbnum': 1,
        'data': reqDb.data
    }

    console.log("send cmd:" + JSON.stringify(reqJson));
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}

function enumVolumeListMgr(reqDb, callback) {

    if (typeof callback !== "function") {
        return 0;
    }

    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 7,
        'dbnum': 1,
        'data': reqDb.data
    }
    console.log("send cmd:" + JSON.stringify(reqJson));
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}
function enumDIRListMgr(reqDb, callback) {

    if (typeof callback !== "function") {
        return 0;
    }

    var sqlText = "SELECT * FROM tbl_dirlist where dfsid = $1;";
    var sqlValue = [reqDb.data.dfsid];
    console.log("========sqlValue" + sqlValue + "===========");
    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(sqlText, sqlValue, function (error, count, rst) {
        if (error) {
            callback(error);
            return;
        }
        if (count == 0) {
            callback(error, []);
            return;
        }
        callback(error, rst);
    });
    return 0;
}
function enumMRCListMgr(reqDb, callback) {

    if (typeof callback !== "function") {
        return 0;
    }

    var sqlText = "SELECT * FROM tbl_mrclist where dfsid = $1;";
    var sqlValue = [reqDb.data.dfsid];
    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(sqlText, sqlValue, function (error, count, rst) {
        if (error) {
            callback(error);
            return;
        }
        if (count == 0) {
            callback(error, []);
            return;
        }
        callback(error, rst);
    });
    return 0;
}
function enumOSDListMgr(reqDb, callback) {

    if (typeof callback !== "function") {
        return 0;
    }

    var sqlText = "SELECT * FROM tbl_osdlist where dfsid = $1;";
    var sqlValue = [reqDb.data.dfsid];
    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(sqlText, sqlValue, function (error, count, rst) {
        if (error) {
            callback(error);
            return;
        }
        if (count == 0) {
            callback(error, []);
            return;
        }
        callback(error, rst);
    });
    return 0;
}
function getDirMrcOsdConfigListMgr(reqDb, callback) {

    if (typeof callback !== "function") {
        return 0;
    }


    //test data
    //var resJson = {
    //    cfgname: "testcfgname",
    //    path: "testpath",
    //    tarray: [],
    //}
    //var num = 0;
    //for (var i = 0; i < 5; i++) {
    //    var dataObj = {}
    //    dataObj.pclass = "testpclass" + i;
    //    dataObj.parray = [];
    //    for (var j = 0; j < 5; j++) {
    //        num++;
    //        var dataObj2 = {
    //            pname: "testname" + num,
    //            pvalue: "testvalue" + num,
    //            description: "testscription" + num,
    //            ismodify: "testismodify" + num,
    //            ptype: "testtype" + num,
    //            vlist: ["on", "off", "partition"],
    //        };
    //        dataObj.parray.push(dataObj2);
    //    }
    //    resJson.tarray.push(dataObj);
    //}
    //var obj = {data: resJson};
    //obj.data.retcode = 0;
    //callback(false, obj);
    //return;


    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 11,
        'dbnum': 1,
        'data': reqDb.data
    }
    console.log("send cmd:" + JSON.stringify(reqJson));
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}
function setDirMrcOsdConfigMgr(reqDb, callback) {

    if (typeof callback !== "function") {
        return 0;
    }


    //test data
    //var resJson = {
    //    data: {
    //        retcode: 0
    //    }
    //}
    //callback(false, resJson);
    //return;


    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 3,
        'subcmd': 14,
        'dbnum': 1,
        'data': reqDb.data
    }
    console.log("send cmd:" + JSON.stringify(reqJson));
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}


function createVolume(reqDb, callback)
{
    if(typeof callback !== "function")
    {
        return 0;
    }

    var reqJson = {
        'hostip':reqDb.ip,
        'hostport':reqDb.port,
        'type':'sync',
        'maincmd':3,
        'subcmd':6,
        'dbnum':1,
        'data':reqDb.data
    }
    console.log("send cmd:" + JSON.stringify(reqJson));
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });

    return 0;
}

function deleteVolume(reqDb, callback)
{
    if(typeof callback !== "function")
    {
        return 0;
    }

    var reqJson = {
        'hostip':reqDb.ip,
        'hostport':reqDb.port,
        'type':'sync',
        'maincmd':3,
        'subcmd':12,
        'dbnum':1,
        'data':reqDb.data
    }
    console.log("send cmd:" + JSON.stringify(reqJson));
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });

    return 0;
}

function deleteDFS(reqDb, callback)
{
    if(typeof callback !== "function")
    {
        return 0;
    }

    var _dbOpt = new myDbOpt();
    var sqlValue = [reqDb.data.dfsid];
    var sqlDelDirText = "DELETE FROM tbl_dirlist where dfsid = $1;";
    _dbOpt.querySql(sqlDelDirText,sqlValue,function(error,count,rst)
    {
        if(error)
        {
            callback(error);
            return;
        }
        if(count == 0){
            callback(error,[]);
            return;
        }
        callback(error,rst);
    });

    var sqlDelMrcText = "DELETE FROM tbl_mrclist where dfsid = $1;";
    _dbOpt.querySql(sqlDelMrcText,sqlValue,function(error,count,rst)
    {
        if(error)
        {
            callback(error);
            return;
        }
        if(count == 0){
            callback(error,[]);
            return;
        }
        callback(error,rst);
    });
    var sqlDelOsdText = "DELETE FROM tbl_osdlist where dfsid = $1;";
    _dbOpt.querySql(sqlDelOsdText,sqlValue,function(error,count,rst)
    {
        if(error)
        {
            callback(error);
            return;
        }
        if(count == 0){
            callback(error,[]);
            return;
        }
        callback(error,rst);
    });
    var sqlDelText = "DELETE FROM tbl_dfslist where id = $1;";
    _dbOpt.querySql(sqlDelText,sqlValue,function(error,count,rst)
    {
        if(error)
        {
            callback(error);
            return;
        }
        if(count == 0){
            callback(error,[]);
            return;
        }
        callback(error,rst);
    });

    return 0;
}

function getVolumePathMgr(reqDb, callback)
{
    if(typeof callback !== "function")
    {
        return 0;
    }

    var _dbOpt = new myDbOpt();
    var sqlValue = [reqDb.data.dfsid];
    var sqlText = "SELECT a.ip, a.port FROM tbl_mrclist a where dfsid = $1;";
    _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
    {
        if(error)
        {
            callback(error);
            return;
        }
        if(count == 0){
            callback(error,[]);
            return;
        }
        console.log(JSON.stringify(rst));
        callback(error,rst);
    });

    return 0;
}

function updateDbTableMgr(data, callback) {
    if (typeof callback !== "function") {
        return 0;
    }
    var _dbOpt = new myDbOpt();
    _dbOpt.execSql(data.sqlText, data.sqlValue, function (error) {
        if (error) {
            callback(error);
            return;
        }
        callback(false);
    });
    return 0;
}
function queryAllRecordMgr(tblName, callback) {
    if (typeof callback !== "function") {
        return 0;
    }
    var sqlText = "select * from " + tblName + ";"
    var sqlValue = [];
    var _dbOpt = new myDbOpt();
    _dbOpt.querySql(sqlText, sqlValue, function (error, count, rst) {
        if (error) {
            callback(error);
            return;
        }
        if (0 == count) {
            callback(false, []);
            return;
        }
        callback(false, rst);
    })
}
function updateDbByDetailInfoMgr(tblName, field, fieldValue, cond, condValue, callback) {
    var sqlText = "update " + tblName + " set " + field + " = $1 where " + cond + " = $2;";
    var sqlValue = [fieldValue, condValue];
    var _dbOpt = new myDbOpt();
    _dbOpt.execSql(sqlText, sqlValue, function (rst) {
        callback(rst);
    })
};
function modifyAliasnameMgr(reqDb,callback) {
    if (typeof callback !== "function"){
        return 1;
    };
    var sqlData = {
        sqlText: "update tbl_dfslist set aliasname=$1 where id=$2",
        sqlValue: [reqDb.aliasname, reqDb.dfsid]
    };
    var _dbOpt = new myDbOpt();
    _dbOpt.execSql(sqlData.sqlText,sqlData.sqlValue,function (error) {
        if (error){
            callback(true);
            return;
        }
        callback(false);
    })
}