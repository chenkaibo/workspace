'use strict';
var verStr = window.sessionStorage.ux_uxdbVersion;
window.sessionStorage.ux_databaseConnection = false;
/*
* 菜单数据
* */
var topMenuDataJson ={'topMenuData':"",'topMenuIconArray':""};
function getTopMenuData(numFlag)
{
    var topMenuIconArray,topMenuData;
    if(numFlag)   //如果为1表示：此时已连接数据库
    {
        topMenuData = [
            {'item':'云数据库管理','data':[{'item':'实例管理','name':'insMan'},{'item':'DFS&nbsp;管&nbsp;理','name':'DFSMan'}]},
            {'item':'数据库管理','data':[{'item':'首页','name':'homePage'}]},
            {'item':'监&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;控',
                'data':[{'item':'实例监控','name':'InstanceMonitor'},
                    {'item':'DFS监控','name':'DFSMonitor'},
                    //{'item':'主机监控','name':'hostMonitor'},
                    //{'item':'拓&nbsp;扑&nbsp;图','name':'topography'}
                ]},
            {'item':'安&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;全',
                'data':[{'item':'WEB用户管理','name':'webUserMan'}]},
            {'item':'数据库选择','data':[]}
        ];
        topMenuIconArray = ["modules/uiframe/image/top/cloudmanage.png",
            "modules/uiframe/image/top/databasemanage.png",
            "modules/uiframe/image/top/monitor.png",
            "modules/uiframe/image/top/safeicon.png",
            "modules/uiframe/image/top/databasechoice.png"];
    }else{
        topMenuData = [
            {'item':'云数据库管理','data':[{'item':'实例管理','name':'insMan'},
                {'item':'DFS&nbsp;管&nbsp;理','name':'DFSMan'}]},
            {'item':'监&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;控', 'data':
            [
                {'item':'实例监控','name':'InstanceMonitor'},
                {'item':'DFS监控','name':'DFSMonitor'},
                //{'item':'主机监控','name':'hostMonitor'},
                //{'item':'拓&nbsp;扑&nbsp;图','name':'topography'}
            ]},
            {'item':'安&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;全','data':[{'item':'WEB用户管理','name':'webUserMan'}]}
        ];
        topMenuIconArray = ["modules/uiframe/image/top/cloudmanage.png",
            "modules/uiframe/image/top/monitor.png",
            "modules/uiframe/image/top/safeicon.png"];
    }
    topMenuDataJson.topMenuData = topMenuData;
    topMenuDataJson.topMenuIconArray = topMenuIconArray;
}
var leftMenuItem = [
    {'item':'首&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;页','data':[]},
    {'item':'数据库对象',
        'data':[
            {'item':'数据库','name':'database'},
            //{'item':'模式','name':'pattern'},
            //{'item':'表','name':'table'},
            //{'item':'索引','name':'index'},
            //{'item':'视图','name':'view'},
            //{'item':'序列','name':'list'},
            //{'item':'同义词','name':'thesaurus'}
        ]},
    //{'item':'公&nbsp;共&nbsp;对&nbsp;象',
    //    'data':[
    //      {'item':'数据类型','name':'dataType'},
    //      {'item':'系统函数','name':'sysFunction'}
    //    ]},
    //{'item':'程&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;序',
    //    'data':[
    //        {'item':'触发器','name':'trigger'},
    //        {'item':'函数','name':'function'}]},
    //{'item':'存&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;储',
    //    'data':[
    //        {'item':'表空间','name':'tableSpace'},
    //        {'item':'数据文件','name':'dataFile'},
    //        {'item':'日志文件','name':'logFile'}]},
    {'item':'安&nbsp;&nbsp;&nbsp;全&nbsp;&nbsp;&nbsp;性',
        'data':[
            {'item':'用户','name':'user'},
            {'item':'角色','name':'role'}]},
    //{'item':'服务器配置','data':[{'item':'系统参数','name':'sysParameter'}]}
];
window.onresize = function(){
    screenframeShow();
};
/*
 * 菜单栏的操作函数
 * */
function menuOperFun()
{
    d3.select("#leftDivId").selectAll("ul.nav li.leftMenuLi").on("click",function(d,i){
        var liStyle = d3.select(this); //on收起菜单栏
        var h3Style = d3.select(this).select("h3");
        d3.select(".nav bttton.ul-change-btn").classed();
        if(liStyle.classed("on"))
        {
            d3.select(this).classed("on",false);
        }else{
            d3.selectAll("ul.nav li.leftMenuLi").classed("on",false);
            d3.select(this).classed("on",true);
        }
        if(h3Style.classed("choice"))
        {
            d3.select(this).selectAll("h3").classed("choice",false);
        }else{
            d3.selectAll("ul.nav li.leftMenuLi").selectAll("h3").classed("choice",false);
            d3.select(this).select("h3").classed("choice",true);
        }
    });

    d3.selectAll("#topContainDiv ul.nav li").on("mouseover",function(d,i){
        d3.select(this).classed("on",true);
        d3.select(this).select("h3").classed("choice",true);
    });
    d3.selectAll("#topContainDiv ul.nav li").on("mouseout", function(){
        d3.select(this).classed("on",false);
        d3.select(this).select("h3").classed("choice",false);
    });
    d3.selectAll("#topContainDiv ul.nav li ul li h3").on("mouseover",function(){
        d3.select(this).classed("on",true);
        d3.select(this).select("ul").classed("no-display",false);
        d3.select(this).selectAll("ul li h3").on("mouseover",function(){
            d3.select(this).classed("choice",true);
        });
        d3.select(this).selectAll("ul li h3").on("mouseover",function(){
            d3.select(this).classed("choice",false);
        });
    });
    d3.selectAll("#topContainDiv ul.nav li ul li h3").on("mouseout", function(){
        d3.select(this).classed("on",false);
        d3.select(this).select("ul").classed("no-display",true);
        d3.select(this).selectAll("ul li h3").on("mouseover",function(){
           d3.select(this).classed("choice",true);
        });
        d3.select(this).selectAll("ul li h3").on("mouseover",function(){
            d3.select(this).classed("choice",false);
        });
    });
    if ($("ul.nav li").find("ul") .html() != "") {
        $("ul.nav li").parent("ul").siblings("h3").append("<span class = 'sub'></span>");
    }
}
function getIframe()
{
    var body = d3.select("body")
        .attr("class","IndexBodyClass");
    getWholeIframe(body);
    screenframeShow();
}
function getWholeIframe(contain)
{
    d3.select(".IndexBodyClass").select("#topDivId").remove();
    getTopDiv(contain);
    getLeftDiv(contain);
    getMainDiv(contain);
    var currentDatabase = window.sessionStorage.ux_databaseConnection;
    if(currentDatabase)
    {
        getTopMenuData(0);
    }else{
        getTopMenuData(1);
    }
    /*登录成功后，进入的界面没有左侧菜单栏，也没有连接数据库*/
    getTopMenu();
}
/*
 * 界面适应性
 * */
function screenframeShow()
{
    var minWidth = 1919;
    var minHeight = 953;
    if(innerHeight < minHeight)
    {
        d3.select("#topDivId").style({
            "height":107,
        });
        d3.select("#mainDivId").style({
            "height":"820px",
        });
        d3.select(".IndexBodyClass").style({
            "background-size":"1921px 908px",
        });
    }else{
        d3.select("#topDivId").style({
            "height":"10%",
        });
        d3.select("#mainDivId").style({
            "height":"90%",
        });
        d3.select(".IndexBodyClass").style({
            "background-size":"1921px 955px",
        });
    }
    if(innerWidth < minWidth)
    {
        d3.select("#topDivId").style({
            "width":"1920px",
        });
        d3.select("#mainDivId").style({
            "width":"1893px",
        });
        d3.select(".IndexBodyClass").style({
            "background-size":"1921px 908px",
        });
    }else{
        d3.select("#topDivId").style({
            "width":"100%",
        });
        d3.select("#mainDivId").style({
            "width":"100%",
        });
        d3.select(".IndexBodyClass").style({
            "background-size":"1921px 955px",
        });
    }
}

/*
* 得到各区域的div
* */
function getTopDiv(contain)
{
    var roleIcon;
    if(window.sessionStorage.ux_curUserRole == 0)
    {
        roleIcon = "modules/uiframe/image/top/superuser.png";
    }else{
        roleIcon = "modules/uiframe/image/top/user.png";
    }
    var topDiv = contain.append("div")
        .attr("id","topDivId")
        .append("div")
        .style("float","right")
        .style("margin","6px 40px");
    d3.select("#topDivId")
        .append("div")
        .attr("class","topContainDiv")
        .append("span")
        .attr("id","topConDivSpan")
        .html("Ver : " + verStr)
        .style("color","#FFF"); //版本号
    var currentRoleDiv = topDiv.append("div")
        .attr("class","topContainDiv");
    currentRoleDiv.append("img")
        .attr("id","userImg")
        .attr("src",roleIcon);
    currentRoleDiv.append("span")
        .attr("id","currentRoleSpan")
        .html(currentRole);
    topDiv.append("div")
        .attr("class","topContainDiv").append("img")
        .attr("src","modules/uiframe/image/top/changeface.png")
        .attr("id","changeFunImg")
        .attr("onclick","changeFace()");
    topDiv.append("div")
        .attr("class","topContainDiv")
        .append("img")
        .attr("src","modules/uiframe/image/top/set.png")
        .attr("id","setImg")
        .attr("onClick","setFun()");
    topDiv.append("div")
        .attr("class","topContainDiv")
        .append("img")
        .attr("src","modules/uiframe/image/top/loginout.png")
        .attr("id","loginOutImg")
        .attr("onClick","loginOut()");
    d3.select("#topDivId")
        .append("div")
        .attr("id","currPosId")
        .append("span")
        .html("您当前的位置：")
        .append("span")
        .attr("id","currentPositionSpan")
        .html(currentPosition);
}
function getLeftDiv(contain)
{
    contain.append("div")
        .attr("id","leftDivId");
    addLeftMenuElem();
    d3.select("#leftDivId").classed("no-display",true);
}
function getMainDiv(contain)
{
    contain.append("div")
        .attr({
            'id':'noDataBg',
            "class":'no-data-bg'
        });
    var mainDiv = contain.append("iframe")
        .attr("id","mainDivId")
        .attr("frameBorder","0");
}
/*
* 上边菜单
*
* */
function getTopMenu()
{
    var dataArray = topMenuDataJson.topMenuData;
    var topMenuIconArray = topMenuDataJson.topMenuIconArray;
    d3.select("#topDivId")
        .append("div")
        .attr("id","topContainDiv")
        .append("ul")
        .attr("id","ulNav")
        .attr("class","nav");
    for(var i = 0;i < dataArray.length;i++)
    {
        var topDiv = d3.select(".nav")
            .append("li")
            .attr("id","topMenuLi" + i);
        topDiv.append("img")
            .attr("class","topMenuLiIcon")
            .attr("id","topMenuLiIcon" + i)
            .attr("src",topMenuIconArray[i]);
        topDiv.append("h3")
            .attr("id","topMenuH3Icon" + i)
            .html(dataArray[i].item);
        /*
        * IE与谷歌顶部菜单栏图标的margin的偏移不相同
        * */
        var userAgent = window.navigator.userAgent;
        var isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; //判断是否IE浏览器
        var isEdge = userAgent.indexOf("Trident/7.0;") > -1 && !isIE; //判断是否IE的Edge浏览器
        if(isEdge)
        {
            d3.selectAll(".nav li img").style("margin","-20px 0px 0px -22px");
        }else if(isIE){
            d3.selectAll(".nav li img").style("margin","-20px 0px 0px -22px");
        }else{
            d3.selectAll(".nav li img").style("margin","-22px 0px 0px -91px");
        }
        var topDivUl = topDiv.append("ul");
        for(var j = 0;j < dataArray[i].data.length;j++)
        {
            var data = topDivUl.append("li")
                .attr("class","topMenuLiId")
                .append("h3")
                .attr("onClick","liEvent(" + i + "," + j + ")")
                .html(dataArray[i].data[j].item);
        }
    }
}
/*
* 添加左侧菜单栏
* */

function addLeftMenuElem()
{
    d3.select("#leftDivId")
        .append("button")
        .attr({
            "id":'left-btn-control',
            "class":"left-btn-bg"
        })
        .on("click",function(){
            if(d3.select(this).classed("left-btn-bg"))
            {
                d3.select(".menu-div").classed("no-display",true);
                d3.select(this).classed("left-btn-bg",false);
                d3.select(this).classed("left-btn-blue",true);
                d3.select(d3.select("iframe")[0][0].contentDocument.body).select("#mainContainDiv").classed("db-manage-div",false);
                d3.select(d3.select("iframe")[0][0].contentDocument.body).select("#mainContainDiv").classed("db-main-contain",true);
                d3.select(d3.select("iframe")[0][0].contentDocument.body).select("#dbOpterBtn").classed("linechart-btn",false);
                d3.select(d3.select("iframe")[0][0].contentDocument.body).select("#dbOpterBtn").classed("db-oper-btn-hide",true);
            }else{
                d3.select(".menu-div").classed("no-display",false);
                d3.select(this).classed("left-btn-bg",true);
                d3.select(this).classed("left-btn-blue",false);
                d3.select(d3.select("iframe")[0][0].contentDocument.body).select("#mainContainDiv").classed("db-manage-div",true);
                d3.select(d3.select("iframe")[0][0].contentDocument.body).select("#mainContainDiv").classed("db-main-contain",false);
                d3.select(d3.select("iframe")[0][0].contentDocument.body).select("#dbOpterBtn").classed("linechart-btn",true);
                d3.select(d3.select("iframe")[0][0].contentDocument.body).select("#dbOpterBtn").classed("db-oper-btn-hide",false);
            }
        });
    d3.select("#leftDivId")
        .append("div")
        .attr({
            "class":"menu-div"
        });
    d3.select(".menu-div").append("p")
        .attr({
            "id":"leftMenuLi"+0,
            "class":"mainDataBase",
        })
        .on("click",function(){
            liLeftEvent(0,0);
        })
        //.style("color","#57D1F7")
        .html(leftMenuItem[0].item);
    for(var i = 1;i < leftMenuItem.length;i++)
    {
        var leftMenuUlElem = d3.select(".menu-div")
            .append("ul")
            .attr("class","nav");
        var leftMenuLiElem = leftMenuUlElem.append("li")
            .attr({
                "id":"leftMenuLi" + i,
                "class":"leftMenuLi"
            });
        leftMenuLiElem.append("h3")
            //.style("color","#57D1F7")
            .html(leftMenuItem[i].item)
            .append("button")
            .attr({
                "class":"under-btn-blue ul-change-btn"
            });
        var leftMenuConUlElem = leftMenuLiElem.append("ul");
        for(var j = 0;j < leftMenuItem[i].data.length; j++)
        {
            leftMenuConUlElem.append("li")
                .append("h3")
                .style("color","#57D1F7")
                .attr("onClick","liLeftEvent(" + i + "," + j + ")")
                .html(leftMenuItem[i].data[j].item);
        }
    }
}
/*
* 换肤操作
* */
function changeFace()
{
    //alert("换肤操作函数");
}
/*
* 设置
* */
function setFun()
{
    //alert("设置操作函数");
}
/*
* 退出登录操作
* */
function loginOut()
{
    var curName = window.sessionStorage.ux_curUserName;
    var curRole = window.sessionStorage.ux_curUserRole;
    var jsonDataObj = {
        "port"    :"",
        "router"  :"logout",
        "request" :{"mainRequest":"logout", "subRequest":"", "ssubRequest":""},
        "data"    :{"name": curName, "role": curRole},
        "oper"    :"退出系统",
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    $.ajax({
        async :true,
        type  :'post',
        url   :serverAddress  + "/logout",
        data  :{"postData":jsonDataStr,
                "postUserName":window.sessionStorage.ux_curUserName,
                "postUserHandle":window.sessionStorage.ux_userHandle
        },
        error :function(jsonString) {
            loginOutCallback(jsonString);
        },
        success :function(jsonString) {
            loginOutCallback(jsonString);
        },
    });
}
function loginOutCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rtscode = "success")
    {
        window.location.replace("/index.html");
    }else{
        uxAlert("请求失败！");
    }
}
