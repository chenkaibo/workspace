'use strict';
//匹配由数字、26个英文字母或者下划线组成的字符串
function isalphawholename(checkStr)
{
    var Rex = '^[0-9a-zA-Z_]{4,20}$';
    var result;
    if(checkStr.match(Rex))
    {
        result = true
    } else{
        result = false;
    }
    return result;
}
function isNumber(checkStr)
{
    var Rex = '^[0-9]*$';
    var result;
    if(checkStr.match(Rex))
    {
        result = true
    } else{
        result = false;
    }
    return result;
}
function isValidIP(ip)
{
    var reg =  /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/
    return reg.test(ip);
}
/*
 * 验证用户密码
 * */
function passwordCheckout(checkStr)
{
    var Rex = "^(?![a-zA-Z0-9]+$)(?![^a-zA-Z/D]+$)(?![^0-9/D]+$).{8,20}$";
    var result;
    if(checkStr.match(Rex))
    {
        result = true
    } else{
        result = false;
    }
    return result;
}
/*
* 验证Volume名：
* */
//匹配字母开头，由数字、26个英文字母或者下划线组成的字符串长度为4-32位的字符
function isvolumename(str)
{
    var reg = /^[a-zA-Z]\w{0,31}$/;
    var result=str.match(reg);
    if(result == null)
    {
        return false;
    }
    return true;
}
function instanceName(checkStr)
{
    var Rex = /^[a-zA-Z][a-zA-Z0-9_!@#$%^&*]*$/;
    var result;
    if(checkStr.match(Rex))
    {
        result = true
    } else{
        result = false;
    }
    return result;
}
function instancePassword(checkStr)
{
    var Rex = /^(?![a-zA-Z0-9]+$)(?![^a-zA-Z/D]+$)(?![^0-9/D]+$).{6,}$/;
    var result;
    if(checkStr.match(Rex))
    {
        result = true
    } else{
        result = false;
    }
    return result;
}
/*校验新建实例的路径*/
function instancePath(checkStr)
{
    var Rex = "^(/[a-zA-Z]\\w*)+$";
    var result;
    if(checkStr.match(Rex))
    {
        result = true
    } else{
        result = false;
    }
    return result;
}