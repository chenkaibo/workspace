/**
 * Created by Zhang on 2017/1/9.
 */
var net = require('net');
var callFun;
function myListenOpt(){
    this.startServer  = startServer;
}

module.exports = myListenOpt;


function startServer(reqFun,port,ip){
    var num = 1;
    //callFun = reqFun;
    var port = port || '8000';
    var host = ip || '127.0.0.1';
    net.createServer(function(sock){
        console.log('Remote Address:' + sock.remoteAddress + ' Port:' + sock.remotePort);
        sock.on('data', function(data) {
            var dataStr = data.toString();
            var index = dataStr.indexOf("HTTP");
            var paraData = dataStr.substring(5,index-1);
            console.log("===================This is " + num + " times request,at time:"+new Date().toLocaleString()+"=================\n");
            num++;
            reqFun(paraData);
            //console.log("======11111111========");
            //reqFun();
            //console.log("======22222222========");
            sock.end("hello world!\n");
            //sock.destroy();
        });
        sock.on('close', function(data) {
            console.log('Close the connect:' + sock.remoteAddress + ' ' + sock.remotePort);
        });
    }).listen(port);
    console.log('Server listening on port:' + port + "   " + reqFun.name);
}
/*
* unit test
* */
if(0){
    var listen = new myListenOpt();
    listen.startServer(exec,'1510');
    function exec(){
        console.log("************** Function has executed! *****************\n");
    }
}
function A(){
    for(var i=0;i<5000;i++){
        console.log("======================================");
    }
}
function B(){
    for(var j=0;j<5000;j++){
        console.log("|||||||||||||||||||||||||||||||||||||||");
    }
}