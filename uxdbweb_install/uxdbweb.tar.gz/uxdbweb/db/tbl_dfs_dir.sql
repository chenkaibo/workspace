CREATE TABLE tbl_dfs_dir
(
  id serial NOT NULL,
  dfsid varchar(64) NOT NULL,
  name varchar(32) NOT NULL,
  address varchar(32) NOT NULL ,
  connectnum varchar(2048),
  requestnum varchar(2048),
  modules    varchar,
  status     integer,
  CONSTRAINT tbl_dfs_dir_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tbl_dfs_dir
  OWNER TO uxdbwebuser;
COMMENT ON COLUMN tbl_dfs_dir.dfsid IS 'DIR所属DFS的ID';
COMMENT ON COLUMN tbl_dfs_dir.name IS '名称';
COMMENT ON COLUMN tbl_dfs_dir.address IS 'DIR访问地址';
COMMENT ON COLUMN tbl_dfs_dir.connectnum IS '客户端连接数';
COMMENT ON COLUMN tbl_dfs_dir.requestnum IS '内存池请求次数';
COMMENT ON COLUMN tbl_dfs_dir.modules IS '模块信息';
COMMENT ON COLUMN tbl_dfs_dir.status IS '模块状态，0-离线，1-在线';
