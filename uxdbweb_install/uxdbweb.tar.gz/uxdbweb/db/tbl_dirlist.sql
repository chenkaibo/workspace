CREATE TABLE tbl_dirlist
(
  id varchar(64) NOT NULL,
  dfsid varchar(64),
  siteid varchar(64),
  dirname varchar(64),
  ip varchar(32),
  port varchar(10),
  httpport varchar(10),
  state char,
  dirid varchar(64),
  maintype char,
  cfgpath varchar(255),
  inittm varchar(32),
  latesttm varchar(32),

  CONSTRAINT tbl_dirlist_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tbl_dirlist
  OWNER TO uxdbwebuser;
COMMENT ON COLUMN tbl_dirlist.id IS 'DIR ID';
COMMENT ON COLUMN tbl_dirlist.dfsid IS 'DIR所属DFS的ID';
COMMENT ON COLUMN tbl_dirlist.siteid IS '所在站点ID';
COMMENT ON COLUMN tbl_dirlist.dirname IS 'DIR名称';
COMMENT ON COLUMN tbl_dirlist.ip IS 'IP地址';
COMMENT ON COLUMN tbl_dirlist.port IS '端口号';
COMMENT ON COLUMN tbl_dirlist.state IS '启动状态，1:启动，2:停止';
COMMENT ON COLUMN tbl_dirlist.dirid IS '主DIRID';
COMMENT ON COLUMN tbl_dirlist.maintype IS '主备类型';
COMMENT ON COLUMN tbl_dirlist.cfgpath IS '配置文件路径';
COMMENT ON COLUMN tbl_dirlist.inittm IS '首次记录时间';
COMMENT ON COLUMN tbl_dirlist.latesttm IS '最近更新时间';