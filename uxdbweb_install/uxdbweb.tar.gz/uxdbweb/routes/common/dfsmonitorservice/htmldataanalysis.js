/**
 * Created by Administrator on 2017/3/8.
 */
var cheerio = require('cheerio');
var http = require('http');
var dbOpt = require('./dboper');
var gAddressToTable = {};
var gDFSID  = "0";
var gDIRName  = "DIR";
var gDecimal = 4;

exports.setDFSID = function(dfsid){
    if(typeof dfsid != "string"){
        return false;
    }
    gDFSID = dfsid;
    return true;
};

exports.setDIRName = function(dirname){
    if(typeof dirname != "string"){
        return false;
    }
    gDIRName = dirname;
    return true;
};

exports.startMonitor = function(dirAddress,callback){
    if(typeof  callback != "function"){
        return;
    }
    getDIRData(dirAddress,function(DIRData){
        if(DIRData != "error") {
            dealWithDFSData(dirAddress,DIRData,function(){
                callback(DIRData);
            });
        }else{
            callback(DIRData);
        }
    });
};



function dealWithDFSData(DIRAddr,DIRData,callback){
    if(DIRAddr == "" ||  typeof  DIRData == "undefined" || typeof callback != "function"){
        return;
    }
    //DIR
    dealWithDIR(DIRAddr,DIRData,function(ret){
        //MRC AND OSD
        var DIR_serviceRegistryData = DIRData.serviceRegistryData;
        var index = 0;
        if(DIR_serviceRegistryData.length > 0){
            dealWithOneLineServiceRegData(DIR_serviceRegistryData[index]);
        }

        function dealWithOneLineServiceRegData(oneLineData){
            function goNextSteps(){
                index++;
                if(index >= DIR_serviceRegistryData.length){
                    callback();
                    return;
                }else{
                    dealWithOneLineServiceRegData(DIR_serviceRegistryData[index]);
                }
            }

            var uuid = oneLineData.uuid;
            var dumpData = oneLineData.dump.data;
            if(dumpData.type == "SERVICE_TYPE_MRC"){
                var name = uuid;
                var data = oneLineData.dump.data;
                var url  = data.status_page_url;
                getMRCData(url,function(MRCData){
                    if(MRCData != "error"){
                        dealWithMRC(data,MRCData,function(ret){
                            goNextSteps();
                        });

                    }else {
                        goNextSteps();
                    }

                });

            }else if(dumpData.type == "SERVICE_TYPE_OSD"){
                var name = uuid;
                var data = oneLineData.dump.data;
                var url = data.status_page_url;
                getOSDData(url, function (OSDData) {
                    if (OSDData != "error") {
                        dealWithOSD(data, OSDData,function(ret){
                            goNextSteps();
                        });
                    }else{
                        goNextSteps();
                    }

                });

            }else if(dumpData.type == "SERVICE_TYPE_VOLUME"){
                //reserved
                goNextSteps();
            }else {
                goNextSteps();
            }

        }


    });


    function dealWithDIR(address,DIRInfo,callbackFunc){
        if(typeof  callbackFunc != "function" || address == ""){
            return;
        }
        var DIRData = {};
        DIRData.dfsid = gDFSID;
        DIRData.name = gDIRName;
        DIRData.address = address;
        DIRData.clientConnects = DIRInfo.baseInfo.load["# client connections"];
        var memory = DIRInfo.baseInfo.memory["Buffer Pool stats"];
        DIRData.memReqNum =  commonGetMemRequestNum(memory);
        //address map
        var modules = [];
        var serviceRegData = DIRInfo.serviceRegistryData;
        for(var i = 0; i < serviceRegData.length; i++){
            var dumpData = serviceRegData[i].dump.data;
            if(dumpData.type == "SERVICE_TYPE_MRC" || dumpData.type == "SERVICE_TYPE_OSD"){
                var oneMap = {};
                oneMap.type = dumpData.type;
                oneMap.name = serviceRegData[i].uuid;
                oneMap.address = dumpData.status_page_url;
                modules.push(oneMap);
            }

        }
        DIRData.modules = JSON.stringify(modules);
        //store--db
        console.log(DIRData);
        DIRDBOpt(DIRData,function(ret){
            callbackFunc(ret);
        });

    }

    function dealWithMRC(DIR_MRC,MRC_Detail,callbackFunc){
        if(typeof  callbackFunc != "function"){
            return;
        }
        var commonFunc = new commonFunction();
        var defaultUnit  = "MB";
        var MRCData = {};
        MRCData.dfsid = gDFSID;
        //load
        MRCData.load = (Number(DIR_MRC.load.split('%')[0])/100).toFixed(gDecimal);
        //url
        MRCData.address = DIR_MRC.status_page_url;
        //name
        var name = DIR_MRC["name"];
        MRCData.name = name.split("MRC @ ")[1];
        //RAM usage
        var totalRAM = DIR_MRC["totalRAM"];
        var usedRAM = DIR_MRC["usedRAM"];
        var tmpStr = totalRAM.replace(/\(|\)/g,"_");
        MRCData.totalRAM = tmpStr.split("_")[1];
        tmpStr = usedRAM.replace(/\(|\)/g,"_");
        MRCData.usedRAM = tmpStr.split("_")[1];
        MRCData.RAMUsage = ((Number(usedRAM.split(' ')[0])/ Number(totalRAM.split(' ')[0]))).toFixed(gDecimal);
        //# client connections
        MRCData.clientConnects = MRC_Detail.load["# client connections"];
        //Volumes
        var volumes = MRC_Detail.volumes;
        //volumeNum
        MRCData.volumeNum = volumes.length;
        //volumeInfo
        //get totalDisk
        var totalOccupiedDisk = 0;
        for(var j = 0; j < volumes.length; j++){
            var occupiedDiskStr = volumes[j].value["occupied disk space:"];
            var occupiedDisk = commonFunc.getUnitMBData(Number(occupiedDiskStr.split(' ')[0]),occupiedDiskStr.split(' ')[1]);
            totalOccupiedDisk += occupiedDisk;
        }
        var volumeInfo = [];
        for(var i = 0; i < volumes.length; i++){
            var oneVolumeInfo = {};
            var oneVolume = volumes[i];
            oneVolumeInfo.volumeName = oneVolume.key;
            var volumeValue = oneVolume.value;
            var freeDiskStr = volumeValue["free disk space:"];
            var occupiedDiskStr = volumeValue["occupied disk space:"];
            var freeDisk = commonFunc.getUnitMBData(Number(freeDiskStr.split(' ')[0]),freeDiskStr.split(' ')[1]) ;
            var occupiedDisk = commonFunc.getUnitMBData(Number(occupiedDiskStr.split(' ')[0]),occupiedDiskStr.split(' ')[1]);
            var totalROM = Number(freeDisk) + totalOccupiedDisk;
            oneVolumeInfo.freeDisk = freeDiskStr;
            oneVolumeInfo.occupiedDisk = occupiedDiskStr;
            oneVolumeInfo.totalDisk = totalROM.toString() +" "+ defaultUnit;
            oneVolumeInfo.diskUsage = ((Number(occupiedDisk)/totalROM)).toFixed(gDecimal);
            volumeInfo.push(oneVolumeInfo);
        }
        MRCData.volumes = JSON.stringify(volumeInfo);
        //store --db
        console.log(MRCData);

        MRCDBOpt(MRCData,function(ret){
            callbackFunc(ret);
        });
    }

    function dealWithOSD(DIR_OSD,OSD_Detail,callbackFunc){
        if(typeof  callbackFunc != "function"){
            return;
        }
        var commonFunc = new commonFunction();
        var defaultUnit  = "MB";
        var OSDData = {};
        OSDData.dfsid = gDFSID;
        //load
        OSDData.load = (Number(DIR_OSD.load.split('%')[0])/100).toFixed(gDecimal);
        //url
        OSDData.address = DIR_OSD.status_page_url;
        //name
        var name = DIR_OSD["name"];
        OSDData.name = name.split("OSD @ ")[1];
        //RAM usage
        var totalRAM = DIR_OSD["totalRAM"];
        var usedRAM = DIR_OSD["usedRAM"];
        var tmpStr = totalRAM.replace(/\(|\)/g,"_");
        OSDData.totalRAM = tmpStr.split("_")[1];
        tmpStr = usedRAM.replace(/\(|\)/g,"_");
        OSDData.usedRAM = tmpStr.split("_")[1];
        OSDData.RAMUsage = ((Number(usedRAM.split(' ')[0])/ Number(totalRAM.split(' ')[0]))).toFixed(gDecimal);

        //# client connections
        OSDData.clientConnects = OSD_Detail.load["# client connections"];
        //diskUsage
        tmpStr = DIR_OSD.total.replace(/\(|\)/g,"_");
        OSDData.totalDisk = tmpStr.split("_")[1];
        var totalBytesDisk = Number(DIR_OSD.total.split(' ')[0]);
        var freeDisk =  OSD_Detail.memory["Free Disk Space"];
        OSDData.freeDisk =  freeDisk;
        var freeBytesDisk = commonFunc.getUnitMBData(Number(freeDisk.split(' ')[0]),freeDisk.split(' ')[1]) * 1024*1024;
        OSDData.diskUsage = ((1 - freeBytesDisk/totalBytesDisk)).toFixed(gDecimal);
        //store--db
        console.log(OSDData);
        OSDDBOpt(OSDData,function(ret){
            callbackFunc(ret);
        });
    }

   function DIRDBOpt(data,callback){
       if(data === undefined || typeof callback == "undefined"){
           return;
       }

       var DIROpt = dbOpt.DIRDBOper().getInstance();
       DIROpt.storeDIR(data,function(ret){
           callback(ret);
       });

   }
    function MRCDBOpt(data,callback){
        if(data === undefined || typeof callback == "undefined"){
            return;
        }

        var MRCOpt = dbOpt.MRCDBOper().getInstance();
        MRCOpt.storeMRC(data,function(ret){
            callback(ret);
        });

    }
    function OSDDBOpt(data,callback){
        if(data === undefined || typeof callback == "undefined"){
            return;
        }

        var OSDOpt = dbOpt.OSDDBOper().getInstance();
        OSDOpt.storeOSD(data,function(ret){
            callback(ret);
        });

    }


    function commonGetMemRequestNum(memReqStringNum){
        if(typeof memReqStringNum != "string"){
            return 0;
        }
        var numRequests = memReqStringNum.split("creates");
        var totalNum = 0;
        for(var i = 0; i < numRequests.length; i++){
            var index = numRequests[i].indexOf('numRequests =');
            if(-1 != index){
                var numArray = numRequests[i].split('numRequests =');
                var num = Number(numArray[1]);
                totalNum += num;
            }

        }
        return totalNum;
    }

}

//getDIRData(testAddress);
function getDIRData(address,callbackFunc) {
    if (address == "" || typeof callbackFunc != "function") {
        return;
    }
    //set map
    gAddressToTable[address] = "tbl_dfs_dir";
    getHtmlData(address, function (html) {
        if (html == "" || html == "error") {
            callbackFunc("error");
            return;
        }
        try{

            var retVal =  analysisDIRHtml(html);
            callbackFunc(retVal);
            return;
        }catch(err){
            console.log(err);

        }
        console.log("getDirData error");
        callbackFunc("error");

    });
}


//getMRCData(testAddress);
function getMRCData(address,callbackFunc) {
    if (address == "" || typeof callbackFunc != "function") {
        return;
    }
    //set map
    gAddressToTable[address] = "tbl_dfs_mrc";
    getHtmlData(address, function (html) {
        if (html == "" || html == "error") {
            callbackFunc("error");
            return;
        }
        try{

            var retVal =  analysisMRCHtml(html);
            callbackFunc(retVal);
            return;
        }catch(err){
            console.log(err);
        }
        console.log("getMRCData error");
        callbackFunc("error");

    });
}

//getOSDData(addrOSD);
function getOSDData(address,callbackFunc) {
    if (address == "" || typeof callbackFunc != "function") {
        return;
    }
    //set map
    gAddressToTable[address] = "tbl_dfs_osd";
    getHtmlData(address, function (html) {
        if (html == "" || html == "error") {
            callbackFunc("error");
            return;
        }
        try{

            var retVal =  analysisOSDHtml(html);
            callbackFunc(retVal);
            return;
        }catch(err){
            console.log(err);

        }
        console.log("getOSDData error");
        callbackFunc("error");

    });
}


function getHtmlData(address,callbackFunc){
    if(address == "" || typeof callbackFunc != "function"){
        return;
    }
    //get webdata
   var req = http.get(address,function(reqest,respone){
        var html = '';
        reqest.on('data',function(data){
            html += data;
        });
        reqest.on('end',function(){
            callbackFunc(html);
        });
    });

    req.on('error',function(err){
        console.error(err);
        dealWithError(err,function(ret){
            callbackFunc("error");
        });

    });

    function dealWithError(err,callback){
        if(typeof err == "undefined" || typeof callback != "function"){
            return;
        }
        if(typeof err.code == "undefined"){
            callback(null);
            return;
        }

        if(err.code == "ECONNREFUSED"){
            var tableName =  gAddressToTable[err.address];
            if(tableName === undefined){
                callback(null);
                return;
            }
            var searchAddress = tableName+":"+err.port;
            if(tableName == "tbl_dfs_dir"){
                dbOpt.DIRDBOper().getInstance().modifyStatus(gDFSID,searchAddress,0,function(retDIR){
                    callback(retDIR);
                });

            }else if(tableName == "tbl_dfs_mrc"){
                dbOpt.MRCDBOper().getInstance().modifyStatus(gDFSID,searchAddress,0,function(retMRC){
                    callback(retMRC);
                });

            }else if(tableName == "tbl_dfs_osd"){
                dbOpt.OSDDBOper().getInstance().modifyStatus(gDFSID,searchAddress,0,function(retOSD){
                    callback(retOSD);
                });

            }else {
                console.log("table is not existence");
                callback(null);
            }
        }


    }

}


function analysisDIRHtml(html){
    if(typeof html != "string"){
        return [];
    }
    var $ = cheerio.load(html, {ignoreWhitespace: true,normalizeWhitespace:true});
    var frameTable = $("table[border='0']")[0];
    //get data with class->'title'
    var classTitleData = analysisClassTitleData( frameTable);

    var boxTable = $("table[frame='box']");
    //analysis Address Mapping
    var uuidAddr = $("td.uuid");
    var dumpAddr = $("td.dump");
    var addressMapData = analysisAddressMapData(uuidAddr,dumpAddr);
    //analysis Service Registry
    var uuidReg = $("td.uuid",boxTable[1]);
    var dumpReg = $("td.dump",boxTable[1]);
    var serviceRegistryData = analysisServiceRegistryData(uuidReg,dumpReg);
    //analysis Configurations
    var uuidConfig = $("td.uuid",boxTable[2]);
    var dumpConfig = $("td.dump",boxTable[2]);
    var configData = analysisConfigData(uuidConfig,dumpConfig);

    var dirData = {};
    dirData.baseInfo = classTitleData;
    dirData.addressMapData = addressMapData;
    dirData.serviceRegistryData = serviceRegistryData;
    dirData.configData = configData;

    return dirData;

    function analysisAddressMapData(uuidAddr,dumpAddr){
        if(uuidAddr.length == 0 || dumpAddr.length == 0){
            return [];
        }
        var retArray = [];
        var count = 0;
        for(var i = 0; i < uuidAddr.length; i++){
            var tablePreDom = uuidAddr[i].parent.parent.prev;
            if(tablePreDom.name == "br"){
                count++;
                if(count > 1){
                    return retArray;
                }

            }
            var oneLineData = {};
            //uuidData
            var uuidData = uuidAddr[i].children[0].data;
            //dumpData
            var dumpData = getDumpData(dumpAddr[i]);
            oneLineData.uuid = uuidData;
            oneLineData.dump = dumpData;
            retArray.push(oneLineData);
        }
        //According to separator ,<br>
        function getDumpData(dumpDom){
            if(dumpDom.name != "td"){
                return [];
            }

            var childTable = cheerio("table",dumpDom);

            //childTable[0]---frame data
            var versionDom = cheerio("b",dumpDom)[0];
            var versionData = versionDom.children[0].data;
            //childTable[1]---main data
            var mainData = [];
            var mainDataChild = childTable[1].children;
            for(var i = 0; i < mainDataChild.length; i++){
                var oneLineData = [];
                var oneLineTrDom = mainDataChild[i].children;
                for(var j = 0; j < oneLineTrDom.length; j++){
                    var oneTdData = oneLineTrDom[j].children[0].data;
                    oneLineData.push(oneTdData);
                }
                mainData.push(oneLineData);
            }
           var dumpData = {};
            dumpData.version = versionData;
            dumpData.data = mainData;
            return dumpData;

        }
    }


    function analysisServiceRegistryData(uuidReg,dumpReg){
        var commonFunc = new commonFunction();
       return commonFunc.commonGetUUIDAndDumpTableData(uuidReg,dumpReg);
    }

    function analysisConfigData(uuidConfig,dumpConfig){
        var commonFunc = new commonFunction();
        return commonFunc.commonGetUUIDAndDumpTableData(uuidConfig,dumpConfig);
    }


    function analysisClassTitleData(frameTable){
        if(typeof  frameTable != "object"){
            return [];
        }
        var commonFunc = new commonFunction();
        var itemData = commonFunc.commonGetClassTitleData(frameTable);
        var retVal = {};
        //itemData[0]--Version
        retVal.version = analysisVersionData(itemData[0]);
        //itemData[1]--Configuration
        //itemData[2]--Load
        retVal.load = analysisLoadData(itemData[2]);
        //itemData[3]--Transfer
        //itemData[4]--VM Info / Memory
        retVal.memory = analysisMemoryData(itemData[4]);
        //itemData[5]--Time
        //itemData[6]--Detailed Status
        return retVal;

    }

    function analysisMemoryData(memDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisVMMemoryData(memDom);

    }

    function analysisLoadData(loadDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(loadDom);

    }

    function analysisVersionData(versionDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(versionDom);
    }

}


var commonFunction = function() {

    this.commonAnalysisClassTitleData = function (domArray) {
        if (typeof domArray != "object") {
            return [];
        }
        var retVal = {};
        for (var i = 0; i < domArray.length; i++) {
            //get row data
            var lineData = [];
            var lingDataDom = domArray[i].children;
            for (var j = 0; j < lingDataDom.length; j++) {
                if (typeof lingDataDom[j].name != "undefined" && lingDataDom[j].children.length > 0) {
                    var type = lingDataDom[j].children[0].type || "";
                    if (type != "text") {
                        lineData.push("");
                    } else {
                        lineData.push(lingDataDom[j].children[0].data);
                    }

                }
            }
            if(typeof lineData[0] != "undefined"){
                retVal[lineData[0]] = lineData[1] || "";
            }

        }

        return retVal;
    };
    this.commonGetUUIDAndDumpTableData = function (uuid, dump) {

        function commonGetDumpData(dumpDom) {
            if (dumpDom.length == 0) {
                return [];
            }
            var retVal = {};
            var dumpData = {};
            var dataChildren = dumpDom.children[0].children;
            for (var i = 0; i < dataChildren.length; i++) {
                var oneLineData = [];
                if (dataChildren[i].name == "tr") {
                    var mainTdDom = dataChildren[i].children;
                    var key = mainTdDom[0].children[0].data;
                    oneLineData.push(key);
                    //<b></b>
                    var domB = cheerio("b", mainTdDom[1])[0];
                    var value = "";
                    if (domB.children.length > 0) {
                        var domA = cheerio("a",domB);
                        if(domA.length > 0 ){
                            value = domA[0].children[0].data;
                        }else{
                            value = domB.children[0].data;
                        }

                    }
                    oneLineData.push(value);
                    if(typeof oneLineData[0] != "undefined"){
                        dumpData[oneLineData[0]] = oneLineData[1] || "";
                    }


                } else if (dataChildren[i].name == "td" && dataChildren[i].children.length > 1) {
                    var version = dataChildren[i].children[1].children[0].data;
                    retVal.version = version;
                }
            }
            retVal.data = dumpData;
            return retVal;

        }

        if (uuid.length == 0 || dump.length == 0) {
            return [];
        }
        var retVal = [];
        for (var i = 0; i < uuid.length; i++) {
            var oneLineData = {};
            var uuidData = uuid[i].children[0].data;
            var dumpData = commonGetDumpData(dump[i]);
            oneLineData.uuid = uuidData;
            oneLineData.dump = dumpData;
            retVal.push(oneLineData);
        }
        return retVal;
    };

    this.commonGetClassTitleData = function (frameTable) {
        if (typeof frameTable == "undefined" || frameTable.name != "table") {
            return;
        }
        var oneItemData = [];
        var allItemData = [];
        var frameTbChild = frameTable.children;
        var bBreak = false;
        var count = 0;
        for (var i = 0; i < frameTbChild.length; i++) {
            if (frameTbChild[i].name != "tr") {
                continue;
            }

            var childrenEm = frameTbChild[i].children;
            for (var j = 0; j < childrenEm.length; j++) {
                if (childrenEm[j].name == "td" && childrenEm[j].attribs.class == "title") {
                    bBreak = true;
                    count++;
                }
            }
            //store heading
            if (1 == count) {
                oneItemData.push(frameTbChild[i]);
            }

            if (!bBreak) {
                oneItemData.push(frameTbChild[i]);
            }
            else if (count > 1) {
                bBreak = false;
                //store data
                allItemData.push(oneItemData);
                //clean cache ,restore index of array
                oneItemData = new Array();
                oneItemData.push(frameTbChild[i]);
            }

        }
        return allItemData;
    };

    this.commonAnalysisVMMemoryData = function (vmDom) {
        if (typeof vmDom != "object") {
            return [];
        }
        var retVal = {};
        for (var i = 0; i < vmDom.length; i++) {
            var oneLineData = [];
            var tdData = vmDom[i].children;
            for (var j = 0; j < tdData.length; j++) {
                if (typeof tdData[j].name != "undefined" && tdData[j].children.length > 0) {
                    var type = tdData[j].children[0].type || "";
                    if (type == "text") {
                        oneLineData.push(tdData[j].children[0].data);
                    } else if (type == "tag") {
                        oneLineData.push(tdData[j].children[0].children[0].data);
                    } else {
                        oneLineData.push("");
                    }

                }
            }
            if(typeof oneLineData[0] != "undefined"){
                retVal[oneLineData[0]] = oneLineData[1] ||"";
            }

        }
        return retVal;

    };
    this.getUnitMBData = function(number,unit){
        if(isNaN(number)){
           return 0;
        }
        var retVal = 0;
        switch (unit){
            case "TB":{
                retVal = number * 1024 * 1024;
            }break;
            case "GB":{
                retVal = number * 1024;
            }break;
            case "MB":{
                retVal = number;
            }break;
            case "KB":{
                retVal = number/1024;
            }break;
            case "bytes":{
                retVal = (number/1024)/1024;
            }break;
            default :{
                console.log("undefined unit");
            }
        }
        return retVal;
    };


};


function analysisMRCHtml(html){
    if(typeof html != "string"){
        return [];
    }
    var $ = cheerio.load(html, {ignoreWhitespace: true,normalizeWhitespace:true});
    var frameTable = $("table[border='0']")[0];
    var classTitleData = analysisClassTitleData( frameTable);
    return classTitleData;

    function analysisClassTitleData(frameTable){
        if(typeof  frameTable != "object"){
            return [];
        }
        var commonFunc = new commonFunction();
        var itemData = commonFunc.commonGetClassTitleData(frameTable);
        var retVal = {};
        //itemData[0]--Version
        retVal.version = analysisVersionData(itemData[0]);
        //itemData[1]--Configuration
        retVal.config = analysisConfigData(itemData[1]);
        //itemData[2]--Load
        retVal.load = analysisLoadData(itemData[2]);
        //itemData[3]--Requests
        retVal.requests = analysisRequestData(itemData[3]);
        ////itemData[4]--Volumes
        retVal.volumes = analysisVolumesData(itemData[4]);
        //itemData[5]--VM Info / Memory
        retVal.memory = analysisVMMemoryData(itemData[5]);
        //itemData[6]--Time
        retVal.time = analysisTimeData(itemData[6]);
        //itemData[7]--Detailed Status
        return retVal;

    }

    function analysisVersionData(versionDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(versionDom);
    }

    function analysisLoadData(loadDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(loadDom);

    }

    function analysisConfigData(configDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(configDom);

    }

    function analysisRequestData(requestsDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(requestsDom);

    }

    function analysisVolumesData(volumesDom){
        if(typeof volumesDom != "object"){
            return [];
        }
        var commonFunc = new commonFunction();
        var keysDom = cheerio("td[align='left']",volumesDom);
        var table = cheerio("table",volumesDom);
        var retVal = [];
        for(var i = 0; i < keysDom.length; i++){
            var oneLineData = {};
            oneLineData.key = keysDom[i].children[0].data;
            oneLineData.value = commonFunc.commonAnalysisClassTitleData(table[i].children);
            retVal.push(oneLineData);
        }
        return retVal;
    }

    function analysisVMMemoryData(vmDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisVMMemoryData(vmDom);
    }

    function analysisTimeData(timeDom){

        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(timeDom);
    }

}

function analysisOSDHtml(html){
    if(typeof html != "string"){
        return [];
    }
    var $ = cheerio.load(html, {ignoreWhitespace: true,normalizeWhitespace:true});
    var frameTable = $("table[border='0']")[0];
    var classTitleData = analysisClassTitleData( frameTable);
    return classTitleData;

    function analysisClassTitleData(frameTable){
        if(typeof  frameTable != "object"){
            return [];
        }
        var commonFunc = new commonFunction();
        var itemData = commonFunc.commonGetClassTitleData(frameTable);
        var retVal = {};
        //itemData[0]--Version
        retVal.version = analysisVersionData(itemData[0]);
        //itemData[1]--Configuration
        retVal.config = analysisConfigData(itemData[1]);
        //itemData[2]--Load
        retVal.load = analysisLoadData(itemData[2]);
        //itemData[3]--transfer
        retVal.transfer = analysisTransferData(itemData[3]);
        //itemData[4]--VM Info / Memory
        retVal.memory = analysisVMMemoryData(itemData[4]);
        //itemData[5]--Time
        retVal.time = analysisTimeData(itemData[5]);
        return retVal;

    }

    function analysisVersionData(versionDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(versionDom);
    }

    function analysisConfigData(configDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(configDom);

    }

    function analysisLoadData(loadDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(loadDom);

    }

    function analysisTransferData(transferDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(transferDom);

    }

    function analysisVMMemoryData(vmDom){
        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisVMMemoryData(vmDom);
    }

    function analysisTimeData(timeDom){

        var commonFunc = new commonFunction();
        return commonFunc.commonAnalysisClassTitleData(timeDom);
    }

}