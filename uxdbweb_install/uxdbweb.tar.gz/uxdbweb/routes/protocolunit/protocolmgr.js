﻿var ProtOptUnit = require('./protocoloptunit');

/*
 功能：协议处理接口函数
 参数：reqJson请求的数据 callback(isErr,resJson)
 返回值：无
 */
 function protocolOpt(reqJson,callback)
{
    if(typeof callback !== 'function')
    {
        return;
    }
    var protOpt = new ProtOptUnit();
    protOpt.linkHost(reqJson,function(isErr)
    {
        if(isErr)
        {
            callback(true,"error_link");
            return;
        }
        protOpt.sendMsg(reqJson,function(isErr,resJson)
        {
            if(isErr)
            {
                callback(true,resJson);
                protOpt = null;
                return;
            }
            callback(false,resJson);
            protOpt = null;
        });
    });
}
exports.execProtocol = function(reqJson,callback)
{
    protocolOpt(reqJson,callback);
}

// unit test
function sendRequest()
{
    var reqJson = {
        'username':'',
        'userrole':'',
        'hostip':'192.168.1.137',
        'hostport':'5000',
        'type':'sync',       //需要反馈（同步请求）
        'maincmd':2,
        'subcmd':2,
        'ssubcmd':1,
        'dbnum':1,
        'data':{
            'isDFS':0,
            'dir':'uxdb3333'
        }
    }
    protocolOpt(reqJson,function(isErr,resJson)
    {
        if(isErr)
        {
            console.log('[protpcolmgr]protocolOpt is failed.');
            return;
        }
        console.log('[protpcolmgr] revJson = %s',JSON.stringify(resJson));
    });
}
function startListen(){
    var listenFun = require('./../listenandsendrequest');
    var listenObj = new listenFun();
    listenObj.startServer(sendRequest,'6969');
}
//startListen();
//sendRequest()