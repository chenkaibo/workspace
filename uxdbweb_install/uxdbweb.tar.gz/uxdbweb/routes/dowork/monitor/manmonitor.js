/**
 * Created by Administrator on 2017/3/23.
 */

var monitorMgr = require("./monitormgr");
var dfsController = require('../../common/dfsmonitorservice/controller');

exports.triggerFunction = triggerFunction;
var mainRequestProcFuncs = {
    "getDFSMonitorData": getDFSMonitorData
};

function triggerFunction(postData, gResponseFunction) {
    if (postData.length <= 0) {
        return;
    }
    if (typeof gResponseFunction != "function") {
        return;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: ""
    };
    var jsonObj = JSON.parse(postData);
    var mainRequest = jsonObj.request.mainRequest;
    var procFunc = mainRequestProcFuncs[mainRequest];
    if (typeof procFunc != "function") {
        gResponseFunction(JSON.stringify(rtRes));
    }
    else {
        procFunc(jsonObj, gResponseFunction);
    }
}

function getDFSMonitorData(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return;
    }
    var resJson = {
        rstcode: "error",
        desc: "",
        data: []
    };
    var reqData = {
        dfsid: jsonObj.data.dfsid
    };
    var subRequest = jsonObj.request.subRequest;
    if (subRequest == "first") {
        monitorMgr.getInstance().getFirstDFSId(jsonObj.data, function (isErr, rst) {
            if (isErr) {
                resJson.desc = "�����Ϣ��ѯʧ�ܣ�";
                gResponseFunction(JSON.stringify(resJson));
                return;
            }
            if (rst.length == 0) {
                resJson.desc = "���޿���DFS��";
                gResponseFunction(JSON.stringify(resJson));
                return;
            }
            reqData.dfsid = rst[0].id;
            getDFSMonitorDataOpt(reqData);
        })
    } else {
        getDFSMonitorDataOpt(reqData)
    }

    function getDFSMonitorDataOpt(reqDb) {

        dfsController.getDFSMonitorData(reqDb, callback);

        function callback(isErr, ret) {
            if (isErr) {
            resJson.desc = "���ݿ���Ϣ��ȡʧ�ܣ�";
                gResponseFunction(JSON.stringify(resJson));
                return;
            }
            resJson.rstcode = "success";
            resJson.data = ret;
            gResponseFunction(JSON.stringify(resJson));
        }
    }
}



