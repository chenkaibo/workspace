
function piechartFun(dataOptions){
    var defalutDataOptions = {
        'containerId': '',
        'data': ''
    };
    var initDataOption = {};//���ò����ʹ�õĶ���
    for (var initTem in defalutDataOptions) {
        initDataOption[initTem] = defalutDataOptions[initTem];
    }
    for (var tem in dataOptions) {
        initDataOption[tem] = dataOptions[tem];
    }
    var width = 280,
        height = 280,
        endAngle = 2 * Math.PI,
        colors = d3.scale.category20();
    if(d3.select("#" + initDataOption.containerId).select("svg")[0][0] != null)
    {
        d3.select("#" + initDataOption.containerId).select("svg").remove();
    }
    var svg = d3.select("#" + initDataOption.containerId).append("svg")
        .attr("class", "pie")
        .attr("height", height)
        .attr("width", width);

    svg.append("circle").attr({
        'cx':'50%',
        'cy':'50%',
        'r':'115'
    }).style({
            'fill':'#050c12',
            'stroke':'#57D1f7',
            'opacity':'60%'
        });
    function render(outerR,innerR) {
        var arc = d3.svg.arc().outerRadius(outerR).innerRadius(innerR);
        svg.select("g").remove();
        //���Ӷ�Ӧ��Ŀ�Ļ���
        var arcs = svg.selectAll("g")
            .append("g")
            .attr("transform", "translate(0,0)");
        //���ӻ���·��Ԫ��
        arcs.append("path")
            .attr("fill",function(d,i){
                if(d.data.name != "others"){
                    return colors(i);
                }
                else if(d.data.name == "others"){
                    return '#03101b';
                }
            })
            .attr("d",function(d){
                return arc(d);//ʹ�û���������ȡ·��
            })
            .attr("opacity",'60%')
            .transition()
            .duration(1000)
            .attrTween("d", function (d) {
                var start = {startAngle: 0, endAngle: 0};
                var interpolate = d3.interpolate(start, d);
                return function (t) {
                    return arc(interpolate(t));
                };
            });
        //�������ӻ������ֵ�ֱ��Ԫ��
        arcs.append("line")
            .style("stroke","#57D1F7")
            .each(function(d,i){
                d.textLine={x1:0,y1:0,x2:0,y2:0};
            })
            .attr("x1",function(d,i){
                d.textLine.x1=arc.centroid(d)[0]*1.3;
                return d.textLine.x1;
            })
            .attr("y1",function(d){
                d.textLine.y1=arc.centroid(d)[1]*1.1;
                return d.textLine.y1;
            })
            .attr("x2",function(d){
                var bx=arc.centroid(d)[0]*2;
                d.textLine.x2=bx;
                return d.textLine.x2;
            })
            .attr("y2",function(d,i){
                d.textLine.y2=arc.centroid(d)[1]*2;
                return d.textLine.y2;
            });
        var fontsize=14;
        arcs.append("text")
            .attr("transform",function(d){
                var x=0;
                var y=0;
                x=(d.textLine.x1+d.textLine.x2+40)/2;
                y=d.textLine.y1;
                y=y>0?y+fontsize*2.8:(y*1.5-10);
                return "translate("+x+","+y+")";
            })
            .style("text-anchor","middle")
            .style("font-size",fontsize)
            //.style("background-color","red")
            .text(function(d,i){
                return d.data.name;
            });

        //����һ����ʾ��
        var tooltip=d3.select("body")
            .append("div")
            .attr("class","tooltip")
            .style({
                "display":'block',
                "opacity":0.0
            });
        arcs.on("mouseover",function(d,i){
            /*
             �������ʱ��
             ��1��ͨ�� selection.html() ��������ʾ�������
             ��2��ͨ��������ʽ left �� top ���趨��ʾ���λ��
             ��3���趨��ʾ���͸����Ϊ1.0����ȫ��͸����
             */
            var percent=Number(d.value)/d3.sum(initDataOption.data,function(d){
                    return d.frequency;
                })*100;
            tooltip.html(d.data.name+"<br/>"+(percent.toFixed(4)+"%"))
                .style("left",(d3.event.pageX)+"px")
                .style("top",(d3.event.pageY+20)+"px")
                .style("display","block")
                .style("opacity",1.0);
            if(d.data.name != "others"){
                tooltip.style("box-shadow","10px 0px 0px"+colors(i));//����ʾ���������Ӱ
            }
            else if(d.data.name == "others"){
                tooltip.style("box-shadow","10px 0px 0px"+"#050c12");//����ʾ���������Ӱ
            }
        })
            .on("mousemove",function(d){
            /* ����ƶ�ʱ��������ʽ left �� top ���ı���ʾ���λ�� */
            tooltip.style("left",(d3.event.pageX)+"px")
                .style("top",(d3.event.pageY+20)+"px")
                .style("display","block");
        }).on("mouseout",function(d){
            //����Ƴ� ͸������Ϊ0
            tooltip.style("opacity",0.0)
                .style("display","none");
        });
    }

    //ת������
    var pie=d3.layout.pie() //������״ͼ
        .value(function(d){
            return d.frequency;
        });//ֵ������
    //initDataOption.dataΪת��ǰ������, piedataΪת���������
    var piedata=pie(initDataOption.data);
    function renderBg(outerRadius,innerRadius) {
        var arc = d3.svg.arc().outerRadius(outerRadius).innerRadius(innerRadius);
        svg.select("g").remove();
        //���Ӷ�Ӧ��Ŀ�Ļ���
        var arcs = svg.selectAll("g")
            .data(piedata)
            .enter()
            .append("g")
            .attr("transform", "translate(140,140)");
        //���ӻ���·��Ԫ��
        arcs.append("path")
            .attr("fill",'#03101b')
            .transition()
            .duration(1000)
            .attrTween("d", function (d) {
                var start = {startAngle: 0, endAngle: 0};
                var interpolate = d3.interpolate(start, d);
                return function (t) {
                    return arc(interpolate(t));
                };
            });
    }
    renderBg(100,50);
    render(100,60);
}