
function uxAjaxInterface () {}
uxAjaxInterface.prototype.ajaxRequest = function(bAsync,dataJsonStr,callbackFunc)
{
    $.ajax({
        async : bAsync,
        type : 'post',
        url :  serverAddress + "/dowork",
        data : {"postData":dataJsonStr,
                "postUserName":window.sessionStorage.ux_curUserName,
                "postUserHandle":window.sessionStorage.ux_userHandle,
        },
        error : function(jsonString) {
            var errJsonObj = jsonString;
            if(typeof jsonString == "string")
            {
                errJsonObj  = JSON.parse(jsonString);
            }
            errJsonObj.rstcode = "error";
            callbackFunc(JSON.stringify(errJsonObj));
        },
        success : function(jsonString) {
            var jsonObj = JSON.parse(jsonString);
            if(jsonObj.rstcode == "error_link")
            {
                uxAlert("数据库连接失败！");
                //do something

                return;
            }
            if(jsonObj.rstcode == "error_refuse")
            {
                uxAlert("服务器连接已失效，请重新登录！",false,function(){
                    top.window.location.replace("/index.html");
                });
                return;
            }
            callbackFunc(jsonString);
        }
    });
};
