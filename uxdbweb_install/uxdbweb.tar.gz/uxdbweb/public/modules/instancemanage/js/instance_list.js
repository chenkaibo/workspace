'use strict';
var instanContainDiv,initElemFlag = true,setTimeFun;
window.onload = function ()
{
    getInstanceList("#instanaceBodyId");
    top.d3.select("#leftDivId").classed("no-display",true);
    top.d3.select("#topMenuLi4").classed("top-del-menu",true);
    window.parent.menuOperFun();
};
/**********************界面弹出框的处理***********************************/
function popUpInsBoxOper()
{
    var w,h;
    function getSrceenWH(){
        w = $(window).width();
        h = $(window).height();
        $('#dialogBg').width(w).height(h);
    }

    window.onresize = function(){
        getSrceenWH();
    };
    $(window).resize();
    $(function(){
        getSrceenWH();
        newInsFun();
        d3.select('.searchSite-btn').on('click',function(){
            queryInstance();
        });
    });
}
/*
* 实例列表元素
* */
var queryFlag = false;
function getInstanceList(contain)
{
    window.focus();
    changePath("云数据库管理->实例管理");
    window.sessionStorage.ux_pagePath = "instanManage,main";
    d3.select("#leftDivId").classed("no-display",true);
    var currentRole = window.sessionStorage.ux_curUserRole;
    d3.select("#mainContainDiv").remove();
    instanContainDiv = d3.select(contain)
        .append("div")
        .attr("class","siteList-content")
        .attr("id","mainContainDiv");
    d3.select(".siteList-content")
        .append("div")
        .attr("id","toolbar")
        .attr("class","toolbar")
        .append("button")
        .attr("id","creatSite")
        .attr("class","btn btn-default admitClick disabledElem")
        .html("新&nbsp;&nbsp;建");
    d3.select(".siteList-content #toolbar")
        .append("button")
        .attr("id","modifySite")
        .attr("onClick","instRefresh()")
        .attr("class","btn btn-default admitClick")
        .html("刷&nbsp;&nbsp;新");
    d3.select(".siteList-content #toolbar")
        .append("button")
        .attr("id","delInstance")
        .attr("class","delBtnClass disabledElem del-btn-position")
        .attr("disabled","disabled")
        .attr("onClick","instanceDel()")
        .html("删&nbsp;&nbsp;除");
    if(currentRole == 1)
    {
        d3.selectAll(".disabledElem").style('display','none');
    }
        getQueryCondition(".siteList-content");
        initSiteList();
        getInstanceData();
        listenTable();
        popUpInsBoxOper();
    /*定时更新实例列表的状态函数*/
    setRealTimer();
}
/*
* 选择条件查询元素
* */
function getQueryCondition(contain)
{
    d3.select(contain)
        .append("div")
        .attr("id","searchSite-form")
        .attr("class","pull-right searchSite")
        .append("div")
        .attr("id","instanceName")
        .attr("class","searchSite-content");
    d3.select("#searchSite-form")
        .append("div")
        .attr("id","instanceType")
        .attr("class","searchSite-content");
    d3.select("#searchSite-form")
        .append("div")
        .attr("id","instanceStatus")
        .attr("class","searchSite-content");
    d3.selectAll(".searchSite-content")
        .append("input")
        .attr("type","checkbox")
        .each(function(d,i){
            d3.select(this).attr({
                id:"checkboxId" + i
            });
        })
        .on("click",function(d,i){
            checkBoxFun(i);
        })
        .attr("class","siteCheck");
    var searchSite_content= d3.selectAll(".searchSite-content");
    d3.select(searchSite_content[0][0])
        .insert("span",":nth-child(2)")
        .attr("class","searchTypeName")
        .html("实例名称：");
    d3.select(searchSite_content[0][0])
        .insert("input",":nth-child(3)")
        .attr({
            'type':'text',
            'id':'selectElemId0',
            'disabled':""
        });
    d3.select(searchSite_content[0][1])
        .insert("span",":nth-child(2)")
        .attr("class","searchTypeName")
        .html("类型：");
    d3.select(searchSite_content[0][1])
        .insert("select",":nth-child(3)")
        .attr({
            'id':'selectElemId1',
            'class':'selectType'
        })
        .attr("disabled",true)
        .append("option")
        .html("云实例");
    d3.select(".selectType")
        .append("option")
        .html("本地实例");
    d3.select(searchSite_content[0][2])
        .insert("span",":nth-child(2)")
        .attr("class","searchTypeName")
        .html("运行状态：");
    d3.select(searchSite_content[0][2])
        .insert("select",":nth-child(3)")
        .attr({
            'id':'selectElemId2',
            'disabled':false,
            'class':'selectState'
        })
        .append("option")
        .html("运行");
    d3.select(".selectState")
        .append("option")
        .html("故障");
    d3.select(".selectState")
        .append("option")
        .html("停止");
    d3.select("#searchSite-form")
        .append("button")
        .attr("class","btn btn-sm btn-bg-color searchSite-btn")
        .on("click",function(){
            queryFlag = true;
            queryInstance();
        })
        .attr("title","查找")
        .style("margin","4px 29px 0 4px");
    d3.select(".siteList-content")
        .append("div")
        .attr("class","instance-list")
        .append("table")
        .attr("id","table");

}
/******************************新建实例**************************/
var cloudItemData; //存放云实例的选项文本信息（DFS和相应的volume）
var newInsInfo = {
    'name':'',
    'type':1,
    'path':'',
    'password':'',
    'site':'',
    'encode':'',
    'isVer':0
}; //新建实例的信息
var cloudPathStr,siteItemArray;  //云实例时的路径
var queryData = {
    'insNameFlag':0,
    'insName':'',
    'insTypeFlag':0,
    'insType':'',
    'insStatusFlag':0,
    'insStatus':''
};
function getSiteList()
{
    /*
    * 获取站点信息的命令请求
    * */
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"getAllActiveSiteInfo","subRequest":"","ssubRequest":""},
        data    :{}
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,getSiteListCallback);

}
function getSiteListCallback(retJson)
{
    var retJsonObj = JSON.parse(retJson);
    if(retJsonObj.rstcode == "success"){
        siteItemArray = retJsonObj.data;
    }else{
        uxAlert(retJsonObj.desc);
        d3.select("#creatSite").classed("admitClick",true);
    }
}
function newInsFun()
{
    d3.select("#creatSite").on('click',function(){
        clearRealTimer();
        d3.select("#creatSite").classed("admitClick",false);
        getSiteList();
        newInsInfo = {
            'name':'',
            'type':1,
            'path':'',
            'password':'',
            'site':siteItemArray[0],
            'encode':'',
            'isVer':0
        };
        OnePage();
    });
}
function OnePage()
{
    var className;
    instanceInfoOneElem();
    d3.select("#newInstanTitleSpan").classed("newTitle",true);
    d3.select("#dialogOne").style({
        "width":"470px",
        "height":"413px"
    });
    if(d3.select("#dialogOne").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgOne').fadeIn(300);
    $('#dialogOne').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function instanceInfoOneElem()
{
    var sureUserFlag = false,surePathFlag = false;
    d3.select("#dialogBgOne").remove();
    d3.select("#dialogOne").remove();
    d3.select("#dialogBgTwo").remove();
    d3.select("#dialogTwo").remove();
    var popUpInputArray = ["实例名称","&nbsp;&nbsp;类&nbsp;&nbsp;&nbsp;型&nbsp;&nbsp;","&nbsp;&nbsp;路&nbsp;&nbsp;&nbsp;径&nbsp;&nbsp;","站点选择"];
    instanContainDiv.append("div")
        .attr("id","dialogBgOne");
    var outPage = instanContainDiv.append("div")
        .attr("id","dialogOne")
        .attr("class","animated");
    d3.select("#dialogOne").append("a")
        .attr({
            "class":"x-close-style"
        })
        .on("click",function(){
            newInsInfo = {
                'name':'',
                'type':1,
                'path':'',
                'password':'',
                'site':siteItemArray[0],
                'encode':'',
                'isVer':0
            };
            d3.select("#dialogOne").classed("bounceIn",false);
            $('#dialogBgOne').fadeOut(300,function(){
                $('#dialogOne').addClass('bounceOutUp').fadeOut();
                setRealTimer();
            });
            d3.select("#creatSite").classed("admitClick",true);
        });
        //.html("x");
    var editFrom = outPage.append("div")
        .attr("id","editFrom");
    var newInstanTitleSpan = editFrom.append("span")
        .attr("id","newInstanTitleSpan")
        .html("新建实例");
    var editFormUl = editFrom.append("ul")
        .attr({
            'id':'editInsId',
            "class":"editInfos"
        });
    for(var k = 0;k < popUpInputArray.length;k++)
    {
        var editFromLi = editFormUl.append("li")
            .attr({
                'id':"editUl" + k,
                "class":function(){
                    var className;
                    className = "editUl";
                    return className;
                }
            });
        editFromLi.append("label").append("span")
            .attr("class","editFromLiSpan")
            .html(popUpInputArray[k]);
        if(k == 1)
        {
            var selectType = editFromLi.append("select")
                .attr({
                    "id":"input"+k,
                    "class":"ipt selectStyle insInputClass",
                    "onchange":"changeSelectValue()"
                });
            selectType.append("option").attr("class","typeChoiceOption").html("本地实例");
            selectType.append("option").attr("class","typeChoiceOption").html("云&nbsp;&nbsp;实&nbsp;&nbsp;例");
            var selectObj = d3.select("#input1");
            selectObj[0][0].selectedIndex = (newInsInfo.type == 1) ? (0):(1);
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = (newInsInfo.type == 1) ? ("本地实例"):("云&nbsp;&nbsp;实&nbsp;&nbsp;例");
        }
        else if(k == 2)
        {
            editFromLi.append("input")
                .attr({
                    "id":"input" + k,
                    "type":"text",
                    "class":"ipt insInputClass",
                    'placeholder':'例如：/home/uxdb'
                })
                .on("blur",function(){
                    var insPathStr = d3.select(this)[0][0].value;
                    if(instancePath(insPathStr))
                    {
                        d3.select(this)[0][0].nextSibling.innerHTML = "";
                        surePathFlag = true;
                    }else{
                        d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip pathError'>请正确输入路径!</span>";
                        surePathFlag = false;
                    }
                });
                d3.select("#input2")[0][0].value = newInsInfo.path;
        }
        else if (k == 3)
        {
            var selectSite = editFromLi.append("select")
                .attr({
                    "id":"input"+k,
                    "class":"ipt siteListStyle insInputClass"
                });
            for(var j = 0;j < siteItemArray.length; j++)
            {
                selectSite.append("option")
                    .attr({
                        "class":"typeChoiceOption",
                        "id":"siteChoiceOption" + j
                    }).html(siteItemArray[j]);
            }
            var selectObj = d3.select("#input3");
            for(var m = 0; m < siteItemArray.length; m++)
            {
                if(newInsInfo.site == siteItemArray[m])
                {
                    selectObj[0][0].selectedIndex = m;
                    break;
                }
            }
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = newInsInfo.site;
        }
        else
        {
            editFromLi.append("input")
                .attr({
                    "id":"input" + k,
                    "type":"text",
                    "class":"ipt insInputClass",
                    'placeholder':'字母开头，特殊字符含下划线，长度不超过64！'
                })
                .on("blur",function(){
                    var nameValue = d3.select(this)[0][0].value;
                    if(instanceName(nameValue) && nameValue.length < 65 && nameValue.length > 0)
                    {
                        d3.select(this)[0][0].nextSibling.innerHTML = "";
                        sureUserFlag = true;
                    }else{
                        d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>字母开头，特殊字符可以包括下划线，长度不超过64！</span>";
                        sureUserFlag = false;
                    }
                });
            d3.select("#input0")[0][0].value = newInsInfo.name;
        }
    }
    initSelectValue();
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });
    editFrom.append("div")
        .attr("class","dialogTop")
        .append("button")
        .attr("class","newInstanceBtn popUpBtn btn btn-default admitClick")
        .on("click",function(){
            var sureIsNullFlag,UserFlag,PathFlag;
            newInsInfo.type = (d3.select("#input1")[0][0].value == "本地实例") ? (1):(2);
            if(instanceName(d3.select("#input0")[0][0].value) && (d3.select("#input0")[0][0].value).length < 65 && (d3.select("#input0")[0][0].value).length > 0)
            {
                d3.select("#input0")[0][0].nextSibling.innerHTML = "";
                UserFlag = true;
            }else{
                d3.select("#input0")[0][0].nextSibling.innerHTML = "<span class='errorTip'>字母开头，特殊字符可以包括下划线，长度不超过64！</span>";
                UserFlag = false;
            }
            if(newInsInfo.type == 1)
            {
                sureIsNullFlag = (d3.select("#input0")[0][0].value == "" || d3.select("#input2")[0][0].value == "") ? (false):(true);
                if(instancePath(d3.select("#input2")[0][0].value))
                {
                    d3.select("#input2")[0][0].nextSibling.innerHTML = "";
                    PathFlag = true;
                }else{
                    d3.select("#input2")[0][0].nextSibling.innerHTML = "<span class='errorTip pathError'>请正确输入路径!</span>";
                    PathFlag = false;
                }
            }else{
                sureIsNullFlag = (d3.select("#input0")[0][0].value == "") ? (false):(true);
                PathFlag = true;
            }
            if(UserFlag && PathFlag && sureIsNullFlag)
            {
                /*综合当前界面的数据*/
                newInsInfo.name = d3.select("#input0")[0][0].value;
                //newInsInfo.type = (d3.select("#input1")[0][0].value == "本地实例") ? (1):(2);
                if(newInsInfo.type == 1)
                {
                    newInsInfo.path = d3.select("#input2")[0][0].value;
                    newInsInfo.site = d3.select("#input3")[0][0].value;
                }else {
                    newInsInfo.path = d3.select("#input4")[0][0].value +","+d3.select("#input5")[0][0].value;
                    newInsInfo.site = "";
                }
                if(newInsInfo.type == 2)
                {
                    getNum();
                }
                d3.select("#dialogOne").classed("bounceIn",false);
                $('#dialogBgOne').fadeOut(300,function(){
                    $('#dialogOne').addClass('bounceOutUp').fadeOut();
                    nextPage();
                });
            }else{
                uxAlert("请正确输入新建的实例信息！");
            }
        })
        .html("下一步");
}
function initSelectValue()
{
    var selectTypeValue = newInsInfo.type;
    if(selectTypeValue == 1)
    {
        //本地实例
        d3.select("#editUl2").style("display","block");
        d3.select("#editUl3").style("display","block");
        d3.select("#editUl4").style("display","none");
        d3.select("#editUl5").style("display","none");
    }else{
        //云实例
        getDfsAndVolumeList();
        if(cloudItemData.data.length > 0)
        {
            d3.select("#editUl2").style("display","none");
            d3.select("#editUl3").style("display","none");
            getDfsAndVolumeElem(cloudItemData.data);

        }else{
            var selectObj = d3.select("#input1");
            selectObj[0][0].selectedIndex = 0;
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = "本地实例";
        }

    }
}
function changeSelectValue()
{
    //d3.selectAll(".dialogOneUl").classed("no-display",true);
    d3.select("#input2")[0][0].value = "";
    d3.select("#input2")[0][0].nextSibling.innerHTML = "";
    var selectTypeValue = (d3.select("#input1")[0][0].value == "本地实例") ? (1):(2);
    if(selectTypeValue == 1)
    {
        //本地实例
        d3.select("#editUl2").style("display","block");
        d3.select("#editUl3").style("display","block");
        d3.select("#editUl4").style("display","none");
        d3.select("#editUl5").style("display","none");
    }else{
        //云实例
        getDfsAndVolumeList();
        if(cloudItemData.data.length > 0)
        {
            d3.select("#editUl2").style("display","none");
            d3.select("#editUl3").style("display","none");
            getDfsAndVolumeElem(cloudItemData.data);
        }else{
            var selectObj = d3.select("#input1");
            selectObj[0][0].selectedIndex = 0;
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = "本地实例";
        }

    }
}
function nextPage()
{
    instanceInfoNextElem();
    var className;
    d3.select("#newInstanTitleSpan").classed("newTitle",true);
    d3.select("#dialogTwo").style({
        "width":"473px",
        "height":"463px"
    });
    if(d3.select("#dialogTwo").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgTwo').fadeIn(300);
    $('#dialogTwo').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function instanceInfoNextElem()
{
    var twoPageFlag = false;
    d3.select("#dialogBgOne").remove();
    d3.select("#dialogOne").remove();
    d3.select("#dialogBgTwo").remove();
    d3.select("#dialogTwo").remove();
    d3.select("#dialogBgFinally").remove();
    d3.select("#dialogFinally").remove();
    var popUpInputArray = ["&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;密&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码&nbsp;&nbsp;&nbsp;&nbsp;","&nbsp;确&nbsp;认&nbsp;&nbsp;&nbsp;密&nbsp;码&nbsp;"];
    instanContainDiv.append("div")
        .attr("id","dialogBgTwo");
    var outPage = instanContainDiv.append("div")
        .attr("id","dialogTwo")
        .attr("class","animated");
    d3.select("#dialogTwo").append("a")
        .attr({
            "class":"x-close-style sen-x-close"
        })
        .on("click",function(){
            newInsInfo = {
                'name':'',
                'type':1,
                'path':'',
                'password':'',
                'site':siteItemArray[0],
                'encode':'',
                'isVer':0
            };
            d3.select("#dialogTwo").classed("bounceIn",false);
            $('#dialogBgTwo').fadeOut(300,function(){
                $('#dialogTwo').addClass('bounceOutUp').fadeOut();
                setRealTimer();
            });
            d3.select("#creatSite").classed("admitClick",true);
        });
    var editFrom = outPage.append("div")
        .attr("id","editFrom");
    var newInstanTitleSpan = editFrom.append("span")
        .attr("id","newInstanTitleSpan")
        .html("新建实例");
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos insTwoPage");
    for(var k = 0;k < popUpInputArray.length;k++)
    {
        var editFromLi = editFormUl.append("li").attr("class","editUl");
        editFromLi.append("label").append("span")
            .attr("class","editFromLiSpan")
            .html(popUpInputArray[k]);
        editFromLi.append("input")
            .attr({
                "id":"input" + k,
                "type":"password",
                "class":"ipt insInputClass twoPageInput",
                'placeholder':'必含数字，字母，特殊字符，长度不小于6！'
            });
    }
    d3.select("#input0")[0][0].value = newInsInfo.password;
    d3.select("#input1")[0][0].value = newInsInfo.password;
    d3.select("#input0").on("blur",function(){
        var onePwd = d3.select(this)[0][0].value;
        if(instancePassword(onePwd))
        {
            d3.select(this)[0][0].nextSibling.innerHTML = "";
            twoPageFlag = true;
        }else{
            d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>必须包含数字，大小写字母，特殊字符，长度大于等于6！</span>";
            twoPageFlag = false;
        }
    });
    d3.select("#input1").on("blur",function(){
        var onePwd = d3.select("#input0")[0][0].value;
        var twoPwd = d3.select(this)[0][0].value;
        if(twoPwd != onePwd)
        {
            d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>两次输入密码不相同，请确认输入！</span>";
            twoPageFlag = false;
        }else if(!instancePassword(twoPwd)){
            d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>必须包含数字，大小写字母，特殊字符，长度大于等于6！</span>";
            twoPageFlag = false;
        }else{
            d3.select(this)[0][0].nextSibling.innerHTML = "";
            twoPageFlag = true;
        }
    });
    editFrom.append("p")
        .attr({
            "class":"otherPara"
        })
        .html("其他参数");
    var editLabel = editFrom.append("div").attr({"class":"encodeDiv"});
    editLabel.append("span")
        .attr("class","editFromLiSpan")
        .html("服&nbsp;务&nbsp;器&nbsp;编&nbsp;码");
    d3.json("js/encoding.json")
        .header("Content-Type", "application/x-www-form-urlencoded")
        .get("",function(error,json){
            if(error)
            {
                uxAlert("编码文件读取失败！");
            }else{
                var selectEncode = editLabel.append("select")
                    .attr({
                        "id":"encodeSelect",
                        "class":'encodeSelectStye'
                    });
                for(var k = 0;k < json.encodeData.length; k++)
                {
                    selectEncode.append("option")
                        .attr({
                            "id":'encodeOption' + k
                        })
                        .html(json.encodeData[k].encodeText);
                }
                newInsInfo.encode = (newInsInfo.encode == "") ? (json.encodeData[0].encodeText):(newInsInfo.encode);
            }
            var selectObj = d3.select("#encodeSelect");
            for(var j = 0 ;j < json.encodeData.length ; j++)
            {
                if(newInsInfo.encode == json.encodeData[j].encodeText)
                {
                    selectObj[0][0].selectedIndex = j;
                    break;
                }
            }
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = newInsInfo.encode;
        });
    var isVerifyLabel = editFrom.append("div")
        .attr({
            "class":"isVerifyDiv"
        });
    isVerifyLabel.append("span")
        .attr("class","editFromLiSpan isVerfyTitleSpan")
        .html("校验数据页面");
    var isVerifyDiv = isVerifyLabel.append("div").attr({"class":"isVerifyDiv"});
    var isVerify = ["是","否"];
    for(var l = 2;l < isVerify.length + 2; l++)
    {
        isVerifyDiv.append("input")
            .attr({
                "id":"input" + l,
                "type":"radio",
                "name":"verifyName",
                "value":isVerify[l-2]
            });
        isVerifyDiv.append("spam")
            .html(isVerify[l - 2]);
    }
    if(newInsInfo.isVer == 1)
    {
        d3.select("#input2").attr("checked","checked");
    }else{
        d3.select("#input3").attr("checked","checked");
    }
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });
    editFrom.append("div")
        .attr("class","dialogTop nextDiallog")
        .append("button")
        .attr("class"," popUpBtn btn btn-default admitClick twoPageNextBtn")
        .on("click",function(){
            d3.select("#dialogTwo").classed("bounceIn",false);
            $('#dialogBgTwo').fadeOut(300,function(){
                $('#dialogTwo').addClass('bounceOutUp').fadeOut();
                OnePage();
            });
        })
        .html("上一步");
    editFrom.select(".dialogTop")
        .append("button")
        .attr("class"," popUpBtn btn btn-default admitClick twoPageNextBtn")
        .on("click",function(){
            var isNullFlag = (d3.select("#input0")[0][0].value == "" || d3.select("#input1")[0][0].value == "") ? (false):(true);
            var sureInfoFlag;
            if(instancePassword(d3.select("#input0")[0][0].value) && instancePassword(d3.select("#input1")[0][0].value) && (d3.select("#input0")[0][0].value == d3.select("#input1")[0][0].value))
            {
                sureInfoFlag = true;
            }else{
                sureInfoFlag = false;
            }
            if(sureInfoFlag && isNullFlag)
            {
                /*综合当前界面的数据*/
                newInsInfo.password = d3.select("#input1")[0][0].value;
                var encodeStr = d3.select("#encodeSelect")[0][0].value;
                if(d3.select("#input2")[0][0].checked)
                {
                    newInsInfo.isVer = 1;
                }else if(d3.select("#input3")[0][0].checked)
                {
                    newInsInfo.isVer = 0;
                }
                newInsInfo.encode = encodeStr;
                d3.select("#dialogTwo").classed("bounceIn",false);
                $('#dialogBgTwo').fadeOut(300,function(){
                    $('#dialogTwo').addClass('bounceOutUp').fadeOut();
                    finallyPage();
                });
            }else{
                uxAlert("请正确输入新建的实例信息！");
            }
        })
        .html("下一步");
}
function finallyPage()
{
    instanceInfoFinallElem();
    var className;
    d3.select("#newInstanTitleSpan").classed("newTitle",true);
    d3.select("#dialogFinally").style({
        "width":"485px",
        "height":function(){
            return (newInsInfo.type == 1) ? ("375px"):("410px");
        }
    });
    if(d3.select("#dialogFinally").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgFinally').fadeIn(300);
    $('#dialogFinally').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function instanceInfoFinallElem()
{
    d3.select("#dialogBgOne").remove();
    d3.select("#dialogOne").remove();
    d3.select("#dialogBgTwo").remove();
    d3.select("#dialogTwo").remove();
    d3.select("#dialogBgFinally").remove();
    d3.select("#dialogFinally").remove();
    var popUpInputArray = [],popItemValue = [],type = newInsInfo.type;
    var isVer = (newInsInfo.isVer == 1) ? ("是"):("否");
    var insType = (newInsInfo.type == 1) ? ("本地实例"):("云实例");
    if(type == 1)
    {
        popUpInputArray = ["&nbsp;&nbsp;实&nbsp;&nbsp;&nbsp;&nbsp;例&nbsp;&nbsp;&nbsp;名&nbsp;&nbsp;&nbsp;称&nbsp; :",
            "&nbsp;&nbsp;实&nbsp;&nbsp;&nbsp;&nbsp;例&nbsp;&nbsp;&nbsp;类&nbsp;&nbsp;&nbsp;型&nbsp; :",
            "&nbsp;&nbsp;&nbsp;&nbsp;路&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;径&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :",
            "&nbsp;&nbsp;&nbsp;&nbsp;编&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :",
            "是否校验数据页面 :"];
        popItemValue = [newInsInfo.name,insType,newInsInfo.path,newInsInfo.encode,isVer];
    }else{
        popUpInputArray = ["&nbsp;&nbsp;实&nbsp;&nbsp;&nbsp;&nbsp;例&nbsp;&nbsp;&nbsp;名&nbsp;&nbsp;&nbsp;称&nbsp; :",
            "&nbsp;&nbsp;实&nbsp;&nbsp;&nbsp;&nbsp;例&nbsp;&nbsp;&nbsp;类&nbsp;&nbsp;&nbsp;型&nbsp; :",
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DFS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :",
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;volume&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :",
            "&nbsp;&nbsp;&nbsp;&nbsp;编&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :",
            "是否校验数据页面 :"];
        var path = newInsInfo.path.split(",");
        popItemValue = [newInsInfo.name,insType,path[0],path[1],newInsInfo.encode,isVer];
    }
    instanContainDiv.append("div")
        .attr("id","dialogBgFinally");
    var outPage = instanContainDiv.append("div")
        .attr("id","dialogFinally")
        .attr("class","animated");
    d3.select("#dialogFinally").append("a")
        .attr({
            "class":"finallyClose"
        })
        .on("click",function(){
            newInsInfo = {
                'name':'',
                'type':1,
                'path':'',
                'password':'',
                'site':'',
                'encode':'',
                'isVer':0
            };
            d3.select("#dialogFinally").classed("bounceIn",false);
            $('#dialogBgFinally').fadeOut(300,function(){
                $('#dialogFinally').addClass('bounceOutUp').fadeOut();
                setRealTimer();
            });
            d3.select("#creatSite").classed("admitClick",true);
        });
        //.html("x");
    var editFrom = outPage.append("div")
        .attr("id","editFrom");
    var newInstanTitleSpan = editFrom.append("span")
        .attr("id","newInstanTitleSpan")
        .html("新建实例");
    for(var k = 0; k < popUpInputArray.length; k++)
    {
        editFrom.append("div")
            .attr({
                'id':'showItemId' + k,
                'class':'showItemClass'
            })
            .html(popUpInputArray[k]);
    }
    d3.selectAll(".showItemClass").append("span").each(function(d,i){
        d3.select(this).attr({
            'id':'span' + i,
            'class':'showClass'
        }).html(popItemValue[i]);
    });
    editFrom.append("div")
        .attr("class","dialogTop nextDiallog")
        .append("button")
        .attr("class"," popUpBtn btn btn-default admitClick twoPageNextBtn")
        .on("click",function(){
            d3.select("#dialogFinally").classed("bounceIn",false);
            $('#dialogBgFinally').fadeOut(300,function(){
                $('#dialogFinally').addClass('bounceOutUp').fadeOut();
            });
            nextPage();
        })
        .html("上一步");
    editFrom.select(".dialogTop")
        .append("button")
        .attr("class"," popUpBtn btn btn-default admitClick")
        .on("click",function(){
            d3.select("#dialogFinally").classed("bounceIn",false);
            $('#dialogBgFinally').fadeOut(300,function(){
                $('#dialogFinally').addClass('bounceOutUp').fadeOut();
            });
            surePage();
        })
        .html("开&nbsp;&nbsp;&nbsp;&nbsp;始");
}
function surePage()
{
    instanceInfoSureElem();
    var className;
    d3.select("#newInstanTitleSpan").classed("newTitle",true);
    d3.select("#dialogSure").style({
        "width": "630px",
        "height": "445px"
    });
    if(d3.select("#dialogSure").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgSure').fadeIn(300);
    $('#dialogSure').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function instanceInfoSureElem()
{
    d3.select("#dialogBgOne").remove();
    d3.select("#dialogOne").remove();
    d3.select("#dialogBgTwo").remove();
    d3.select("#dialogTwo").remove();
    d3.select("#dialogBgFinally").remove();
    d3.select("#dialogFinally").remove();
    d3.select("#dialogBgSure").remove();
    d3.select("#dialogSure").remove();
    instanContainDiv.append("div")
        .attr("id","dialogBgSure");
    var outPage = instanContainDiv.append("div")
        .attr("id","dialogSure")
        .attr("class","animated");
    var editFrom = outPage.append("div")
        .attr("id","editFrom");
    var newInstanTitleSpan = editFrom.append("span")
        .attr("id","newInstanTitleSpan")
        .html("新建实例");
    editFrom.append("div")
        .attr({
            "class":"proceInfoClass"
        })
        .call(newInstance);
    d3.select(".proceInfoClass").append("p").html("正在获取新建实例的进度信息，请稍等...");
    editFrom.append("div")
        .attr("class","dialogTop finishDialog")
        .append("button")
        .attr("class"," popUpBtn btn btn-default admitClick")
        .on("click",function(){
            d3.select("#dialogSure").classed("bounceIn",false);
            $('#dialogBgSure').fadeOut(300,function(){
                $('#dialogSure').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#creatSite").classed("admitClick",true);
        })
        .html("完&nbsp;&nbsp;&nbsp;&nbsp;成");
}
function getPrintProcInfo(callbackFunc)
{
    function getPrintProcInfoCallback(retJson)
    {
        getPrintProcInfoOperCallback(retJson,callbackFunc);
    }
    var encode = newInsInfo.encode.substring(newInsInfo.encode.indexOf("（") + 1,newInsInfo.encode.indexOf("）"));
    newInsInfo.encode = encode;
    if(newInsInfo.type == 2)
    {
        var pathArray = cloudPathStr.split(",");
        var dfsid = pathArray[0];
    }
    var siteInfo = newInsInfo.site.split(":");
    //获取新建实例
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"getCreateInstState","subRequest":"","ssubRequest":""},
        data    :{
            ip:siteInfo[0],
            port:siteInfo[1],
            instancename:newInsInfo.name,
            type:newInsInfo.type,//1:本地实例,2:云实例
            pwd:newInsInfo.password,
            encoding:newInsInfo.encode,
            pagecheck:newInsInfo.isVer,
            path:newInsInfo.path,//type = 1
            dfsid:dfsid//type = 2
        }
    };
    if(jsonDataObj.data.type == 2)
    {
        jsonDataObj.data.dirip = cloudInsInfo.dirip;
        jsonDataObj.data.dirport = cloudInsInfo.dirport;
        jsonDataObj.data.ip = cloudInsInfo.hostip;
        jsonDataObj.data.port = cloudInsInfo.hostport;
    }
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(true,jsonDataStr,getPrintProcInfoCallback);

}
function getPrintProcInfoOperCallback(retJsonStr,callbackFunc)
{
    if(typeof callbackFunc != "function" || typeof retJsonStr != "string")
     {
       return;
     }
    var jsonObj = JSON.parse(retJsonStr);
    if(jsonObj.rstcode == "success")
    {
     for(var k = 0; k < jsonObj.data.length; k++)
     {
         d3.select(".proceInfoClass")
             .append("p")
             .html(jsonObj.data[k]);
     }
    }
    callbackFunc(jsonObj.desc);
}
function getProcInfo()
{
    function getOnePrintInfo(info)
    {
        var getFunFlag;
        getPrintProcInfo(function(rst)
        {
           
            if(rst != "over")
            {
                getFunFlag = setTimeout(getOnePrintInfo(), 1000);
            }else{
                getInstanceData();
                setRealTimer();
                uxAlert("新建实例成功！");
                clearTimeout(getFunFlag);
            }
        });
    }
    setTimeout(getOnePrintInfo(), 1000);
}
/********新建实例命令发送函数**************/
function newInstance()
{
    var encode = newInsInfo.encode.substring(newInsInfo.encode.indexOf("（") + 1,newInsInfo.encode.indexOf("）"));
    newInsInfo.encode = encode;
    if(newInsInfo.type == 2)
    {
        var pathArray = cloudPathStr.split(",");
        var dfsid = pathArray[0];
    }
    var siteInfo = newInsInfo.site.split(":");
    //if(newInsInfo.name.indexOf(newInsInfo.name.length - 1) == "/")
    //{
    //    newInsInfo.name = newInsInfo.name.substr(0,newInsInfo.name.length - 2);
    //}
    //新建实例
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"createInstance","subRequest":"","ssubRequest":""},
        data    :{
            ip:siteInfo[0],
            port:siteInfo[1],
            instancename:newInsInfo.name,
            type:newInsInfo.type,//1:本地实例,2:云实例
            pwd:newInsInfo.password,
            encoding:newInsInfo.encode,
            pagecheck:newInsInfo.isVer,
            path:newInsInfo.path,//type = 1
            dfsid:dfsid//type = 2
        }
    };
    if(jsonDataObj.data.type == 2)
    {
        jsonDataObj.data.dirip = cloudInsInfo.dirip;
        jsonDataObj.data.dirport = cloudInsInfo.dirport;
        jsonDataObj.data.ip = cloudInsInfo.hostip;
        jsonDataObj.data.port = cloudInsInfo.hostport;
    }
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(true,jsonDataStr,newInstanceCallback);
    getProcInfo();
}
function newInstanceCallback(retJson)
{
    //var retJsonStr = JSON.parse(retJson);
    //if(retJsonStr.rstcode == "success")
    //{
    //    if(retJsonStr.data.retcode == "")
    //}
}
/*获取用户所要选择的DFS列表和volume列表（发送命令获取）函数*/
function getDfsAndVolumeList()
{
    /*
     * DFS列表
     * */
    var ss;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"getAllActiveDFSInfo","subRequest":"","ssubRequest":""},
        data    :{}
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,setDfsAndVolumeListCallback);
}
function setDfsAndVolumeListCallback(retJson)
{
    var retJsonObj = JSON.parse(retJson);
    if(retJsonObj.rstcode == "success"){
        cloudItemData = retJsonObj;
    }else{
        cloudItemData = {"data":[]};
        uxAlert(retJsonObj.desc);
    }
}

/*************实现选择DFS和Volume的界面操作**********************/
var numI,numJ;
var volumeItemArray;
var cloudInsInfo;
function getDfsAndVolumeElem(dataArray)
{
    d3.select("#editUl4").remove();
    d3.select("#editUl5").remove();
    var editFormUl = d3.select("#editInsId");
    var popUpInputArray = ["实例名称","&nbsp;&nbsp;类&nbsp;&nbsp;&nbsp;型&nbsp;&nbsp;","&nbsp;&nbsp;路&nbsp;&nbsp;&nbsp;径&nbsp;&nbsp;","站点选择","&nbsp;&nbsp;&nbsp;&nbsp;DFS&nbsp;&nbsp;&nbsp;&nbsp;","&nbsp;volume&nbsp;"];
    for(var k = 4;k < 6; k++)
    {
        var editFromLi = editFormUl.append("li")
            .attr({
                'id':"editUl" + k,
                "class":function(){
                    var className;
                    className = "editUl";
                    return className;
                }
            });
        editFromLi.append("label").append("span")
            .attr("class","editFromLiSpan")
            .html(popUpInputArray[k]);
        editFromLi.append("select")
            .attr({
                "id":"input" + k,
                "class":"ipt siteListStyle insInputClass",
                "onchange":"changeDfsValue()"
            });
    }
    for(var j = 0;j < dataArray.length; j++)
    {
        d3.select("#input4").append("option")
            .attr({
                "class":"typeChoiceOption",
                "id":"siteChoiceOption" + j
            }).html(dataArray[j].name);
    }
    if(newInsInfo.path != "")
    {
        var path = newInsInfo.path;
        var selectTypePath = path.split(",");
        var selectObj = d3.select("#input4");
        for(var m = 0; m < dataArray.length; m++)
        {
            if(selectTypePath[0] == dataArray[m].name)
            {
                selectObj[0][0].selectedIndex = m;
                break;
            }
        }
        selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = selectTypePath[0];
    }
    changeDfsValue();
}
function changeDfsValue()
{
    volumeItemArray = [];
    var selectObj = d3.select("#input4");
    var numI = selectObj[0][0].selectedIndex;
    getVolumeItem(cloudItemData.data[numI].id);
    getVolumeItemElem(volumeItemArray.data);
}
function getVolumeItemElem(volumeArray)
{
    d3.select("#input5").selectAll("option").remove();
    for(var j = 0;j < volumeArray.length; j++)
    {
        d3.select("#input5").append("option")
            .attr({
                "class":"typeChoiceOption",
                "id":"siteChoiceOption" + j
            }).html(volumeArray[j].name);
    }
    if(newInsInfo.path != "")
    {
        var path = newInsInfo.path;
        var selectTypePath = path.split(",");
        var selectObj = d3.select("#input5");
        for(var m = 0; m < volumeArray.length; m++)
        {
            if(selectTypePath[1] == volumeArray[m].name)
            {
                selectObj[0][0].selectedIndex = m;
                break;
            }
        }
        selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = selectTypePath[1];
    }
}
function getNum()
{
    var selectObj = d3.select("#input4");
    var selectVolume = d3.select("#input5");
    var cloudDfsId = cloudItemData.data[selectObj[0][0].selectedIndex].id;
    var cloudDfsName = cloudItemData.data[selectObj[0][0].selectedIndex].name;
    var cloudVolumeId = volumeItemArray.data[selectVolume[0][0].selectedIndex].id;
    var cloudVolumeName = volumeItemArray.data[selectVolume[0][0].selectedIndex].name;
    cloudPathStr = cloudDfsId + "," +cloudDfsName + "," + cloudVolumeId+ "," + cloudVolumeName;
    //var pathStr = "/" +cloudDfsName + "/" + cloudVolumeName;
    //d3.select("#input2")[0][0].value = pathStr;
    //d3.selectAll(".dialogOneUl").classed("no-display",true);
    return cloudPathStr;
}
function getVolumeItem(dfsId)
{
    /*
    * volume列表
    * */
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"enumVolumeList","subRequest":"dfs","ssubRequest":""},
        data    :{
            dfsid:dfsId
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,getVolumeItemCallback);
}
function getVolumeItemCallback(retJson)
{
    var retJsonObj = JSON.parse(retJson);
    if(retJsonObj.rstcode == "success"){
        volumeItemArray = retJsonObj;
        cloudInsInfo = retJsonObj.cloudInsInfo;
    }else{
        volumeItemArray = [];
    }
}
/***************************初始化实例列表表格********************/
function initSiteList()
{
    var par = [[{field: 'instance_radio' , radio: true ,align: 'center' },
        {field: 'instance_number' ,title: '序&nbsp;&nbsp;&nbsp;&nbsp;号' ,align: 'center' },
        {field: 'instance_name' ,title: '实例名称' ,align: 'center' ,
            editable: {
                type: 'text',
                title: '实例名称',
                validate: function (value) {
                    value = trim(value);
                    if (!value) {
                        return '请输入正确实例名称！';
                    }
                    if (instanceName(value) && value.length < 65 && value.length > 0)
                    {
                        var data = $('#table').bootstrapTable('getData'),
                            index = $(this).parents('tr').data('index');
                        modfiInsName(value,data[index]);
                    }else{
                        return '字母开头，特殊字符含下划线，长度不超过64！';
                    }
                    return '';
                },
                //save:function(value){
                //    console.log("helohgjh");
                //    modfiInsName(value);
                //}
            }
        },
        {field: 'instance_ID' ,title: '实例ID' ,align: 'center' },
        {field: 'instance_state' , title: '运行状态' ,align: 'center' ,formatter:function(value,row,index){
            if(row.instance_state == 1) {
                var discon = '<a title = "运行">' + '<button class = "btn-link run-btn"></button>' + '</a>';
                return discon;
            }else if(row.instance_state == 2){
                var constr = '<a title = "停止">' + '<button class = "btn-link stop-btn"></button>' + '</a>';
                return constr;
            }else{
                var err = '<a title = "故障">' + '<button class = "btn-link error-btn"></button>' + '</a>';
                return err;
            }
        }},
        {field: 'creat_time' , title: '创建时间',align: 'center' },
        {field: 'instance_type' , title: '类&nbsp;&nbsp;&nbsp;&nbsp;型' ,align: 'center' },
        {field: 'db_version' , title: '数据库版本' ,align: 'center' },
        {field: 'instance_operate' , title: '操&nbsp;&nbsp作' ,align: 'center' , formatter:function(value,row,index){
            var par = row.instance_name + "," + row.instance_type + "," + row.creat_time+"," + row.instance_ID + "," + row.cluster_path + "," + row.DFSId ;
            var constr;
            if(row.instance_state == 1 || row.instance_state == 2)
            {
                constr = '<a title = "配置">' + '<button class = "btn-link site-setupImg" onclick = "getInstanceOper(\'' + par + '\')"' + '></button>' + '</a>';
            }else{
                constr = '<a title = "配置">' + '<button class = "site-no-operImg"' + '></button>' + '</a>';
            }
            return constr;
        }}
    ]];
    $('#table').bootstrapTable({
        classes:"table table-no-bordered",
        //toolbar:"#dfslist_toobar",
        height:606,
        columns: par,
        idField:"instance_number",
    });
    $('#table').on('editable-shown.bs.table',function(arg){
        clearRealTimer();
    });
    $('#table').on('editable-hidden.bs.table editable-save.bs.table',function(arg){
        setRealTimer();
    });
}
function modfiInsName(value,data)
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"modifyAliasname","subRequest":"","ssubRequest":""},
        data    :{
            aliasname:value,
            instid:data.instance_ID
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,modfiInsNameCallback);
}
function modfiInsNameCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        uxAlert("修改实例名称成功！");
    }else{
        uxAlert("修改实例名称失败！");
    }
    setRealTimer();
}
function getInstanceData()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"enumInstList","subRequest":"","ssubRequest":""},
        data    :{}
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,getInstanceDatacallbackFunc);
}
function getInstanceDatacallbackFunc(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        var dataJson =  getNewJson(jsonObj.data);
        $("#table").bootstrapTable('load',dataJson);
        d3.select("#delInstance")[0][0].disabled = true;
        d3.select("#delInstance").classed("delBtnClass",true);
        d3.select("#delInstance").classed("btn admitClick",false);
        listenTable();
    }else{
        clearRealTimer();
        uxAlert("初始化实例列表失败！");
    }
}
/*********************** ***实例操作管理界面************************/
function getInstanceOper(data)
{
    clearRealTimer();
    instanceOperElem(data,false);
}
/***************************辅助函数区****************************/
//重组数据格式
function getNewJson(data)
{
    var newJson = [];
    for(var i = 0;i < data.length;i++)
    {
        var info = {};
        info.instance_number = (i + 1);
        info.instance_name = data[i].aliasname;
        info.instance_ID = data[i].id;
        info.instance_state = data[i].state;
        info.creat_time = data[i].inittm;
        info.cluster_path = data[i].clspath;
        info.instance_type = (data[i].type == 1) ? ("本地实例"):("云实例"); //1:本地实例，2:云实例
        info.DFSId = data[i].dfsid;
        info.db_version = data[i].version;
        newJson.push(info);
    }
    return newJson;
}
//监听表格
function listenTable()
{
    var $table = $("#table");
    $table.on('check.bs.table page-change.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table',function(arg){
        setButtonStatus("delInstance");
    });
}
//判断单选框是否选中
function setButtonStatus(btid)
{
    if(btid == "")
    {
        return;
    }
    var selected = $("#table").bootstrapTable('getSelections');
    if(selected.length > 0)
    {
        d3.select("#" + btid)[0][0].disabled = false;
        d3.select("#" + btid).classed("delBtnClass",false);
        d3.select("#" + btid).classed("btn",true);
        d3.select("#" + btid).classed("admitClick",true);
        //d3.select('#' + btid).style({"background-color":"#57D1F7"});
    }
    else
    {
        d3.select("#" + btid)[0][0].disabled = true;
        d3.select("#" + btid).classed("delBtnClass",true);
        d3.select("#" + btid).classed("btn",false);
        d3.select("#" + btid).classed("admitClick",false);
        //d3.select('#' + btid).style({"background":"none"});
    }
}
//返回选中行
function getIdSelections()
{
    return $.map($("#table").bootstrapTable('getSelections'), function (row) {
        return row;
    });
}
/************************刷新实例列表********************************/
function instRefresh()
{
    d3.select("#modifySite").classed("admitClick",false);
    getInstanceData();
    setButtonStatus("delInstance");
    d3.select("#modifySite").classed("admitClick",true);
}
/***********************删除实例列表*********************************/
function instanceDel()
{
    clearRealTimer();
    d3.select("#delInstance").classed("admitClick",false);
    uxConfirm("是否确认删除该实例？",function(rst)
    {
        //点击取消
        if(!rst)
        {
            d3.select("#delInstance").classed("admitClick",true);
            setRealTimer();
           return;
        }
        var ids = getIdSelections();
        /*删除实例发送数据*/

        var jsonDataObj = {
            ip      :"",
            port    :"",
            router  :"instmanage",
            request :{"mainRequest":"deleteInstance","subRequest":"","ssubRequest":""},
            data    :{
                instid:ids[0].instance_ID,
                type:(ids[0].instance_type == "本地实例") ? 1 : 2
            }
        };
        var jsonDataStr = JSON.stringify(jsonDataObj);
        ux_reqInterface.ajaxRequest(false,jsonDataStr,instanceDelCallback);
    });
}
function instanceDelCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    var ids = getIdSelections();
    if(retJsonStr.rstcode == "success")
    {
        uxAlert("删除实例成功！");
    }else{
        uxAlert(retJsonStr.desc);
    }
    getInstanceData();
    setButtonStatus("delInstance");
    setRealTimer();
}
/***********************查询功能*******************************/
function queryInstance()
{
    queryFlag = true;
    clearRealTimer();
    /*
     * 修改查询按钮的颜色*/
    var queryItem = {
        'insNameFlag':0,
        'insName':'',
        'insTypeFlag':0,
        'insType':'',
        'insIdFlag':0,
        'insId':'',
        'insStatusFlag':0,
        'insStatus':''
    };
    d3.select("#searchSite-form button").classed("searchSite-btn",false);
    d3.select("#searchSite-form button").classed("searchSite-btn-backWhite",true);
    var formDataArray = d3.selectAll(".siteCheck");
    queryItem.insNameFlag = (formDataArray[0][0].checked == false) ? (0):(1);
    queryItem.insTypeFlag = (formDataArray[0][1].checked == false) ? (0):(1);
    queryItem.insStatusFlag = (formDataArray[0][2].checked == false) ? (0):(1);
    if(queryItem.insNameFlag)
    {
        queryItem.insName = trim(d3.select("#selectElemId0")[0][0].value);
    }
    if(queryItem.insTypeFlag)
    {
        var insType = trim(d3.select("#selectElemId1")[0][0].value);
        queryItem.insType = (insType == "云实例" ? (2):(1));
    }
    if(queryItem.insStatusFlag)
    {
        var status = trim(d3.select("#selectElemId2")[0][0].value);
        queryItem.insStatus = (status == "运行") ? (1) :　((status == "停止") ? (2) : (0));
    }
    if(queryItem.insNameFlag && queryItem.insName == "")
    {
        uxAlert("请填入查询条件！");
        d3.select("#searchSite-form button").classed("searchSite-btn-backWhite",false);
        d3.select("#searchSite-form button").classed("searchSite-btn",true);
        return;
    }
    queryData = queryItem;
    /*
     * 发送的查询数据*/
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"queryInstance","subRequest":"","ssubRequest":""},
        data    :queryItem
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,queryInsCallback);
}
function queryInsCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        var dataJson =  getNewJson(jsonObj.data);
        d3.select("#delInstance")[0][0].disabled = true;
        d3.select("#delInstance").classed("delBtnClass",true);
        d3.select("#delInstance").classed("btn admitClick",false);
        $("#table").bootstrapTable('load',dataJson);
        setRealTimer();
    }else{
        uxAlert("实例列表加载失败！");
    }
    d3.select("#searchSite-form button").classed("searchSite-btn-backWhite",false);
    d3.select("#searchSite-form button").classed("searchSite-btn",true);
}
/************************实时状态获取************************************/
function getRealtimeData()
{
    /*
     * 修改查询按钮的颜色*/
    var queryItem;
    if(queryFlag)
    {
        queryItem = queryData;
    }else{
        queryItem = {
            'insNameFlag':0,
            'insName':'',
            'insTypeFlag':0,
            'insType':'',
            'insStatusFlag':0,
            'insStatus':''
        };
    }
    /*
     * 发送的查询数据*/
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"queryInstance","subRequest":"timer","ssubRequest":""},
        data    :queryItem
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,getRealtimeDataCallback);
}
function getRealtimeDataCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        var dataJson =  getNewJson(jsonObj.data);
        d3.select("#delInstance")[0][0].disabled = true;
        d3.select("#delInstance").classed("delBtnClass",true);
        d3.select("#delInstance").classed("btn admitClick",false);
        $("#table").bootstrapTable('load',dataJson);
    }else{
        //clearRealTimer();
        //uxAlert("实例列表实时数据加载失败！");
    }
    d3.select("#searchSite-form button").classed("searchSite-btn-backWhite",false);
    d3.select("#searchSite-form button").classed("searchSite-btn",true);
}
function setRealTimer()
{
    clearInterval(setTimeFun);
    setTimeFun  = setInterval(getRealtimeData,10 * 1000);
}
function clearRealTimer()
{
    clearInterval(setTimeFun);
}
