var express = require('express');
var router = express.Router();
var usrOnline = require('../common/onlinectrl');

router.post('/',function(req,res,next)
{
    var resDb = {
        rstcode: "success",
        desc:"",
        data:''
    };
    var reqDb = JSON.parse(req.body.postData);
    var user = {};
    user.name = reqDb.data.name;
    user.id = req.body.postUserHandle || "";
    usrOnline.getInstance().isValidSession(user,function(bAllowed){
        if(bAllowed)
        {
            usrOnline.getInstance().delOfflineUser(user,function(error){});
        }
        res.send(JSON.stringify(resDb));
    });
});

module.exports = router;