/**
 * Created by Administrator on 2017/3/30.
 */
'use strict';
//collect data interval default 30s

var gCollectInterval = 30;
//default xUnit 60s
var gXUnit = 60;
var gCollectSpan = gXUnit/gCollectInterval -1;

/**
 * 功能说明：得到每个数组的最大值，并且相应缩小所显示的数值
 * **/
function tempFun(dataArr,defaultData)
{
    var maxValue =  d3.max(dataArr,function(a){
        return +a;
    });
    var blockDataUnit = getMaxData(maxValue,defaultData);
    return blockDataUnit;
}
function getMaxData(data,defaultData)
{
    var unitInfo = {
        'unitStr':'',
        'unitValue':1,
        'maxFlag':false
    };
    unitInfo.maxFlag = (data > defaultData) ? (true):(false);
    var dataStr = data.toString();
    var dataStrLength = dataStr.length;
    var n = dataStrLength - 3;//图形Y轴显示数值最大为3位数
    if(n <= 0)
    {
        unitInfo.unitStr = "";
        unitInfo.unitValue = 1;
    }else{
        if(n == 1)
        {
            unitInfo.unitStr = "<tspan>/10</tspan>";
        }else{
            unitInfo.unitStr = "<tspan>/10<tspan baseline-shift='super'>" + n + "</tspan></tspan>";
        }
        unitInfo.unitValue = Math.pow(10,n);
    }
    return unitInfo;
}

function getRecordMaxLength(recordField){
    //recordField --- [[],[]]
    if(recordField.length == 0){
        return recordField.length;
    }
    var lengthArray = [];
    for(var i = 0; i < recordField.length; i++){
        lengthArray.push(recordField[i].length);
    }
    if(lengthArray.length > 0){
        return Math.max.apply(Math,lengthArray);
    }else{
        return 0;
    }
}
function showOSDLoad(dfsdata){
    if(typeof  dfsdata.OSDData == "undefined"){
        return;
    }
    var OSDData = dfsdata.OSDData;
    var dataArray = [];
    for(var i = 0; i < OSDData.length; i++){
        var oneOSD = {};
        oneOSD.name = OSDData[i].name;
        oneOSD.frequency = OSDData[i].load;
        dataArray.push(oneOSD);
    }
    for(var j in dataArray){
        var dataArrayInfo = [Number(dataArray[j].frequency)*100];
        var dataArrayUnit = tempFun(dataArrayInfo,100);
        dataArrayUnit.maxFlag = true;
        dataArray.maxFlag = dataArrayUnit.maxFlag;
    }
    dfsbarchart({
        'containerId':'barChartOsd',
        'data':dataArray.slice(0,15),
        //'data':dataInfo.slice(0,3),
        'legendWidth':100,
        'margin':{top: 20, right: 20, bottom: 30, left: 40},
        'axisName': ["负载率/%","名称"],
        'upBtnId':'osdUpBtn',
        'downBtnId':'osdDownBtn',
        'titleHeight':20,
        'defaultY':100,
        'unit':'%',
        'hasMaxY':dataArray.maxFlag,
        'yDomain': [1, 100]
    });
    /*
     * 追加总览->OSD负载率翻页按钮
     * */
    var result = [];
    for(var index = 0;index < dataArray.length;index=index+15){
        result.push(dataArray.slice(index,index+15));
    }
    var j = 0;
    d3.select("#osdDownBtn")
     .on("click",function(){
            j = j + 1;
            barchartOsdextend();
        });
    d3.select("#osdUpBtn")
        .on("click",function(){
            if(j > 0){
                j--;
                barchartOsdextend();
            }
        });
    function barchartOsdextend(){
        if(j<result.length){
            dfsbarchart({
                'containerId': 'barChartOsd',
                'data': result[j],
                'legendWidth':100,
                'margin':{top: 20, right: 20, bottom: 30, left: 40},
                'axisName': ["负载率/%","名称"],
                'upBtnId':'osdUpBtn',
                'downBtnId':'osdDownBtn',
                'titleHeight':20,
                'defaultY':100,
                'unit':'%',
                'hasMaxY':dataArray.maxFlag,
                'yDomain': [1, 100]
            })
        }
        d3.select("#osdDownBtn")
            .on("click",function(){
                j = j+1;
                barchartOsdextend();
            });
        d3.select("#osdUpBtn")
            .on("click",function(){
                if(j > 0){
                    j--;
                    barchartOsdextend();
                }
            });
    }
}
function showMRCLoad(dfsdata){
    if(typeof  dfsdata.MRCData == "undefined"){
        return;
    }
    var MRCData = dfsdata.MRCData;
    var dataArray = [];
    for(var i = 0; i < MRCData.length; i++){
        var oneMRC = {};
        oneMRC.name = MRCData[i].name;
        oneMRC.frequency = MRCData[i].load;
        dataArray.push(oneMRC);
    }
    for(var j in dataArray){
        var dataArrayInfo = [Number(dataArray[j].frequency)*100];
        var dataArrayUnit = tempFun(dataArrayInfo,100);
        dataArrayUnit.maxFlag = true;
        dataArray.maxFlag = dataArrayUnit.maxFlag;
    }
    //dataInfo1.maxFlag = false;
    dfsbarchart({
        'containerId':'barChartMrc',
        'data':dataArray.slice(0,15),
        //'data':dataInfo1.slice(0,3),
        'legendWidth':100,
        'margin':{top: 20, right: 20, bottom: 30, left: 40},
        'axisName': ["负载率/%","名称"],
        'upBtnId':'mrcUpBtn',
        'downBtnId':'mrcDownBtn',
        'titleHeight':20,
        'defaultY':100,
        'unit':'%',
        'hasMaxY':dataArray.maxFlag,
        //'hasMaxY':dataInfo1.maxFlag,
        'xDomain': [1, 60],//默认的x的比例尺的自变量
        'yDomain': [1, 100]
    });
    /**
     * 追加总览->MRC负载率翻页按钮
     */
    var k = 0;
    d3.select("#mrcDownBtn")
        .on("click",function(){
            k = k+1;
            barchartMrcextend();
        });
    d3.select("#mrcUpBtn")
        .on("click",function(){
            if(k > 0){
                k--;
                barchartMrcextend();
            }
        });
    var result = [];
    for(var index = 0;index < dataArray.length;index=index+15){
        result.push(dataArray.slice(index,index+15));
    }
    function barchartMrcextend(){
        if(k<result.length){
            dfsbarchart({
                'containerId': 'barChartMrc',
                'data': result[k],
                'legendWidth':100,
                'margin':{top: 20, right: 20, bottom: 30, left: 40},
                'axisName': ["负载率/%","名称"],
                'upBtnId':'mrcUpBtn',
                'downBtnId':'mrcDownBtn',
                'titleHeight':20,
                'defaultY':100,
                'unit':'%',
                'hasMaxY':dataInfo1.maxFlag,
                'yDomain': [1, 100]
            })
        }
        d3.select("#mrcDownBtn")
            .on("click",function(){
                k = k+1;
                barchartMrcextend();
            });
        d3.select("#mrcUpBtn")
            .on("click",function(){
                if(k > 0){
                    k--;
                    barchartMrcextend();
                }
            });
    }
}


function showVolumeInfo(dfsdata){
    if(typeof  dfsdata.MRCData == "undefined"){
        return;
    }
    var MRCData = dfsdata.MRCData;
    var dataArray = [];
    var oneMRC;
    for(var i = 0; i < MRCData.length; i++){
        oneMRC= JSON.parse(MRCData[i].volumes);
    }
    var usageSpce = 0;
    var disUsage = 0;
    for(var j = 0;j<oneMRC.length;j++){
        var oneVolume = {};
        oneVolume.name = oneMRC[j].volumeName;
        oneVolume.frequency = oneMRC[j].diskUsage;
        dataArray.push(oneVolume);
        disUsage = disUsage + Number(oneMRC[j].diskUsage);
        var totalSpace = (oneMRC[j].totalDisk).split(' ')[0];
        usageSpce = usageSpce + Number((oneMRC[j].occupiedDisk).split(' ')[0]);
    }

    if(disUsage < 1.00){
        var oneVolume1 = {};
        oneVolume1.name = "others";
        oneVolume1.frequency = 1.00-disUsage;
        dataArray.push(oneVolume1);
    }
    d3.select("#totalSpace").html((totalSpace/1024).toFixed(2)+"GB");
    d3.select("#usageSpace").html((usageSpce/1024).toFixed(2)+'GB');
    d3.select("#num").html(oneMRC.length+1);
    /*饼图主函数*/
    piechartFun({
        'containerId':'pieChartViewVolume',
        //'data':pieDataInfo
        'data':dataArray
    });
}
function showOSDDiskUsage(dfsdata){
    if(typeof  dfsdata.OSDData == "undefined"){
        return;
    }
    var color_arr = ["#9B69FB","#9EC935","#73E5FD","#FA8356","#466928","#99CC33","#00CBFF","#005CFD","#003399","#8966FD"];
    var OSDData = dfsdata.OSDData;
    var dataArray = [];
    for(var i = 0; i < OSDData.length; i++){
        var oneOSDDiskUsage = {};
        oneOSDDiskUsage.name = OSDData[i].name;
        oneOSDDiskUsage.frequency = OSDData[i].diskusage;
        dataArray.push(oneOSDDiskUsage);
    }
    for(var j in dataArray){
        var dataArrayInfo = [Number(dataArray[j].frequency)*100];
        var dataArrayUnit = tempFun(dataArrayInfo,100);
        dataArrayUnit.maxFlag = true;
        dataArray.maxFlag = dataArrayUnit.maxFlag;
    }
    dfsbarchart({
        'containerId':'barChartOsdDisk',
        'data':dataArray,
        'legendWidth':100,
        'margin':{top: 20, right: 20, bottom: 30, left: 40},
        'axisName': ["负载率/%","名称"],
        'upBtnId':'',
        'downBtnId':'',
        'colorArr':color_arr,
        'titleHeight':20,
        'defaultY':100,
        'unit':'%',
        'hasMaxY':dataArray.maxFlag,
        'xDomain': [1, 60],//默认的x的比例尺的自变量
        'yDomain': [1, 100]
    });
}
function dealWithLineChartLoadData(dfsdata,moduleName,fieldName,maxValueFlag){
    if(typeof dfsdata == "undefined" || typeof dfsdata[moduleName] == "undefined"){
        return;
    }
    var setData = { "data_arr":[],"host_name_map":{},"maxValueUnit":""};
    var moduleArray = dfsdata[moduleName] || [];
    var recordArray = [];
    var nameObject = {};
    for(var i = 0; i < moduleArray.length; i++){
        var collectNum = JSON.parse((moduleArray[i])[fieldName]);
        recordArray.push(collectNum);
        nameObject[moduleArray[i].name || moduleArray[i].address] = moduleArray[i].name || moduleArray[i].address;
    }
    setData.host_name_map = nameObject;
    var maxLen = getRecordMaxLength(recordArray);
    if(maxLen == 0){
        return;
    }
    var spanCount = 0;
    for(var j = 0; j < maxLen; j++){
        if(spanCount == gCollectSpan){
            spanCount = 0;
            continue;
        }
        spanCount++;
        var oneRecordPoint = {};
        for(var m = 0; m < moduleArray.length; m++){
            var recordLen = recordArray[m].length;
            if(recordLen+j < maxLen){
                continue;
            }
            var name = moduleArray[m].name || moduleArray[m].address;
            oneRecordPoint.day = j*gCollectInterval/gXUnit;
            oneRecordPoint[name] = recordArray[m][recordLen+j-maxLen];
        }
        setData.data_arr.push(oneRecordPoint);
    }
    if(!maxValueFlag){
        for(var i = 0;i<setData.data_arr.length;i++){
            for(var j in setData.data_arr[i]){
                var setDataInfo = [setData.data_arr[i][j]];
                var setDataUnit = tempFun(setDataInfo,120);
                var setDataUnitStr = setDataUnit.unitStr;
                var setDataUnitValue = setDataUnit.unitValue;
                setData.data_arr[i][j] = setData.data_arr[i][j]/setDataUnitValue;
                setData.maxValueUnit = setDataUnitStr;
                setData.maxFlag = setDataUnit.maxFlag;
            }
        }
    }
    return setData;
}
function showOSDRAMUsage(dfsdata){
    if(typeof  dfsdata.OSDData == "undefined"){
        return;
    }
    var setData = dealWithLineChartLoadData(dfsdata,"OSDData","ramusage",true);
    lineChartFun({
        'containerId':'lineChartOsdMemory',
        'data':setData,
        'colorArr':["#7AC5FD"],
        'margin':{top: 0, right: 20, bottom: 30, left: 40},
        'legendWidth':'100',
        'axisName' : ["使用率/%","min"],
        'upBtnId':"",
        'downBtnId':"",
        'valueflag':true,
        'legendPosition':false,//右侧图示
        'leftPosition':'1625',
        'topPosition':'-100',
        'unit':'%',
        'order':"",
        'titleHeight': '40',
        'hasMaxY':setData.maxFlag,
        'defaultY':100,
        'hasArea':true,
        'hasPoint':true,
        'hasOddNum':false,
        'hasTitleIcon':false,
        'topTipX':20,
        'xDomain':[1,60],
        'yDomain':[1,100],

    });
}
function showMRCClientNum(dfsdata){
    if(typeof  dfsdata.MRCData == "undefined"){
        return;
    }
    var setData = dealWithLineChartLoadData(dfsdata,"MRCData","connectnum",false);
    //var dataArr = [];
    //for(var i = 0;i<hostInfoData.data_arr.length;i++){
    //    for(var j in hostInfoData.data_arr[i]){
    //        var valueData = {};
    //        valueData.value = hostInfoData.data_arr[i][j];
    //        valueData.valueName = j;
    //        dataArr.push(valueData);
    //    }
    //}
    //var initData1 = [];
    //var initData2 = [];
    //var k1 = 0;
    ////debugger;
    //for(var j = 0;j<dataArr.length;j= j+9){
    //    initData1.push(dataArr[j]);
    //}
    //for(var j1 = 0;j1<dataArr.length;j1= j1+9){
    //    k1++;
    //    if(k1 < 4){
    //        if(k1 != j1){
    //            initData2.push(dataArr[k1]);
    //        }
    //    }
    //}
    //
    //var mrcInitData = {};
    //var initData = [];
    //var tempInfo = new Object();
    //for(var k3 = 0;k3<initData2.length;k3++){
    //    tempInfo[initData2[k3].valueName] = initData2[k3].value;
    //    initData.push(tempInfo)
    //}
    //mrcInitData.valueArr = initData;
    //console.log(mrcInitData);
    //
    //var dataarr = new Array();
    //for(var j in hostInfoData.host_name_map){
    //    var nameData = {};
    //    nameData.name = j;
    //    nameData.nameValue = hostInfoData.host_name_map[j];
    //    dataarr.push(nameData);
    //}
    //var initMrcDataname = dataarr.slice(0,4);
    //var temp = new Object();
    //for(var k = 0;k<initMrcDataname.length;k++){
    //    temp[initMrcDataname[k].name] = initMrcDataname[k].nameValue;
    //}
    //mrcInitData.name_map = temp;
    ////console.log(mrcInitData);
    ////console.log(hostInfoData);
    lineChartFun({
        'containerId':'mrcClientLinkNum',
        'data':setData,
        //'data':mrcInitData,
        'colorArr':["#9B69Ff","#8EC935","#75E5FD","#FC8358","#46FA28","#9DAC33","#0FCBFF","#0A5CFD","#30339C","#6366FD"],
        'margin':{top: 0, right: 20, bottom: 30, left: 40},
        'legendWidth':'100',
        'axisName' : ["个数","min"],
        'upBtnId':'mrcClientUpBtn',
        'downBtnId':'mrcClientDownBtn',
        'valueflag':"",
        'hasMaxY':setData.maxFlag,
        'defaultY':10,
        'unit':'个',
        'order':setData.maxValueUnit,
        'hasOddNum':false,
        'topTipX':20,
        'hasPoint':false,
        'hasTitleIcon':true,
        'legendPosition':false,
        'leftPosition':'1625',
        'topPosition':'-60',
        'titleContent': '',
        'xDomain':[1,60],
        'yDomain':[1,100],
        'titleHeight': '40',
        'hasArea':true
    });
    /**
     * 追加MRC->客户连接数翻页按钮
     */
    //var result = [];
    //for(var index = 0;index < hostInfoData.length;index=index+3){
    //    result.push(hostInfoData.slice(index,index+3));
    //}
    //var j = 0;
    //d3.select("#mrcClientDownBtn")
    //    .on("click",function(){
    //        j = j + 1;
    //        lineMrcClientextend();
    //    });
    //d3.select("#mrcClientUpBtn")
    //    .on("click",function(){
    //        if(j > 0){
    //            j--;
    //            lineMrcClientextend();
    //        }
    //    });
    //function lineMrcClientextend(){
    //    if(j<result.length){
    //        lineChartFun({
    //            'containerId': 'mrcClientLinkNum',
    //            //'data': result[j],
    //            'data':"",
    //            'colorArr':["#9B69Ff","#8EC935","#75E5FD","#FC8358","#46FA28","#9DAC33","#0FCBFF","#0A5CFD","#30339C","#6366FD"],
    //            'margin':{top: 0, right: 20, bottom: 30, left: 40},
    //            'legendWidth':'100',
    //            'axisName' : ["个数","min"],
    //            'upBtnId':'mrcClientUpBtn',
    //            'downBtnId':'mrcClientDownBtn',
    //            'hasMaxY':setData.maxFlag,
    //            'defaultY':120,
    //            'unit':'个',
    //            'order':setData.maxValueUnit,
    //            'hasOddNum':false,
    //            'topTipX':20,
    //            'hasPoint':false,
    //            'hasTitleIcon':true,
    //            'legendPosition':false,
    //            'leftPosition':'1625',
    //            'topPosition':'-60',
    //            'titleContent': '',
    //            'xDomain':[1,60],
    //            'yDomain':[1,100],
    //            'titleHeight': '40',
    //            'hasArea':true
    //        })
    //    }
    //    d3.select("#mrcClientDownBtn")
    //        .on("click",function(){
    //            j = j+1;
    //            lineMrcClientextend();
    //        });
    //    d3.select("#mrcClientUpBtn")
    //        .on("click",function(){
    //            if(j > 0){
    //                j--;
    //                lineMrcClientextend();
    //            }
    //        });
    //}
}
function showMRCRAMUsage(dfsdata){
    if(typeof  dfsdata.MRCData == "undefined"){
        return;
    }
    var setData = dealWithLineChartLoadData(dfsdata,"MRCData","ramusage",true);
    lineChartFun({
        'containerId':'mrcMemoryUsage',
        'data':setData,
        'colorArr':["#FFFFFF","#3EC535","#1AE5FD","#CD8356","#806928","#CC0033","#AB0BFF","#330CFD","#FF3030","#FCDFBD"],
        'margin':{top: 0, right: 20, bottom: 30, left: 40},
        'legendWidth':'100',
        'axisName' : ["使用率/%","min"],
        'upBtnId':'mrcMemoryUpBtn',
        'downBtnId':'mrcMemoryDownBtn',
        'valueflag':true,
        'hasMaxY':setData.maxFlag,
        'defaultY':100,
        'unit':'%',
        'order':'',
        'hasOddNum':false,
        'topTipX':20,
        'hasPoint':false,
        'hasTitleIcon':true,
        'legendPosition':false,//右侧图示
        'leftPosition':'1615',
        'topPosition':'-60',
        'titleContent': '',
        'titleHeight': '40',
        'xDomain':[1,60],
        'yDomain':[1,100],
        'hasArea':true
    });
    /**
     * 追加MRC->内存使用率翻页按钮
     */

}
function showDIRClientNum(dfsdata){
    if(typeof  dfsdata.DIRData == "undefined"){
        return;
    }
    var setData = dealWithLineChartLoadData(dfsdata,"DIRData","connectnum",false);
    lineChartFun({
        'containerId':'dirClientLinkNum',
        'data':setData,
        'colorArr':["#FFFF66","#FFFF10","#CCDDAF","#AABBDD","#00882C","#81CCFF","#DDABEE","#EECA30","#220091","#00EEBB"],
        'margin':{top: 0, right: 20, bottom: 30, left: 40},
        'legendWidth':'100',
        'axisName' : ["个数"+setData.maxValueUnit,"min"],
        'upBtnId':'dirClientUpBtn',
        'downBtnId':'dirClientDownBtn',
        'valueflag':"",
        'hasMaxY':setData.maxFlag,
        'defaultY':10,
        'unit':'个',
        'order':setData.maxValueUnit,
        'hasOddNum':false,
        'topTipX':20,
        'hasPoint':false,
        'hasTitleIcon':true,
        'legendPosition':false,//右侧图示
        'leftPosition':'1615',
        'topPosition':'-60',
        'titleContent': '',
        'titleHeight': '40',
        'xDomain':[1,60],
        'yDomain':[1,100],
        'hasArea':true
    });
    /**
     * 追加DIR->客户连接数翻页按钮
     */

}
function showDIRMsgQueue(dfsdata){
    if(typeof  dfsdata.DIRData == "undefined"){
        return;
    }
    var setData = dealWithLineChartLoadData(dfsdata,"DIRData","requestnum",false);
    lineChartFun({
        'containerId':'dirMessageQuenue',
        'data':setData,
        'colorArr':["#EECDFA","#5BE00A","#7AC5FD","#ED8906","#5810EE","#FF0033","#99BCFF","#AA5CFD","#BE0099","#AAFFFD"],
        'margin':{top: 0, right: 20, bottom: 30, left: 40},
        'legendWidth':'100',
        'axisName' : ["个数"+setData.maxValueUnit,"min"],
        'upBtnId':'dirMessageUpBtn',
        'downBtnId':'dirMessageDownBtn',
        'valueflag':"",
        'hasMaxY':setData.maxFlag,
        'defaultY':120,
        'unit':'个',
        'order':setData.maxValueUnit,
        'hasOddNum':false,
        'topTipX':20,
        'hasPoint':false,
        'hasTitleIcon':true,
        'legendPosition':false,//右侧图示
        'leftPosition':'1615',
        'topPosition':'-60',
        'titleContent': '',
        'titleHeight': '40',
        'xDomain':[1,60],
        'yDomain':[1,100],
        'hasArea':true
    });
    /**
     * 追加DIR->消息队列翻页按钮
     */

}
function showDFSMonitor(data){
    if(typeof data == "undefined"){
        return;
    }
    showOSDLoad(data);
    showMRCLoad(data);
    showVolumeInfo(data);
    showOSDDiskUsage(data);
    showOSDRAMUsage(data);
    showMRCClientNum(data);
    showMRCRAMUsage(data);
    showDIRClientNum(data);
    showDIRMsgQueue(data);
}
function getDFSMonitorData(sub){
    var dfsid = window.sessionStorage.ux_currentChoiceDfsId;
    var reqData = {"dfsid":dfsid};
    var dfsAjax = new uxAjaxInterface();
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"monitormanage",
        request :{"mainRequest":"getDFSMonitorData","subRequest":"","ssubRequest":""},
        data    :reqData
    };
    if(sub == "first"){
        jsonDataObj.request.subRequest = "first";
    }
    var jsonDataStr = JSON.stringify(jsonDataObj);
    dfsAjax.ajaxRequest(false,jsonDataStr,function(retJson){
        var dataJson = JSON.parse(retJson);
        if(dataJson.rstcode == "success"){
            showDFSMonitor(dataJson.data);
        }else{
            uxAlert("获取DFS监控数据失败！");
        }
    });
}