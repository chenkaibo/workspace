'use strict';
var instanceInfo = {
     'name':'',
     'type':'',
     'path':'',
     'ID':'',
     'status':0
};
var DFSInfo = {
     'name':'',
     'ID':'',
     'status':0,
     'path':''
};
var instanceOperData;
var databaseUserInfo = {  //用于记录数据库连接或者列表获取时的用户名及密码
    'userName':'',
    'passward':'',
    'dataName':'',
    'insID':''
};
var getFirstDatabaseFlag = true,setTimeInsStatus,getDfsStateLoading;
/*
* 实例操作元素
* */
var instanceOperContainDiv;
function instanceOperElem(data,reflashFlag)
{
    window.focus();
    changePath("云数据库管理->实例管理->实例操作");
    window.sessionStorage.ux_pagePath = "instanManage,insOper";
    setParameterData(data);
    instanceOperData = data;
    var baseSpanData = data.split(",");
    databaseUserInfo.insID = baseSpanData[3];
    getEachData(data);
    var baseInfoItem;
    if(instanceInfo.type == "云实例")
    {
        baseInfoItem = ['实例名称：','实例类型：','创建时间：','实&nbsp;&nbsp;例&nbsp;&nbsp;ID：','实例路径：','DFS&nbsp;&nbsp;&nbsp;&nbsp;ID：'];
    }else{
        baseInfoItem = ['实例名称：','实例类型：','创建时间：','实&nbsp;&nbsp;例&nbsp;&nbsp;ID：','实例路径：'];
    }
    getInitStatus();
    d3.select("#mainContainDiv").remove();
    instanceOperContainDiv = d3.select("#instanaceBodyId")
        .append("div")
        .attr({
            'id':'mainContainDiv',
            'class':'siteList-content'
        })
        .append("div")
        .attr("id","contain-div-id")
        .style("padding","70px 0px 0px 32px");
    instanceOperContainDiv.append("button")
        .attr("class","btn btn-default admitClick backBtn")
        .attr("onClick","goBack()")
        .html("返回上一级");
    /*
    * 基本信息*/
    var baseInfoDiv = instanceOperContainDiv.append("fieldset")
        .attr("id","baseInfoDiv");
    baseInfoDiv.append("legend")
        .html("基本信息");
    for(var i = 0;i < baseInfoItem.length; i++)
    {
        if(i == 0)
        {
            baseInfoDiv.append("div")
                .attr({
                    'id':'baseItemId' + i,
                    'class':'baseItemClass'
                })
                .style("padding-top",function(){
                    return ((instanceInfo.type == "云实例") ? ("12px"):("40px"));
                })
                .html(baseInfoItem[i]);
        }else{
            baseInfoDiv.append("div")
                .attr({
                    'id':'baseItemId' + i,
                    'class':'baseItemClass'
                })
                .html(baseInfoItem[i]);
        }
    }
    d3.selectAll(".baseItemClass").append("span").each(function(d,i){
        d3.select(this).attr({
            'id':'span' + i,
            'class':'baseClass'
        }).html(baseSpanData[i]);
    });
    /*
     * 实例操作*/
    updateStatus();
    /*
     * 数据库列表*/
   var databaseDiv =  instanceOperContainDiv.append("fieldset")
        .attr("id","baseDataListDIv");
    databaseDiv.append("legend")
        .html("数据库列表");
    databaseDiv.append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","getDatabaseBtnId")
        .style("margin","20px 0px 0px 30px")
        .on("click",function(){
            d3.select(this).classed("admitClick",false);
            getDatabaseDataElem();
        })
        .html("获取数据库列表");
    databaseDiv.append("button")
        .attr({
            'id':'reflashBtn',
            "class":"delBtnClass disabledElem reflash-btn",
            "disabled":"disabled"
        })
        .on("click",function(){
            getDatabaseData(true);
        })
        .html("刷&nbsp;&nbsp;新");
    databaseDiv.append("div")
        .attr("id","dataBaseQuery");
    d3.select("#dataBaseQuery").append("span")
        .html("数据库名：");
    d3.select("#dataBaseQuery").append("input")
        .attr("id","queryDatabaseName")
        .style("color","#57D1F7");
    d3.select("#dataBaseQuery").append("button")
        .attr("class","searchSite-btn searchSite btn btn-bg-color")
        .on("click",function(){
            queryDatabase();
        });
    databaseDiv.append("table")
        .attr("id","databaseTableId");
    if(reflashFlag && databaseUserInfo.userName != "" && databaseUserInfo.passward != "")
    {
        getDatabaseData(true);
    }
    setDfsRealTimer();
}
/*****************************实例操作函数处理区****************************/
/***更新实例的运行状态***/
function updateStatus()
{
    var currentRole = window.sessionStorage.ux_curUserRole;
    if(currentRole == 1)
    {
        if(instanceInfo.type == '云实例')
        {
            instanceOperDivElem("#contain-div-id","../common/image/startrun.gif","../common/image/startrun.gif");
        }else{
            var insStatusIcon = (instanceInfo.status == 1) ? ("../common/image/startrun.gif"):("../common/image/stoprun.svg");
            localInstanceOperDivElem("#contain-div-id",insStatusIcon);
        }
        d3.selectAll(".no-handle").style({
            "cursor":"not-allowed"
        }).attr("title","您目前没有操作权限！");
    }else{
        if(instanceInfo.type == '云实例')
        {
            if(DFSInfo.status != 1)
            {
                instanceOperStopDivElem("#contain-div-id","../common/image/stoprun.svg");
            }else if(DFSInfo.status == 1 && instanceInfo.status != 1){
                instanceOperDivElem("#contain-div-id","../common/image/stoprun.svg","../common/image/startrun.gif");
            }else if(DFSInfo.status == 1 && instanceInfo.status == 1){
                instanceOperDivElem("#contain-div-id","../common/image/startrun.gif","../common/image/startrun.gif");
            }else{
                uxAlert("状态获取失败！");
            }
        }else{
            var insStatusIcon = (instanceInfo.status == 1) ? ("../common/image/startrun.gif"):("../common/image/stoprun.svg");
            localInstanceOperDivElem("#contain-div-id",insStatusIcon);
        }
        d3.selectAll(".no-handle").style({
            "cursor":"hand"
        });
    }
}
/****实例操作界面元素设置*********/
function instanceOperDivElem(contain,instanImageStr,DFSImageStr)
{
    d3.select("#instanceOperDiv").remove();
    var instanceDiv = d3.select(contain).append("fieldset")
        .attr({
            "id":"instanceOperDiv"
        });
    instanceDiv.append("legend")
        .html("实例操作");
    instanceDiv.append("div")
        .attr("class","instance-Contain");
    var stopRunDiv = instanceDiv.append("div")
        .attr({
            "id":"stop-run-div",
            "class":"DfsOperDiv"
        });
    stopRunDiv.append("img")
        .attr({
            "src":DFSImageStr,
            "id":"DFS-img-id"
        });
    var DFSInfoDiv = stopRunDiv.append("div")
        .attr("class","DFS-contain-div");
    DFSInfoDiv.append("span")
        .attr("class","instanceItemClass")
        .html("DFS：");
    DFSInfoDiv.append("span")
        .style("color","#FFF")
        .html(DFSInfo.name);
    stopRunDiv.append("button")
        .attr({
            "id":"DFSStartId",
            "class":function(){
                var classNameStr = "btn btn-bg-color no-handle";
                if(DFSInfo.status == 2)
                {
                    classNameStr = classNameStr + " instanceStartClass";
                    d3.select(this)[0][0].disabled = false;
                }else{
                    classNameStr = classNameStr + " startUpNoOper";
                    d3.select(this)[0][0].disabled = true;
                }
              return classNameStr;
            },
            "onClick":"operBtnFun(" + 1 + "," + 1 + ")"
        });
    stopRunDiv.append("button")
        .attr({
            "id":"DFSStopId",
            "class":function(){
                var classNameStr = "btn btn-bg-color no-handle";
                if(DFSInfo.status == 1)
                {
                    classNameStr = classNameStr + " instanceStopClass";
                    d3.select(this)[0][0].disabled = false;
                }else{
                    classNameStr = classNameStr + " stopDownNoOper";
                    d3.select(this)[0][0].disabled = true;
                }
                return classNameStr;
            },
            "onClick":"operBtnFun(" + 1 + "," + 2 + ")"
        });
    var startRunDiv = instanceDiv.append("div")
        .attr("class","start-div-id instanDiv");
    startRunDiv.append("img")
        .attr({
            "src":instanImageStr,
            "id":"instance-img-class"
        });
    var instaceInfoDiv = startRunDiv.append("div")
        .attr("class","instance-info-class");
    instaceInfoDiv.append("span")
        .attr("class","instanceItemClass")
        .html("实&nbsp;&nbsp;例：");
    instaceInfoDiv.append("span")
        .style("color","#FFF")
        .html(instanceInfo.name);
    startRunDiv.append("button")
        .attr({
            "id":"instanceStartId",
            "class":function(){
                var classNameStr = "btn btn-bg-color no-handle";
                if(instanceInfo.status == 2)
                {
                    classNameStr = classNameStr + " instanceStartClass";
                    d3.select(this)[0][0].disabled = false;
                }else{
                    classNameStr = classNameStr + " startUpNoOper";
                    d3.select(this)[0][0].disabled = true;
                }
                return classNameStr;
            },
            "onClick":"operBtnFun(" + 2 + "," + 1 + ")"
        });
    startRunDiv.append("button")
        .attr({
            "id":"instanceStopId",
            "class":function(){
                var classNameStr = "btn btn-bg-color no-handle";
                if(instanceInfo.status == 1)
                {
                    classNameStr = classNameStr + " instanceStopClass";
                    d3.select(this)[0][0].disabled = false;
                }else{
                    classNameStr = classNameStr + " stopDownNoOper";
                    d3.select(this)[0][0].disabled = true;
                }
                return classNameStr;
            },
            "onClick":"operBtnFun(" + 2 + "," + 2 + ")"
        });
    startRunDiv.append("button")
        .attr("class","btn btn-default admitClick config-btn")
        //.style({
        //
        //    "margin":"23px 0px 0px 50px",
        //    "padding":"3px 20px"
        //})
        .on("click",function(){
            d3.select(this).classed("admitClick",false);
            configureInstance();
        })
        .html("配置实例");
}
function localInstanceOperDivElem(contain,instanImageStr)
{
    d3.select("#instanceOperDiv").remove();
    var instanceDiv = d3.select(contain).append("fieldset")
        .attr({
            "id":"instanceOperDiv"
        });
    instanceDiv.append("legend")
        .html("实例操作");
    instanceDiv.append("div")
        .attr("class","instance-stop-Contain localInsContain");
    var startRunDiv = instanceDiv.append("div")
        .attr("class","start-div-id onlyInstanOperDiv");
    startRunDiv.append("img")
        .attr({
            "src":instanImageStr,
            "id":"instance-img-class"
        });
    var instaceInfoDiv = startRunDiv.append("div")
        .attr("class","instance-info-class");
    instaceInfoDiv.append("span")
        .attr("class","instanceItemClass")
        .html("实&nbsp;&nbsp;例：");
    instaceInfoDiv.append("span")
        .style("color","#FFF")
        .html(instanceInfo.name);
    startRunDiv.append("button")
        .attr({
            "id":"instanceStartId",
            "class":function(){
                var classNameStr = "btn btn-bg-color no-handle";
                if(instanceInfo.status == 2)
                {
                    classNameStr = classNameStr + " instanceStartClass";
                    d3.select(this)[0][0].disabled = false;
                }else{
                    classNameStr = classNameStr + " startUpNoOper";
                    d3.select(this)[0][0].disabled = true;
                }
                return classNameStr;
            },
            "onClick":"operBtnFun(" + 2 + "," + 1 + ")"
        });
    startRunDiv.append("button")
        .attr({
            "id":"instanceStopId",
            "class":function(){
                var classNameStr = "btn btn-bg-color no-handle";
                if(instanceInfo.status == 1)
                {
                    classNameStr = classNameStr + " instanceStopClass";
                    d3.select(this)[0][0].disabled = false;
                }else{
                    classNameStr = classNameStr + " stopDownNoOper";
                    d3.select(this)[0][0].disabled = true;
                }
                return classNameStr;
            },
            "onClick":"operBtnFun(" + 2 + "," + 2 + ")"
        });
    startRunDiv.append("button")
        .attr("class","btn btn-default admitClick")
        .style("margin","23px 0px 0px 56px")
        .on("click",function(){
            d3.select(this).classed("admitClick",false);
            configureInstance();
        })
        .html("配置实例");
}
function instanceOperStopDivElem(contain,DFSImageStr)
{
    d3.select("#instanceOperDiv").remove();
    var instanceDiv = d3.select(contain).append("fieldset")
        .attr({
            "id":"instanceOperDiv"
        });
    instanceDiv.append("legend")
        .html("实例操作");
    instanceDiv.append("div")
        .attr("class","instance-stop-Contain");
    d3.select("#instanceOperDiv").append("p")
        .attr("class","HintP")
        .html("注意：启动实例之前，请先启动DFS").style("color","#FFF");
    var stopRunDiv = instanceDiv.append("div")
        .attr({
            "id":"stop-run-div",
            "class":" onlyCloudOperDiv"
        });
    stopRunDiv.append("img")
        .attr({
            "src":DFSImageStr,
            "id":"DFS-img-id"
        });
    var DFSInfoDiv = stopRunDiv.append("div")
        .attr("class","DFS-contain-div");
    DFSInfoDiv.append("span")
        .attr("class","instanceItemClass")
        .html("DFS：");
    DFSInfoDiv.append("span")
        .style("color","#FFF")
        .html(DFSInfo.name);
    stopRunDiv.append("button")
        .attr({
            "id":"DFSStartId",
            "class":function(){
                var classNameStr = "btn btn-bg-color no-handle";
                if(DFSInfo.status == 2)
                {
                    classNameStr = classNameStr + " instanceStartClass";
                    d3.select(this)[0][0].disabled = false;
                }else{
                    classNameStr = classNameStr + " startUpNoOper";
                    d3.select(this)[0][0].disabled = true;
                }
                return classNameStr;
            },
            "onClick":"operBtnFun(" + 1 + "," + 1 + ")"
        });
    stopRunDiv.append("button")
        .attr({
            "id":"DFSStopId",
            "class":function(){
                var classNameStr = "btn btn-bg-color no-handle";
                if(DFSInfo.status == 1)
                {
                    classNameStr = classNameStr + " instanceStopClass";
                    d3.select(this)[0][0].disabled = false;
                }else{
                    classNameStr = classNameStr + " stopDownNoOper";
                    d3.select(this)[0][0].disabled = true;
                }
                return classNameStr;
            },
            "onClick":"operBtnFun(" + 1 + "," + 2 + ")"
        });
}
/**配置实例处理函数********/
function configureInstance()
{
    clearDfsRealTimer();
    getConfigureInstanElem(instanceInfo.ID);
}
/*
 * operId:1
 *   DFS操作 statusId 1:开启操作 2:停止操作
 * operId:2
 *   instance操作 statusId 1:开启操作 2:停止操作
 * */
function operBtnFun(operId,statusId)
{
    var currentRole = window.sessionStorage.ux_curUserRole;
    if(currentRole == 1)
    {
        uxAlert("您目前没有操作权限！");
        return;
    }
    /*
     * 发送数据格式，数据域无数据
     * */
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"",
        request :{"mainRequest":"","subRequest":"","ssubRequest":""},
        data    :{
            opertype:statusId,
        },
    };
    var currentStatus,jsonDataStr;
    if(operId == 1)
    {
        //if(DFSInfo.status == statusId){
        //    currentStatus = (statusId == 1) ? ("启动"):("停止");
        //    uxAlert("当前DFS已为【"+currentStatus+"】状态");
        //    return ;
        //}
        dfsStateLoading();
        jsonDataObj.router = "dfsmanage";
        jsonDataObj.request.mainRequest = "optDFS";
        jsonDataObj.data.instid = instanceInfo.ID;
        jsonDataObj.data.dfsid = DFSInfo.ID;
        jsonDataObj.data.dfspath = DFSInfo.path;
        jsonDataStr = JSON.stringify(jsonDataObj);
        ux_reqInterface.ajaxRequest(false,jsonDataStr,dfsSwitchCallback);
    }else{
        //if(instanceInfo.status == statusId)
        //{
        //    currentStatus = (statusId == 1) ? ("启动"):("停止");
        //    uxAlert("当前实例已为【"+currentStatus+"】状态");
        //    return ;
        //}
        jsonDataObj.router = "instmanage";
        jsonDataObj.request.mainRequest = "optInst";
        jsonDataObj.data.instname = instanceInfo.name;
        jsonDataObj.data.instpath = instanceInfo.path;
        jsonDataObj.data.instid = instanceInfo.ID;
        jsonDataObj.data.type = instanceInfo.type == "本地实例" ? "1" : "2";
        jsonDataStr = JSON.stringify(jsonDataObj);
        ux_reqInterface.ajaxRequest(false,jsonDataStr,operBtnCallback);
    }
}
function operBtnCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){

        //if(jsonObj.data.oper == "inst"){//实例操作
            instanceInfo.status = jsonObj.data.instanStatus;
            updateStatus();
            /*如果DFS运行，那么实例状态为运行显示，同时DFS停止操作禁用*/
            /*如果实例状态为停止，那么DFS停止操作放开*/
            if(instanceInfo.status == 1 && instanceInfo.type == '云实例')
            {
                d3.select("#DFSStopId")[0][0].disabled = true;
            }else{
                d3.select("#DFSStopId")[0][0].disabled = false;
            }
        //}else if(jsonObj.data.oper == "DFS"){//DFS操作
        //    //if(instanceInfo.type == '云实例'){
        //    //    DFSInfo.status = jsonObj.data.dfsStatus;
        //    //}else{
        //    //    DFSInfo.status = "";
        //    //}
        //}else{
        //    return;
        //}

    }else{
        uxAlert("实例操作失败！");
    }
}
function dfsSwitchCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        currDfsStateLoad(jsonObj.data);
    }else{
        uxAlert("dfs操作失败!");
    }
}

//获取DFS状态加载进度
function currDfsStateLoad(data){
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"getOptDFSState","subRequest":"","ssubRequest":""},
        data    :data
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,dfsStateLoadCallback);
}
//更具后台返回的获取DFS状态进度判断是否继续发送请求
function dfsStateLoadCallback(retJson){
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success") {
        //0:未启动，1:启动中，2:启动成功，3:启动失败
        //0:未停止，1:停止中，2:停止成功，3:停止失败
        if(jsonObj.data.result == 2 || jsonObj.data.result == 3){
            d3.select("#dialogBgLoading").remove();
            d3.select("#dialogLoading").remove();
            if(jsonObj.data.opertype == 1){
                if(jsonObj.data.result == 2){
                    DFSInfo.status = 1;
                    uxAlert("DFS启动成功！");
                    updateStatus();
                }else if(jsonObj.data.result == 3){
                    uxAlert("DFS启动失败！")
                }
            }else{
                if(jsonObj.data.result == 2){
                    DFSInfo.status = 2;
                    uxAlert("DFS停止成功！");
                    updateStatus();
                }else if(jsonObj.data.result == 3){
                    uxAlert("DFS停止失败！");
                }
            }
            return;
        } else{
            setTimeout(function(){currDfsStateLoad(jsonObj.data)},2*1000);
        }
    }else{
        uxAlert(jsonObj.desc);
    }
}
function dfsStateLoading()
{
    d3.select("#dialogBgLoading").remove();
    d3.select("#dialogLoading").remove();
    var className;
    d3.select("#mainContainDiv").append("div")
        .attr("id","dialogBgLoading");
    var outPage = d3.select("#mainContainDiv").append("div")
        .attr("id","dialogLoading");
    var editFrom = outPage.append("div")
        .attr("id","editFromLoading");
    editFrom.append("img")
        .attr({
            "src":'../../../modules/common/image/loading.gif',
            "class":'loading-img',
            "alt":"加载中......"
        });
    editFrom.append("span")
        .attr({
            "class":"optering-title"
        })
        .html("正在操作，请稍候......");
    if(d3.select("#dialogLoading").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgLoading').fadeIn(300);
    $('#dialogLoading').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
/*
 * dfs与实例状态的初始化
 * */
function getInitStatus()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"getInstState","subRequest":"","ssubRequest":""},
        data    :{
            instname:instanceInfo.name,
            instpath:instanceInfo.path,
            instid:instanceInfo.ID,
            type:instanceInfo.type == "本地实例" ? "1" : "2",
            status:instanceInfo.status
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,getInitStatusCallback);
}
function getInitStatusCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        instanceInfo.status = jsonObj.data.instState;
        DFSInfo.name = jsonObj.data.dfsName;
        DFSInfo.status = jsonObj.data.dfsState;
        DFSInfo.path = jsonObj.data.dfspath;
        updateStatus();
    }else{
        clearDfsRealTimer();
        uxAlert("dfs状态获取失败！");
    }
}
/********************************数据库相关操作函数区*****************************/
var currentDatabase;
function InitDatabaseTable()
{
    var par = [{field:'boxStatus',radio: true,align: 'center'},
        {field:'index',title:'序&nbsp;&nbsp;&nbsp;&nbsp;号',align: 'center'},
        {field:'databaseName',title:'数据库名称',align: 'center'},
        {field: 'databaseOperate', title: '操&nbsp;&nbsp作',align: 'center', formatter:function(value,row,index){
            if(row.operStatus == 0) {
                var constr = '<a title = "断开">' + '<button class = "btn-link disconnect-img" onclick = "connectDatabase(0,\'' + row.databaseName + '\',\'' + index + '\')"></button>' + '</a>' +
                    '<span style = "color: #1A5DAB" id = "separator">&nbsp;</span>' + '|' + '<span>&nbsp;</span>'
                    + '<a title = "管理">' + '<button class = "btn-link manage-btn-img" onclick = "databaseManage(\'' + row.databaseName + '\')" data-toggle = "modal" data-backdrop = "static"></button>'+ '</a>';
                return constr;
            }else{
                var discon = '<a title = "连接">' + '<button class = "btn-link database-connect-img" onclick = "connectDatabase(1,\'' + row.databaseName + '\',\'' + index + '\')"></button>' + '</a>';
                return discon;
            }
        }}
    ];
    $('#databaseTableId').bootstrapTable({
        classes:"table table-no-bordered",
        toolbar:"#toolbar",
        height:560,
        columns: par,
        idField:"index"
    });
}
function getDatabaseDataElem()
{
    var className;
    if(instanceInfo.status == 2)
    {
        uxAlert("请先启动实例");
        d3.select("#getDatabaseBtnId").classed("admitClick",true);
        return;
    }
    DatabaseDataInfoElem(instanceOperContainDiv);
    d3.select("#ItemSpanDatabase").text("获取数据库列表").classed("databaseTitle",true);
    d3.select("#sureBtnDatabase").attr({'onclick':'getDatabaseData(false)'});
    d3.select("#dialogDatabase").style({
        'width': '400px',
        'height': '275px'
    });
    if(d3.select("#dialogDatabase").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgDatabase').fadeIn(300);
    $('#dialogDatabase').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function DatabaseDataInfoElem(userContainDivElem)
{
    d3.select("#dialogBgDatabase").remove();
    d3.select("#dialogDatabase").remove();
    var pupUpItem = "";
    var popUpInputArray = ["用&nbsp;&nbsp;户&nbsp;名","密&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码"];
    userContainDivElem.append("div")
        .attr("id","dialogBgDatabase");
    var outPage = userContainDivElem.append("div")
        .attr("id","dialogDatabase");
    var editFrom = outPage.append("div")
        .attr("id","editFromDatabase");
    var newUserItemSpan = editFrom.append("span")
        .attr("id","ItemSpanDatabase")
        .html(pupUpItem);
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos");
    for(var i = 0;i < popUpInputArray.length;i++)
    {
        var editFromLi = editFormUl.append("li");
        editFormUl.selectAll("li").attr("class",function(d,i){return ((i == 1) ? ("editUl get-database-li"):("editUl"))});
        editFromLi.append("label").append("span")
            .attr("class","editFromLiSpan")
            .html(popUpInputArray[i]);
        if(i == 1)
        {
            editFromLi.append("input").attr({
                'class':'ipt database-input',
                'id':'input' + i,
                'type':'password'
            });
        }else{
            editFromLi.append("input")
                .attr({
                    'id':"input" + i,
                    'type':"text",
                    'class':'ipt database-input',
                    'autofocus':true
                });
        }
    }
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop getDatabase")
        .append("button")
        .attr("id","sureBtnDatabase")
        .attr("class","btn btn-sm btn-bg-color popUpBtn")
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-sm btn-bg-color popUpBtn claseDialogBtn")
        .attr("id","claseDialogBtnDatabase")
        .on("click",function(){
            d3.select("#dialogDatabase").classed("bounceIn",false);
            $('#dialogBgDatabase').fadeOut(300,function(){
                $('#dialogDatabase').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#getDatabaseBtnId").classed("admitClick",true);
        })
        .html("取&nbsp;&nbsp;消");
    document.onkeydown = function(event_e){
        if(window.event)
            event_e = window.event;
        var int_keycode = event_e.charCode||event_e.keyCode;
        if(int_keycode == 13){
            $('#sureBtnDatabase').click();
        }
    }
}
function getDatabaseData(flag)
{
    if(!flag)
    {
        databaseUserInfo.userName = trim(d3.select("#input0")[0][0].value);
        databaseUserInfo.passward = trim(d3.select("#input1")[0][0].value);
        if(databaseUserInfo.userName == "" || databaseUserInfo.passward == "")
        {
            uxAlert("请输入数据库用户信息");
            return;
        }
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbmanage",
        request :{"mainRequest":"enumDbList","subRequest":"","ssubRequest":""},
        data    :{
            webusername:window.sessionStorage.ux_curUserName,
            dbusername:databaseUserInfo.userName,
            instid:instanceInfo.ID,
            dbname:databaseUserInfo.dataName,
            passwd:databaseUserInfo.passward,
        },
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,databaseDataCallback);
}
function databaseDataCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success")
    {
        var dataJson =  getNewDbJsonData(jsonObj.data);
        currentDatabase  = dataJson;
        InitDatabaseTable();
        $("#databaseTableId").bootstrapTable('load',dataJson);
        d3.select("#reflashBtn")[0][0].disabled = false;
        d3.select("#reflashBtn").classed("delBtnClass",false);
        d3.select("#reflashBtn").classed("btn admitClick",true);
    }else{
        uxAlert("初始化数据库失败！");
    }
    d3.select("#dialogDatabase").classed("bounceIn",false);
    $('#dialogBgDatabase').fadeOut(300,function(){
        $('#dialogDatabase').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#getDatabaseBtnId").classed("admitClick",true);
}
/*数据库查询 */
function queryDatabase()
{
    var queryDatabaseName = trim(d3.select("#queryDatabaseName")[0][0].value);
    if(queryDatabaseName == "")
    {
        //uxAlert("请输入需要查询的数据库名称！");
        getDatabaseData();
        //return ;
    }else{
        getDatabaseData();
        queryDatabaseCallabck(queryDatabaseName);
    }
}
function queryDatabaseCallabck(dataBaseName)
{
    var dataJson =  queryDatabaseJson(dataBaseName);
    $("#databaseTableId").bootstrapTable('load',dataJson);
}
function queryDatabaseJson(databaseName)
{
    var jsonData = [];
    for(var i = 0;i<currentDatabase.length;i++){
        if(currentDatabase[i].databaseName.indexOf(databaseName) != -1)
        {
            var dataValue = {};
            dataValue.index = (i + 1);
            dataValue.databaseName = currentDatabase[i].databaseName;
            dataValue.operStatus = currentDatabase[i].operStatus;
            jsonData.push(dataValue);
        }
    }
    return jsonData;
}
/*
 * 数据库连接、断开操作
 * 参数：oper:1表示连接操作、0表示断开操作
 * */
var currentStatus,modIndex; //当前所选数据库状态
function connectDatabase(operNum,databaseName,index)
{
    databaseUserInfo.dataName = trim(databaseName);
    modIndex = parseInt(index);
    if(operNum == 0)
    {
        currentStatus = 0; //连接状态

        var jsonDataObj = {
            ip      :"",
            port    :"",
            router  :"dbmanage",
            request :{"mainRequest":"disConnDb","subRequest":"","ssubRequest":""},
            data    :{
                webusername:window.sessionStorage.ux_curUserName,
                dbname:databaseName,
                instid:databaseUserInfo.insID
            }
        };
        var jsonDataStr = JSON.stringify(jsonDataObj);
        ux_reqInterface.ajaxRequest(false,jsonDataStr,connectDatabaseCallback);

    }else{
        currentStatus = 1; //断开状态
       /*
       * 需要输入用户名及密码
       * */
        var connectInfo;
        uxConfirm("是否以当前用户连接数据库？",function(rst){
           if(rst)
           {
               connectInfo = databaseUserInfo;
               var jsonDataObj = {
                   ip      :"",
                   port    :"",
                   router  :"dbmanage",
                   request :{"mainRequest":"connectDb","subRequest":"","ssubRequest":""},
                   data    :{
                       webusername:window.sessionStorage.ux_curUserName,
                       dbusername:connectInfo.userName,
                       pwd:connectInfo.passward,
                       dbname:connectInfo.dataName,
                       instid:databaseUserInfo.insID
                   }
               };
               var jsonDataStr = JSON.stringify(jsonDataObj);
               ux_reqInterface.ajaxRequest(false,jsonDataStr,connectDatabaseCallback);
           }else{
               var className;
               DatabaseDataInfoElem(instanceOperContainDiv);
               d3.select("#ItemSpanDatabase").text("连接数据库").classed("databaseTitle",true);
               d3.select("#sureBtnDatabase").attr({'onclick':'getDatabaseConnectData()'});
               d3.select("#dialogDatabase").style({
                   'width': '400px',
                   'height': '275px'
               });
               if(d3.select("#dialogDatabase").classed("bounceIn"))
               {
                   className = "bounceOutUp";
               }else{
                   className = "bounceIn";
               }
               $('#dialogBgDatabase').fadeIn(300);
               $('#dialogDatabase').removeAttr('class').addClass('animated ' + className + '').fadeIn();
           }
        });
    }
}
/*
 * 用来发送切换了用户之后的连接操作请求
 * */
function getDatabaseConnectData()
{
    var connectInfo = {};
    connectInfo.userName = d3.select("#input0")[0][0].value;
    connectInfo.passward = d3.select("#input1")[0][0].value;
    connectInfo.insID = databaseUserInfo.insID;
    if(connectInfo.userName == "" || connectInfo.passward == "")
    {
        uxAlert("请正确输入切换后用户的信息！");
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbmanage",
        request :{"mainRequest":"connectDb","subRequest":"","ssubRequest":""},
        data    :{
            webusername:window.sessionStorage.ux_curUserName,
            dbusername:connectInfo.userName,
            pwd:connectInfo.passward,
            dbname:databaseUserInfo.dataName,
            instid:connectInfo.insID
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,connectDatabaseCallback);
}
function connectDatabaseCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
          window.sessionStorage.ux_databaseConnection = true;  //表示当前有数据库为已连接状态
          var modfiStatus = (currentStatus == 0) ? (1):(0);
          $("#databaseTableId").bootstrapTable('updateCell',{index:modIndex,field:'operStatus',value:modfiStatus});
    }
    uxAlert(retJsonStr.desc);
    d3.select("#dialogDatabase").classed("bounceIn",false);
    $('#dialogBgDatabase').fadeOut(300,function(){
        $('#dialogDatabase').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#getDatabaseBtnId").classed("admitClick",true);

}
/*
* 数据库连接成功之后的界面(是否修改顶部菜单栏)
* */
var instanceAndDatabaseInfo;
function databaseConnecting()
{
    window.sessionStorage.ux_databaseConnection = true;
    getInstanceListAndDatabaseList();
    refashTopMenu(instanceAndDatabaseInfo);
}
/*
* 查看当前数据库首页
* */
function databaseManage(databaseName)
{
    clearDfsRealTimer();
    databaseConnecting();
    window.sessionStorage.ux_databaseConnection = true;
    top.d3.select("#mainDivId").attr("src","modules/dbmanage/dbmanager.html");
    //window.sessionStorage.ux_currentDatabase = databaseName;
    window.sessionStorage.ux_currentChoiceDataName = databaseName;
}
/***************************辅助函数区****************************************/
function getNewDbJsonData(data){
    var jsonData = [];
    for(var i = 0;i<data.length;i++){
        var dataValue = {};
        dataValue.index = (i + 1);
        dataValue.databaseName = data[i].dbname;
        dataValue.operStatus = data[i].operStatus;
        jsonData.push(dataValue);
    }
    return jsonData;
}
/**重组实例和DFS各个参数**/
function getEachData(data)
{
    var baseSpanData = data.split(",");
    instanceInfo.name = baseSpanData[0];
    instanceInfo.type = baseSpanData[1];
    instanceInfo.path = baseSpanData[4];
    instanceInfo.ID = baseSpanData[3];
    DFSInfo.ID = baseSpanData[5];
}
function getInstanceListAndDatabaseList()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbmanage",
        request :{"mainRequest":"getAllConnectedDb","subRequest":"","ssubRequest":""},
        data    :{
            webusername:window.sessionStorage.ux_curUserName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,getInstanceListAndDatabaseListCallback);
}
function getInstanceListAndDatabaseListCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        var index;
        for(var k = 0;k < retJsonStr.data.length; k++)
        {
            if(instanceInfo.ID == retJsonStr.data[k].instanceid)
            {
                index = k;
                break;
            }
        }
        window.sessionStorage.ux_currentChoiceInsId = retJsonStr.data[index].instanceid;//默认显示第一个实例的
        //window.sessionStorage.ux_currentChoiceDataName = retJsonStr.data[0].dbarr[0];
        instanceAndDatabaseInfo = retJsonStr.data;
    }else{
        uxAlert(retJsonStr.desc);
    }
}
/*****************************返回上一级*************************************/
function goBack()
{
    clearDfsRealTimer();
    getInstanceList("#instanaceBodyId");
}
/******************************定时刷新函数********************************************/
function getInsStatus()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"getInstState","subRequest":"timer","ssubRequest":""},
        data    :{
            instname:instanceInfo.name,
            instpath:instanceInfo.path,
            instid:instanceInfo.ID,
            type:instanceInfo.type == "本地实例" ? "1" : "2",
            status:instanceInfo.status
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,getInsStatusCallback);
}
function getInsStatusCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        instanceInfo.status = jsonObj.data.instState;
        DFSInfo.name = jsonObj.data.dfsName;
        DFSInfo.status = jsonObj.data.dfsState;
        updateStatus();
    }else{
        //clearDfsRealTimer();
        //uxAlert("dfs状态获取失败！");
    }
}
function setDfsRealTimer()
{
    clearInterval(setTimeInsStatus);
    setTimeInsStatus  = setInterval(getInsStatus,30 * 1000);
}
function clearDfsRealTimer()
{
    clearInterval(setTimeInsStatus);
}


