var reflashTime = 30,setReflashFun;
window.onload = function()
{
    //window.parent.menuOperFun();
    top.d3.select("#leftDivId").classed("no-display",true);
    top.d3.select("#topMenuLi4").classed("top-del-menu",true);
    dfsMonitoringElem("#dfsMonitoringId");
    getDFSMonitorData("first");
};

function dfsMonitoringElem(contain) {
    window.sessionStorage.ux_pagePath = "monitor,dfsMonitor";
    changePath("监控->DFS监控");
    d3.select("#mainContainDiv").remove();
    var dfsMonitoringDiv = d3.select(contain)
        .append("div")
        .attr({
            'id': 'mainContainDiv',
            'class': 'siteList-content'
        });
    var choicebtn = dfsMonitoringDiv.append("button")
        .attr({
            'id': 'dfsChoiceId',
            'class': 'dfsChoiceClass'
        })
        .on("click", function () {
            dfsChoice();
        })
        .html("DFS选择");

    var refreshSelect = dfsMonitoringDiv.append("select")
        .attr({
            'id': 'refreshSelectId',
            'class': 'refreshSelectClass'
        });
    var optionItem = ['30s刷新一次', '60s刷新一次', '300s刷新一次'];
    for (var k = 0; k < optionItem.length; k++) {
        refreshSelect.append("option")
            .attr({
                'class': 'option-all',
                'name': optionItem[k]
            })
            .html(optionItem[k]);
    }
    var refreshBtn = dfsMonitoringDiv.append("button")
        .attr({
            'id': 'refreshBtnId',
            'class': 'refreshBtnClass'
        })
        .on("click", function () {
            var timeArr = [30, 60, 300];
            var selectedTimeIndex = d3.select("#refreshSelectId")[0][0].selectedIndex;
            reflashTime = timeArr[selectedTimeIndex];
            dfsMonitoringElem("#dfsMonitoringId");
            getDFSMonitorData("first");
        })
        .html("刷新");
    /**
     * 总览
     */
    var viewA = dfsMonitoringDiv.append("a")
        .attr({
            'id': 'viewA',
            'href': '#'
        })
        .html('总     览');
    viewA.append("hr")
        .attr({
            'id': 'viewHr',
            'class': 'view-hr'
        });
    var viewTriangle = viewA.append("button")
        .attr({
            'id': 'btn',
            'class': 'view-ctl-icon viewFlagShow'
        })
        .on("click", function () {
            if(d3.select(this).classed("viewFlagShow")){
                d3.select(this).classed("control-btn-hide viewFlagHide",true);
                d3.select(this).classed("viewFlagShow control-btn-show",false);
            }else{
                d3.select(this).classed("control-btn-hide viewFlagHide",false);
                d3.select(this).classed("viewFlagShow control-btn-show",true);
            }
            foldFun();
        });

    /*总览->osd负载率 */
    var viewOsdDiv = dfsMonitoringDiv.append("div")
        .attr({
            'id': 'barChartOsd',
            'class': 'bar-chart-view'
        }).html("OSD负载率");
    /* 总览->mrc负载率 */
    var viewMrcDiv = dfsMonitoringDiv.append("div")
        .attr({
            'id': 'barChartMrc',
            'class': 'bar-chart-view'
        }).html("MRC负载率");
    /**
     * 总览->volume负载率
     */
    var volumeMessage = dfsMonitoringDiv.append("div")
        .attr({
            'id': 'volumeMessage',
            'class': 'bar-chart-view'
        }).html("基本信息");
    var message1 = volumeMessage.append("div")
        .attr({
            'id': 'message1',
            'class': 'bar-chart-view'
        })
        .html("volume个数：");
    message1.append("span")
        .attr({
            'id': 'num'
        })
    var message2 = volumeMessage.append("div")
        .attr({
            'id': 'message2',
            'class': 'bar-chart-view'
        })
        .html("volume总空间：");
    message2.append("span")
        .attr({
            'id': 'totalSpace'
        })
    var message3 = volumeMessage.append("div")
        .attr({
            'id': 'message3',
            'class': 'bar-chart-view'
        })
        .html("volume已使用空间：");
    message3.append("span")
        .attr({
            'id': 'usageSpace'
        })
    var viewVolume = dfsMonitoringDiv.append("p")
        .attr({
            'id': 'viewVolume',
            'class': 'bar-chart-view'
        })
        .html("Volume负载率");
    var viewVolumeDiv = dfsMonitoringDiv.append("div")
        .attr({
            'id': 'pieChartViewVolume',
            'class': 'bar-chart-view'
        });


    /**
     * OSD监控
     */
    var osdA = dfsMonitoringDiv.append("a")
        .attr({
            'id': 'osdA',
            'href': '#'
        })
        .html("OSD监控");
    osdA.append("hr")
        .attr({
            'id': 'osdHr',
            'class': 'osd-hr'
        });
    var osdTriangle = osdA.append("button")
        .attr("class", "view-ctl-icon viewFlagShow")
        .on("click", function () {
            if(d3.select(this).classed("viewFlagShow")){
                d3.select(this).classed("control-btn-hide viewFlagHide",true);
                d3.select(this).classed("viewFlagShow control-btn-show",false);
            }else{
                d3.select(this).classed("control-btn-hide viewFlagHide",false);
                d3.select(this).classed("viewFlagShow control-btn-show",true);
            }
            osdFoldFun()
        });

    /* osd->磁盘使用率 */
    var osdDiskUsageDiv = dfsMonitoringDiv.append("div")
        .attr({
            'id': 'barChartOsdDisk',
            'class': 'bar-chart-osd'
        }).html("磁盘使用率");

    /* osd->内存使用率 */
    var osdMemoryUsageDiv = dfsMonitoringDiv.append("div")
        .attr({
            'id': 'lineChartOsdMemory',
            'class': 'bar-chart-osd'
        }).html("OSD内存使用率");

    /**
     * MRC监控
     */
    var mrcA = dfsMonitoringDiv.append("a")
        .attr({
            'id': 'mrcA',
            'href': '#'
        })
        .html('MRC监控');
    var mrcHr = mrcA.append("hr")
        .attr({
            'id': 'mrcHr',
            'class': 'mrc-hr'
        });
    var mrcTriangle = mrcA.append("button")
        .attr("class", "view-ctl-icon viewFlagShow")
        .on("click", function () {
            if(d3.select(this).classed("viewFlagShow")){
                d3.select(this).classed("control-btn-hide viewFlagHide",true);
                d3.select(this).classed("viewFlagShow control-btn-show",false);
            }else{
                d3.select(this).classed("control-btn-hide viewFlagHide",false);
                d3.select(this).classed("viewFlagShow control-btn-show",true);
            }
            mrcFoldFun();
        });

    /*客户端连接数*/
    var mrcClientLinkNum = dfsMonitoringDiv.append("div")
        .attr({
            'id': 'mrcClientLinkNum',
            'class': 'mrc-chart'
        })
        .html('MRC客户连接数量');

    /*内存使用率*/
    var mrcMemoryUsage = dfsMonitoringDiv.append("div")
        .attr({
            'id': 'mrcMemoryUsage',
            'class': 'mrc-chart'
        })
        .html('MRC内存使用率');

    /**
     * DIR模块
     */
    var dirA = dfsMonitoringDiv.append("a")
        .attr({
            'id': 'dirA',
            'href': '#'
        })
        .html('DIR监控');
    var dirHr = dirA.append("hr")
        .attr({
            'id': 'dirHr',
            'class': 'dir-hr'
        });
    var dirTriangle = dirA.append("button")
        .attr("class", "view-ctl-icon viewFlagShow")
        .on("click", function () {
            if(d3.select(this).classed("viewFlagShow")){
                d3.select(this).classed("control-btn-hide viewFlagHide",true);
                d3.select(this).classed("viewFlagShow control-btn-show",false);
            }else{
                d3.select(this).classed("control-btn-hide viewFlagHide",false);
                d3.select(this).classed("viewFlagShow control-btn-show",true);
            }
            dirFoldFun();
        });

    /*客户端连接数*/
    var dirClientLinkNum = dfsMonitoringDiv.append("div")
        .attr({
            'id': 'dirClientLinkNum',
            'class': 'dir-chart'
        })
        .html('DIR客户连接数量');
    var messageQuenue = dfsMonitoringDiv.append("div")
        .attr({
            'id': 'dirMessageQuenue',
            'class': 'dir-chart'
        })
        .html('DIR消息队列数量');
}

/**
 * DFS选择
 */
function dfsChoice()
{
    var className;
    dfsChoiceInfo();
    if(d3.select("#dialogDfsChoice").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgDfsChoice').fadeIn(300);
    $('#dialogDfsChoice').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}

function dfsChoiceInfo() {
    d3.select("#dialogBgDfsChoice").remove();
    d3.select("#dialogDfsChoice").remove();

    d3.select("#mainContainDiv").append("div")
        .attr("id", "dialogBgDfsChoice");
    var outPage = d3.select("#mainContainDiv").append("div")
        .attr("id", "dialogDfsChoice");
    var editFrom = outPage.append("div")
        .attr("id","editFromDfsChoice");
    var newUserItemSpan = editFrom.append("span")
        .attr("id","newUserItemSpanDfsChoice")
        .html("请进行DFS选择：");
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos");
    var queryDiv = editFormUl.append("div")
        .attr({
            "class":'query-choice-dfs'
        });
    var selectItem = queryDiv.append("select")
        .attr({
            'id':'choiceSelectItem',
            'class':'selectStyle dfsInputClass',
            'onchange':'changeOper()'
        });
    var item = ['DFS名称','ID'];
    for(var k = 0;k <item.length; k++)
    {
        selectItem.append("option")
            .html(item[k]);
    }
    queryDiv.append("input")
        .attr({
            'id':'queryName',
            'type':'text',
            'class':'ipt'
        });
    queryDiv.append("button")
        .attr("class","btn btn-sm btn-bg-color searchSite-btn")
        .on("click",function(){
            queryDfs();
        })
        .attr("title","查找");
    editFormUl.append("div")
        .attr("class","dfs-choice-table-div")
        .append("table")
        .attr("id","dfsChoiceTable")
        .attr("color","#57D1F7");
    initDfsChoiceTableReq();
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("button")
        .attr("id","sureBtn")
        .attr("class","popup-sure-btn btn btn-sm btn-bg-color popUpBtn")
        .on("click",function(){
            dfsMonitoringFun();
        })
        .html("确&nbsp;&nbsp;&nbsp;&nbsp;定");
    editFromDivBtn.append("button")
        .attr("class","btn btn-sm btn-bg-color popUpBtn claseDialogBtn")
        .on("click",function(){
            d3.select("#dialogDfsChoice").classed("bounceIn",false);
            $('#dialogBgDfsChoice').fadeOut(300,function(){
                $('#dialogDfsChoice').addClass('bounceOutUp').fadeOut();
            });
        })
        .html("取&nbsp;&nbsp;&nbsp;&nbsp;消");
}
function changeOper()
{
    var selectObj = d3.select("#choiceSelectItem");
    return selectObj[0][0].selectedIndex;
}
function initDfsChoiceTable()
{
    var par = [{field: 'dfs_radio' , radio: true ,align: 'center' },
        {field: 'dfs_number' ,title: '序&nbsp;&nbsp;&nbsp;&nbsp;号' ,align: 'center' },
        {field: 'dfs_name' ,title: 'DFS名称' ,align: 'center' },
        {field: 'dfs_id' ,title: 'DFS ID' ,align: 'center' }
    ];
    $('#dfsChoiceTable').bootstrapTable({
        classes:"table table-no-bordered",
        toolbar:"#toolbar",
        height:400,
        columns: par,
        idField:"dfs_number"
    });
}
function initDfsChoiceTableReq()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"getAllActiveDFSInfo","subRequest":"","ssubRequest":""},
        data    :{}
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,initDfsChoiceTableReqCallback);
}
function initDfsChoiceTableReqCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        var dataJson =  dfsGetNewJson(jsonObj.data);
        initDfsChoiceTable();
        $("#dfsChoiceTable").bootstrapTable('load',dataJson);
        listenTable();
    }else{
        uxAlert("选择DFS列表加载失败！");
    }
}
function listenTable()
{
    var $table = $("#dfsChoiceTable");
    $table.on('check.bs.table page-change.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table',function(arg){

    });
}

//重组dfs数据格式
function dfsGetNewJson(data)
{
    var newJson = [];
    for(var i = 0;i<data.length;i++)
    {
        var info = {};
        info.dfs_number = (i+1);
        info.dfs_name = data[i].name;
        info.dfs_id = data[i].id;
        info.dfs_state = data[i].state;
        info.dfs_copy = data[i].dfspath;
        info.dfs_copystate = data[i].type;
        info.dfs_version = data[i].latesttm;
        info.dfs_creatTime = data[i].inittm;
        newJson.push(info);
    }
    return newJson;
}
function dfsMonitoringFun(){
    var ids = getIdSelections("dfsChoiceTable");
    window.sessionStorage.ux_currentChoiceDfsId = ids[0].dfs_id;
    //getDFSMonitorData();
    d3.select("#dialogDfsChoice").classed("bounceIn",false);
    $('#dialogBgDfsChoice').fadeOut(300,function(){
        $('#dialogDfsChoice').addClass('bounceOutUp').fadeOut();
    });
}

function queryDfs()
{
    /*修改查询按钮的颜色*/
    var queryItem = {
        'dfsNameFlag':0,
        'dfsName':'',
        'dfsIdFlag':0,
        'dfsId':'',
        'dfsStatusFlag':0,
        'dfsStatus':''
    };
    var choiceItem = changeOper();
    var strVlalue = trim(d3.select("#queryName")[0][0].value);
    if(strVlalue != "")
    {
        if(choiceItem == 0)
        {
            queryItem.dfsNameFlag = 1;
            queryItem.dfsName = strVlalue;
        }else{
            queryItem.dfsIdFlag = 1;
            queryItem.dfsId = strVlalue;
        }
    }
    /*发送的查询数据*/
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"queryDFS","subRequest":"","ssubRequest":""},
        data    :queryItem
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,queryDfsCallback);
}

function queryDfsCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        var dataJson =  dfsGetNewJson(jsonObj.data);
        $("#dfsChoiceTable").bootstrapTable('load',dataJson);
        uxAlert("查询成功");
    }else{
        uxAlert("查询失败！");
    }
}

var viewflag = true;
function foldFun(){
    if (viewflag == true) {
        d3.selectAll(".bar-chart-view").style('display','none');
        viewflag = false;
    }
    else {
        d3.selectAll(".bar-chart-view").style('display','block');
        viewflag = true;
    }
}
var osdflag = true;
function osdFoldFun(){
    if (osdflag == true) {
        d3.selectAll(".bar-chart-osd").style('display','none');
        osdflag = false;
    }
    else {
        d3.selectAll(".bar-chart-osd").style('display','block');
        osdflag = true;
    }
}
var mrcflag = true;
function mrcFoldFun(){
    if (mrcflag == true) {
        d3.selectAll(".mrc-chart").style('display','none');
        mrcflag = false;
    }
    else {
        d3.selectAll(".mrc-chart").style('display','block');
        mrcflag = true;
    }
}
var dirflag = true;
function dirFoldFun(){
    if (dirflag == true) {
        d3.selectAll(".dir-chart").style('display','none');
        dirflag = false;
    }
    else {
        d3.selectAll(".dir-chart").style('display','block');
        dirflag = true;
    }
}