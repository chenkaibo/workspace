CREATE TABLE tbl_instance
(
  id varchar(64) NOT NULL,
  clsname varchar(64),
  aliasname varchar(64),
  clspath varchar(255),
  type char,
  port varchar(10),
  state char,
  siteid varchar(64),
  dfsid varchar(64),
  voluname varchar(64),
  version varchar(16),
  inittm varchar(32),
  updatetm varchar(32),
  dfsurl varchar(64),
  dfsdb varchar(64),
  CONSTRAINT tbl_instance_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tbl_instance
  OWNER TO uxdbwebuser;
COMMENT ON COLUMN tbl_instance.id IS '实例ID,siteIP云实例：DFSURL+DFSDB 根据实例名,类型和路径生成唯一标识';
COMMENT ON COLUMN tbl_instance.clsname IS '集群名';
COMMENT ON COLUMN tbl_instance.aliasname IS '集群别名';
COMMENT ON COLUMN tbl_instance.clspath IS '路径';
COMMENT ON COLUMN tbl_instance.type IS '类型';
COMMENT ON COLUMN tbl_instance.port IS '端口';
COMMENT ON COLUMN tbl_instance.state IS '状态[0:故障,1:运行,2:停止]';
COMMENT ON COLUMN tbl_instance.siteid IS '站点ID';
COMMENT ON COLUMN tbl_instance.dfsid IS 'DFSID 通过DIRIP查询得到';
COMMENT ON COLUMN tbl_instance.voluname IS 'volume名称';
COMMENT ON COLUMN tbl_instance.version IS '版本';
COMMENT ON COLUMN tbl_instance.inittm IS '创建时间';
COMMENT ON COLUMN tbl_instance.updatetm IS '最近更新时间';
COMMENT ON COLUMN tbl_instance.dfsurl IS 'dfsurl';
COMMENT ON COLUMN tbl_instance.dfsdb IS 'dfsdb';