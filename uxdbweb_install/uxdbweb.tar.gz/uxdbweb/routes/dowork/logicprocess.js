﻿//用户管理
//var manUser = require("./manuser/manuser");
var instmanage = require("./instancemanage/maninstmanage");
var dfsmanage = require("./dfsmanage/mandfsmanage");
var dbmanage = require("./dbmanage/mandbmanage");
var dbopt = require("./dboperate/dboperate");
var monitormanage = require("./monitor/manmonitor");
var funcModelRouter = {
	"instmanage"    :instmanage.triggerFunction,
	"dfsmanage"     :dfsmanage.triggerFunction,
	"dbmanage"      :dbmanage.triggerFunction,
	"dbopt"			:dbopt.triggerFunction,
	"monitormanage" :monitormanage.triggerFunction,
};

function triggerFunction(postData,gResponeFunction)
{
	var postDataObj = JSON.parse(postData);
	var router = postDataObj.router;
	var func = funcModelRouter[router];
    if(typeof func == "undefined")
	{
		//not found
		var rtRes = {
			rstcode: "error_dowork",
			desc:"模块功能不存在!"
		};
		gResponeFunction(JSON.stringify(rtRes));
		return;
	}		
	func(postData,gResponeFunction);
}

exports.triggerFunction = triggerFunction;

