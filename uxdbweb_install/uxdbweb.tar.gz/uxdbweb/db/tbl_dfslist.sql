CREATE TABLE tbl_dfslist
(
  id varchar(64) NOT NULL,
  dfsname varchar(64),
  aliasname varchar(64),
  dfspath varchar(255),
  siteid varchar(64),
  type char,
  state char,
  mrcid varchar(64),
  inittm varchar(32),
  latesttm varchar(32),

  CONSTRAINT tbl_dfslist_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tbl_dfslist OWNER TO uxdbwebuser;
COMMENT ON COLUMN tbl_dfslist.id IS 'DFS ID';
COMMENT ON COLUMN tbl_dfslist.dfsname IS 'DFS名称';
COMMENT ON COLUMN tbl_dfslist.aliasname IS 'DFS别名';
COMMENT ON COLUMN tbl_dfslist.dfspath IS 'DFS路径';
COMMENT ON COLUMN tbl_dfslist.siteid IS 'DFS站点ID';
COMMENT ON COLUMN tbl_dfslist.type IS 'DFS类型
0:DIR,
1:MRC,
2:OSD,
3:DIR,MRC,
4:DIR,OSD,
5:MRC,OSD,
6:DIR,MRC,OSD';
COMMENT ON COLUMN tbl_dfslist.state IS 'DFS启动状态 0:故障，1:启动，2:停止';
COMMENT ON COLUMN tbl_dfslist.mrcid IS 'DFS创建者(MRC)';
COMMENT ON COLUMN tbl_dfslist.inittm IS '首次记录时间';
COMMENT ON COLUMN tbl_dfslist.latesttm IS '最近更新时间';