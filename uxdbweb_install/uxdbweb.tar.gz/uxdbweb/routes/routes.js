var express = require('express');
var router = express.Router();
var uxdbLogicProcess  = require('./dowork/logicprocess');
var userLogicProcess = require('./user/mandbuser');
var usrOnline = require('./common/onlinectrl');

router.post('/', function(req, res, next)
{
	res.setTimeout(25000,function()
	{
		if(res.finished)
		{
			return;
		}
		var rtRes =
		{
			rstcode:"error",
			desc:"system timeout",
			data:{}
		};
		console.log("system response timeout");
		res.writeHead(501, {"Content-Type" : "text/html"});
		res.write(JSON.stringify(rtRes));
		res.end();
	});
	function triggerFunction()
	{
		function callback(retJsonData)
		{
			if(res.finished)
			{
				return;
			}
			if(typeof  retJsonData == "undefined")
			{
				res.writeHead(400, {"Content-Type" : "text/html"});
				res.end();
				return;
			}

			if(typeof retJsonData != "object")
			{
				res.writeHead(200, {"Content-Type" : "text/html"});
				res.write(retJsonData);
				res.end();
			}
			else
			{
				var rtRes = {
					rstcode:"error",
					desc:"system err",
					data:""
				};
				res.writeHead(501, {"Content-Type" : "text/html"});
				res.write(JSON.stringify(rtRes));
				res.end();
			}
		}

		var postData =  req.body.postData;
        var url = req.baseUrl;
		switch (url)
		{
			case "/user":
				{
					userLogicProcess.triggerFunction(postData,callback);
				}
				break;
			case "/dowork":
				{
					uxdbLogicProcess.triggerFunction(postData,callback);
				}
				break;
			default :
				{
					if(res.finished)
					{
						return;
					}
					res.writeHead(404, {"Content-Type" : "text/html"});
					res.end();
					return;
				}
				break;
		}
	}

	var postUserName = req.body.postUserName ||"";
    if(postUserName == "")
    {
		serverRefuse(res);
		return;
    }
    var postUserHandle = req.body.postUserHandle ||"";
	if(postUserHandle == "")
	{
		serverRefuse(res);
		return;
	}
	var user = {};
	user.id = postUserHandle;
	user.name = postUserName;
	var opttime = Math.floor((req._startTime.getTime())/1000);
	user.lastOptTime = opttime.toString();
	usrOnline.getInstance().isValidSession(user,function(rst)
	{
		if(!rst)
		{
		   serverRefuse(res);
		}
		else
		{
			var withoutFlag = withoutUpdateLastOptTime(req.body.postData);
			if (withoutFlag) {
				triggerFunction();
			} else {
				usrOnline.getInstance().updateLastOptTime(user, function(error) {
					if (!error)
					{
						triggerFunction();
					}
					else
					{
						serverRefuse(res);
					}
				});
			}
		}
	});
});
function withoutUpdateLastOptTime(jsonStr){
	if (typeof jsonStr != "string"){
		return;
	}
	var jsonObj = JSON.parse(jsonStr);
	if (jsonObj.request.subRequest == "timer"){
		return true;
	} else {
		return false;
	}
}

function serverRefuse(res)
{
	if(res.finished)
	{
		return;
	}
	var rtRes = {
		rstcode:"error_refuse",
		desc:"非法访问！",
		data:{}

	};
	res.writeHead(200, {"Content-Type" : "text/html"});
	res.write(JSON.stringify(rtRes));
	res.end();
}

module.exports = router;
