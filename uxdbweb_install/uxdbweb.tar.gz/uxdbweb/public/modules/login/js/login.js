'use strict';
/**
 * Created by lrl on 2017/1/5.
 */
window.onload = function () {
    main();
    createCode();

};
window.onresize = function(){
    screenShow();
};
/*
* 界面适应性
* */
function screenShow()
{
    var minWidth = 1919;
    var minHeight = 953;
    if(innerHeight < minHeight)
    {
        d3.select("#indexBodyId").style({
            "height":"1036px",
            "background-size":"1921px 1081px",
        });
    }else{
        d3.select("#indexBodyId").style({
            "height":"98%",
            "background-size":"1921px 955px"
        });
    }
    if(innerWidth < minWidth)
    {
        d3.select("#indexBodyId").style({
            "width":"1921px",
            "background-size":"1921px 1081px",
        });
    }else{
        d3.select("#indexBodyId").style({
            "width":"100%",
            "background-size":"1921px 955px"
        });
    }
}
function main(){
    //清空所有session
    var sessionObj = window.sessionStorage;
    for(var i in sessionObj)
    {
        window.sessionStorage.removeItem(i);
    }
    var body = d3.select('body');
    login_box(body);
    screenShow();
    if(error_masg != ""){
        d3.select(".error-div").style("display","block");
    }else{
        d3.select(".error-div").style("display","none");
    }
}

function login_box(container)
{
    var firstTop = 0.10 * innerHeight + "px";
    var endTop = (0.10 * innerHeight + 133.56) + "px";
    container.append("div")
        .style({
            'position': 'relative',
            'margin': '36px 0px 0px 816px',
            'height': '6%',
            'width': '17%',
            'id':'titleId'
         })
        .append("img")
        .attr("src",STATIC_URL + "/login/image/login_sec_image.png")
        .style({
            'width':'300px',
            'position': 'relative',
            'top':firstTop ,
            'opacity':'0'
        })
        .transition()
        .duration(2000)
        .style("top",endTop)
        .style('opacity','1');
    container.append("div")
        .attr("id","loginImageDivId")
        .append("img")
        .attr({
            'id':'logoImgId',
            'src':'modules/login/image/logo.gif'
        });
    d3.select("#loginImageDivId")
        .style('opacity','1')
        .transition()
        .duration(1400)
        .style('opacity','0');
    var contain_div = container.append("div").attr("id","allContainDiv");
    var logo_back = contain_div.append("div");
    logo_back.append('div')
        .attr('class','Logo-back');
    var login_box_out = logo_back.append("div")
        .attr("class","login-div-out");
    login_box_out.append("img")
        .attr("class","login-map")
        .attr("src",STATIC_URL + "/login/image/login_image.png")
        .style({
            'margin':'59px 11px 0px 777px',
            'opacity':'0'
        })
        .transition()
        .duration(2000)
        .style({
            'margin':'59px 11px 0px 580px',
            'opacity':'1'
        });
    var login_box = logo_back.append('form')
        .attr('id','loginform')
        .attr('method','post')
        .attr('autocomplete','off')
        .attr("onsubmit","return false")
        .append('div')
        .attr('class','login-box');
    var input_box = login_box.append("div")
        .attr("class","input-box");
    var inputDiv = input_box.append("div");
    inputDiv.append("input")
        .attr('type','text')
        .attr('placeholder','用户名')
        .attr('class','user-input')
        .attr('id','userName')
        .attr('name','username')
        .attr('autofocus',true)
        .attr('autocomplete','off');
    inputDiv.append("img")
        .attr("class","red-flag-span")
        .attr("src",STATIC_URL + "login/image/red_flag.svg");
    var password_input_div = input_box.append("div");
    password_input_div.append('input')
        .attr('type','password')
        .attr('placeholder','密码')
        .attr('class','password-input')
        .attr('id','password')
        .attr('name','password')
        .attr('autocomplete','off');
    password_input_div.append("img")
        .attr("class","red-flag-span")
        .attr("src",STATIC_URL + "login/image/red_flag.svg");
    var validation_input_div = input_box.append("div")
        .style({
           "border-radius": "20px"
        });
    validation_input_div.append('input')
        .attr('type','text')
        .attr('placeholder','验证码')
        .attr('class','validation-input')
        .attr('id','validation')
        .attr('name','validation')
        .attr('autocomplete','off');
    validation_input_div.append("div")
        .attr("id","checkCode")
        .attr("class","code")
        .attr("onClick","createCode()");
    var submit_button = input_box.append("div")
        .style("margin","36px 0px 0px 17px");
    submit_button.append('button')
        .attr('class','submit-button')
        .attr('id','submitButton')
        .attr('type','submit')
        .attr('onClick','login()')
        .html('登录');
    submit_button.append('button')
        .attr('class','cancel-button')
        .attr('id','cancelButton')
        .style("float","right")
        .style("margin-left","90px")
        .style("margin-right","84px")
        .attr('onClick','cancel()')
        .html('取消');
    d3.select("form")
        .style({
            'margin':'-224px 0px 0px 0px',
            'opacity':'0'
        })
        .transition()
        .duration(2000)
        .style({
            'margin':'-224px 441px 0px 0px',
            'opacity':'1'
        });
    var error_div = login_box.append("div")
        .attr("class","error-div")
        .text("请输入正确的用户名和密码!");

    /*登录请求*/
    var token_input = login_box.append('input');
    token_input
        .attr('type','hidden')
        .attr('id','token')
        .attr('name','csrfmiddlewaretoken')
        .attr('value',token);
    return login_box;
}

/**
 * 提交登陆表单前做的简单的判空验证
 */
function subform(){
    var userName = d3.select('#userName').property('value');
    var password = d3.select('#password').property('value');
    var checkCode = validateCode();
    var checkResult;
    if(userName == '' || userName == null){
        d3.select(".error-div").style("display","block").text("请输入正确的用户名！");
        checkResult = 1;
    }else if (password == '' || password == null)
    {
        d3.select(".error-div").style("display","block").text("请输入正确的密码！");
        checkResult = 2;
    }else if(checkCode == 1){
        d3.select(".error-div").style("display","block").text("请输入验证码！");
        checkResult = 3;
    }else if(checkCode == 2){
        d3.select(".error-div").style("display","block").text("验证码输入有误！");
        checkResult = 3;
    }else{
        d3.select(".error-div").style("display","none");
        checkResult = 4;
    }
    return checkResult;
}

/*
* 登录
*/
function login()
{
    /*
    * checkResult:1.定位至用户名   2.定位至密码  3.定位至校验码 4.信息正常
    * */
    var checkResult = subform();
    if(checkResult == 1)
    {
        d3.select('#userName')[0][0].value = "";
        document.getElementById('userName').focus();
    }else if(checkResult == 2)
    {
        d3.select('#password')[0][0].value = "";
        document.getElementById('password').focus();
    }else if(checkResult == 3)
    {
        d3.select('#validation')[0][0].value = "";
        document.getElementById('validation').focus();
    }else{
        /*
         * 发送数据域
         * */
        var ux_login_Interface = new uxLoginAjaxInterface();  //登录请求接口
        var jsonDataObj = {
            "data"        :{"name":"","pwd":""},
            "oper" : "登录系统"
        };
        var username = $("input[name = 'username']:text").val();
        var pwd = $("input[name = 'password']:password").val();
        jsonDataObj.data.name = username;
        jsonDataObj.data.pwd = hex_md5("uxdb"+pwd);
        window.sessionStorage.ux_curUserPwd = pwd;
        var jsonDataStr = JSON.stringify(jsonDataObj);
        ux_login_Interface.ajaxRequest(false,jsonDataStr,dealWithLoginData);
    }
}
/*
* 功能：处理登录数据
*/
function dealWithLoginData(retJson)
{
    var retjsonStr = JSON.parse(retJson);
    if(retjsonStr.rstcode == "success")
    {
        window.sessionStorage.ux_curUserRole = retjsonStr.data.role;//0:管理员，1:普通用户
        window.sessionStorage.ux_curUserName = retjsonStr.data.name; //用户名
        window.sessionStorage.ux_userHandle = retjsonStr.data.userhandle;//sessionID
        window.sessionStorage.ux_uxdbVersion = retjsonStr.data.version;//version
        window.location.replace("/dbmanage.html");
    }else{
        uxAlert("请输入正确的用户和密码！");
    }
}
/*
* 取消
* */
function cancel()
{
    window.location.replace("/index.html");
}