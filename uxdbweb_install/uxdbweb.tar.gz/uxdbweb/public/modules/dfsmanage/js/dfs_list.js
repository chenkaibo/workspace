//站点列表
window.onload = function()
{
    getDfsList("#dfsBodyId");
    top.d3.select("#leftDivId").classed("no-display",true);
};
function getDfsList(contain)
{
    window.focus();
    clearTimerFun();
    changePath("云数据库管理->DFS管理");
    window.sessionStorage.ux_pagePath = "dfsManage,dfsList";
    //window.sessionStorage.ux_pagePath = "dfsManage,main";
    var currentRole = window.sessionStorage.ux_curUserRole;
    d3.select("#mainContainDiv").remove();
     d3.select(contain)
        .append("div")
        .classed("siteList-content",true)
        .attr("id","mainContainDiv");
    d3.select(".siteList-content")
        .append("div")
        .classed("toolbar",true)
        .attr("id","dfslist_toobar")
        .style("padding-top","38px")
        .append("button")
        .classed("btn admitClick",true)
        .attr("onclick","dfsRefresh()")
        .html("刷&nbsp;&nbsp;新");
    d3.select("#dfslist_toobar")
        .append("button")
        .classed("del-btn-position btn disabledElem delBtnClass",true)
        .attr("id","delDfsBtn")
        .on("click",function(){
            dfsDel();
        })
        .html("删&nbsp;&nbsp;除");
    d3.select(".siteList-content")
        .append("div")
        .attr("id","searchDfs_form")
        .classed("pull-right searchSite",true)
        .append("div")
        .classed("searchSite-content",true);
    d3.select("#searchDfs_form")
        .append("div")
        .classed("searchSite-content",true);
    d3.selectAll(".searchSite-content")
        .append("input")
        .attr("type","checkbox")
        .each(function(d,i){
            d3.select(this).attr({
                id:"checkboxId"+i
            });
        })
        .on("click",function(d,i){
            checkBoxFun(i);
        })
        .classed("siteCheck",true);
    var searchSite_content = d3.selectAll(".searchSite-content");
    d3.select(searchSite_content[0][0])
        .insert("span",":nth-child(2)")
        .classed("searchTypeName",true)
        .html("DFS名称：");
    d3.select(searchSite_content[0][0])
        .insert("input",":nth-child(3)")
        .attr({
            'type':'text',
            'id':'selectElemId0',
            'disabled':""
        });
    d3.select(searchSite_content[0][1])
        .insert("span",":nth-child(2)")
        .classed("searchTypeName",true)
        .html("状态：");
    d3.select(searchSite_content[0][1])
        .insert("select",":nth-child(3)")
        .attr({
            'id':'selectElemId1',
            'class':'selectState',
            "disabled":true
        })
        .append("option")
        .html("运行");
    d3.select(".selectState")
        .append("option")
        .html("故障");
    d3.select(".selectState")
        .append("option")
        .html("停止");
    d3.select("#searchDfs_form")
        .append("button")
        .classed("btn btn-sm btn-bg-color searchSite-btn",true)
        .on("click",function(){
            queryDfs()
        })
        .attr("title","查找")
        .style("margin","4px 29px 0px 4px");
    d3.select(".siteList-content")
        .append("div")
        .classed("instance-list",true)
        .append("table")
        .attr({
            "id":"dfs_list_table",
            "data-toggle":"table",
            "color":"#57D1F7"
        });
    //d3.select(".siteList-content")
    //    .append("div")
    //    .classed("dfslist-line",true)
    //    .attr("id","dfslist_line");
    if(currentRole == 1)
    {
        d3.selectAll(".disabledElem").style('display','none');
        d3.select("#searchSite-form").style('opacity','0');
    }
    initDfsList();
    getDfsData();
    listenTable("dfs_list_table","delDfsBtn");
    refreshDfslistTimer = setInterval("getDfsData()",10 * 1000);
}
 /* 选择框显示*/
function checkBoxFun(idNum)
{
    var checkBoxSelectItem ="selectElemId" + idNum;
    var checkBoxSelect = "checkboxId" + idNum;
    var checkitemArray = d3.select("#" + checkBoxSelectItem);
    var checkBoxArray = d3.select("#" + checkBoxSelect);
    if(checkBoxArray[0][0].checked)
    {
        checkitemArray[0][0].disabled = false;
    }else{
        checkitemArray[0][0].disabled = true;
    }
}
//初始化dfs列表表格
function initDfsList()
{
    var par = [{field: 'dfs_radio', radio: true,align: 'center'},
        {field:'dfs_number',title:'序&nbsp;&nbsp;&nbsp;&nbsp;号',align: 'center'},
        {field:'dfs_id',title:'DFS ID',align: 'center'},
        {field:'dfs_name',title:'DFS名称',align: 'center',
            editable: {
                type: 'text',
                title: 'DFS名称',
                validate: function (value) {
                    value = trim(value);
                    if (!value) {
                        return '请输入正确DFS名称！';
                    }
                    if (instanceName(value) && value.length < 65 && value.length > 0)
                    {
                        var data = $('#dfs_list_table').bootstrapTable('getData'),
                            index = $(this).parents('tr').data('index');
                        modfiDfsName(value,data[index]);
                    }else{
                        return '字母开头，特殊字符含下划线，长度不超过64！';
                    }
                    return '';
                }
            }
        },
        {field: 'dfs_state', title: '状&nbsp;&nbsp;&nbsp;&nbsp;态',align: 'center',formatter:function(value,row,index){
            if(row.dfs_state == 2) {
                var constr = '<a title="停止">' + '<button class = "btn-link stop-btn"></button>' + '</a>';
                return constr;
            }else if(row.dfs_state == 1){
                var discon = '<a title="运行">' + '<button class = "btn-link run-btn"></button>' + '</a>';
                return discon;
            }else if(row.dfs_state == 0){
                var erroricon = '<a title="故障">' + '<button class = "btn-link error-btn"></button>' + '</a>';
                return erroricon;
            }
        }},
        {field: 'dfs_operate', title: '操&nbsp;&nbsp作',align: 'center', formatter:function(value,row,index){
            //var constr = '<a title="设置">' + '<button class="btn-link site-setupImg" onclick="setUpDfs(\''+row.dfs_name+'\',\''+row.dfs_id+'\',\''+row.dfs_state+'\')" ></button>' +'</a>';
            if(row.dfs_state == 1 || row.dfs_state == 2)
            {
                constr = '<a title = "设置">' + '<button class = "btn-link site-setupImg" onclick = "setUpDfs(\''+row.dfs_name+'\',\''+row.dfs_id+'\',\''+row.dfs_state+'\')" ></button>' +'</a>';
            }else{
                constr = '<a title = "设置">' + '<button class = "site-no-operImg"' + '></button>' + '</a>';
            }
            return constr;
        }}
    ];
    $('#dfs_list_table').bootstrapTable({
        classes:"table table-no-bordered",
        toolbar:"#dfslist_toobar",
        height:657,
        columns: par,
        idField:"dfs_number",
    });
    $('#dfs_list_table').on('editable-shown.bs.table',function(arg){
        clearInterval(refreshDfslistTimer);
    });
    $('#dfs_list_table').on('editable-hidden.bs.table editable-save.bs.table',function(arg){
        refreshDfslistTimer = setInterval("getDfsData()",10 * 1000);
    });
}
function modfiDfsName(dfsName,data)
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"modifyAliasname","subRequest":"","ssubRequest":""},
        data    :{
            aliasname:dfsName,
            dfsid:data.dfs_id
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,modfiDfsNameCallback);
}
function modfiDfsNameCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        uxAlert("修改dfs名称成功！");
    }else{
        uxAlert("修改dfs名称失败！");
    }
}
//获取dfs数据
function getDfsData()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"enumDFSList","subRequest":"","ssubRequest":""},
        data    :{}
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,dfscallbackFunc);
}
//回调函数
function dfscallbackFunc(retJson)
{
    var dataJson = JSON.parse(retJson);
    if(dataJson.rstcode == "success"){
        //changeButtonStatus("dfs_list_table","delDfsBtn");
        d3.select("#delDfsBtn").classed("admitClick btn",false).classed("delBtnClass",true);
        var dataJson = dfsGetNewJson(dataJson.data);
        //var dataJson = dfsGetNewJson(dataJson);
        $("#dfs_list_table").bootstrapTable('load',dataJson);
        //if(dataJson.length >= 17){
        //    $("#dfslist_line").css("display","block");
        //}else{
        //    $("#dfslist_line").css("display","none");
        //}
    }else{
        clearInterval(refreshDfslistTimer);
        uxAlert("初始化DFS列表失败！");
    }
}
//重组dfs数据格式
function dfsGetNewJson(data)
{
    var newJson = [];
    for(var i = 0;i<data.length;i++)
    {
        var info = {};
        info.dfs_number = (i+1);
        info.dfs_name = data[i].aliasname;
        info.dfs_id = data[i].id;
        info.dfs_state = data[i].state;
        info.dfs_copy = data[i].dfspath;
        info.dfs_copystate = data[i].type;
        info.dfs_version = data[i].latesttm;
        info.dfs_creatTime = data[i].inittm;
        newJson.push(info);
    }
    window.sessionStorage.ux_dfsData = JSON.stringify(newJson);
    return newJson;
}
//dfs手动刷新数据
function dfsRefresh()
{
    getDfsData();
    refreshDfslistTimer = setInterval("getDfsData()",10 * 1000);
    changeButtonStatus("dfs_list_table","delDfsBtn");
}

/* 查询功能 */
function queryDfs()
{
    var queryItem = {
        'dfsNameFlag':0,
        'dfsName':'',
        'dfsStatusFlag':0,
        'dfsStatus':''
    };
    var formDataArray = d3.selectAll(".siteCheck");
    queryItem.dfsNameFlag = (formDataArray[0][0].checked == false) ? (0):(1);
    queryItem.dfsStatusFlag = (formDataArray[0][1].checked == false) ? (0):(1);
    if((!queryItem.dfsNameFlag) && (!queryItem.dfsStatusFlag))
    {
        clearInterval(refrQueryDfsTimer);
        getDfsData();
        refreshDfslistTimer = setInterval("getDfsData()",10 * 1000);
        return;
    }else if(queryItem.dfsNameFlag && (!queryItem.dfsStatusFlag)){
        if(d3.select("#selectElemId0")[0][0].value != ""){
            queryItem.dfsName = d3.select("#selectElemId0")[0][0].value;
            getDfsQueryData(queryItem);
            clearInterval(refreshDfslistTimer);
            refrQueryDfsTimer = setInterval(getDfsQueryData(queryItem),10*1000);
            return;
        }else{
            uxAlert("请完善查询条件！")
        }
    }else{
        queryItem.dfsName = d3.select("#selectElemId0")[0][0].value;
        var status = d3.select("#selectElemId1")[0][0].value;
        if(status == "运行"){
            queryItem.dfsStatus = 1
        }else if(status == "故障"){
            queryItem.dfsStatus = 0
        }else{
            queryItem.dfsStatus = 2
        }
        getDfsQueryData(queryItem);
        clearInterval(refreshDfslistTimer);
        refrQueryDfsTimer = setInterval(getDfsQueryData(queryItem),10*1000);
        return;
    }
}
/*从后台获取DFS查询过后的数据*/
function getDfsQueryData(queryItem)
{
    clearInterval(refreshDfslistTimer);
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"queryDFS","subRequest":"","ssubRequest":""},
        data :queryItem
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,queryDfsCallback);
}
function queryDfsCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        var dataJson =  dfsGetNewJson(jsonObj.data);
        $("#dfs_list_table").bootstrapTable('load',dataJson);
    }else{
        uxAlert(jsonObj.desc);
    }
}
//跳转至DFS操作页面
function setUpDfs(dfsName,dfsId,dfsState)
{
    window.sessionStorage.ux_dfsid = dfsId;
    currDfsStatus = dfsState;
    getOperDFSInfo(dfsId);
    getDfsHandle(parameterData);
}
//获取当前DFS信息
function getOperDFSInfo(dfsid){
    var dfsid = window.sessionStorage.ux_dfsid;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"getDFSInfo","subRequest":"","ssubRequest":""},
        data    :{
            dfsid:dfsid
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,OperDFSInfoCallback);
}
//所操作的DFS信息回调函数
function OperDFSInfoCallback(retJson){
    var jsonObj = JSON.parse(retJson);
    var data = [jsonObj.data.dfsname,jsonObj.data.dfsid,jsonObj.data.version,jsonObj.data.inittime,jsonObj.data.copy == 0 ? "否" : "是",jsonObj.data.copyState == 0 ? "异常" : "正常",jsonObj.data.dfspath]
    setParameterData(data);
}
//删除DFS
function dfsDel()
{
    clearInterval(refreshDfslistTimer);
    d3.select("#delDfsBtn").classed("admitClick",false);
    var currDfsStatus = getIdSelections("dfs_list_table")[0].dfs_state;
    if(currDfsStatus == 1){
        uxAlert("DFS正在启动，请先停止DFS!");
        d3.select("#delDfsBtn").classed("admitClick",true);
        return;
    };
    uxConfirm("是否确认删除该DFS？",function(rst)
    {
        //点击取消
        if(!rst)
        {
            refreshDfslistTimer = setInterval("getDfsData()",10 * 1000);
            d3.select("#delDfsBtn").classed("admitClick",true);
            return;
        }
        var selected = $("#dfs_list_table").bootstrapTable('getSelections');
        var dfsId = selected[0].dfs_id;
        /*删除实例发送数据*/
        var jsonDataObj = {
            ip      :"",
            port    :"",
            router  :"dfsmanage",
            request :{"mainRequest":"deleteDFS","subRequest":"","ssubRequest":""},
            data    :{
                dfsid: dfsId
            }
        };
        var jsonDataStr = JSON.stringify(jsonDataObj);
        ux_reqInterface.ajaxRequest(false,jsonDataStr,delDfsCallback);

    });
}
function delDfsCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success") {
        getDfsData();
        uxAlert("删除DFS成功！");
    }else{
        uxAlert("删除DFS失败！");
    }
    changeButtonStatus("dfs_list_table","delDfsBtn");
    //uxAlert(retJsonStr.subdesc);

}
