var gDbUserMgr = require('./dbusermgr');
var usrOnline = require('../common/onlinectrl');
var api = require('../common/api');
/*
DB用户管理业务逻辑处理路由部分
 */

// DB用户管理需要处理的请求函数
var RequestProcFuncs = {
    "newUser":newUser,
    "modUser":modUser,
    "delUser":delUser,
    "queryUser":queryUser,
    "enumUser":queryUser,
};
function triggerFunction(postData,gResponeFunction)
{
    if(typeof gResponeFunction != "function")
    {
        return;
    }
    var jsonObj = JSON.parse(postData);
    var mainRequest = jsonObj.request.mainRequest;
    var procFunc = RequestProcFuncs[mainRequest];
    var rtRes = {
        rstcode:"error",
        desc:"",
        data:""
    };
    if(typeof procFunc != "function")
    {
        rtRes.rstcode = 'error';
        //rtRes.desc = ''
        gResponeFunction(JSON.stringify(rtRes));
    }
    else
    {
        procFunc(jsonObj,gResponeFunction);
    }
}

exports.triggerFunction = triggerFunction;
/*
 功能：新建用户
 参数：userDb 用户信息
      callback 响应回调函数 rstJson：回应消息，JSON格式字符串
 返回值：无
 */
function newUser(reqDb,callback)
{
    if(typeof callback != "function")
    {
        return;
    }
    var rstJson = {
        rstcode:"error",
        desc:"",
        data:""
    };
    if(reqDb.data.username == "" || reqDb.data.userrole == "" || reqDb.data.userpwd == ""){
        rstJson.desc = "请输入完整的用户信息！";
        callback(JSON.stringify(rstJson));
        return;
    }
    reqDb.data.time = api.formatDate(new Date());
    gDbUserMgr.getInstance().newUserMgr(reqDb.data,function(error)
    {
        if(error)
        {
            console.log("[execSql adduser]:" + error.detail);
            if(error.code == '23505' && error.constraint == 'tbl_user_pkey'){
                rstJson.desc = "该用户已存在！";
            }else{
                rstJson.desc = "添加失败！";
            }
        }
        else
        {
            rstJson.rstcode = "success";
        }
        callback(JSON.stringify(rstJson));
    });
}
/*
 功能：修改用户
 参数：reqDb 请求的数据
     callback(resJson) 回调函数
 返回值：无
 */
function modUser(reqDb,callback) {
    if (typeof callback != "function") {
        return;
    }

    var resJson = {
        rstcode:"error",
        desc:"",
        data:""
    };

    if(reqDb.data.userrole != "0"){ //普通用户需要校验旧密码
        var userInfo = {
            name:reqDb.data.username,
            pwd:reqDb.data.userpwd,
            type:"3"
        }
        gDbUserMgr.getInstance().queryUserMgr(userInfo,function(isErr,rst){
            if(isErr){
                resJson.desc = "数据库操作失败！";
                callback(JSON.stringify(resJson));
                return;
            }
            if(rst.length == 0){
                resJson.desc = "旧密码不正确！";
                callback(JSON.stringify(resJson));
                return;
            }
            reqDb.data.userpwd = reqDb.data.userNewPwd;
            execMod();
        })
    }else{
        execMod();
    }

    function execMod(){
        reqDb.data.time = api.formatDate(new Date());
        gDbUserMgr.getInstance().modUserMgr(reqDb.data, function (error)
        {
            if(error){
                resJson.desc = "修改失败！";
            }else{
                resJson.rstcode = "success";
            }
            callback(JSON.stringify(resJson));
        });
    }
}

/*
 功能：删除用户
 参数：reqDb 请求的数据
      callback(resJson) 回调函数
 */
function delUser(reqDb,callback)
{
    if(typeof callback !== 'function')
    {
        return;
    }
    var resJson = {
        rstcode:'error',
        desc:'',
        data:''
    };

    //test
    //callback(JSON.stringify(resJson));
    //return;

    var isOnlineUser = [];
    var noOnlineUser = [];

    function execDelUser(){
        if(noOnlineUser.length != 0){
            gDbUserMgr.getInstance().delUserMgr(noOnlineUser,function(error)
            {
                if(error)
                {
                    console.log(error.detail);
                    resJson.desc = "删除失败！";
                }
                else
                {
                    if(isOnlineUser.length != 0){
                        resJson.desc = "用户【" + isOnlineUser + "】正在登录, 不能删除！";
                        resJson.data = "1";
                    }else{
                        resJson.rstcode = "success";
                    }
                }
                callback(JSON.stringify(resJson));
            });
        }else{
            if(isOnlineUser.length != 0){
                resJson.desc = "用户【" + isOnlineUser + "】正在登录, 不能删除！";
                resJson.data = "1";
            }
            callback(JSON.stringify(resJson));
        }
    }
    var num = 0;
    var len = reqDb.data.length;
    function checkUser(userInfo){
        var user = {name:userInfo.userName};
        usrOnline.getInstance().isOnline(user,function(rst) {
            if(rst)
            {
                isOnlineUser.push(user.name);
            }
            else
            {
                noOnlineUser.push("\'"+user.name+"\'");
            }
            num++;
            if(num < len){
                checkUser(reqDb.data[num]);
            }else{
                execDelUser();
            }
        });
    }
    checkUser(reqDb.data[num]);
}

/*
 功能：查询用户
 参数：reqDb:请求查询数据
      callback(resJson) 回应回调函数
 */
function queryUser(reqDb,callback)
{
    if(typeof callback !== 'function')
    {
        return;
    }
    var resJson = {
        rstcode:"error",
        desc:"",
        data:[]
    };
    //if(reqDb.request.subRequest == "cond"){
    //    var data = reqDb.data;
    //    if(data.userNameFlag && data.userRoleFlag){
    //        reqDb.data.type = "4";
    //        reqDb.data.name = data.userName;
    //        reqDb.data.usertype = data.userRole;
    //    }else if(data.userNameFlag){
    //        reqDb.data.type = "1";
    //        reqDb.data.name = data.userName;
    //    }else{
    //        reqDb.data.type = "2";
    //        reqDb.data.usertype = data.userRole;
    //    }
    //}

    gDbUserMgr.getInstance().queryUserMgr(reqDb.data,function(error,rows)
    {
        if(error)
        {
            resJson.desc = error.detail;
            callback(JSON.stringify(resJson));
            return;
        }
        resJson.rstcode = "success";
        resJson.data = reStructure(rows);
        callback(JSON.stringify(resJson));
    });
}
function reStructure(rows){
    var data = [];
    for(var i=0;i<rows.length;i++){
        var dataValue = {};
        dataValue.userName = rows[i].username;
        dataValue.userRole = rows[i].usertype;
        dataValue.userId = rows[i].id;
        dataValue.createTime = rows[i].createtime;
        dataValue.lastModTime = rows[i].lastmodtime;
        data.push(dataValue);
    }
    return data;
}