CREATE TABLE tbl_dfs_osd
(
  id serial NOT NULL,
  dfsid varchar(64) NOT NULL,
  name varchar(32) NOT NULL,
  address varchar(32) NOT NULL ,
  load varchar(16) NOT NULL,
  totalram varchar(32),
  usedram varchar(32),
  ramusage varchar(2048),
  connectnum varchar(2048),
  totaldisk varchar(32),
  freedisk varchar(32),
  diskusage varchar(16),
  status     integer,
  CONSTRAINT tbl_dfs_osd_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tbl_dfs_mrc
  OWNER TO uxdbwebuser;
COMMENT ON COLUMN tbl_dfs_osd.dfsid IS 'DIR所属DFS的ID';
COMMENT ON COLUMN tbl_dfs_osd.name IS '名称';
COMMENT ON COLUMN tbl_dfs_mrc.address IS '访问地址';
COMMENT ON COLUMN tbl_dfs_osd.load IS '负载率';
COMMENT ON COLUMN tbl_dfs_osd.totalram IS '总内存';
COMMENT ON COLUMN tbl_dfs_osd.usedram IS '已使用内存';
COMMENT ON COLUMN tbl_dfs_osd.ramusage IS '内存使用率';
COMMENT ON COLUMN tbl_dfs_osd.connectnum IS '客户端连接数';
COMMENT ON COLUMN tbl_dfs_osd.totaldisk IS '总磁盘容量';
COMMENT ON COLUMN tbl_dfs_osd.freedisk IS '剩余容量';
COMMENT ON COLUMN tbl_dfs_osd.diskusage IS '磁盘使用率';
COMMENT ON COLUMN tbl_dfs_dir.status IS '模块状态，0-离线，1-在线';

