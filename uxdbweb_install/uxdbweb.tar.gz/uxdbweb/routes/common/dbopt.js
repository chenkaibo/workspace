﻿var uxdb = require('uxdb');
var gPrivatePwd = "hn5sFyvrgH";
var uxdbConfig = require('./../../uxwebconfig.json').uxdb;
var gPrivatePort = "5432";

/*  uxdb数据库操作类 */
function MyDbOpt(sevname,username,dbname,port,pwd)
{
	gPrivatePort = port || uxdbConfig.port;
	this.username = username || uxdbConfig.username;
	this.servername = sevname || uxdbConfig.servername;
	this.dbname = dbname || uxdbConfig.dbname;

	this.pwd = pwd || gPrivatePwd;
	this.querySql = querySql;
	this.execSql = execSql;
	this.checkConnect = checkConnect;
	this.setPrivatePwd = function(pwd)
	{
		gPrivatePwd = pwd;
		this.pwd = pwd;
	};
	this.getPrivatePwd = function()
	{
		return gPrivatePwd;
	};
	this.getPrivatePort = function()
	{
		return gPrivatePort;
	};
}
module.exports = MyDbOpt;

// 执行查询SQL语句（异步）
function querySql(strSql,value,callback)
{
	console.log(strSql);
	var conStr = "uxdb://";
	conStr = conStr.concat(this.username,":",this.pwd,"@",this.servername+":"+gPrivatePort,"/",this.dbname);
	var cl = new uxdb.Client(conStr);
	var rest;
	cl.connect(function(err)
	{
		if(err)
		{
			console.log("connect uxdb failed.");
			if (typeof callback === "function")
			{
				callback(err,rest);
			}
			cl.end();
			return;
		}

		cl.query(strSql,value,function(error,results)
		{
			//console.log("in callback function.");
			if (error)
			{
				console.log("error");
				cl.end();
				if (typeof callback === "function")
				{
					callback(error,0,rest);
				}
				return;
			}
			if (results.rowCount > 0)
			{
				rest = results.rows;
			}
			if (typeof callback === "function")
			{
				//console.log("--[querySql] rst = %s",JSON.stringify(results.rows));
				callback(error,results.rowCount,rest);

			}
			cl.end();
			return;
		});
		//cl.query(strSql,value,function(error,results)//实现条件查询
	});
}
// 执行非查询类型的SQL语句
function execSql(text,value,callback)
{
	var conStr = "uxdb://";
	conStr = conStr.concat(this.username,":",this.pwd,"@",this.servername+":"+gPrivatePort,"/",this.dbname);
	var cl = new uxdb.Client(conStr);
	cl.connect(function(error)
	{
		if(error)
		{
			console.log("---[execSql]" + error);
			if (typeof callback === "function")
			{
				callback(error);
			}
			return;
		}
		cl.query(text,value,function(error,results)
		{
			if(error)
			{
				console.log("--- [execSql]" + error);
				cl.end();
			}
			if(typeof callback === "function")
			{
				callback(error);
			}
			cl.end();
			return;
		});
	})
}
//数据库连接检测
function checkConnect(callback)
{
	var conStr = "uxdb://";
	conStr = conStr.concat(this.username,":",this.pwd,"@",this.servername+":"+gPrivatePort,"/",this.dbname);
	var cl = new uxdb.Client(conStr);
	cl.connect(function(err) {
		if (err)
		{
			if (typeof callback === "function")
			{
				callback(false);
			}

		}
		else
		{
			callback(true);
		}
		cl.end();
	});
}


//unit test
if(0)
{
	var dbOpt = new MyDbOpt();
	function addDataTest(){
		var text = "insert into tbl_user (username,usertype,password,createtime,lastmodtime) values ($1,$2,$3,$4,$5);"
		var sqlValue = new Array();
		sqlValue[0] = "admin";
		sqlValue[1] = 0;
		sqlValue[2] = "123456";
		sqlValue[3] = new Date().toLocaleString();
		sqlValue[4] = new Date().toLocaleString();
		dbOpt.execSql(text,sqlValue,function(error){
			if(error){
				console.log("add user failed!");
			}else{
				console.log("add user success!");
			}
		})
	}
	function queryTest(){
		var text = "select * from tbl_user order by username;"
		var sqlValue = new Array();
		dbOpt.querySql(text,sqlValue,function(error,count,rows){
			if(error){
				console.log("query failed!");
			}
			console.log("count:"+count);
			console.log("rows:"+JSON.stringify(rows));
		})
	}
	function execTest(){
		var text = "update tbl_user set password = $1,lastmodtime = $2 where username = $3;"
		var sqlValue = new Array();
		sqlValue[0] = "666666";
		sqlValue[1] = new Date().toLocaleString();
		sqlValue[2] = "adfadsfas";
		dbOpt.execSql(text,sqlValue,function(error,a,b){
			if(error){
				console.log("modify passwd failed!");
			}else{
				console.log("modify passwd success!");
			}
		})
	}
	//addDataTest();
	//queryTest();
	execTest();
}
function deleteAllDataOfTables(){
	var dbOpt = new MyDbOpt();

	var sqlText = "";
	var sqlValue = [];

	var tables = ["tbl_siteinfo","tbl_instance","tbl_dfslist","tbl_dirlist","tbl_mrclist","tbl_osdlist"];

	for(var i=0;i<tables.length;i++){
		sqlText = "delete from " + tables[i] + ";"
		dbOpt.execSql(sqlText,sqlValue,function(isErr){if(isErr){console.log("delete error!");}});
	}
}
//deleteAllDataOfTables();