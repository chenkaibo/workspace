var dbmanageMgr = require("./dbmanagemgr").dbmanageMgr;
var dbOpt = require('../../common/dbopt');
exports.triggerFunction = triggerFunction;
var mainRequestProcFuncs = {
    "enumDbList": enumDbList,
    "connectDb": connectDb,
    "disConnDb": disConnDb,
    "getAllConnectedDb": getAllConnectedDb,
    "getAllCondbByInstance": getAllCondbByInstance,
    "getThisInstConnectedDb": getThisInstConnectedDb,
    "dbMonitor": dbMonitor,
    "getDbHomePageInfo": getDbHomePageInfo,
}

function triggerFunction(postData, gResponseFunction) {
    if (postData.length <= 0) {
        return;
    }
    if (typeof gResponseFunction != "function") {
        return;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: ""
    };
    var jsonObj = JSON.parse(postData);
    var mainRequest = jsonObj.request.mainRequest;
    var procFunc = mainRequestProcFuncs[mainRequest];
    if (typeof procFunc != "function") {
        gResponseFunction(JSON.stringify(rtRes));
    } else {
        procFunc(jsonObj, gResponseFunction);
    }
}
var _dbOpt = new dbOpt();
function enumDbList(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }
    var resJson = {
        rstcode: "error",
        desc: "",
        data: []
    }


    var sqlText = "select a.clsname,a.state as inststate,a.port as dbport,b.ip as hostip,b.port as hostport,b.state as sitestate from tbl_instance a left join tbl_siteinfo b on a.siteid = b.id where a.id = $1;";
    var sqlValue = [jsonObj.data.instid];
    //查询实例相关信息
    _dbOpt.querySql(sqlText, sqlValue, function (isErr, count, retData) {
        if (isErr || count == 0) {
            resJson.desc = "实例相关信息获取失败！";
            gResponseFunction(JSON.stringify(resJson));
            return;
        }

        var dataInfo = retData[0];

        if (dataInfo.sitestate != 1) {
            console.log("[enumDbList]:site " + dataInfo.hostip + " has crashed!");
            resJson.desc = "站点故障！";
            gResponseFunction(JSON.stringify(resJson));
            return;
        }

        if (dataInfo.inststate != 1) {
            console.log("[enumDbList]:instance " + dataInfo.clsname + " has stoped!");
            resJson.desc = "该实例已停止运行，无法获取数据库列表！";
            gResponseFunction(JSON.stringify(resJson));
            return;
        }

        var reqJsonObj = {
            ip: dataInfo.hostip,
            port: dataInfo.hostport,
            data: {
                name: jsonObj.data.dbusername,
                password: jsonObj.data.passwd,
                port: parseInt(dataInfo.dbport),
            }
        }

        function callback(isErr, ret) {
            if (isErr) {
                resJson.desc = "数据库信息获取失败！";
                gResponseFunction(JSON.stringify(resJson));
                return;
            }
            resJson.rstcode = "success";

            var dbData = ret.data;
            console.log("======db data:" + JSON.stringify(dbData) + "============");

            for (var i = 0; i < dbData.length; i++) {
                var dataValue = {};
                dataValue.dbname = dbData[i].dbname;
                dataValue.operStatus = 1;
                resJson.data.push(dataValue);
            }

            var dbJson = {
                webusername: jsonObj.data.webusername,
                instanceid: jsonObj.data.instid
            }
            dbmanageMgr.getInstance().getThisInstConnectedDbMgr(dbJson, function (isNull, clObject) {
                if (!isNull) {
                    var clObj = clObject;
                    var nameStr = "";
                    for (var i = 0; i < resJson.data.length; i++) {
                        nameStr = trim(resJson.data[i].dbname);
                        if (nameStr in clObj) {
                            resJson.data[i].operStatus = 0;
                        }
                    }
                }
                gResponseFunction(JSON.stringify(resJson));
            })
        }

        dbmanageMgr.getInstance().enumDbListMgr(reqJsonObj, callback);
    })
}
function trim(str) {
    if (typeof str != "string") {
        return "";
    } else {
        return str.replace(/(^\s+)|(\s+$)/g, "");
    }
}
function connectDb(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var resJson = {
        rstcode: "error",
        desc: "",
        data: ""
    };

    var reqDb = jsonObj.data;
    if (typeof reqDb.instid == "undefined" || reqDb.instid == "") {
        resJson.desc = "数据库连接信息有误！[101]";
        gResponseFunction(JSON.stringify(resJson));
        return;
    }

    var sqlText = "select a.id as instid,a.port as dbport,a.clsname as instname,b.ip,b.port as hostport,b.state as sitestate from tbl_instance a " +
        "left join tbl_siteinfo b on a.siteid = b.id where a.id = $1;";
    var sqlValue = [reqDb.instid];
    _dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
        if (isErr || count == 0) {
            console.log("[conn]:instance info get faild!");
            resJson.desc = "实例相关信息获取失败！";
            gResponseFunction(JSON.stringify(resJson));
            return;
        }

        var rstData = rst[0];

        if (rstData.sitestate != 1) {
            console.log("[enumDbList]:site " + rstData.hostip + " has crashed!");
            resJson.desc = "站点故障！";
            gResponseFunction(JSON.stringify(resJson));
            return;
        }

        var conJson = {
            webusername: reqDb.webusername || "",
            dbusername: reqDb.dbusername || "",
            pwd: reqDb.pwd || "",
            dbname: reqDb.dbname || "",
            ip: rstData.ip || "",
            port: rstData.dbport || "",
            instid: rstData.instid || "",
            instname: rstData.instname || ""
        }

        if (conJson.dbusername == "" || conJson.pwd == "" || conJson.ip == "" || conJson.port == "" || conJson.dbname == "") {
            console.log("[conn]:parameter is error!");
            resJson.desc = "参数有误，无法连接！";
            gResponseFunction(JSON.stringify(resJson));
            return;
        }

        function callback(isErr, rst) {
            if (isErr) {
                console.log(rst);
                resJson.desc = rst;
            } else {
                console.log("[conn]:database connected successfully!");
                resJson.rstcode = "success";
            }
            gResponseFunction(JSON.stringify(resJson));
        }

        dbmanageMgr.getInstance().connectDbMgr(conJson, callback);
    })
}
function disConnDb(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }
    var resJson = {
        rstcode: "error",
        desc: "",
        data: ""
    }

    function callback(isErr, rst) {
        if (isErr) {
            console.log(rst);
            resJson.desc = rst;
        } else {
            console.log("[discon]:database disconnected successfully!");
            resJson.rstcode = "success";
        }
        gResponseFunction(JSON.stringify(resJson));
    }

    dbmanageMgr.getInstance().disConnDbMgr(jsonObj.data, callback);
}

function getAllConnectedDb(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    dbmanageMgr.getInstance().getAllConnectedDbMgr(jsonObj.data, function (isErr, dbData) {
        if (isErr) {
            console.log("get connected dbinfo faild!");
            rtRes.desc = "获取所有已连接数据库失败！";
            gResponseFunction(JSON.stringify(rtRes))
            return;
        }
        rtRes.rstcode = "success";

        rtRes.data = dbData;

        console.log("get connected dbinfo success!");
        gResponseFunction(JSON.stringify(rtRes));
    })
}
function getAllCondbByInstance(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    };

    dbmanageMgr.getInstance().getAllCondbByInstanceMgr(jsonObj.data, function (isErr, dbData) {
        if (isErr) {
            console.log("get connected dbinfo faild!");
            rtRes.desc = "获取所有已连接数据库失败！";
            gResponseFunction(JSON.stringify(rtRes))
            return;
        }
        rtRes.rstcode = "success";

        rtRes.data = dbData;

        console.log("get connected dbinfo success!");
        gResponseFunction(JSON.stringify(rtRes));
    })
}
function getThisInstConnectedDb(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: ""
    }

    dbmanageMgr.getInstance().getThisInstConnectedDbMgr(jsonObj.data, function (isErr, data) {
        if (isErr) {
            console.log("get connected dbinfo faild!");
            rtRes.desc = "get connected dbinfo faild!";
            gResponseFunction(JSON.stringify(rtRes))
            return;
        }
        rtRes.rstcode = "success";
        rtRes.data = data;
        console.log("get connected dbinfo success!");
        gResponseFunction(JSON.stringify(rtRes));
    })
}

function getDbHomePageInfo(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: {
            dbInfo: {},
            sessionInfo: {
                sessionNum: [],
                loginNum: []
            },
            hostInfo: {
                cpuUsage: [],
                memeryUsage: [],
                diskUsage: [],
            }
        }
    }

    dbmanageMgr.getInstance().getDbHomePageInfoMgr(jsonObj.data, function (isErr, monitorinfo) {
        if (isErr) {
            rtRes.desc = monitorinfo;
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        rtRes.rstcode = "success";

        if (monitorinfo.length == 0) {
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var monitorinfoData = monitorinfo[0];

        rtRes.data.dbInfo.dbname = monitorinfoData.dbname;
        rtRes.data.dbInfo.runtime = new Date().getTime() - monitorinfoData.conntime;
        rtRes.data.dbInfo.version = monitorinfoData.version;
        rtRes.data.dbInfo.type = monitorinfoData.type;
        rtRes.data.dbInfo.instname = monitorinfoData.clsname;
        rtRes.data.dbInfo.platform = "优炫云";
        if (monitorinfoData.type == 1) {//localdb
            rtRes.data.dbInfo.path = monitorinfoData.clspath;
        } else { //dfsdb
            rtRes.data.dbInfo.path = monitorinfoData.clsname + "/" + monitorinfoData.dfsurl + "/" + monitorinfoData.dfsdb;
        }

        if (!monitorinfoData.isNull) {
            var rate = 6;//获取数据的间隔频率，数据库中的数据间隔频率是30s，首页需要的数据的间隔频率是3分钟
            rtRes.data.sessionInfo.sessionNum = restructData(monitorinfoData.sessionnum, rate);
            rtRes.data.sessionInfo.loginNum = restructData(monitorinfoData.loginnum, rate);
            rtRes.data.hostInfo.cpuUsage = restructData(monitorinfoData.cpuusage, rate);
            rtRes.data.hostInfo.memeryUsage = restructData(monitorinfoData.memeryusage, rate);
            rtRes.data.hostInfo.diskUsage = restructData(monitorinfoData.diskusage, rate);
        }

        gResponseFunction(JSON.stringify(rtRes));
    })
}
function restructData(data, rate) {
    if (typeof data != "string") {
        return new Array();
    }
    var dataArr = data.split(":");
    var dataValue = [];
    for (var i = 0; i < dataArr.length; (i += rate)) {
        dataValue.push(dataArr[i]);
    }
    return dataValue;
}

function dbMonitor(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: {
            sessionNum: [],
            loginNum: [],
            hitBlks: [],
            readBlks: [],
            insertNum: [],
            deleteNum: [],
            updateNum: [],
            fetchNum: [],
            returnNum: [],
            rollbackNum: [],
            commitNum: [],
            diskUsage: [],
            cpuUsage: [],
            memeryUsage: [],
        }
    };
    dbmanageMgr.getInstance().dbMonitorMgr(jsonObj.data, function (isErr, rst) {
        if (isErr) {
            rtRes.desc = rst;
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }
        rtRes.rstcode = "success";
        if (rst.length == 0) {
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }
        var rate = 2;//获取数据的间隔频率，数据库中的数据间隔频率是30s，db监控需要的数据的间隔频率是1分钟
        rtRes.data.sessionNum = restructData(rst[0].sessionnum, rate);
        rtRes.data.loginNum = restructData(rst[0].loginnum, rate);
        rtRes.data.hitBlks = restructData(rst[0].hitblks, rate);
        rtRes.data.readBlks = restructData(rst[0].readblks, rate);
        rtRes.data.insertNum = restructData(rst[0].insertnum, rate);
        rtRes.data.deleteNum = restructData(rst[0].deletenum, rate);
        rtRes.data.updateNum = restructData(rst[0].updatenum, rate);
        rtRes.data.fetchNum = restructData(rst[0].fetchnum, rate);
        rtRes.data.returnNum = restructData(rst[0].returnnum, rate);
        rtRes.data.rollbackNum = restructData(rst[0].rollbacknum, rate);
        rtRes.data.commitNum = restructData(rst[0].commitnum, rate);
        rtRes.data.diskUsage = restructData(rst[0].diskusage, rate);
        rtRes.data.cpuUsage = restructData(rst[0].cpuusage, rate);
        rtRes.data.memeryUsage = restructData(rst[0].memeryusage, rate);
        gResponseFunction(JSON.stringify(rtRes));
    })
}






//unit test
function testConnectDb(data) {
    var dataArr = data.split("?");
    var jsonObj = {
        data: {
            username: (dataArr.length > 1 ? "uxdbwebuser" : "uxdb"),
            pwd: (dataArr.length > 1 ? "hn5sFyvrgH" : "123456"),
            dbname: (dataArr.length > 1 ? "uxdbwebdb" : "uxdb"),
            instid: (dataArr[0] == 2 ? "93496289a175df15368e01878b889e5b" : "3989f07ddb2109365c26e53e2237065d")
        }
    }
    connectDb(jsonObj, function (isErr, rst) {
        console.log(isErr);
    })
}
function testDisConnDb(data) {
    var dataArr = data.split("?");
    var jsonObj = {
        data: {
            username: (dataArr.length > 1 ? "uxdbwebuser" : "uxdb"),
            pwd: (dataArr.length > 1 ? "hn5sFyvrgH" : "123456"),
            dbname: (dataArr.length > 1 ? "uxdbwebdb" : "uxdb"),
            instid: (dataArr[0] == 2 ? "93496289a175df15368e01878b889e5b" : "3989f07ddb2109365c26e53e2237065d"),
        }
    }
    disConnDb(jsonObj, function (isErr, rst) {
        console.log(isErr);
    })
}
function testCreateDb(data) {
    var dataArr = data.split("?");
    var sqlText = "select a.port as dbport,b.ip,b.port as hostport from tbl_instance a " +
        "left join tbl_siteinfo b on a.siteid = b.id where a.id = $1;";
    var sqlValue = [dataArr[0] == 2 ? "93496289a175df15368e01878b889e5b" : "3989f07ddb2109365c26e53e2237065d"];
    _dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
        if (isErr || count == 0) {
            console.log("get instance info faild!");
            return;
        }
        var rstData = rst[0];
        var jsonObj = {
            username: (dataArr.length > 1 ? "uxdbwebuser" : "uxdb"),
            pwd: (dataArr.length > 1 ? "hn5sFyvrgH" : "123456"),
            dbname: (dataArr.length > 1 ? "uxdbwebdb" : "uxdb"),
            ip: rstData.ip,
            port: rstData.dbport,
            sqlText: "create table tbl_test(id int);",
            sqlValue: []
        }
        dbmanageMgr.getInstance().execDbOptMgr(jsonObj, function (isErr, rst) {
            if (isErr) {
                console.log("create table faild!");
                console.log("rst:" + JSON.stringify(rst));
            } else {
                console.log("create table success!");
            }

        })
    })
}
function testInsertDb(data) {

    var dataArr = data.split("?");
    var sqlText = "select a.port as dbport,b.ip,b.port as hostport from tbl_instance a " +
        "left join tbl_siteinfo b on a.siteid = b.id where a.id = $1;";
    var sqlValue = [dataArr[0] == 2 ? "93496289a175df15368e01878b889e5b" : "3989f07ddb2109365c26e53e2237065d"];
    _dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
        if (isErr || count == 0) {
            console.log("get instance info faild!");
            return;
        }
        var rstData = rst[0];
        var jsonObj = {
            username: (dataArr.length > 1 ? "uxdbwebuser" : "uxdb"),
            pwd: (dataArr.length > 1 ? "hn5sFyvrgH" : "123456"),
            dbname: (dataArr.length > 1 ? "uxdbwebdb" : "uxdb"),
            ip: rstData.ip,
            port: rstData.dbport,
            sqlText: "insert into tbl_test values(1);",
            sqlValue: []
        }
        dbmanageMgr.getInstance().execDbOptMgr(jsonObj, function (isErr, rst) {
            if (isErr) {
                console.log("insert faild!");
                console.log("rst:" + JSON.stringify(rst));
            } else {
                console.log("insert success!");
            }

        })
    })
}
function testQueryDb(data) {

    var dataArr = data.split("?");
    var sqlText = "select a.port as dbport,b.ip,b.port as hostport from tbl_instance a " +
        "left join tbl_siteinfo b on a.siteid = b.id where a.id = $1;";
    var sqlValue = [dataArr[0] == 2 ? "93496289a175df15368e01878b889e5b" : "3989f07ddb2109365c26e53e2237065d"];
    _dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
        if (isErr || count == 0) {
            console.log("get instance info faild!");
            return;
        }
        var rstData = rst[0];
        var jsonObj = {
            username: (dataArr.length > 1 ? "uxdbwebuser" : "uxdb"),
            pwd: (dataArr.length > 1 ? "hn5sFyvrgH" : "123456"),
            dbname: (dataArr.length > 1 ? "uxdbwebdb" : "uxdb"),
            ip: rstData.ip,
            port: rstData.dbport,
            sqlText: "select * from tbl_test;",
            sqlValue: []
        }
        dbmanageMgr.getInstance().queryDbOptMgr(jsonObj, function (isErr, count, rst) {
            if (isErr) {
                console.log("query tblinfo faild!");
                console.log(rst);
            } else {
                console.log("query tblinfo success!");
                console.log("rows:" + JSON.stringify(rst));
            }
        })
    })
}
function getAllConnectedDbTest() {
    var jsonObj = {}
    dbmanageMgr.getInstance().getAllConnectedDbMgr(jsonObj, function (isErr, data) {
        if (isErr) {
            console.log("get connected dbinfo faild!");
            return;
        }
        console.log("get connected dbinfo success!");
        console.log(JSON.stringify(data));
    })
}

//startListen();
function startListen() {
    var listen = require('../../listenandsendrequest');
    var listenObj = new listen();
    listenObj.startServer(testConnectDb, "12301");
    listenObj.startServer(testDisConnDb, "12302");
    listenObj.startServer(testCreateDb, "12303");
    listenObj.startServer(testInsertDb, "12304");
    listenObj.startServer(testQueryDb, "12305");
    listenObj.startServer(getAllConnectedDbTest, "12306");
}