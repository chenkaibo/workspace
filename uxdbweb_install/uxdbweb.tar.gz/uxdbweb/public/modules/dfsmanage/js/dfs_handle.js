//var initElemFlag = true;
var checkFlag = false,currDfsStatus,refeshDfsStateFlag = true;
//window.onresize = function(){
//    onsreenChange()
//}
//function onsreenChange(){
//    var minWidth = 1919;
//    var minHeight = 953;
//    if(innerHeight < minHeight)
//    {
//        d3.select("#dfsBodyId").style({
//            "height":796,
//            "background-size":"1920px 1081px",
//        });
//    }else{
//        d3.select("#dfsBodyId").style({
//            "height":"98%",
//            "background-size":"1920px 955px"
//        });
//    }
//    if(innerWidth < minWidth)
//    {
//        d3.select("#dfsBodyId").style({
//            "width":1920,
//            "background-size":"1920px 1081px",
//        });
//    }else{
//        d3.select("#dfsBodyId").style({
//            "width":"100%",
//            "background-size":"1920px 955px"
//        });
//    }
//    var ss = d3.select("#indexBodyId");
//}
//DFS操作界面元素添加
function getDfsHandle(operDFSInfo)
{
    window.focus();
    clearTimerFun();
    changePath("云数据库管理->DFS管理->DFS操作");
    window.sessionStorage.ux_pagePath = "dfsManage,dfsHandle";
    var currentRole = window.sessionStorage.ux_curUserRole;
    d3.select("#mainContainDiv").remove();
    setParameterData(operDFSInfo);
    volumeContainDiv = d3.select("#dfsBodyId")
        .append("div")
        .classed("siteList-content container",true)
        .attr("id","mainContainDiv");
    d3.select(".siteList-content")
        .append("div")
        .classed("revers",true)
        .append("a")
        .classed("dfs-reverse",true)
        .append("button")
        .attr({
            "id":"dfs-reverseBtn",
            "onclick":"returnDfsList()"
        })
        .classed("btn admitClick",true)
        .html("返回上一级");
    d3.select(".siteList-content")
        .append("fieldset")
        .classed("dfs-basicInfo",true)
        .append("legend")
        .classed("legendText",true)
        .html("基本信息");
    d3.select(".dfs-basicInfo")
        .append("div")
        .classed("info-detail",true);
    var dfsInfo = ["DFS 名称：","DFS&nbsp;&nbspID：","DFS 版本：","创建时间：","是否备份：","备份状态："];
    var dfsInfoId = ["dfsName","dfsId","dfsVersion","dfsCreatTime","copyResult","dfsCopyState"];
    for(var i = 0;i < dfsInfo.length;i++){
        d3.select(".info-detail")
            .append("div")
            .classed("detail-margin",true)
            .append("span")
            .html(dfsInfo[i]);
    };
    d3.selectAll(".detail-margin")
       .append("span").classed("infoDetail-text",true);
    var detailText = d3.selectAll(".infoDetail-text");
    for(var i = 0;i < dfsInfo.length;i++){
        d3.select(detailText[0][i])
            .attr("id",dfsInfoId[i])
            .html(parameterData[i]);
    };
    d3.select(".siteList-content")
        .append("fieldset")
        .classed("dfs-runStop",true)
        .append("legend")
        .classed("legendText",true)
        .html("DFS操作");
    d3.select(".dfs-runStop")
        .append("div")
        .classed("dfsRunStop-wrapper",true);
    for(var i = 0;i < 2;i++){
        var dfsOperateID = ["dfsRunBtn","dfsStopBtn"];
        d3.select(".dfsRunStop-wrapper")
            .append("button")
            .classed("dfsOperBtn highlight",true)
            .attr("id",dfsOperateID[i]);
    };
    d3.select("#dfsRunBtn")
        .attr("title","启动")
        .on("click",function(){
            dfsSwitch(1,parameterData)
        });
    d3.select("#dfsStopBtn")
        .attr({
            "title":"停止",
            "class":"dfsStopBtn dfsOperBtn"
        })
        .on("click",function(){
            dfsSwitch(2,parameterData)
        });
    d3.select(".dfsRunStop-wrapper")
        .append("span")
        .classed("dfsRunIcon",true)
        .attr("id","dfsRunIcon");
    d3.select(".siteList-content")
        .append("fieldset")
        .classed("dfsList-content",true)
        .append("legend")
        .html("DFS列表");
    /*DFS列表左侧目录*/
    d3.select(".dfsList-content")
        .append("div")
        .attr("class","dfsList-catalog")
        .append("ul")
        .classed("dfsList-catalogul",true);
    var dfsCatalog = ["Volume模块列表","DIR模块列表","MRC模块列表","OSD模块列表"];
    for(var i = 0;i < 4;i++){
        d3.select(".dfsList-catalogul")
            .append("a")
            .append("li")
            .html(dfsCatalog[i]);
    };
    d3.select(".dfsList-catalogul a").style("color","white").append("div").classed("dfsList-catalogli",true);
    /*DFS右侧table*/
    d3.select(".dfsList-content")
        .append("div")
        .classed("dfsmodule-content",true)
        .append("div")
        .classed("dfsmodule-wrapper",true);
    var innerListName = ["volumeList","dirList","mrcList","osdList"];
    var innerToolbar = ["volumeToolbar","dirToolbar","mrcToolbar","osdToolbar"];
    var innerListHtml = ["Volume","DIR","MRC","OSD"];
    var searchListName = ["searchVolume","searchDir","searchMrc","searchOsd"];
    var searchTypeName = ["Volume名称：","Dir名称：","Mrc名称：","Osd名称："];
    var searchIpt = ["volumeSearchIpt","dirSearchIpt","mrcSearchIpt","osdSearchIpt"];
    var queryFun = ["queryVolume()","queryDir()","queryMrc()","queryOsd()"];
    var tableId = ["volumeTable","dirTable","mrcTable","osdTable"];
    for(var i = 0;i < innerListName.length;i++ ){
        d3.select(".dfsmodule-wrapper")
            .append("div")
            .classed("dfsmodule-inner",true)
            .attr("id",innerListName[i])
            .append("div")
            .classed("toolbar",true)
            .attr("id",innerToolbar[i])
            .append("span")
            .classed("dfsmodule-text",true)
            .html(innerListHtml[i]);
        if(i == 0){
            d3.select("#"+innerListName[i]).classed("show",true);
            instanContainDiv = d3.select(".toolbar")
                .append("button")
                .attr("id","newVolumeBtn")
                .html("新&nbsp;&nbsp;建");
            if(currDfsStatus == 1){
                d3.select("#newVolumeBtn").attr("class",null).classed("btn btn-default admitClick bounceIn disabledElem",true);
            }else{
                d3.select("#newVolumeBtn").attr("class",null).classed("delBtnClass disabledElem",true).attr("disabled","disabled");
            };
            d3.select(".toolbar")
                .append("button")
                .classed("del-btn-position disabledElem delBtnClass",true)
                .attr({
                    "id":"delVolume",
                    "disabled":true,
                })
                .on("click",function(){
                    volumeDel();
                })
                .html("删&nbsp;&nbsp;除");
        };

    };
    d3.selectAll(".dfsmodule-inner")
        .each(function(d,i){
            d3.select(this)
                .append("div")
                .classed("pull-right searchAll",true)
                .attr("id",searchListName[i])
                .append("div")
                .classed("searchSite-content",true)
                .append("span")
                .classed("searchTypeName",true)
                .html(searchTypeName[i]);
        });
    d3.selectAll(".searchAll .searchSite-content")
        .each(function(d,i){
            d3.select(this)
                .append("input")
                .attr({
                    "type":"text",
                    "id":searchIpt[i]
                });
        });
    d3.selectAll(".searchAll .searchSite-content")
        .each(function(d,i) {
            d3.select(this)
                .append("button")
                .classed("btn searchSite-btn", true)
                .attr({
                    "title": "查找",
                    "onclick":queryFun[i]
                });
        })
    d3.selectAll(".dfsmodule-inner")
        .each(function(d,i) {
            d3.select(this)
                .append("table")
                .attr({
                    "id": tableId[i],
                    "data-toggle": "table",
                    "color": "#57D1F7"
                })
        });


    //d3.select(".dfsList-content")
    //    .append("div")
    //    .classed("space-line",true)
    //    .attr("id","dfsmodule_line");
    if(currentRole == 1)
    {
        d3.selectAll(".disabledElem").style('display','none');
        d3.select("#searchSite-form").style('opacity','0');
    }
    initVolumeList();
    initDirList(parameterData);
    initMrcList();
    initOsdList();
    leftCatalog();
    newVolumeInfoFun();
    intervalRefreshDfsState();
    updateDfsStatus(currDfsStatus);

}
//定时刷新DFS状态
function intervalRefreshDfsState()
{
    //console.log("refeshDfsStateFlag = "+refeshDfsStateFlag);
    if(refeshDfsStateFlag == true){
        clearTimeout(refreshCurrDfsTimer);
        intervalRefreshCurrDfs();
        refreshCurrDfsTimer = setTimeout("intervalRefreshDfsState()",10*1000);
        refeshDfsStateFlag = true;
    }
    else{
        clearTimeout(refreshCurrDfsTimer);
        refeshDfsStateFlag = false;
    }

}
//dfs列表左侧目录样式实现以及相应定时器触发改变列表的state
function leftCatalog()
{
   d3.selectAll(".dfsList-catalogul a").on('click',function(d,i){
       d3.selectAll(".dfsList-catalogul a").style("color","#57D1f7");
       d3.selectAll(".dfsList-catalogli").remove();
       d3.select(this).style("color","white").append("div").classed("dfsList-catalogli",true);
       d3.selectAll(".dfsmodule-inner").classed("show",false);
       var inner = d3.selectAll(".dfsmodule-inner");
       d3.select(inner[0][i]).classed("show",true);
       window.sessionStorage.ux_dfsHandleReference = i;
       refeshDfsStateFlag = false;
       refreshVolmDirMrcOsd(i);
       setTimeout("intervalRefreshDfsState()",10*1000);
    });
    //if($(".dfsmodule-wrapper").height() >= 432) {
    //   d3.select("#dfsmodule_line").style("display","block");
    //}else{
    //    d3.select("#dfsmodule_line").style("display","none");
    //}
}
//Volume、Dir、Mrc、Osd点击后定时刷新状态
function refreshVolmDirMrcOsd(refrence)
{
    if(refrence == 0){
        clearInterval(dirTimer);
        clearInterval(mrcTimer);
        clearInterval(osdTimer);
        clearTimeout(refreshCurrDfsTimer);
        getVolumeData();
        //volumeTimer = setInterval("getVolumeData()",10*1000);
        refeshDfsStateFlag = false;
        intervalRefreshDfsState();
    }
    if(refrence == 1){
        clearInterval(mrcTimer);
        clearInterval(osdTimer);
        clearTimeout(volumeTimer);
        clearTimeout(refreshCurrDfsTimer);
        getDirData();
        dirTimer = setInterval("getDirData()",10*1000);
        refeshDfsStateFlag = true;
    };
    if(refrence == 2){
        clearInterval(dirTimer);
        clearInterval(osdTimer);
        clearTimeout(volumeTimer);
        clearTimeout(refreshCurrDfsTimer);
        getMrcData();
        mrcTimer = setInterval("getMrcData()",10*1000);
        refeshDfsStateFlag = true;
    };
    if(refrence == 3){
        clearInterval(dirTimer);
        clearInterval(mrcTimer);
        clearTimeout(volumeTimer);
        clearTimeout(refreshCurrDfsTimer);
        getOsdData();
        osdTimer = setInterval("getOsdData()",10*1000);
        refeshDfsStateFlag = true;
    };
}
//初始化Volume列表表格
function initVolumeList()
{
    var par = [{field: 'radio', radio: true,align: 'center'},
        {field:'volume_number',title:'序&nbsp;&nbsp;&nbsp;&nbsp;号',align: 'center'},
        {field:'volume_name',title:'名称',align: 'center'},
        {field:'volume_ID',title:'ID',align: 'center'}
    ];
    $('#volumeTable').bootstrapTable({
        classes:"table table-no-bordered",
        toolbar:"#volumeToolbar",
        columns: par,
        height:360,
        idField:"volume_number",
    });
    //getVolumeData();
}
//获取volume数据
function getVolumeData()
{
    if(currDfsStatus != 1){
        d3.select("#delVolume").classed("disabledElem delBtnClass",true).attr("disabled",true);
        d3.select("#newVolumeBtn").classed("delBtnClass disabledElem",true).attr("disabled",true);
        return;
    };
    var currentDfsId = window.sessionStorage.ux_dfsid;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"enumVolumeList","subRequest":"","ssubRequest":""},
        data    :{
            dfsid:currentDfsId
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,enumVoumeListCallFunc);
}
function enumVoumeListCallFunc(retJson)
{
    var dataJson = JSON.parse(retJson);
    //console.log("volume列表数据后台返回信息"+ retJson);
    if(dataJson.rstcode == "success"){
        volumeDataJson = volumeGetNewJson(dataJson.data);
        $("#volumeTable").bootstrapTable('load',volumeDataJson);
        listenTable("volumeTable","delVolume");
        d3.select("#newVolumeBtn").attr("class",null).classed("btn btn-default admitClick bounceIn disabledElem",true);
    }else{
        uxAlert(dataJson.desc);
    }
}
//重组volume数据格式
function volumeGetNewJson(data)
{
    var newJson = [];
    for(var i = 0;i<data.length;i++)
    {
        var info = {};
        info.volume_number = (i+1);
        info.volume_name = data[i].name;
        info.volume_ID = data[i].id;
        newJson.push(info);
    }
    return newJson;
}
// 从后台获取Volume路径
var volumePath;
function getVolumePath()
{
    var currentDfsId = window.sessionStorage.ux_dfsid;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"getVolumePath","subRequest":"","ssubRequest":""},
        data    :{
            dfsid: currentDfsId
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,getVolumePathCallback);
}
function getVolumePathCallback(regdata)
{
    var objdata = JSON.parse(regdata);
    if(objdata.rstcode == "success"){
        volumePath = objdata.data;
    }
}
//Volume新建页面
function newVolumeInfoFun()
{
    var className;
    d3.select("#newVolumeBtn").on('click',function(){
        d3.select("#newVolumeBtn").classed("admitClick",false);
        getVolumePath();
        newVolumeInfoElem(volumeContainDiv,'New',volumePath);
        d3.select("#newUserItemSpanNew").text("新建Volume").classed("newTitle",true);
        d3.select("#sureBtnNew").attr({'onclick':'newVolumeInfo()'});
        if(d3.select("#dialogNew").classed("bounceIn"))
        {
            className = "bounceOutUp";
        }else{
            className = "bounceIn";
        }
        $('#dialogBgNew').fadeIn(300);
        $('#dialogNew').removeAttr('class').addClass('animated ' + className + '').fadeIn();
    });

    }
//Volume新建弹出框实现
function newVolumeInfoElem(volumeContainDivElem,operName,volumePath)
{
    d3.select("#dialogBgNew").remove();
    d3.select("#dialogNew").remove();
    var pupUpItem = "";
    var popUpInputArray;
    popUpInputArray = ["volume名称","&nbsp;&nbsp;路&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;径&nbsp;&nbsp;"];
    volumeContainDivElem.append("div")
        .attr("id","dialogBg" + operName);
    var outPage = volumeContainDivElem.append("div")
        .attr("id","dialog" + operName)
        .style({
            "height":"263px",
            "width":"445px"
        });
    var editFrom = outPage.append("div")
        .attr("id","editFrom" + operName);
    var newUserItemSpan = editFrom.append("span")
        .attr("id","newUserItemSpan" + operName)
        .html(pupUpItem);
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos");
    for(var i = 0;i < popUpInputArray.length;i++)
    {
        var editFromLi = editFormUl.append("li").attr("class","editUl");
        editFromLi.append("label")
            .attr("class","editFromLiSpan")
            .html(popUpInputArray[i]);
        if(i == 1)
        {
            var selectElem = editFromLi.append("select").attr({
                'class':'ipt selectStyle',
                'id':'input' + i
            });
            for(var k = 0;k<volumePath.length; k++)
            {
                selectElem.append("option")
                    .html(volumePath[k]);
            }
        }else
        {
            editFromLi.append("input")
                .attr({
                    'id':"input" + i,
                    'type':"text",
                    'class':'ipt',
                    'placeholder':'字母开头，字母、数字、下划线组成，小于32位'
                })
                .on('blur',function(d,i){
                    var volumeName = d3.select(this)[0][0].value;
                    if(!isvolumename(volumeName))
                    {
                        checkFlag = true;
                        d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'> 以字母开头，由字母、数字、下划线组成，长度小于32位 </span>";
                    }else{
                        checkFlag = false;
                        d3.select(this)[0][0].nextSibling.innerHTML = "";
                    }
                });
        }
    }
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("button")
        .attr("id","sureBtn" + operName)
        .attr("class","btn btn-sm btn-bg-color popUpBtn")
        .html("确定");
    editFromDivBtn.append("button")
        .attr("class","btn btn-sm btn-bg-color popUpBtn claseDialogBtn")
        .attr("id","claseDialogBtn" + operName)
        .on("click",function(){
            var operIdStr = d3.select(this)[0][0].id;
            if(operIdStr.indexOf("New") > 0)
            {
                d3.select("#dialogNew").classed("bounceIn",false);
                $('#dialogBgNew').fadeOut(300,function(){
                    $('#dialogNew').addClass('bounceOutUp').fadeOut();
                });
                d3.select("#newVolumeBtn").classed("admitClick",true);
            }
        })
        .html("取消");
}
//Volume新建页面与后台交互
function newVolumeInfo()
{
    var volumeName = d3.select("#input" + 0)[0][0].value;
    if(checkFlag || volumeName == "")
    {
        uxAlert("请正确输入需新建Volume的信息！");
        return;
    }
    var currentDfsId = window.sessionStorage.ux_dfsid;
    var volumename = d3.select("#input" + 0)[0][0].value;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"createVolume","subRequest":"","ssubRequest":""},
        data    :{
            dfsid: currentDfsId,
            volume_name:volumename
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,newVolumeInfoCallback);
}
function newVolumeInfoCallback(retJson)
{
    clearTimeout(volumeTimer);
    clearTimeout(refreshCurrDfsTimer);
    clearInterval(volumeQueryTimer);
    var retJsonStr = JSON.parse(retJson);
    console.log("新建volume后台返回数据 = "+retJson);
    if((retJsonStr.rstcode == "success") && (currDfsStatus == 1))
    {
        uxAlert("新建Volume成功!");
        getVolumeData();
    }else{
        uxAlert("新建Volume失败!");
    }

    d3.select("#dialogNew").classed("bounceIn",false);
    $('#dialogBgNew').fadeOut(300,function(){
        $('#dialogNew').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#newVolumeBtn").classed("admitClick",true);
}
//删除volumeDel
function volumeDel()
{
    uxConfirm("是否确认删除该Volume？",function(rst)
    {
        //点击取消
        if(!rst)
        {
            return;
        }
        var selected = $("#volumeTable").bootstrapTable('getSelections');
        var volumename = selected[0].volume_name;
        //var volumeID = selected[0].volume_ID;
        var currentDfsId = window.sessionStorage.ux_dfsid;
        var jsonDataObj = {
            ip      :"",
            port    :"",
            router  :"dfsmanage",
            request :{"mainRequest":"deleteVolume","subRequest":"","ssubRequest":""},
            data    :{
                dfsid: currentDfsId,
                volume_name:volumename
            }
        };
        var jsonDataStr = JSON.stringify(jsonDataObj);
        ux_reqInterface.ajaxRequest(false,jsonDataStr,delVolumeCallback);

        /*=====模拟数据=====*/
        //var jsonDataObj = {"rstcode":"success","desc":"成功删除此条数据"};  //test
        //var jsonDataStr = JSON.stringify(jsonDataObj)
        //delVolumeCallback(jsonDataStr);
    });
}
function delVolumeCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if((retJsonStr.rstcode == "success") && (currDfsStatus == 1))
    {
        getVolumeData();
        uxAlert("删除Volume成功！");
    }else{
        uxAlert("删除Volume失败！");
    }
    changeButtonStatus("volumeTable","delVolume");
}
//初始化DIR表格
function initDirList(operDFSInfo)
{
    var par = [{field: 'radio', radio: true,align: 'center'},
        {field:'dir_number',title:'序&nbsp;&nbsp;&nbsp;&nbsp;号',align: 'center'},
        {field:'dir_name',title:'名称',align: 'center'},
        {field:'dir_ip',title:'侦听IP',align: 'center'},
        {field:'dir_port',title:'端&nbsp;&nbsp;&nbsp;&nbsp;口',align: 'center'},
        {field:'dir_state',title:'状&nbsp;&nbsp;&nbsp;&nbsp;态',align: 'center',formatter:function(value,row,index){
            if(row.dir_state == 1) {
                var discon = '<a title="运行">' + '<button class="btn-link run-btn"></button>' + '</a>';
                return discon;
            }else{
                var constr = '<a title="停止">' + '<button class="btn-link stop-btn"></button>' + '</a>';
                return constr;
            }
        }},

        {field:'dir_state',title:'操&nbsp;&nbsp;&nbsp;&nbsp;作',align: 'center',formatter:function(value,row,index){
            var constr = '<a title="配置">' + '<button class="btn-link configurate" onclick="dirConfigurate(\''+row.dir_id+'\')"></button>' +'</a>';
            return constr;
        }}
    ];
    $('#dirTable').bootstrapTable({
        classes:"table table-no-bordered",
        toolbar:"#dirToolbar",
        columns: par,
        height:360,
        idField:"dir_number",
    });
    //getDirData();
}
//获取dir数据
function getDirData()
{
    var currentDfsId = window.sessionStorage.ux_dfsid;
    var jsonDataObj = {
        ip: "",
        port: "",
        router: "dfsmanage",
        request: {"mainRequest": "enumDIRList", "subRequest": "", "ssubRequest": ""},
        data: {
            dfsid: currentDfsId
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,dirCallback);
    /*=====模拟数据======*/
    //var jsonDataObj =  [
    //    {
    //        "dirname":"mrc-one",
    //        "id":"192.168.1.2"
    //    }]
    //var jsonDataStr = JSON.stringify(jsonDataObj);
    //dirCallback(jsonDataStr);
}
//dir回调函数
function dirCallback(retJson)
{
    var data = JSON.parse(retJson);
    if(data.rstcode=="success") {
        var dataJson = dirGetNewJson(data.data);
        //var dataJson = dirGetNewJson(data);
        $("#dirTable").bootstrapTable('load',dataJson);
    }else{
        clearInterval(dirTimer);
        uxAlert("初始化DIR列表失败！");
    }
}
//重组dir数据格式
function dirGetNewJson(data)
{
    var newJson = [];
    for(var i = 0;i<data.length;i++)
    {
        var info = {};
        info.dir_number = (i+1);
        info.dir_name = data[i].dirname;
        info.dir_ip = data[i].ip;
        info.dir_port = data[i].port;
        info.dir_state = data[i].state;
        info.dir_handle = data[i].maintype;
        info.dir_id = data[i].id;
        newJson.push(info);
    }
    return newJson;
}
//跳转至dir配置界面
function dirConfigurate(dirId)
{
    dirCurrId = dirId;
    getDirHandle(parameterData);
}
//初始化MRC表格
function initMrcList()
{
    var par = [{field: 'radio', radio: true,align: 'center'},
        {field:'mrc_number',title:'序&nbsp;&nbsp;&nbsp;&nbsp;号',align: 'center'},
        {field:'mrc_name',title:'名称',align: 'center'},
        {field:'mrc_ip',title:'侦听IP',align: 'center'},
        {field:'mrc_port',title:'端&nbsp;&nbsp;&nbsp;&nbsp;口',align: 'center'},
        {field:'mrc_state',title:'状&nbsp;&nbsp;&nbsp;&nbsp;态',align: 'center',formatter:function(value,row,index){
            if(row.mrc_state == 1) {
                var discon = '<a title="运行">' + '<button class="btn-link run-btn"></button>' + '</a>';
                return discon;
            }else{
                var constr = '<a title="停止">' + '<button class="btn-link stop-btn"></button>' + '</a>';
                return constr;
            }
        }},

        {field:'mrc_state',title:'操&nbsp;&nbsp;&nbsp;&nbsp;作',align: 'center',formatter:function(value,row,index){
            var constr = '<a title="配置">' + '<button class="btn-link configurate" onclick="mrcConfigurate(\''+row.mrc_id+'\')"></button>' +'</a>';
            return constr;
        }}
    ];
    $('#mrcTable').bootstrapTable({
        classes:"table table-no-bordered",
        toolbar:"#mrcToolbar",
        columns: par,
        height:360,
        idField:"mrc_number",
    });
    getMrcData();
}
//跳转至mrc配置界面
function mrcConfigurate(mrcId)
{
    clearTimerFun();
    mrcCurrId = mrcId;
    getMrcHandle(parameterData);

}
//获取mrc数据
function getMrcData()
{
    var currentDfsId = window.sessionStorage.ux_dfsid;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"enumMRCList","subRequest":"","ssubRequest":""},
        data    :{
            dfsid:currentDfsId
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,mrcCallback);
    //var jsonDataObj =  [
    //    {
    //        "mrcname":"mrc-one",
    //        "ip":"192.168.1.2"
    //    }]
    //var jsonDataStr = JSON.stringify(jsonDataObj);
    //mrcCallback(jsonDataStr);
}
//mrc回调函数
function mrcCallback(retJson)
{
    var data = JSON.parse(retJson);
    if(data.rstcode=="success") {
        var dataJson = mrcGetNewJson(data.data);
        $("#mrcTable").bootstrapTable('load',dataJson);
    }else{
        clearInterval(mrcTimer);
        uxAlert("初始化MRC列表失败！");
    }

}
//获取mrc更新的数据
function mrcGetNewJson(data)
{
    var newJson = [];
    for(var i = 0;i<data.length;i++)
    {
        var info = {
            'mrc_number':0,
            "mrc_name":"",
            "mrc_ip":"",
            "mrc_port":"",
            "mrc_state":"",
            "mrc_handle":""
        };
        info.mrc_number = (i+1);
        info.mrc_name = data[i].mrcname;
        info.mrc_ip = data[i].ip;
        info.mrc_port = data[i].port;
        info.mrc_state = data[i].state;
        info.mrc_handle = data[i].maintype;
        info.mrc_id = data[i].id;
        newJson.push(info);
    }
    return newJson;
}

//初始化OSD表格
function initOsdList()
{
    var par = [{field: 'radio', radio: true,align: 'center'},
        {field:'osd_number',title:'序&nbsp;&nbsp;&nbsp;&nbsp;号',align: 'center'},
        {field:'osd_name',title:'名称',align: 'center'},
        {field:'osd_ip',title:'侦听IP',align: 'center'},
        {field:'osd_port',title:'端&nbsp;&nbsp;&nbsp;&nbsp;口',align: 'center'},
        {field:'osd_state',title:'状&nbsp;&nbsp;&nbsp;&nbsp;态',align: 'center',formatter:function(value,row,index){
            if(row.osd_state == 1) {
                var discon = '<a title="运行">' + '<button class="btn-link run-btn"></button>' + '</a>';
                return discon;
            }else{
                var constr = '<a title="停止">' + '<button class="btn-link stop-btn"></button>' + '</a>';
                return constr;
            }
        }},

        {field:'osd_state',title:'操&nbsp;&nbsp;&nbsp;&nbsp;作',align: 'center',formatter:function(value,row,index){
            var constr = '<a title="配置">' + '<button class="btn-link configurate" onclick="osdConfigurate(\''+row.osd_id+'\')"></button>' +'</a>';
            return constr;
        }}
    ];
    $('#osdTable').bootstrapTable({
        classes:"table table-no-bordered",
        toolbar:"#osdToolbar",
        columns: par,
        height:360,
        idField:"volume_number",
    });
    getOsdData();
}
//跳转至osd配置界面
function osdConfigurate(osdId)
{
    osdCurrId = osdId;
    getOsdHandle(parameterData);
}
//获取osd数据
function getOsdData()
{
    var currentDfsId = window.sessionStorage.ux_dfsid;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"enumOSDList","subRequest":"","ssubRequest":""},
        data    :{
            dfsid:currentDfsId
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,osdCallback);
}
//osd回调函数
function osdCallback(retJson)
{
    var data = JSON.parse(retJson);
    if(data.rstcode=="success") {
        var dataJson = osdGetNewJson(data.data);
        $("#osdTable").bootstrapTable('load',dataJson);
    }else{
        clearInterval(osdTimer);
        uxAlert("初始化OSD列表失败！");
    }

}
//获取osd更新的数据
function osdGetNewJson(data)
{
    var newJson = [];
    for(var i = 0;i<data.length;i++)
    {
        var newJson = [];
        for(var i = 0;i<data.length;i++)
        {
            var info = {};
            info.osd_number = (i+1);
            info.osd_name = data[i].osdname;
            info.osd_ip = data[i].ip;
            info.osd_port = data[i].port;
            info.osd_state = data[i].state;
            info.osd_handle = data[i].maintype;
            info.osd_id = data[i].id;
            newJson.push(info);
        }
        return newJson;
    }
    return newJson;
}
//返回DFS列表页面
function returnDfsList()
{
    getDfsList("#dfsBodyId");
}
