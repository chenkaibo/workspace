#!/usr/bin/env node

/**
 * Module dependencies.
 */
var server;
var debug = require('debug')('uxdbweb:server');
var https = require('https');
var fs = require("fs");
var myApi = require('./routes/common/api');
var gdbOpt = require('./routes/common/dbopt');
var webconfig = require('./uxwebconfig.json').webserver;
var checkdbTable = require('./routes/common/checkdbtable');
var uxdbConfig = require('./uxwebconfig.json').uxdb;
var options = {
  key: fs.readFileSync('./privatekey.pem'),
  cert: fs.readFileSync('./certificate.pem')
};


/**
 * Listen on provided port, on all network interfaces.
 */
function initServer()
{
  var app = require('./app');

  /**
   * Normalize a port into a number, string, or false.
   */

  function normalizePort(val) {
    var port = parseInt(val, 10);

    if (isNaN(port)) {
      // named pipe
      return val;
    }

    if (port >= 0) {
      // port number
      return port;
    }

    return false;
  }

  /**
   * Event listener for HTTP server "error" event.
   */

  function onError(error) {
    if (error.syscall !== 'listen') {
      throw error;
    }

    var bind = typeof port === 'string'
        ? 'Pipe ' + port
        : 'Port ' + port;

    // handle specific listen errors with friendly messages
    switch (error.code) {
      case 'EACCES':
        console.error(bind + ' requires elevated privileges');
        process.exit(1);
        break;
      case 'EADDRINUSE':
        console.error(bind + ' is already in use');
        process.exit(1);
        break;
      default:
        throw error;
    }
  }

  /**
   * Event listener for HTTP server "listening" event.
   */
  function onListening() {
    var addr = server.address();
    var bind = typeof addr === 'string'
        ? 'pipe ' + addr
        : 'port ' + addr.port;
    debug('Listening on ' + bind);
  }

  /**
   * Get port from environment and store in Express.
   */
  var port = normalizePort(webconfig.port || '10001');
  app.set('port', port);
  server = https.createServer(options, app);

  server.listen(port);
  server.on('error', onError);
  server.on('listening', onListening);
}
function insertWebUser(){
  var dbOpt = new gdbOpt();
  var sqlText = "select * from tbl_user where username = $1;";
  var sqlValue = ["uxdbweb"];
  dbOpt.querySql(sqlText,sqlValue,function(isErr,count,rst){
    if(isErr){
      return 1;
    }
    if(count == 1 && rst[0].usertype == 0){
      return;
    }else{
      if(count > 0){
        return 0;
      }
      sqlText = "insert into tbl_user (username,usertype,password,createtime,lastmodtime) " +
          "values('uxdbweb',0,'1b285452fe1717821085b644d86c274d',now(),now());";
      sqlValue = [];
      dbOpt.execSql(sqlText,sqlValue,function(isErr,rst){
        if(isErr){
          console.log("The web user \"uxdbweb\" insert error!");
          return 1;
        }
      })
    }
  })
}
function startHeartbeatServer(){
  var udpHeartbeatServer = require('./routes/workserver/udpheartbeatserver');
  udpHeartbeatServer.udpHeartbeatServerStart();
}
function startServer(){
  checkdbTable.checkdbTable(function(isErr){
    if(!isErr){
      initServer();
      startHeartbeatServer();
      insertWebUser();
      startDFSMonitor();
    }else{
      console.log("数据库表初始化失败！");
    }
  });
}
function checkuxdbwebdb(){
  var dbOpt = new gdbOpt();
  dbOpt.checkConnect(function(bSucc){
    if(!bSucc){
      var uxDb = new gdbOpt(undefined,undefined,"uxdb");
      uxDb.checkConnect(function(bSucc){
        if(!bSucc){
          console.log("数据库连接失败！");
          return;
        }else{
          var text = "CREATE DATABASE " + uxdbConfig.dbname + " OWNER = " + uxdbConfig.username + ";";
          var value = new Array();
          uxDb.execSql(text,value,function(error){
            if(error == null){
              startServer();
            }else if((error.code != null) && (error.code == '42P04') && (error.routine == 'createdb')) {
              startServer();
            }else{
              console.log("数据库连接失败！");
              return;
            }
          })
        }
      });
    }else{
      startServer();
    }
  })
}


function startDFSMonitor(){
  var dfsMonitorCtrl = require('./routes/common/dfsmonitorservice/controller');
  dfsMonitorCtrl.startDFSMonitor();

}

function clusterServer(){
  var cluster = require('cluster');
  var numCPUs = require('os').cpus().length;
  if (cluster.isMaster) {
    for (var i = 0; i < numCPUs; i++) {
      cluster.fork();
    }
    cluster.on('listening', function (worker, address) {
      console.log('[master] ' + 'listening: worker' + worker.id +
          ',pid:' + worker.process.pid + ', Address:' + address.address + ":" + address.port);
    });
  } else if (cluster.isWorker) {
    exports.getCluster = cluster;
    checkuxdbwebdb();
  }
}
//clusterServer();
checkuxdbwebdb();
