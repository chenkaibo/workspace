function dfsbarchart(dataOptions) {
    var defalutDataOptions = {
        'containerId': '',
        'data': '',
        'colorArr':["#9B69FB","#9EC935","#73E5FD","#FA8356","#466928","#99CC33","#00CBFF","#005CFD","#003399","#8966FD"],
        'legendWidth':'100',
        'axisName': ["负载率/%","名称"],
        'margin':{top: 40, right: 20, bottom: 30, left: 40},
        'xDomain': [1, 60],//默认的x的比例尺的自变量
        'yDomain': [1, 100]//默认的y比例尺的自变量
    }

    var initDataOption = {};//设置插件中使用的对象
    for (var initTem in defalutDataOptions) {
        initDataOption[initTem] = defalutDataOptions[initTem];
    }
    for (var tem in dataOptions) {
        initDataOption[tem] = dataOptions[tem];
    }
    var chartInfo = {
        svg_width: parseInt(d3.select("#" + initDataOption.containerId).style("width")),
        svg_height: parseInt(d3.select("#" + initDataOption.containerId).style("height")),
        xScale: "",//横坐标的比例尺
        yScale: ""//纵坐标的比例尺
    };
    DURATION = 2000;
        width = chartInfo.svg_width - initDataOption.margin.left - initDataOption.margin.right - 18;
        height = chartInfo.svg_height - initDataOption.margin.bottom;
    chartInfo.xScale = d3.scale.ordinal().domain(defalutDataOptions.xDomain).rangeRoundBands([0, width-45], .0);
    chartInfo.yScale = d3.scale.linear().domain(defalutDataOptions.yDomain).range([height,0]);

    //var formatPercent = d3.format(".0%");
    var xAxis = d3.svg.axis().scale(chartInfo.xScale).orient("bottom");
    var yAxis = d3.svg.axis().scale(chartInfo.yScale).orient("left").ticks(5);
        //.tickFormat(formatPercent);

    if(d3.select("#" + initDataOption.containerId).select("svg")[0][0] != null)
    {
        d3.select("#" + initDataOption.containerId).select("svg").remove();
    }
    if(d3.select("#" + initDataOption.containerId).select("button")[0][0] != null)
    {
        d3.select("#" + initDataOption.containerId).selectAll("button").remove();
    }
    if(initDataOption.upBtnId != '' && initDataOption.downBtnId != ''){
        d3.select("#" + initDataOption.containerId).append("button")
            .attr({
                'id':initDataOption.upBtnId,
                "class":"view-up-btn"
            });
        d3.select("#" + initDataOption.containerId).append("button")
            .attr({
                'id':initDataOption.downBtnId,
                "class":"view-down-btn first-btn"
            });
    }

    var svg = d3.select("#" + initDataOption.containerId).insert("svg","button")
        .attr("width", width + initDataOption.margin.left + initDataOption.margin.right)
        .attr("height", height + initDataOption.margin.top + initDataOption.margin.bottom)
        .append("g")
        .attr("transform", "translate(" + initDataOption.margin.left + "," + initDataOption.margin.top + ")");
    refresh(initDataOption.data);
    function refresh(data){
        chartInfo.xScale.domain((data.map(function(d) { return d.name; })));
        var max_value = d3.max(data, function(d) {
            return (d.frequency); });//获取所有value中最大的值
        if((initDataOption.hasMaxY))
        {
            chartInfo.yScale.domain([0, max_value <= 100 ? initDataOption.yDomain[1]: max_value]);//当数据中都为0，没办法给y轴设置自变量时，使用默认的值
        }else{
            chartInfo.yScale.domain([0, initDataOption.defaultY]);//当数据中都为0，没办法给y轴设置自变量时，使用默认的值
        }
        yAxis.scale(chartInfo.yScale);
    }
    var x_axis_con = svg.append("g")
        .attr("class", "bar-chart-x axis")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis)
        .append("text")
        .attr("x", 1750)
        .attr("dx", ".0em")
        .attr("y",20)
        .attr("dy",".25em")
        .style("text-anchor", "end")
        .text(initDataOption.axisName[1]);

    var y_axis_con = svg.append("g")
        .attr("class", "bar-chart-y axis")
        .call(yAxis)
        .append("text")
        .attr("transform", 'translate('+ initDataOption.legendWidth +',0)')
        .attr("x",-70)
        .attr("y", -17)
        .attr("dy", ".71em")
        .style("text-anchor", "end")
        .text(initDataOption.axisName[0]);
    var bars = svg.append('g')
        .attr('class','bar-container');
    var line = d3.svg.line()
        .interpolate("cardinal");
    var barWidth;
    var bars_rect = bars.selectAll(".bar")
        .data(initDataOption.data)
        .enter()
        .append("rect")
        .attr({
            "class": "sum-grap-bar",
            "width": function(){
                if(chartInfo.xScale.rangeBand()>30){
                    barWidth = 26;
                }
                else{
                    barWidth = chartInfo.xScale.rangeBand();
                }
                return barWidth;     //柱子的宽度
            },
            "x": function(d,i) {
                return chartInfo.xScale(d.name)+(1748/(initDataOption.data.length))/2-barWidth/2; },
            "y": function(d) {
                return chartInfo.yScale(d.frequency); },
            "height": function(d) { return height - chartInfo.yScale(d.frequency); },
            "fill":function(d,i){
                var colorStr;
                if(d.frequency >= 0.00 && d.frequency < 0.25)
                {
                    colorStr = "#33CC66";
                }
                else if(d.frequency < 0.50){
                    colorStr = "#ffff66";
                }
                else if(d.frequency < 0.75){
                    colorStr = "#FF6600";
                }
                else if(d.frequency >= 0.75){
                    colorStr = "#FF3030";
                }
                return colorStr;
            },
            'rx':13,
            'ry':13
        })
        .call(function(d){
            bars.selectAll(".bar")
                .data(initDataOption.data)
                .enter()
                .append("path")
                .attr({
                    'class':'path-opacity',
                    'd':function(d,i){
                        if(d.frequency > 0.0869){
                            var pathX = d3.select(this)[0][0].parentNode.childNodes[i].x.baseVal.value + barWidth/2;
                            var pathY = d3.select(this)[0][0].parentNode.childNodes[i].y.baseVal.value + (height - chartInfo.yScale((d.frequency)));
                            var array = [
                                [pathX + 16,pathY],
                                [pathX - 1,pathY - 18],
                                [pathX - 16,pathY]];
                            return line.tension(0.3)(array)
                        }
                    }
                })
                .style({
                    'stroke': function(d,i){
                        var colorStr;
                        if(d.frequency >= 0.00 && d.frequency < 0.25)
                        {
                            colorStr = "#33CC66";
                        }
                        else if(d.frequency < 0.50){
                            colorStr = "#ffff66";
                        }
                        else if(d.frequency < 0.75){
                            colorStr = "#FF6600";
                        }
                        else if(d.frequency >= 0.75){
                            colorStr = "#FF3030";
                        }
                        return colorStr;
                    },
                    'fill':function(d,i){
                        var colorStr;
                        if(d.frequency >= 0.00 && d.frequency < 0.25)
                        {
                            colorStr = "#33CC66";
                        }
                        else if(d.frequency <0.50){
                            colorStr = "#ffff66";
                        }
                        else if(d.frequency <0.75){
                            colorStr = "#FF6600";
                        }
                        else if(d.frequency >= 0.75){
                            colorStr = "#FF3030";
                        }
                        return colorStr;
                    }
                });
        })
    //生成tooltip框
    var bar_tooltips = d3.select("body").append("div")
        .attr("class", "tooltip")
        .style({
            'display':'block',
            "opacity":0.0
        });
    bars_rect.on('mouseover',function(d){
            bar_tooltips.html(d.name+"<br/>负载率:" +((d.frequency)*100).toFixed(0)+"%")
                .style({
                    'left':d3.event.pageX + 10 + 'px',
                    'top':d3.event.pageY + 10 + 'px',
                    'display':'block',
                    "opacity":1.0
                })
        })
        .on('mousemove',function(d){
            bar_tooltips.html(d.name+"<br/>负载率:" +((d.frequency)*100).toFixed(0)+"%")
                .style({
                    'left':d3.event.pageX + 10 + 'px',
                    'top':d3.event.pageY + 10 + 'px',
                    'display':'block',
                    "opacity":1.0
                })
        })
        .on('mouseout',function(d){
            bar_tooltips.html(d.name+"<br/>负载率:" +((d.frequency)*100).toFixed(0)+"%")
                .style({
                    'display':'none'
                })
        })
        .on('click',function(d,i){
            callback(d,i,"mouseclick");
        });
    //统计图的柱子的动画
    bars_rect.attr({
         'height':function(d,i){return 0;},
         'y':function(d){return height;}
        })
        .transition()
        .delay(function(d,i){
            return i * 50;
        })
        .duration(DURATION)
        .ease('bounce')
        .attr({
            'height':function(d){return height - chartInfo.yScale((d.frequency)*100);},
            'y':function(d,i){return chartInfo.yScale((d.frequency)*100);}
        });

    d3.selectAll(".bar-chart-y").selectAll("line")
        .transition()
        .duration(DURATION)
        .attr({x2: width-40});//网格的水平线
}