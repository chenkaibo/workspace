var express = require('express');
var router = express.Router();
var usrMgr = require('../user/dbusermgr');
var usrOnline = require('../common/onlinectrl');
var buffer = require("buffer").Buffer;
var crypto = require("crypto");
var uxproduct = require('../../uxwebconfig.json').product;
router.post('/',function(req,res,next)
{
    var reqDb = JSON.parse(req.body.postData);

    var resDb = {
        rstcode:"error",
        desc:"",
        data:{
            name:"",
            role:""
        }
    };

    var userInfo = {};
    userInfo.name = reqDb.data.name;
    userInfo.pwd = reqDb.data.pwd;

    usrMgr.getInstance().verifyUserMgr(userInfo,function(error,rows)
    {
        if(error){
            console.log("[--verify user failed]:"+error.detail);
            resDb.desc  = error.detail;
            res.send(JSON.stringify(resDb));
            return;
        }
        if(rows.length == 0){
            resDb.desc = "用户名或密码错误！";
            res.send(JSON.stringify(resDb));
            return;
        }


        var userData = {};
        var sessionID = usrOnline.getInstance().buildId();
        userData.id = creatmd5(sessionID);
        userData.name = rows[0].username;
        userData.role = rows[0].usertype;
        var opttime = Math.floor((new Date().getTime())/1000);
        userData.lastOptTime = opttime.toString();
        userData.optSite = "";
        regOnlineUser(userData,function(isErr) {
            if (isErr) {
                resDb.desc = "登录失败！";
            }
            else
            {
                resDb.rstcode = "success";
                resDb.data.name = userData.name;
                resDb.data.role = userData.role;
                resDb.data.userhandle =  userData.id;
                resDb.data.version = uxproduct.version || "0.0.0";
            }
            res.send(JSON.stringify(resDb));
        });
    });
});
module.exports = router;

function regOnlineUser(userData,callback)
{
    if(userData.name == "" || userData.role == "")
    {
        return "error";
    }
    if(typeof callback != "function")
    {
        return "error";
    }
    usrOnline.getInstance().regOnlineUser(userData,function(rst){
        callback(rst);
    });
}

function creatmd5(data)
{
    var buf = new buffer(data);
    var str = buf.toString("binary");
    return crypto.createHash("md5").update(str).digest("hex");
}