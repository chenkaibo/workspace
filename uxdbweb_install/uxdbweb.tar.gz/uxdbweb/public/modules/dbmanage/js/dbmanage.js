'use strict';
window.onload = function(){
    window.parent.menuOperFun();
    top.d3.select("#leftDivId").classed("no-display",false);
    top.d3.select("#topMenuLi4").classed("top-del-menu",false);
    initNeedData();
    //reqDatabaseHomeData();
    getDatabaseElem("#databaseBodyId");
    timeData = setInterval(reqDatabaseHomeData,30 * 1000);

};
/*
* 数据库首页界面数据请求
* */
var timeData;
var currentDataInfo = {
    "databaseInfo" : [],
    "hostInfoData" : {
        "data_arr":[],
        "host_name_map":{
            "cpu":"CPU",
            "memory":"内存",
            "disk":"磁盘"
        }
    },
    "sessionData"  : {
        "data_arr":[],
        "host_name_map":{
            "sessionCount":"会话总数",
            "inlineCount":"在线用户数"
        }
    }
};
var barData = {
    "cpu":{
        "example":{
            "name":"cpu",
            "value":0
        }
    },
    "session_act":{
        "sessionCount":{
            "name":"会话总数",
            "value":0
        },
        "inlineCount":{
            "name":"在线用户数",
            "value":0
        }
    },
    "memory":{
        "memory":{
            "name":"内存",
            "value":0
        }
    },
    "disk":{
        "disk":{
            "name":"磁盘",
            "value":0
        }
    }
};
var indexData,showInfoFlag = false;
var barChartObj = {
    'cpuRefresh':'',
    'sessionRefresh':'',
    'memoryRefresh':'',
    'distRefresh':''
};
var oldLength = 0;
function initNeedData()
{
    for(var k = 0;k < 20 ; k++)
    {
        var hostInfo = {
            "day":k,
            "cpu":0,
            'memory':0,
            "disk":0
        };
        currentDataInfo.hostInfoData.data_arr.push(hostInfo);
        var sessionInfo = {
            "day":k,
            "sessionCount":0,
            'inlineCount':0
        };
        currentDataInfo.sessionData.data_arr.push(sessionInfo);
    }
}
function reqDatabaseHomeData()
{
    /*
    * 请求的命令
    * */
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbmanage",
        request :{"mainRequest":"getDbHomePageInfo","subRequest":"","ssubRequest":""},
        data    :{
            webusername: window.sessionStorage.ux_curUserName,
            instanceid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,reqDatabaseHomeDataCallback);
}
function reqDatabaseHomeDataCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        currentDataInfo.databaseInfo[0] = retJsonStr.data.dbInfo.dbname;
        currentDataInfo.databaseInfo[1] = retJsonStr.data.dbInfo.instname;
        currentDataInfo.databaseInfo[2] = retJsonStr.data.dbInfo.path;
        currentDataInfo.databaseInfo[3] = retJsonStr.data.dbInfo.platform;
        currentDataInfo.databaseInfo[4] = getDateFun(retJsonStr.data.dbInfo.runtime);
        currentDataInfo.databaseInfo[5] = (retJsonStr.data.dbInfo.type == 1) ? ("云实例"):("本地实例");
        currentDataInfo.databaseInfo[6] = retJsonStr.data.dbInfo.version;
        for(var k = 0;k <retJsonStr.data.hostInfo.cpuUsage.length; k++)
        {
            currentDataInfo.hostInfoData.data_arr[k].cpu = retJsonStr.data.hostInfo.cpuUsage[k];
            currentDataInfo.hostInfoData.data_arr[k].disk = retJsonStr.data.hostInfo.diskUsage[k];
            currentDataInfo.hostInfoData.data_arr[k].memory = retJsonStr.data.hostInfo.memeryUsage[k];
            currentDataInfo.sessionData.data_arr[k].inlineCount = retJsonStr.data.sessionInfo.loginNum[k];
            currentDataInfo.sessionData.data_arr[k].sessionCount = retJsonStr.data.sessionInfo.sessionNum[k];
            indexData = k;
        }
        initBarData();
        getDbManageInfo(".db-status-list");
        if(oldLength != retJsonStr.data.hostInfo.cpuUsage.length)
        {
            if(showInfoFlag)
            {
                drawSessionCountLineChart();
            }else{
                drawHostInfoLineChart();
            }
        }
        oldLength = retJsonStr.data.hostInfo.cpuUsage.length;
    }else{
        clearInterval(timeData);
        if(retJsonStr.desc == "connect_out")
        {
            uxAlert("数据库已断开，请重新连接！",true);
        }else{
            uxAlert("数据库首页获取失败！");
        }
    }
}
/**初始化条形图的数据**/
function initBarData()
{
    var temp = currentDataInfo.hostInfoData.data_arr;
    var tempSession = currentDataInfo.sessionData.data_arr;
    barData.cpu.example.value = temp[indexData].cpu;
    barData.session_act.sessionCount.value = tempSession[indexData].sessionCount;
    barData.session_act.inlineCount.value = tempSession[indexData].inlineCount;
    barData.memory.memory.value = temp[indexData].memory;
    barData.disk.disk.value = temp[indexData].disk;
}
/**返回连接时间**/
function getDateFun(date)
{
    var hourData = parseInt(date/(1000 * 60 * 60));
    hourData = (hourData < 10) ? ("0" + hourData):(hourData);
    var minData = parseInt(date/(1000 * 60));
    minData = (minData < 10) ? ("0" + minData):(minData);
    return (hourData +　"小时" + minData + "分钟");
}
/*
* 数据库界面获取元素
* 当前查看数据库名
* */
function getDatabaseElem(contain) {
    showInfoFlag = false;
    window.sessionStorage.ux_pagePath = "dbManage,main";
    changePath("首页:"+window.sessionStorage.ux_currentChoiceDataName+"");
    d3.select("#mainContainDiv").remove();
    var dbManageDiv = d3.select(contain)
        .append("div")
        .attr({
            'id':'mainContainDiv',
            'class':'db-manage-div'
        });
        var dbStatusDiv = dbManageDiv.append('div').attr('class','db-status');
        var hostPerformance = dbManageDiv.append("div").attr({
            'class':'host-performance'

        });
        var hostResource = dbManageDiv.append('div')
            .attr({
                'class':'host-resource'
            });

        /**数据库状态模块**/
        dbStatusDiv.append('div')
            .attr({
                'class':'db-status-head db-manage-head'
            })
            .text("数据库状态");
        var dbStatusList = dbStatusDiv.append('div')
            .attr({
                'class':'db-status-list'
            });
        getDbManageInfo(".db-status-list");
        /**数据库状态模块**/

        /**主机资源模块**/
        hostResource.append('div')
            .attr({
                'class':'db-resource-head db-manage-head'
            })
            .text("主机资源");
        var hostResourceId = ['','cpu-div','session-div','memory-div','disk-div'];
        hostResource
            .selectAll('div')
            .data(hostResourceId)
            .enter()
            .append('div')
            .attr({
                'class':'host-list-div',
                'id':function(d,i){
                    return d;
                }
            });

        /**主机资源模块**/

        /**主机性能**/
        hostPerformance.append('div')
            .attr({
                'class':'db-per-head db-manage-head'
            })
            .text('主机性能');
        hostPerformance.append('div')
            .attr({
                'class':'line-chart-div',
                'id':'lineChartCon'
            });

        d3.select("#lineChartCon")
            .append("div")
            .attr({
                'id':'dbOpterBtn',
                'class':"linechart-btn"
            })
            .append("button")
            .attr({
                "id":'actionClass',
                "class":'onfocuse-blue first-btn'
            })
            .on("click",function(){
                d3.select(this).classed("onfocuse-white",true);
                d3.select(this).classed("onfocuse-blue",false);
                d3.select("#service").classed("onfocuse-blue",true);
                d3.select("#service").classed("onfocuse-white",false);
                showInfoFlag = true;
                initBarData();
                refreshBarChart("","","");
                drawSessionCountLineChart();
            })
            .html("活动类");
        d3.select("#dbOpterBtn")
            .append("button")
            .attr({
                "id":'service',
                "class":'onfocuse-white'
            })
            .on("click",function(){
                d3.select(this).classed("onfocuse-white",true);
                d3.select(this).classed("onfocuse-blue",false);
                d3.select("#actionClass").classed("onfocuse-blue",true);
                d3.select("#actionClass").classed("onfocuse-white",false);
                showInfoFlag = false;
                initBarData();
                refreshHostinfoBarChart("","","");
                drawHostInfoLineChart();
            })
            .html("服&nbsp;&nbsp;&nbsp;务");
        reqDatabaseHomeData();
        drawBarChart(barData,barChartObj);
    var leftBtnStatus = top.d3.select("#left-btn-control");
    if(leftBtnStatus.classed("left-btn-bg"))
    {
        d3.select("#mainContainDiv").classed("db-manage-div",true);
        d3.select("#mainContainDiv").classed("db-main-contain",false);
        d3.select("#dbOpterBtn").classed("linechart-btn",true);
        d3.select("#dbOpterBtn").classed("db-oper-btn-hide",false);
    }else{
        d3.select("#mainContainDiv").classed("db-manage-div",false);
        d3.select("#mainContainDiv").classed("db-main-contain",true);
        d3.select("#dbOpterBtn").classed("linechart-btn",false);
        d3.select("#dbOpterBtn").classed("db-oper-btn-hide",true);
    }
}
/**折线图处理**/
function drawHostInfoLineChart (){

    lineChartFun({
        'containerId':'lineChartCon',
        'data':currentDataInfo.hostInfoData,
        'colorArr':["#9B69FB","#9EC935","#73E5FD","#FA8356","#466928","#99CC33","#00CBFF","#005CFD","#003399","#8966FD"],
        'margin':{top: 30, right: 20, bottom: 30, left: 60},
        'legendWidth':'100',
        'axisName' : ["利用率/%","时间"],
        'legendPosition':true,//右侧图示
        'leftPosition':'700',
        'topPosition':'-90',
        'titleHeight':'20',
        'hasArea':true,
        'hasPoint':true,
        'hasMaxY':false,
        'defaultY':100,
        'hasTitleIcon':true,
        'unit':"%",
        'order':"",
        'topTipX':20,
        'hasOddNum':true,
        'xDomain':[0,20],//默认的x的比例尺的自变量
        'yDomain':[1,100]//默认的y比例尺的自变量
    },refreshHostinfoBarChart);
}
function drawSessionCountLineChart (){
    lineChartFun({
        'containerId':'lineChartCon',
        'data':currentDataInfo.sessionData,
        'colorArr':["#9B69FB","#9EC935","#73E5FD","#FA8356","#466928","#99CC33","#00CBFF","#005CFD","#003399","#8966FD"],
        'margin':{top: 30, right: 20, bottom: 30, left: 60},
        'legendWidth':'100',
        'axisName' : ["个数","时间"],
        'legendPosition':true,//右侧图示
        'leftPosition':'700',
        'topPosition':'-90',
        'titleHeight':'20',
        'hasArea':true,
        'hasPoint':true,
        'hasMaxY':false,
        'unit':"%",
        'order':"",
        'defaultY':100,
        'hasOddNum':true,
        'hasTitleIcon':true,
        'topTipX':20,
        'xDomain':[0,20],//默认的x的比例尺的自变量
        'yDomain':[1,100]//默认的y比例尺的自变量
    },refreshBarChart);
}
/**条形图处理**/
function drawBarChart (data,barChartObj){
    var cpu = data.cpu;
    var session_act = data.session_act;
    var memory = data.memory;
    var disk = data.disk;
    var color_arr = ["#9B69FB","#9EC935","#73E5FD","#FA8356","#466928","#99CC33","#00CBFF","#005CFD","#003399","#8966FD"];

    barChartObj.cpuRefresh = barChart({
        'containerId':'cpu-div',
        'data':cpu,
        'colorArr':color_arr,
        'margin':{top: 30, right: 50, bottom: 30, left: 0},
        'legendWidth':'100',
        'unit':"%",
        'axisName' : ["%",""],
        'titleContent':'CPU',
        'titleHeight':'40'
    });
    barChartObj.sessionRefresh = barChart({
        'containerId':'session-div',
        'data':session_act,
        'colorArr':color_arr,
        'margin':{top: 30, right: 50, bottom: 30, left: 0},
        'legendWidth':'100',
        'unit':"个",
        'axisName' : ["个",""],
        'titleContent':'会话活动',
        'titleHeight':'40'
    });
    barChartObj.memoryRefresh = barChart({
        'containerId':'memory-div',
        'data':memory,
        'colorArr':color_arr,
        'margin':{top: 30, right: 50, bottom: 30, left: 0},
        'legendWidth':100,
        'unit':"%",
        'axisName' : ["%",""],
        'titleContent':'内存',
        'titleHeight':40
    });
    barChartObj.distRefresh = barChart({
        'containerId':'disk-div',
        'data':disk,
        'colorArr':color_arr,
        'margin':{top: 30, right: 50, bottom: 30, left: 0},
        'legendWidth':100,
        'unit':"%",
        'axisName' : ["%",""],
        'titleContent':'磁盘',
        'titleHeight':40
    });
}
/**刷新条形图**/
function refreshHostinfoBarChart(data,index,opterStr){
    if(opterStr == "mouseclick")
    {
        barData.cpu.example.value = data.cpu;
        barData.session_act.sessionCount.value = currentDataInfo.sessionData.data_arr[index].sessionCount;
        barData.session_act.inlineCount.value = currentDataInfo.sessionData.data_arr[index].inlineCount;
        barData.memory.memory.value = data.memory;
        barData.disk.disk.value = data.disk;
    }
    var cpu = barData.cpu;
    var session_act = barData.session_act;
    var memory = barData.memory;
    var disk = barData.disk;
    //if(cpu.example.value == 0 || disk.disk.value == 0 || memory.memory.value == 0 || session_act.inlineCount.value == 0 || session_act.sessionCount.value == 0)
    //{
    //    var cpuStr = (cpu.example.value == 0 ) ? ("cpu当前使用率为0"):("");
    //    var memStr = (disk.disk.value == 0 ) ? ("内存当前使用率为0"):("");
    //    var diskStr = (memory.memory.value == 0 ) ? ("磁盘当前使用率为0"):("");
    //    var inlineStr = (session_act.inlineCount.value == 0 ) ? ("当前登录用户数为0"):("");
    //    var sessionStr = (session_act.sessionCount.value == 0 ) ? ("当前会话数为0"):("");
    //    var str = "故，不刷新为当前为“0”的条形图！";
    //    uxAlert(cpuStr +"<br>" + memStr+"<br>" + diskStr+"<br>" + sessionStr+"<br>" + inlineStr+"<br><br>" + str);
    //}
    //if(cpu.example.value != 0)
    //{
        barChartObj.cpuRefresh(cpu);
    //}
    //if(disk.disk.value != 0)
    //{
        barChartObj.distRefresh(disk);
    //}
    //if(memory.memory.value != 0)
    //{
        barChartObj.memoryRefresh(memory);
    //}
    //if(session_act.sessionCount.value != 0 || session_act.inlineCount.value != 0 )
    //{
        barChartObj.sessionRefresh(session_act);
    //}
}
function refreshBarChart(data,index,opterStr){
    if(opterStr == "mouseclick")
    {
        barData.cpu.example.value = currentDataInfo.hostInfoData.data_arr[index].cpu;
        barData.session_act.sessionCount.value = data.sessionCount;
        barData.session_act.inlineCount.value = data.inlineCount;
        barData.memory.memory.value = currentDataInfo.hostInfoData.data_arr[index].memory;
        barData.disk.disk.value = currentDataInfo.hostInfoData.data_arr[index].disk;
    }
    var cpu = barData.cpu;
    var session_act = barData.session_act;
    var memory = barData.memory;
    var disk = barData.disk;
    //if(cpu.example.value == 0 || disk.disk.value == 0 || memory.memory.value == 0 || session_act.inlineCount.value == 0 || session_act.sessionCount.value == 0)
    //{
    //    var cpuStr = (cpu.example.value == 0 ) ? ("cpu当前使用率为 : 0"):("");
    //    var memStr = (disk.disk.value == 0 ) ? ("内存当前使用率为 : 0"):("");
    //    var diskStr = (memory.memory.value == 0 ) ? ("磁盘当前使用率为 : 0"):("");
    //    var inlineStr = (session_act.inlineCount.value == 0 ) ? ("当前登录用户数为 : 0"):("");
    //    var sessionStr = (session_act.sessionCount.value == 0 ) ? ("当前会话数为 : 0"):("");
    //    var str = "故，不刷新为当前为“0”的条形图！";
    //    uxAlert(cpuStr +"<br>" + memStr+"<br>" + diskStr+"<br>" + sessionStr+"<br>" + inlineStr+"<br><br>" + str);
    //}
    //if(cpu.example.value != 0)
    //{
        barChartObj.cpuRefresh(cpu);
    //}
    //if(disk.disk.value != 0)
    //{
       barChartObj.distRefresh(disk);
    //}
    //if(memory.memory.value != 0)
    //{
        barChartObj.memoryRefresh(memory);
    //}
    //if(session_act.sessionCount.value != 0 || session_act.inlineCount.value != 0 )
    //{
        barChartObj.sessionRefresh(session_act);
    //}
}
/*基础信息元素*/
function getDbManageInfo(contain)
{
    d3.select(contain).select("table").remove();
    var dbStatusInfo = ['数据库名称：','实例名：','主目录：','平台名：','连接时间：','类型：','数据库版本：'];
    var dbStatusValue = currentDataInfo.databaseInfo;
    var dbStatusTable = d3.select(contain).append('table')
        .attr({
            'class':'db-status-table'
        });
    dbStatusInfo.forEach(function(value,index){
        var dbStatusTr = dbStatusTable.append('tr');
        dbStatusTr.append('td')
            .attr({
                'class':'db-status-info'
            })
            .text(dbStatusInfo[index]);
        dbStatusTr.append('td')
            .attr({
                'class':'db-status-value'
            })
            .text(dbStatusValue[index])
    });
}

