CREATE TABLE tbl_dfs_mrc
(
  id serial NOT NULL,
  dfsid varchar(64) NOT NULL,
  name varchar(32) NOT NULL,
  address varchar(32) NOT NULL ,
  load varchar(16) NOT NULL,
  totalram varchar(32),
  usedram varchar(32),
  ramusage varchar(2048),
  connectnum varchar(2048),
  volumes varchar,
  status     integer,
  CONSTRAINT tbl_dfs_mrc_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tbl_dfs_mrc
  OWNER TO uxdbwebuser;
COMMENT ON COLUMN tbl_dfs_mrc.dfsid IS 'DIR所属DFS的ID';
COMMENT ON COLUMN tbl_dfs_mrc.name IS '名称';
COMMENT ON COLUMN tbl_dfs_mrc.address IS '访问地址';
COMMENT ON COLUMN tbl_dfs_mrc.load IS '负载率';
COMMENT ON COLUMN tbl_dfs_mrc.totalram IS '总内存';
COMMENT ON COLUMN tbl_dfs_mrc.usedram IS '已使用内存';
COMMENT ON COLUMN tbl_dfs_mrc.ramusage IS '内存使用率';
COMMENT ON COLUMN tbl_dfs_mrc.connectnum IS '客户端连接数';
COMMENT ON COLUMN tbl_dfs_mrc.volumes IS '存储卷';
COMMENT ON COLUMN tbl_dfs_dir.status IS '模块状态，0-离线，1-在线';

