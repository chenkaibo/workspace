CREATE TABLE tbl_siteinfo
(
  id varchar(64) NOT NULL,
  sitename varchar(64),
  ip varchar(32),
  port varchar(10),
  type char,
  clsnum varchar(10),
  clsinfo varchar(32),
  dfsnum varchar(10),
  dfsinfo varchar(32),
  firsttm varchar(32),
  state char,
  latesttm varchar(32),
  CONSTRAINT tbl_siteinfo_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tbl_siteinfo OWNER TO uxdbwebuser;
COMMENT ON COLUMN tbl_siteinfo.id IS '站点ID,IP和类型生成唯一标识';
COMMENT ON COLUMN tbl_siteinfo.sitename IS '站点名称';
COMMENT ON COLUMN tbl_siteinfo.ip IS '站点IP';
COMMENT ON COLUMN tbl_siteinfo.port IS '端口';
COMMENT ON COLUMN tbl_siteinfo.type IS '类型';
COMMENT ON COLUMN tbl_siteinfo.clsnum IS '集群数量';
COMMENT ON COLUMN tbl_siteinfo.clsinfo IS '集群信息 MD5码';
COMMENT ON COLUMN tbl_siteinfo.dfsnum IS 'DFS模块数量';
COMMENT ON COLUMN tbl_siteinfo.dfsinfo IS 'DFS模块信息';
COMMENT ON COLUMN tbl_siteinfo.firsttm IS '首次发现时间';
COMMENT ON COLUMN tbl_siteinfo.state IS '状态，启动[1],故障[2]';
COMMENT ON COLUMN tbl_siteinfo.latesttm IS '最近一次心跳时间';