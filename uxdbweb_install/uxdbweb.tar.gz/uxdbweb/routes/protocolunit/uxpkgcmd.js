﻿var gUXPackProtocol = {
	/**
	 * @brief 主命令
	 * @enum e_comm_pkg_main_cmd
	 */
	e_main_cmd_login_remote_host    : 0,    /**< 登录远程主机*/

	/**
	 * @brief 子命令
	 * @enum e_comm_pkg_sub_cmd
	 */
	e_sub_cmd_none                  : 0,        /**< 无效子命令*/

/**
	 * @brief 子子命令
	 * @enum e_comm_pkg_sub_cmd
	 */
    e_ssub_cmd_none                         : 0,    /**< 无效子子命令*/
};

module.exports = gUXPackProtocol;
