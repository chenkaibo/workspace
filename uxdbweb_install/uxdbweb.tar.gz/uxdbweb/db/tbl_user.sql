CREATE TABLE tbl_user
(
  id serial NOT NULL,
  username varchar(64) NOT NULL UNIQUE,
  usertype char NOT NULL,
  password varchar(64) NOT NULL,
  createtime varchar(32),
  lastmodtime varchar(32),
  CONSTRAINT tbl_user_pkey PRIMARY KEY (username)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tbl_user
  OWNER TO uxdbwebuser;
COMMENT ON COLUMN tbl_user.username IS '用户名称';
COMMENT ON COLUMN tbl_user.usertype IS '用户类型
0：管理员
1：普通用户';
COMMENT ON COLUMN tbl_user.password IS '用户密码';
COMMENT ON COLUMN tbl_user.createtime IS '首次记录时间';
COMMENT ON COLUMN tbl_user.lastmodtime IS '最后一次修改时间';

