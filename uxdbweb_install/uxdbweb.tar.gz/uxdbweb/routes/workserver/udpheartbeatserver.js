/**
 * Created by zhigao.yang on 2017/1/12 0012.
 */
var config = require('./../../uxwebconfig').server;
var dgram = require('dgram');
var serverSocket = dgram.createSocket('udp4');
var protocolMgr = require('../protocolunit/protocolmgr');
var api = require('../common/api');
var dbMgr = require('./heartbeatpackmgr');
var sysDbMgr = dbMgr.sysDbMgr;
var instanceDbMgr = dbMgr.instanceDbMgr;
var dfsDbMgr = dbMgr.dfsDbMgr;
var myDbMgr = require('../dowork/dbmanage/dbmanagemgr').dbMgr;

exports.udpHeartbeatServerStart = udpHeartbeatServerStart;

function udpHeartbeatServerStart() {
    startInterval();

    serverSocket.bind(config.udpPort);
    serverSocket.on('error', function (err) {
        console.log('error, msg - %s, stack - %s\n', err.message, err.stack);
    });

    serverSocket.on('message', function (msg, rinfo) {
        console.log('\nheartbeat info: %s(%d bytes) from client %s:%d\n', msg, msg.length, rinfo.address, rinfo.port);
        //echo to client
        var data = JSON.parse(msg);
        var tcp_port = data.tcp_port;
        var host_type = data.host_type;
        var clusters_num = data.clusters_num;
        var cluserts_md5 = data.clusters_md5;
        var dfs_modules_num = data.dfs_modules_num;
        var dfs_modules_md5 = data.dfs_modules_md5;
        var state_flag = data.stateflag;

        //console.log('recv heartbeat info prot = %s, host_typr = %s, clusters_num = %s, cluserts_md5 = %s, dfs_modules_num = %s, dfs_modules_md5 = %s',
       //    tcp_port, host_type, clusters_num, cluserts_md5, dfs_modules_num, dfs_modules_md5);

        var siteInfoJson = {
            'id': '',
            'sitename': 'uxdb_site',
            'ip': rinfo.address,
            'port': data.tcp_port,
            'type': data.host_type,
            'clsnum': data.clusters_num,
            'clsinfo': data.clusters_md5,
            'dfsnum': data.dfs_modules_num,
            'dfsinfo': data.dfs_modules_md5,
            'firsttm': 0,
            'state': 1,
            'latesttm': 0
        }

        var ipInfo = rinfo.address + ":" + data.tcp_port;
        var md5 = api.createmd5(ipInfo);
        siteInfoJson.id = md5;


        sysDbMgr.getInstance().queryHeartbeatInfo(md5, function (error, count, rst) {
            if (error) {
                console.log("query siteinfo table error!");
            }
            var d = new Date();
            var time = d.getTime();

            if (0 == count) {
                siteInfoJson.firsttm = time;
                siteInfoJson.latesttm = time;
                //siteInfoJson.clsnum = 0;
                //siteInfoJson.dfsnum = 0;
                console.log("\n insert site data:" + JSON.stringify(siteInfoJson) + "\n");
                sysDbMgr.getInstance().insertHeartbeatInfo(siteInfoJson, function (error) {
                    if (error) {
                        console.log("insert site " + siteInfoJson.ip + " info error!\n");
                        return;
                    } else {
                        console.log("insert site " + siteInfoJson.ip + " info success!\n");
                    }
                    getInstanceAndDFSInfo();
                });
            } else if (1 == count) {
                getInstanceAndDFSInfo();
                siteInfoJson.latesttm = time;
                sysDbMgr.getInstance().updateHeartbeatInfo(siteInfoJson, function (error) {
                    if (error) {
                        console.log("update siteinfo error!\n");
                    }
                });
            } else {
                console.log("ID is not unique!\n");
            }
            function getInstanceAndDFSInfo() {

                var instChangeFlag = false;
                var dfsChangeFlag = false;

                if (count == 0 || rst[0].clsnum != siteInfoJson.clsnum || rst[0].clsinfo != siteInfoJson.clsinfo || state_flag == 1 || state_flag == 3 || state_flag == 16) {
                    instChangeFlag = true;
                }

                if (count == 0 || rst[0].dfsnum != siteInfoJson.dfsnum || rst[0].dfsinfo != siteInfoJson.dfsinfo || state_flag == 2 || state_flag == state_flag == 3 || state_flag == 16) {
                    dfsChangeFlag = true;
                }

                if (instChangeFlag) {
                    getInstanceList(rinfo.address, data.tcp_port, siteInfoJson.id, function () {
                        if (dfsChangeFlag) {
                            getDFSListInfo(rinfo.address, data.tcp_port, siteInfoJson.id, function () {
                            });
                        }
                    })
                } else {
                    if (dfsChangeFlag) {
                        getDFSListInfo(rinfo.address, data.tcp_port, siteInfoJson.id, function () {
                        });
                    }
                }
            }
        });
    });

    serverSocket.on('listening', function () {
        console.log("echo server is listening on port %d.", config.udpPort);
    })
}
function getInstanceList(hostip, hostport, siteid, callback) {
    var reqJson = {
        'hostip': hostip,
        'hostport': hostport,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 1,
        'dbnum': 1,
        'data': []
    }
    console.log("发送获取实例列表的请求！");
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        callback();
        if (isErr || (resJson.maincmd == 0 && resJson.subcmd == 0)) {
            console.log("get instance info faild!");
            return;
        }

        var instIdArr = [];
        if (!("dbclusters" in resJson.data)) {
            console.log("There is no dbclusters field in resJson.data at agent:%s", hostip);
            //deleteNotExistInst(instIdArr, siteid);
            return;
        }

        var clusters = resJson.data.dbclusters;
        var clsNum = clusters.length;

        if (clsNum > 0) {
            dealInstance();
        } else {
            console.log("There is no clusters in agent:%s", hostip);
            //deleteNotExistInst(instIdArr, siteid);
        }
        function dealInstance() {
            clsNum--;
            if (clsNum < 0) {
                //deleteNotExistInst(instIdArr, siteid);
                return;
            }
            var instanceInfo = hostip + clusters[clsNum].dfsurl + clusters[clsNum].dfsdb +
                clusters[clsNum].cluster_name + clusters[clsNum].type + clusters[clsNum].cluster_path;
            var instanceMd5 = api.createmd5(instanceInfo);
            instIdArr.push(instanceMd5);
            var instanceJson = {
                'id': instanceMd5,
                'clsname': clusters[clsNum].cluster_name,
                'clspath': clusters[clsNum].cluster_path,
                'type': clusters[clsNum].type,
                'port': clusters[clsNum].port,
                'state': clusters[clsNum].state,
                'siteid': siteid,
                'dfsid': '',
                'voluname': clusters[clsNum].dfsdb,
                'version': clusters[clsNum].version,
                'inittm': api.formatDate(new Date(parseInt(clusters[clsNum].init_time) * 1000)),
                'updatetm': (new Date().getTime()),
                'dfsurl': clusters[clsNum].dfsurl,
                'dfsdb': clusters[clsNum].dfsdb
            }


            instanceDbMgr.getInstance().queryInstanceRecord(instanceMd5, function (error, count, rst) {
                if (error) {
                    console.log("query instance info error!");
                    return 1;
                }

                if (0 == count) {
                    console.log("\n insert instance data:" + JSON.stringify(instanceJson) + "\n");
                    instanceDbMgr.getInstance().insertInstanceRecord(instanceJson, function (error) {
                        if (error) {
                            console.log("insert instance info failed!\n");
                            console.log(JSON.stringify(error));
                        }
                        dealInstance();
                    });
                } else if (1 == count) {
                    if (instanceJson.dfsurl == rst[0].dfsurl) {
                        instanceJson.dfsid = rst[0].dfsid;
                    }
                    instanceDbMgr.getInstance().updateInstanceRecord(instanceJson, function (error) {
                        if (error) {
                            console.log("update instance info failed!\n");
                        }
                        dealInstance();
                    });
                } else {
                    console.log("instance info error!\n");
                    dealInstance();
                }
            });
        }

        function deleteNotExistInst(idArr, siteid) {
            var sqlData = {
                sqlText: "",
                sqlValue: []
            }
            if (idArr.length == 0) {
                sqlData.sqlText = "delete from tbl_instance where siteid = $1;";
                sqlData.sqlValue = [siteid];
                sysDbMgr.getInstance().updateDbTableMgr(sqlData, function (isErr) {
                    if (isErr) {
                        console.log("delete instance faild!");
                    }
                });
            } else {
                sqlData.sqlText = "select id from tbl_instance where siteid = $1;";
                sqlData.sqlValue = [siteid];
                sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
                    if (isErr || rst.length == 0) {
                        return;
                    }
                    var notExistInstIdArr = [];
                    for (var i = 0; i < rst.length; i++) {
                        if (idArr.indexOf(rst[i].id) == -1) {
                            notExistInstIdArr.push(rst[i].id);
                        }
                    }
                    if (notExistInstIdArr.length == 0) {
                        return;
                    }
                    sqlData.sqlText = "delete from tbl_instance where id in('" + notExistInstIdArr.join("','") + "');";
                    sqlData.sqlValue = [];
                    sysDbMgr.getInstance().updateDbTableMgr(sqlData, function (isErr) {
                        if (isErr) {
                            console.log("delete instance faild!");
                        }
                    })
                })
            }
        }
    });
}
function getDFSListInfo(hostip, hostport, siteid, callback) {
    var reqJson = {
        'hostip': hostip,
        'hostport': hostport,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 3,
        'dbnum': 1,
        'data': []
    }

    function getDfsCallback(isErr, resJson) {
        callback();
        if (isErr || (resJson.maincmd == 0 && resJson.subcmd == 0)) {
            console.log("get DFS info faild!");
            return;
        }

        var allDfsModulesNum = 3;//dri,mrc,osd
        var updatedDfsModNum = 0;//已更新完成的dfs模块个数

        if (typeof resJson.data.dir_modules != "undefined") {
            updateDirInfo(resJson.data.dir_modules, siteid, hostip, function () {
                console.log("update dir info finished!");
                updatedDfsModNum++;
                updateDfsStateAfterUpdatedDfsModules();
            });
        }
        if (typeof resJson.data.mrc_modules != "undefined") {
            updateMrcInfo(resJson.data.mrc_modules, siteid, resJson.data.dfs_path, resJson.data.dfs_name, hostip, function () {
                console.log("update mrc info finished!");
                updatedDfsModNum++;
                updateDfsStateAfterUpdatedDfsModules();
            });
        }
        if (typeof resJson.data.osd_modules != "undefined") {
            updateOsdInfo(resJson.data.osd_modules, siteid, hostip, function () {
                console.log("update osd info finished!");
                updatedDfsModNum++;
                updateDfsStateAfterUpdatedDfsModules();
            });
        }
        function updateDfsStateAfterUpdatedDfsModules() {
            console.log("\nupdatedDfsModNum:" + updatedDfsModNum + ",allDfsModulesNum:" + allDfsModulesNum);
            if (updatedDfsModNum < allDfsModulesNum) {
                return;
            }
            timingUpdateDfsInfo();
        }
    }

    console.log("发送获取DFS列表的请求！");
    protocolMgr.execProtocol(reqJson, getDfsCallback);
}


function updateDirInfo(dataInfo, siteid, siteip, callback) {
    var currentTm = new Date().getTime();
    var dirLen = dataInfo.length;

    execDirRecord();

    function execDirRecord() {
        console.log("==============dirLen:" + dirLen);
        dirLen--;
        if (dirLen < 0) {
            callback();
            return;
        }
        var ipInfo = siteip + dataInfo[dirLen].ip + ":" + dataInfo[dirLen].listen_port;
        var dirMd5 = api.createmd5(ipInfo);
        var dirJson = {
            'id': dirMd5,
            'dfsid': '',
            'siteid': siteid,
            'dirname': dataInfo[dirLen].uuid,
            'ip': dataInfo[dirLen].ip,
            'port': dataInfo[dirLen].listen_port,
            'httpport': dataInfo[dirLen].http_port,
            'state': dataInfo[dirLen].module_status,
            'dirid': '',
            'maintype': 0,
            'cfgpath': dataInfo[dirLen].config_file,
            'inittm': currentTm,
            'latesttm': currentTm
        }

        if (dataInfo[dirLen].ip == "localhost") {

            var sqlData = {
                sqlText: "select dfsid from tbl_mrclist where ((dirip1 = $1 and dirport1 = $2) or " +
                "(dirip2 = $1 and dirport2 = $2) or " +
                "(dirip3 = $1 and dirport3 = $2) or " +
                "(dirip4 = $1 and dirport4 = $2) or " +
                "(dirip5 = $1 and dirport5 = $2) or " +
                "(dirip6 = $1 and dirport6 = $2)) and siteid = $3 limit 1;",
                sqlValue: [dirJson.ip, dirJson.port, siteid]
            };
            sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
                if (isErr) {
                    console.log("query dfsid from tbl_mrc faild!");
                    return;
                }
                if (rst.length > 0) {
                    dirJson.dfsid = rst[0].dfsid;
                }
                execUpdateDirInfo();
            });
        }
        else//ip address
        {
            //find dfsid from tbl_mrc by dir_ip and dir_port,then set dir.dfsid = mrc.dfsid

            var sqlData = {
                sqlText: "select dfsid from tbl_mrclist where (dirip1 = $1 and dirport1 = $2) or " +
                "(dirip2 = $1 and dirport2 = $2) or " +
                "(dirip3 = $1 and dirport3 = $2) or " +
                "(dirip4 = $1 and dirport4 = $2) or " +
                "(dirip5 = $1 and dirport5 = $2) or " +
                "(dirip6 = $1 and dirport6 = $2) limit 1;",
                sqlValue: [dirJson.ip, dirJson.port]
            };
            sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
                if (isErr) {
                    console.log("query dfsid from tbl_mrc faild!");
                    return;
                }
                if (rst.length > 0) {
                    dirJson.dfsid = rst[0].dfsid;
                }
                execUpdateDirInfo();
            });
        }

        function execUpdateDirInfo() {
            dfsDbMgr.getInstance().queryRecord('tbl_dirlist', "id", dirMd5, function (error, count, rst) {
                if (error) {
                    console.log("query dir info error!");
                    return 1;
                }

                if (0 == count) {
                    console.log("\n insert dir data:" + JSON.stringify(dirJson) + "\n");
                    dfsDbMgr.getInstance().insertDirRecord(dirJson, function (error) {
                        if (error) {
                            console.log("insert dir info error!\n");
                        }
                        execDirRecord();
                    });
                } else {
                    console.log("\n update dir data:" + JSON.stringify(dirJson) + "\n");
                    dfsDbMgr.getInstance().updateDirRecord(dirJson, function (error) {
                        if (error) {
                            console.log("update dir info error!\n");
                        }
                        execDirRecord();
                    });
                }
            });
        }
    }
}

function updateMrcInfo(dataInfo, id, dfspath, dfsname, siteip, callback) {
    var currentTm = new Date().getTime();
    var mrcLen = dataInfo.length;

    execMrcRecord();

    function execMrcRecord() {
        mrcLen--;
        if (mrcLen < 0) {
            callback();
            return;
        }
        var ipInfo = siteip + dataInfo[mrcLen].ip + ":" + dataInfo[mrcLen].listen_port;
        var mrcMd5 = api.createmd5(ipInfo);
        var mrcJson = {
            'id': mrcMd5,
            'dfsid': '',
            'siteid': id,
            'mrcname': dataInfo[mrcLen].uuid,
            'ip': dataInfo[mrcLen].ip,
            'port': dataInfo[mrcLen].listen_port,
            'httpport': dataInfo[mrcLen].http_port,
            'state': dataInfo[mrcLen].module_status,
            'dirip1': "",
            'dirport1': "",
            'dirip2': "",
            'dirport2': "",
            'dirip3': "",
            'dirport3': "",
            'dirip4': "",
            'dirport4': "",
            'dirip5': "",
            'dirport5': "",
            'dirip6': "",
            'dirport6': "",
            'maintype': 0,
            'cfgpath': dataInfo[mrcLen].config_file,
            'inittm': currentTm,
            'latesttm': currentTm
        }
        for (var i = 0; i < dataInfo[mrcLen].ref_dirs.length; i++) {
            mrcJson["dirip" + (i + 1)] = dataInfo[mrcLen].ref_dirs[i].ip;
            mrcJson["dirport" + (i + 1)] = dataInfo[mrcLen].ref_dirs[i].port;
        }

        var dfsListJson = {
            'id': '',
            'dfsname': 'uxdb_dfs_' + siteip.split('.')[3],
            'dfspath': dfspath,
            'siteid': id,
            'type': 0,
            'state': 2,
            'mrcid': mrcJson.id,
            'inittm': api.formatDate(new Date()),
            'latesttm': new Date().getTime()
        }


        var tm = new Date().getTime();
        var dfsId = api.createmd5("" + tm);
        dfsListJson.id = dfsId;
        mrcJson.dfsid = dfsListJson.id;

        dfsDbMgr.getInstance().queryRecord("tbl_mrclist", "id", mrcMd5, function (error, count, rst) {
            if (error) {
                console.log("find mrc error!");
            }
            if (0 == count) {
                if (mrcJson.ip == 'localhost') {
                    var sqlData = {
                        sqlText:"select dfsid from tbl_mrclist where siteid = $1 and ip = $2;",
                        sqlValue:[id,"localhost"]
                    }
                    sysDbMgr.getInstance().queryDbTableMgr(sqlData,function(isErr,rst){
                        if(isErr){
                            console.log();
                        }
                        if(rst.length == 0){
                            console.log("\n insert DFS data:" + JSON.stringify(dfsListJson) + "\n");
                            dfsDbMgr.getInstance().insertDfsRecord(dfsListJson, function (error) {
                                if (error) {
                                    console.log("insert dfs info error!");
                                }
                                execUpdateMrc("insert");
                            });
                        }else if(rst.length > 0){
                            for(var i=0;i<rst.length;i++){
                                if(
                                    mrcJson.dirip1 == rst[i].dirip1 && mrcJson.dirport1 == rst[i].dirport1 &&
                                    mrcJson.dirip2 == rst[i].dirip2 && mrcJson.dirport2 == rst[i].dirport2 &&
                                    mrcJson.dirip3 == rst[i].dirip3 && mrcJson.dirport3 == rst[i].dirport3 &&
                                    mrcJson.dirip4 == rst[i].dirip4 && mrcJson.dirport4 == rst[i].dirport4 &&
                                    mrcJson.dirip5 == rst[i].dirip5 && mrcJson.dirport5 == rst[i].dirport5 &&
                                    mrcJson.dirip6 == rst[i].dirip6 && mrcJson.dirport6 == rst[i].dirport6
                                ){
                                    mrcJson.dfsid = rst[i].dfsid;
                                    execUpdateMrc("insert");
                                    break;
                                }
                            }
                        } else {
                            return 1;
                        }
                    })
                }
                else//ip address
                {
                    dfsDbMgr.getInstance().queryAllRecord("tbl_mrclist", function (isErr, count, rst) {
                        if (isErr) {
                            console.log("query mrc_list error!");
                            return 1;
                        }
                        if (0 == count) {
                            console.log("\n insert dfs data:" + JSON.stringify(dfsListJson) + "\n");
                            dfsDbMgr.getInstance().insertDfsRecord(dfsListJson, function (error) {
                                if (error) {
                                    console.log("insert dfs info error!");
                                }
                                execUpdateMrc("insert");
                            });
                        } else if (count > 0) {
                            var isExist = false;
                            for (var i = 0; i < rst.length; i++) {
                                if (
                                    mrcJson.dirip1 == rst[i].dirip1 && mrcJson.dirport1 == rst[i].dirport1 &&
                                    mrcJson.dirip2 == rst[i].dirip2 && mrcJson.dirport2 == rst[i].dirport2 &&
                                    mrcJson.dirip3 == rst[i].dirip3 && mrcJson.dirport3 == rst[i].dirport3 &&
                                    mrcJson.dirip4 == rst[i].dirip4 && mrcJson.dirport4 == rst[i].dirport4 &&
                                    mrcJson.dirip5 == rst[i].dirip5 && mrcJson.dirport5 == rst[i].dirport5 &&
                                    mrcJson.dirip6 == rst[i].dirip6 && mrcJson.dirport6 == rst[i].dirport6
                                ) {
                                    mrcJson.dfsid = rst[i].dfsid;
                                    execUpdateMrc("insert");
                                    isExist = true;
                                    break;
                                }
                            }
                            if (!isExist) {
                                console.log("\n insert dfs data:" + JSON.stringify(dfsListJson) + "\n");
                                dfsDbMgr.getInstance().insertDfsRecord(dfsListJson, function (error) {
                                    if (error) {
                                        console.log("insert dfs info error!");
                                    }
                                    execUpdateMrc("insert");
                                });
                            }
                        }
                    });
                }
            } else {
                execUpdateMrc("update");
            }
        });


        function execUpdateMrc(typeStr) {
            if (typeStr == "insert") {
                console.log("\n insert mrc data:" + JSON.stringify(mrcJson) + "\n");
                dfsDbMgr.getInstance().insertMrcRecord(mrcJson, function (error) {
                    if (error) {
                        console.log("insert mrc info error!");
                    }
                    execMrcRecord();
                });
            } else if (typeStr == "update") {
                console.log("\n update mrc data:" + JSON.stringify(mrcJson) + "\n");
                dfsDbMgr.getInstance().updateMrcRecord(mrcJson, function (error) {
                    if (error) {
                        console.log("update mrc info error!");
                    }
                    execMrcRecord();
                });
            }
        }
    }
}

function updateOsdInfo(dataInfo, siteid, siteip, callback) {
    var currentTm = new Date().getTime();
    var osdLen = dataInfo.length;

    execOsdRecord();

    function execOsdRecord() {
        osdLen--;
        if (osdLen < 0) {
            callback();
            return;
        }
        var ipInfo = siteip + dataInfo[osdLen].ip + ":" + dataInfo[osdLen].listen_port;
        var osdMd5 = api.createmd5(ipInfo);

        var osdJson = {
            'id': osdMd5,
            'dfsid': '',
            'siteid': siteid,
            'osdname': dataInfo[osdLen].uuid,
            'ip': dataInfo[osdLen].ip,
            'port': dataInfo[osdLen].listen_port,
            'httpport': dataInfo[osdLen].http_port,
            'state': dataInfo[osdLen].module_status,
            'dirip1': "",
            'dirport1': "",
            'dirip2': "",
            'dirport2': "",
            'dirip3': "",
            'dirport3': "",
            'dirip4': "",
            'dirport4': "",
            'dirip5': "",
            'dirport5': "",
            'dirip6': "",
            'dirport6': "",
            'maintype': 0,
            'cfgpath': dataInfo[osdLen].config_file,
            'inittm': currentTm,
            'latesttm': currentTm
        }

        for (var i = 0; i < dataInfo[osdLen].ref_dirs.length; i++) {
            osdJson["dirip" + (i + 1)] = dataInfo[osdLen].ref_dirs[i].ip;
            osdJson["dirport" + (i + 1)] = dataInfo[osdLen].ref_dirs[i].port;
        }

        if (osdJson.ip == "localhost") {

            var sqlData = {
                sqlText: "select dfsid from tbl_mrclist where (dirip1 = $1 and dirport1 = $2) and " +
                "(dirip2 = $3 and dirport2 = $4) and " +
                "(dirip3 = $5 and dirport3 = $6) and " +
                "(dirip4 = $7 and dirport4 = $8) and " +
                "(dirip5 = $9 and dirport5 = $10) and " +
                "(dirip6 = $11 and dirport6 = $12) and siteid = $13 limit 1;",
                sqlValue: [osdJson.dirip1, osdJson.dirport1, osdJson.dirip2, osdJson.dirport2, osdJson.dirip3, osdJson.dirport3,
                    osdJson.dirip4, osdJson.dirport4, osdJson.dirip5, osdJson.dirport5, osdJson.dirip6, osdJson.dirport6, siteid]
            };
            sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
                if (isErr) {
                    console.log("query dfsid from tbl_mrc faild!");
                    return;
                }
                if (rst.length > 0) {
                    osdJson.dfsid = rst[0].dfsid;
                }
                execUpdateOsd();
            });
        }
        else//ip address
        {
            var sqlData = {
                sqlText: "select dfsid from tbl_mrclist where dirip1 = $1 and dirport1 = $2" +
                " and dirip2 = $3 and dirport2 = $4 and dirip3 = $5 and dirport3 = $6 and dirip4 = $7 and dirport4 = $8" +
                " and dirip5 = $9 and dirport5 = $10 and dirip6 = $11 and dirport6 = $12 limit 1;",
                sqlValue: [osdJson.dirip1, osdJson.dirport1, osdJson.dirip2, osdJson.dirport2, osdJson.dirip3, osdJson.dirport3,
                    osdJson.dirip4, osdJson.dirport4, osdJson.dirip5, osdJson.dirport5, osdJson.dirip6, osdJson.dirport6]
            };
            sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
                if (isErr) {
                    console.log("query dfsid from tbl_mrc faild!");
                    return;
                }
                if (rst.length > 0) {
                    osdJson.dfsid = rst[0].dfsid;
                }
                execUpdateOsd();
            });
        }

        function execUpdateOsd() {
            dfsDbMgr.getInstance().queryRecord('tbl_osdlist', "id", osdMd5, function (error, count, rst) {
                if (error) {
                    console.log("query osd info error!");
                    return 1;
                }

                if (0 == count) {
                    console.log("\n insert osd data:" + JSON.stringify(osdJson) + "\n");
                    dfsDbMgr.getInstance().insertOsdRecord(osdJson, function (error) {
                        if (error) {
                            console.log("insert osd info error!\n");
                        }
                        execOsdRecord();
                    });
                } else {
                    console.log("\n update osd data:" + JSON.stringify(osdJson) + "\n");
                    dfsDbMgr.getInstance().updateOsdRecord(osdJson, function (error) {
                        if (error) {
                            console.log("update osd info error!\n");
                        }
                        execOsdRecord();
                    });
                }
            });
        }
    }
}

function timingUpdateSiteInfo() {

    var sqlData = {
        sqlText: "select * from tbl_siteinfo where state = '1';",
        sqlValue: []
    }

    sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
        if (isErr) {
            console.log("query site info error!");
            return;
        }
        if (rst.length > 0) {
            var curTime = new Date().getTime();
            for (var i = 0; i < rst.length; i++) {
                updateHeartbeatInfo(rst[i]);
            }
            function updateHeartbeatInfo(siteInfo) {
                checkInstAndDfsInfo(siteInfo);
                var timeTmp = curTime - siteInfo.latesttm;
                if (timeTmp > config.totaltimeout) {

                    var sqlData = {
                        sqlText: "update tbl_siteinfo set clsnum = $1,clsinfo = $2,dfsnum = $3,dfsinfo = $4,state = $5 where id = $6;",
                        sqlValue: ["0", "0", "0", "0", 2, siteInfo.id]
                    }

                    sysDbMgr.getInstance().updateDbTableMgr(sqlData)

                    var updateJson = {
                        clsnum: "0",
                        clsinfo: "0",
                        dfsnum: "0",
                        dfsinfo: "0",
                        state: 2,
                        id: siteInfo.id
                    }
                    changeAllStateToErrorOfThisSite(updateJson.id);
                    sysDbMgr.getInstance().updateHeartbeatInfoState(updateJson, function () {
                        console.log('agent ip:%s,port:%s is fault!', siteInfo.ip, siteInfo.port);
                    });
                } else if (timeTmp > config.timeout && timeTmp < config.totaltimeout) {
                    console.log('agent server ip:%s,port:%s timeout!', siteInfo.ip, siteInfo.port);
                }
            }
        }
    })
    function checkInstAndDfsInfo(siteInfo) {
        if (siteInfo.state != 1) {
            return;
        }
        var sqlData = {
            sqlText: "select a.clsnum,b.dfsnum,c.dirnum,d.mrcnum,e.osdnum from (select count(*) as clsnum from tbl_instance where siteid = $1) as a," +
            "(select count(*) as dfsnum from tbl_dfslist where siteid = $1) as b," +
            "(select count(*) as dirnum from tbl_dirlist where siteid = $1) as c," +
            "(select count(*) as mrcnum from tbl_mrclist where siteid = $1) as d," +
            "(select count(*) as osdnum from tbl_osdlist where siteid = $1) as e;",
            sqlValue: [siteInfo.id]
        }
        sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
            if (isErr || rst.length == 0) {
                return;
            }
            var clsNum = rst[0].clsnum;
            var dfsNum = (parseInt(rst[0].dfsnum) + parseInt(rst[0].dirnum) + parseInt(rst[0].mrcnum) + parseInt(rst[0].osdnum)) - 1;
            console.log("clsNum:" + clsNum + ",dfsModNum:" + dfsNum);
            if (clsNum != siteInfo.clsnum || dfsNum != siteInfo.dfsnum) {
                sqlData.sqlText = "update tbl_siteinfo set clsnum = $1,dfsnum = $2 where id = $3;";
                sqlData.sqlValue = [clsNum, dfsNum, siteInfo.id];
                sysDbMgr.getInstance().updateDbTableMgr(sqlData, function (isErr) {
                    if (isErr) {
                        console.log("update clsnum and dfsnum faild!");
                    }
                })
            }
        })
    }
}

function changeAllStateToErrorOfThisSite(siteid) {
    var field = "state";
    var fieldValue = "0";
    var cond = "siteid";
    var condValue = siteid;
    sysDbMgr.getInstance().updateTableValue("tbl_instance", field, fieldValue, cond, condValue, function (rst) {
    })
    sysDbMgr.getInstance().updateTableValue("tbl_dfslist", field, fieldValue, cond, condValue, function (rst) {
    })
    sysDbMgr.getInstance().updateTableValue("tbl_dirlist", field, fieldValue, cond, condValue, function (rst) {
    })
    sysDbMgr.getInstance().updateTableValue("tbl_mrclist", field, fieldValue, cond, condValue, function (rst) {
    })
    sysDbMgr.getInstance().updateTableValue("tbl_osdlist", field, fieldValue, cond, condValue, function (rst) {
    })

    var sqlData = {
        sqlText: "select id from tbl_instance where siteid = $1;",
        sqlValue: [siteid]
    }
    sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
        if (isErr) {
            console.log("instance info query error!");
            return;
        }
        if (rst.length == 0) {
            return;
        }
        for (var i = 0; i < rst.length; i++) {
            myDbMgr.disConnectByInst(rst[i].id);
        }
    })
}
function timingUpdateDirInfo() {

    var sqlData = {
        sqlText: "select * from tbl_dirlist where dfsid = '';",
        sqlValue: []
    }
    sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
        if (isErr) {
            console.log("query all dirlist error!");
            return;
        }
        if (rst.length == 0) {
            return;
        }
        for (var i = 0; i < rst.length; i++) {
            updateDirDfsid(rst[i]);
        }
        function updateDirDfsid(dirInfo) {
            var sqlData = {
                sqlText: "",
                sqlValue: []
            }
            if (dirInfo.ip == 'localhost' || dirInfo.ip == '127.0.0.1') {
                sqlData.sqlText = "select dfsid from tbl_mrclist where dirip1 = $1 and dirport1 = $2 and siteid = $3;";
                sqlData.sqlValue = [dirInfo.ip, dirInfo.port, dirInfo.siteid];
            } else {
                sqlData.sqlText = "select dfsid from tbl_mrclist where dirip1 = $1 and dirport1 = $2;";
                sqlData.sqlValue = [dirInfo.ip, dirInfo.port];
            }
            sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
                if (isErr) {
                    console.log("[updateDIR]:query mrc_info error!");
                    return 1;
                }
                if (rst.length > 0) {
                    var dfsid = rst[0].dfsid;
                    sysDbMgr.getInstance().updateTableValue("tbl_dirlist", "dfsid", dfsid, "id", dirInfo.id, function (isErr) {
                        if (isErr) {
                            console.log("update dir_dfsid faild!");
                        }
                    })
                }
            })
        }
    })
}
function timingUpdateOsdInfo() {
    var sqlData = {
        sqlText: "select * from tbl_osdlist where dfsid = '';",
        sqlValue: []
    }
    sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
        if (isErr) {
            console.log("query osdlist error!");
            return;
        }
        if (rst.length == 0) {
            return;
        }
        for (var i = 0; i < rst.length; i++) {
            updateOsdDfsid(rst[i]);
        }
        function updateOsdDfsid(osdInfo) {
            var sqlData = {
                sqlText: "",
                sqlValue: []
            }
            if (osdInfo.ip == 'localhost' || osdInfo.ip == '127.0.0.1') {
                sqlData.sqlText = "select dfsid from tbl_mrclist where dirip1 = $1 and dirport1 = $2" +
                    " and dirip2 = $3 and dirport2 = $4 and dirip3 = $5 and dirport3 = $6 and dirip4 = $7 and dirport4 = $8" +
                    " and dirip5 = $9 and dirport5 = $10 and dirip6 = $11 and dirport6 = $12 and siteid = $13;";
                sqlData.sqlValue = [osdInfo.dirip1, osdInfo.dirport1, osdInfo.dirip2, osdInfo.dirport2, osdInfo.dirip3, osdInfo.dirport3,
                    osdInfo.dirip4, osdInfo.dirport4, osdInfo.dirip5, osdInfo.dirport5, osdInfo.dirip6, osdInfo.dirport6, osdInfo.siteid];
            } else {
                sqlData.sqlText = "select dfsid from tbl_mrclist where dirip1 = $1 and dirport1 = $2" +
                    " and dirip2 = $3 and dirport2 = $4 and dirip3 = $5 and dirport3 = $6 and dirip4 = $7 and dirport4 = $8" +
                    " and dirip5 = $9 and dirport5 = $10 and dirip6 = $11 and dirport6 = $12;";
                sqlData.sqlValue = [osdInfo.dirip1, osdInfo.dirport1, osdInfo.dirip2, osdInfo.dirport2, osdInfo.dirip3, osdInfo.dirport3,
                    osdInfo.dirip4, osdInfo.dirport4, osdInfo.dirip5, osdInfo.dirport5, osdInfo.dirip6, osdInfo.dirport6];
            }

            sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
                if (isErr) {
                    console.log("[updateOSD]:query mrc_info error!");
                    return 1;
                }
                if (rst.length > 0) {
                    var dfsid = rst[0].dfsid;
                    sysDbMgr.getInstance().updateTableValue("tbl_osdlist", "dfsid", dfsid, "id", osdInfo.id, function (isErr) {
                        if (isErr) {
                            console.log("update osd_info faild!");
                        }
                    })
                }
            })
        }
    })
}

function timingUpdateDfsInfo(dfsid) {

    if (typeof dfsid != "undefined") {
        var sqlData = {
            sqlText: "select state from tbl_dfslist where id = $1",
            sqlValue: [dfsid]
        }
        sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
            if (isErr || rst.length == 0) {
                console.log("query dfs state error!");
                return;
            }
            var dfsState = rst[0].state;
            updateDfsState(dfsid, dfsState);
        })
    } else {
        var sqlData = {
            sqlText: "select id,state from tbl_dfslist;",
            sqlValue: []
        }
        sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
            if (isErr) {
                console.log("query all dfslist error!");
                return;
            }
            for (var i = 0; i < rst.length; i++) {
                updateDfsState(rst[i].id, rst[i].state);
            }
        })
    }
    function updateDfsState(dfsid, dfsState) {

        var sqlData = {
            sqlText: "select a.state,b.state,c.state from tbl_dirlist a,tbl_mrclist b,tbl_osdlist c " +
            "where a.state = $1 and a.dfsid = $2 and b.state = $1 and b.dfsid = $2 and c.state = $1 and c.dfsid = $2;",
            sqlValue: ["1", dfsid]
        }

        sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
            if (isErr) {
                return;
            }
            var newDfsState = 2;
            if (rst.length > 0) {
                newDfsState = 1;
                execUpdateDfsState();
            } else if (dfsState == 0) {
                //判断该DFS所在站点是不是故障状态
                sqlData.sqlText = "select state from tbl_siteinfo where id = (select siteid from tbl_dfslist where id = $1);";
                sqlData.sqlValue = [dfsid];
                sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
                    if (isErr || rst.length == 0) {
                        return;
                    }
                    if (rst[0].state != 1) {
                       return;
                    }
                    execUpdateDfsState();
                })
            } else {
                execUpdateDfsState();
            }
            function execUpdateDfsState(){
                if (newDfsState != dfsState) {
                    sysDbMgr.getInstance().updateTableValue("tbl_dfslist", "state", newDfsState, "id", dfsid, function (isErr) {
                        if (isErr) {
                            console.log("update dfs %s state faild!", dfsid);
                        }
                    })
                }
            }
        })
    }
}
function timingUpdateInstanceInfo() {

    var sqlData = {
        sqlText: "select id,dfsurl from tbl_instance where type = '2' and dfsid = '';",
        sqlValue: []
    }
    sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
        if (isErr) {
            console.log("query instance info error!");
            return 1;
        }
        if (rst.length > 0) {
            for (var i = 0; i < rst.length; i++) {
                updateInstanceInfo(rst[i]);
            }
        }
        function updateInstanceInfo(instanceInfo) {
            var dfsurl = instanceInfo.dfsurl;
            var dfsurlArr = dfsurl.split(":");

            var sqlData = {
                sqlText: "select dfsid from tbl_dirlist where ip = $1 and port = $2;",
                sqlValue: [dfsurlArr[0], dfsurlArr[1]]
            }
            sysDbMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
                if (isErr) {
                    console.log("query dir info error!");
                    return;
                }
                if (rst.length > 0) {
                    var dfsid = rst[0].dfsid;
                    sysDbMgr.getInstance().updateTableValue("tbl_instance", "dfsid", dfsid, "id", instanceInfo.id, function (isErr) {
                        if (isErr) {
                            console.log("update instance state faild!");
                        }
                    })
                }
            })
        }
    })
}
function startInterval() {
    var timingDetectionTime = config.detectionTime;
    setInterval(function () {
        console.log("timing detection site info begin:");
        timingUpdateSiteInfo();
    }, timingDetectionTime);

    var timingDfsUpdateTime = config.dfsUpdateTime;
    setInterval(function () {
        console.log("timing detection dfs info begin:");
        timingUpdateDirInfo();
        timingUpdateOsdInfo();
        timingUpdateDfsInfo();
        timingUpdateInstanceInfo();
    }, timingDfsUpdateTime);
}
function udpServer(){
    this.getInstanceList = getInstanceList;
    this.getDFSlistInfo = getDFSListInfo;
    this.timingUpdateSite = timingUpdateSiteInfo;
    this.timingUpdateDir = timingUpdateDirInfo;
    this.timingUpdateOsd = timingUpdateOsdInfo;
    this.timingUpdateDfs = timingUpdateDfsInfo;
    this.timingUpdateInstance = timingUpdateInstanceInfo;
}
exports.udpServer = udpServer;