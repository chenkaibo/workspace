'use strict';
window.onload = function ()
{
    window.focus();
    window.parent.menuOperFun();
    top.d3.select("#leftDivId").classed("no-display",true);
    top.d3.select("#topMenuLi4").classed("top-del-menu",true);
    getUserTableElem("#userPageBodyId");
};
/*
 * 弹出框
 * */
var userContainDiv,modfiItem,checkFlag = false;
var toolTip;
function popUpBoxOper()
{
    var w,h;
    function getSrceenWH()
    {
        w = $(window).width();
        h = $(window).height();
        $('#dialogBg').width(w).height(h);
    }

    window.onresize = function(){
        getSrceenWH();
    };
    $(window).resize();
    newUserInfoFun();
}
/*
* 获取用户的列表
* */
function getUserTableElem(contain)
{
    var currentRole = window.sessionStorage.ux_curUserRole;
    d3.select("#mainContainDiv").remove();
    userContainDiv = d3.select(contain)
        .append("div")
        .attr({
            'id':'mainContainDiv',
            'class':'siteList-content'
        });
    d3.select(".siteList-content")
        .append("div")
        .attr({
            'id':'toolbar',
            'class':'toolbar box'
        });

    d3.select(".siteList-content #toolbar")
        .append("button")
        .attr({
            'id':'newUserBtn',
            'class':'btn btn-default admitClick bounceIn disabledElem'
        })
        .html("新&nbsp;&nbsp;建");
    d3.select(".siteList-content #toolbar")
        .append("button")
        .attr({
            'id':'delUserInfo',
            'class':'disabledElem delBtnClass',
            'disabled':'disabled',
            'onClick':'delUser()'
        })
        .html("删&nbsp;&nbsp;除");
    getUserQueryCondition('.siteList-content');
    if(currentRole == 1)
    {
       d3.selectAll(".disabledElem").style('display','none');
       d3.select("#searchSite-form").style('opacity','0');
    }
    d3.select(".siteList-content")
        .append("div")
        .attr("class","instance-list")
        .append("table")
        .attr("id","userListId")
        .attr("color","#57D1F7");
    initUserTable();
    initUserTableReq();
    listenUserTable();
    popUpBoxOper();
}
/*
 * 选择条件查询元素
 * */
function getUserQueryCondition(contain)
{
    d3.select(contain)
        .append("div")
        .attr("id","searchSite-form")
        .attr("class","pull-right searchSite")
        .append("div")
        .attr("id","instanceName")
        .attr("class","searchSite-content");
    d3.select("#searchSite-form")
        .append("div")
        .attr("id","instanceType")
        .attr("class","searchSite-content");
    d3.selectAll(".searchSite-content")
        .append("input")
        .attr("type","checkbox")
        .each(function(d,i){
            d3.select(this).attr({
                id:"checkboxId" + i
            });
        })
        .on("click",function(d,i){
            checkBoxFun(i);
        })
        .attr("class","siteCheck");
    var searchSite_content = d3.selectAll(".searchSite-content");
    d3.select(searchSite_content[0][0])
        .insert("span",":nth-child(2)")
        .attr("class","searchTypeName")
        .html("用户名：");
    d3.select(searchSite_content[0][0])
        .insert("input",":nth-child(3)")
        .attr({
            'type':'text',
            'id':'selectElemId0',
            'disabled':""
        });
    d3.select(searchSite_content[0][1])
        .insert("span",":nth-child(2)")
        .attr("class","searchTypeName")
        .html("用户角色：");
    d3.select(searchSite_content[0][1])
        .insert("select",":nth-child(3)")
        .attr({
            'id':'selectElemId1',
            'class':'selectType'
        })
        .attr("disabled",true)
        .append("option")
        .html("管理员");
    d3.select(".selectType")
        .append("option")
        .html("普通用户");
    d3.select("#searchSite-form")
        .append("button")
        .attr("class","btn btn-sm btn-bg-color searchSite-btn")
        .on("click",function(){
            queryUserInstance();
        })
        .attr("title","查找")
        .style("margin","4px 29px 0 4px");
}

/*******************************用户查询处理区*********************/
function queryUserInstance()
{
    /*
    * 修改查询按钮的颜色*/
    d3.select("#searchSite-form button").classed("searchSite-btn",false);
    d3.select("#searchSite-form button").classed("searchSite-btn-backWhite",true);
    var queryJsonData = {
        'userNameFlag':0,
        'userName':'',
        'userRoleFlag':0,
        'userRole':'',
    };
    var formDataArray = d3.selectAll(".siteCheck");
    queryJsonData.userNameFlag = (formDataArray[0][0].checked == false) ? (0):(1);
    queryJsonData.userRoleFlag = (formDataArray[0][1].checked == false) ? (0):(1);
    if(queryJsonData.userNameFlag)
    {
       queryJsonData.userName = trim(d3.select("#selectElemId0")[0][0].value);
    }
    if(queryJsonData.userRoleFlag)
    {
       queryJsonData.userRole = d3.select("#selectElemId1")[0][0].selectedIndex;
    }
   if((queryJsonData.userNameFlag && queryJsonData.userName == ""))
    {
        uxAlert("请完善查询条件！");
        d3.select("#searchSite-form button").classed("searchSite-btn-backWhite",false);
        d3.select("#searchSite-form button").classed("searchSite-btn",true);
        return;
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"usermanage",
        request :{"mainRequest":"queryUser","subRequest":"cond","ssubRequest":""},
        data    :queryJsonData
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_userInterface.ajaxRequest(false,jsonDataStr,queryDataCallback);

}
function queryDataCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    var userData = getNewJsonData(retJsonStr.data);
    if(retJsonStr.rstcode == "success")
    {
        initUserTable();
        $('#userListId').bootstrapTable('load',userData);
    }else{
        //uxAlert(retJsonStr.desc);
    }
    /*
     * 修改查询按钮的颜色*/
    d3.select("#searchSite-form button").classed("searchSite-btn-backWhite",false);
    d3.select("#searchSite-form button").classed("searchSite-btn",true);
}
/********************************用户列表初始化区*****************/
function initUserTable()
{
    var par = [
        {field:'status',radio:true,align:'center'},
        {field:'index',title:'序号',align:'center'},
        {field:'userName',title:'用户名',align:'center'},
        {field:'userId',title:'用户ID',align:'center'},
        {field:'userRole',title:'用户角色',align:'center'},
        {'field':'oper','title':'操  作','algin':'center',formatter:function(value,row,index){
             var par = row.userName + "," + row.userRole + "," + index;
             var modifUserPwdOper = '<a title = "修改">' + '<button id = "modifBtn'+ index +'" class = "btn-link modifBtn modifPsw bounceIn" onclick = "modfiUserInfo(\''+ par+ '\')"'+'></button>' + '</a>';
             return modifUserPwdOper;
           }
        }
    ];
    $('#userListId').bootstrapTable({
        classes:"table table-no-bordered",
        toolbar:"#toolbar",
        height:606,
        columns: par,
        idField:"index"
    });
}
function initUserTableReq()
{
    /*
     * 发送数据域的数据（当前登录的用户名和角色）//发送数据，包含当前用户角色和用户名
     * */
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"usermanage",
        request :{"mainRequest":"enumUser","subRequest":"","ssubRequest":""},
        data    :{
            name:window.sessionStorage.ux_curUserName,
            role:window.sessionStorage.ux_curUserRole
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_userInterface.ajaxRequest(false,jsonDataStr,initUserTableReqCallback);
}
function initUserTableReqCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    var userData = getNewJsonData(retJsonStr.data);
    if(retJsonStr.rstcode == "success")
    {
        $('#userListId').bootstrapTable('load',userData);
    }else{
        uxAlert("用户列表初始化失败！");
    }
}


/**********************************修改用户处理区****************/
var modIndex;
function modfiUserInfo(str)
{
    var className;
    var itemArray = str.split(",");
    var selectUserName = itemArray[0];
    var selectUserRole = itemArray[1];
    modIndex = parseInt(itemArray[2]);
    d3.select("#modifBtn" + modIndex).classed("modifPsw-white",true);
    newUserInfoElem(userContainDiv,selectUserName,"Mod",selectUserRole);
    $("#newUserItemSpanMod").text("修改用户密码").addClass("modfiTitle");
    d3.select("#input" + 0).attr("value",selectUserName).attr("disabled","disabled");
    var userRole = parseInt(window.sessionStorage.ux_curUserRole);
    d3.select("#input" + 1)[0][0].value = selectUserRole;
    d3.select("#input" + 1).attr("disabled","disabled");
    $("#sureBtnMod").attr("onClick","modifUserPwd()");
    if(!userRole)
    {
        d3.select("#dialogMod").style("height","400px");
    }else{
        d3.select("#dialogMod").style("height","465px");
    }
    if(d3.select("#dialogMod").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgMod').fadeIn(300);
    $('#dialogMod').removeAttr('class').addClass('animated '+className+'').fadeIn();
}
function modifUserPwd()
{
    var userRole = window.sessionStorage.ux_curUserRole;
    var username = $("#input" + 0).val();
    var useNewPwd = "";
    var pwdSureFlag = false;
    if(userRole == '1')
    {
        useNewPwd = $("#input" + 3).val();
        var renamePwd = $("#input" + 4).val();
        var oldUsepwd = $("#input" + 2).val();
        if(useNewPwd.length > 7 && useNewPwd.length < 21 && passwordCheckout(useNewPwd) && useNewPwd == renamePwd && oldUsepwd == currentPwd)
        {
            pwdSureFlag = false;
        }else{
            pwdSureFlag = true;
        }
    }else{
        var usepwd = $("#input" + 2).val();
        var reUserPwd = $("#input" + 3).val();
        if(usepwd.length > 7 && usepwd.length < 21 && passwordCheckout(usepwd) && usepwd == reUserPwd)
        {
            pwdSureFlag = false;
        }else{
            pwdSureFlag = true;
        }
    }
    if(pwdSureFlag)
    {
        uxAlert("请正确输入需修改用户的信息！");
        return;
    }
    if(userRole == "1" && useNewPwd != "")
    {
        uxAlert("请正确输入需修改用户的信息！");
        return;
    }
    currentPwd = useNewPwd;
    /*发送数据*/
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"usermanage",
        request :{"mainRequest":"modUser","subRequest":"","ssubRequest":""},
        data    :{'username':username,
                  'userrole':userRole,
                  'userpwd':hex_md5("uxdb"+usepwd),
                  'userNewPwd':hex_md5("uxdb"+useNewPwd)
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_userInterface.ajaxRequest(false,jsonDataStr,modifUserPwdCallback);
}
var currentPwd;
function modifUserPwdCallback(retJson)
{
    var dataJsonStr = JSON.parse(retJson);
    if(dataJsonStr.rstcode == "success")
    {
        uxAlert("修改用户成功!");
        initUserTableReq();
        window.sessionStorage.ux_curUserPwd = currentPwd;
    }else{
        uxAlert(dataJsonStr.desc);
    }
    modfiItem = {
        'm_username':'',
        'm_userrole':''
    };
    d3.select("#dialogMod").classed("bounceIn",false);
    $('#dialogBgMod').fadeOut(300,function(){
        $('#dialogMod').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#modifBtn" + modIndex).classed("modifPsw-white",false);
}
/********************************新建用户处理区****************/
function newUserInfoFun()
{
    var className;
    d3.select("#newUserBtn").on('click',function(){
        d3.select("#newUserBtn").classed("admitClick",false);
        newUserInfoElem(userContainDiv,"",'New',"普通用户");
        d3.select("#newUserItemSpanNew").text("新建用户").classed("newTitle",true);
        d3.select("#sureBtnNew").attr({'onclick':'newUserInfo()'});
        if(d3.select("#dialogNew").classed("bounceIn"))
        {
            className = "bounceOutUp";
        }else{
            className = "bounceIn";
        }
        $('#dialogBgNew').fadeIn(300);
        $('#dialogNew').removeAttr('class').addClass('animated ' + className + '').fadeIn();
    });
}
function newUserInfo()
{
    var username = d3.select("#input" + 0)[0][0].value;
    var userole = trim(d3.select("#input" + 1)[0][0].value);
    userole = (userole == "管理员") ? ("0"):("1");
    var userpwd = d3.select("#input" + 2)[0][0].value;
    var reUserpwd = d3.select("#input" + 3)[0][0].value;
    var newSureFlag = false,pwdSureFlag = false,equalFlag = false;
    if(userpwd.length > 7 && userpwd.length < 21 && passwordCheckout(userpwd))
    {
        if(userpwd == reUserpwd)
        {
            pwdSureFlag = true;//匹配。可以提交
        }else{
            pwdSureFlag = false;
        }
    }else{
        pwdSureFlag = false;
    }
    if(isalphawholename(username))
    {
        newSureFlag = true;//匹配，可以提交
    }else{
        newSureFlag = false;
    }
    if(!newSureFlag)
    {
        uxAlert("请正确输入需新建用户的信息！");
        return;
    }
    if(!pwdSureFlag)
    {
        uxAlert("请正确输入需新建用户的信息！");
        return;
    }
    if(username == "" || userpwd == "")
    {
        uxAlert("请正确输入需新建用户的信息！");
        return;
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"usermanage",
        request :{"mainRequest":"newUser","subRequest":"","ssubRequest":""},
        data    :{'username':username,
                  'userrole':userole,
                  'userpwd':hex_md5("uxdb"+userpwd)
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_userInterface.ajaxRequest(false,jsonDataStr,newUserInfoCallback);
}
function newUserInfoCallback(retJson)
{
   var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        initUserTableReq();
        uxAlert("新建用户成功！");
    }else{
        uxAlert(retJsonStr.desc);
    }
    d3.select("#dialogNew").classed("bounceIn",false);
    $('#dialogBgNew').fadeOut(300,function(){
        $('#dialogNew').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#newUserBtn").classed("admitClick",true);
}
/******************************删除用户处理区*****************/
function delUser()
{
    d3.select("#delUserInfo").classed("admitClick",false);
    uxConfirm("是否确认删除该用户？",function(rst)
    {
        if(!rst)
        {
            d3.select("#delUserInfo").classed("admitClick",true);
            return;
        }
        var selectData = $("#userListId").bootstrapTable("getSelections");
        var jsonDataObj = {
            ip      :"",
            port    :"",
            router  :"usermanage",
            request :{"mainRequest":"delUser","subRequest":"","ssubRequest":""},
            data    :selectData
        };
        var jsonDataStr = JSON.stringify(jsonDataObj);
        ux_userInterface.ajaxRequest(false,jsonDataStr,delUserCallback);
    });
}
function delUserCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        initUserTableReq();
        uxAlert("删除用户成功！");
    }else{
        uxAlert(retJsonStr.desc);
    }
    changeButtonStatus("delUserInfo");
}
/*********************************辅助函数区*****************/
/*
 * 选择框显示
 * */
function checkBoxFun(idNum)
{
    var checkBoxSelectItem = "selectElemId" + idNum;
    var checkBoxSelect = "checkboxId" + idNum;
    var checkitemArray = d3.select("#" + checkBoxSelectItem);
    var checkBoxArray = d3.select("#" + checkBoxSelect);
    if(checkBoxArray[0][0].checked)
    {
        checkitemArray[0][0].disabled = false;
    }else{
        if(checkitemArray[0][0].type == "text")
        {
            checkitemArray[0][0].value = "";
        }
        checkitemArray[0][0].disabled = true;
    }
}
/*
 * 重组数据格式
 * */
function getNewJsonData(dataJson)
{
    var resultData = [];
    for(var i = 0;i < dataJson.length;i++)
    {
        var info = {
            'index':0,
            'userName':'',
            'userId':'',
            'userRole':''
        };
        info.index = (i + 1);
        info.userName = dataJson[i].userName;
        info.userId = dataJson[i].userId;
        info.userRole = (dataJson[i].userRole == 0) ? ("管理员"):("普通用户");
        resultData.push(info);
    }
    return resultData;
}
/*
 * 监听表格
 * */
function listenUserTable()
{
    var $table = $("#userListId");
    $table.on('check.bs.table page-change.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table',function(arg){
        changeButtonStatus("delUserInfo");
    });
}
/*
 * 判断单选框是否选中
 * */
function changeButtonStatus(btid)
{
    if(btid == "")
    {
        return;
    }
    var selected = $("#userListId").bootstrapTable('getSelections');
    if(selected.length > 0)
    {
        d3.select("#" + btid)[0][0].disabled = false;
        d3.select("#" + btid).classed("delBtnClass",false);
        d3.select("#" + btid).classed("btn",true);
        d3.select("#" + btid).classed("admitClick",true);
    }
    else
    {
        d3.select("#" + btid)[0][0].disabled = true;
        d3.select("#" + btid).classed("delBtnClass",true);
        d3.select("#" + btid).classed("btn",false);
        d3.select("#" + btid).classed("admitClick",false);
    }
}
/*
* 弹出框实现
* */
function newUserInfoElem(userContainDivElem,selectUsserName,operName,selectUserRole)
{

    d3.select("#dialogBgMod").remove();
    d3.select("#dialogMod").remove();
    d3.select("#dialogBgNew").remove();
    d3.select("#dialogNew").remove();
    var curPwd = window.sessionStorage.ux_curUserPwd;
    var pupUpItem = "";
    var userRole = window.sessionStorage.ux_curUserRole;
    var popUpInputArray;
    if(userRole == '0' && operName == 'Mod')
    {
        popUpInputArray = ["用&nbsp;&nbsp;户&nbsp;&nbsp;名","用户角色","密&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码","确认密码"];
    }
    else  if(userRole == '1' && operName == 'Mod')
    {
        popUpInputArray = ["用&nbsp;&nbsp;户&nbsp;&nbsp;名","用户角色","旧&nbsp;&nbsp;密&nbsp;&nbsp;码","新&nbsp;&nbsp;密&nbsp;&nbsp;码","确认密码"];
    }
    else
    {
        popUpInputArray = ["用&nbsp;&nbsp;户&nbsp;&nbsp;名","用户角色","密&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码","确认密码"];
    }
    userContainDivElem.append("div")
        .attr("id","dialogBg" + operName);
    var outPage = userContainDivElem.append("div")
        .attr("id","dialog" + operName);
    var editFrom = outPage.append("div")
        .attr("id","editFrom" + operName);
    var newUserItemSpan = editFrom.append("span")
        .attr("id","newUserItemSpan" + operName)
        .html(pupUpItem);
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos");
    for(var i = 0;i < popUpInputArray.length;i++)
    {
        var editFromLi = editFormUl.append("li").attr("class","editUl");
        editFromLi.append("label").append("span")
            .attr("class","editFromLiSpan")
            .html(popUpInputArray[i]);
        if(i == 1)
        {
            editFromLi.append("input").attr({
                    'class':'ipt insInputClass',
                    'id':'input' + i,
                    'disabled':'disabled'
                    });
        }else if(i >= 2)
        {
            editFromLi.append("input")
                .attr({
                    'id':"input" + i,
                    'type':"password",
                    'class':'ipt insInputClass ',
                    'placeholder':'至少一个字母、数字及特殊字符，8-20位'
                })
                .on('blur',function(){
                   var userPwd = d3.select(this)[0][0].value;
                   if(userPwd.length > 7 && userPwd.length < 21 && passwordCheckout(userPwd))
                   {
                       d3.select(this)[0][0].nextSibling.innerHTML = "";
                   }else{
                       d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>至少包含一个字母、数字及特殊字符，长度为8-20位！</span>";
                   }

                });
        }else{
            editFromLi.append("input")
                .attr({
                    'id':"input" + i,
                    'type':"text",
                    'class':'ipt insInputClass',
                    'placeholder':'字母、数字、下划线组成，4-20位'
                })
                .on('blur',function(d,i){
                   var userName = d3.select(this)[0][0].value;
                    if(!isalphawholename(userName))
                    {
                      d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'> 由字母、数字、下划线组成，长度在4-20位之间！</span>";
                    }else{
                      d3.select(this)[0][0].nextSibling.innerHTML = "";
                    }
                });
        }
    }
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
        d3.select(this).attr({
            'id':'errorSpan' + i
        });
    });
    d3.select("#input1")[0][0].value = selectUserRole;
    if(operName == "New" || (userRole == '0' && operName == 'Mod'))
    {
        d3.select("#input3").on('blur',function(){
            var currentPwd = d3.select("#input2")[0][0].value;
            var surePwd = d3.select(this)[0][0].value;
            if(surePwd != currentPwd)
            {
                checkFlag = true;
                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>两次密码输入不一致，请确认输入！</span>";
            }else{
                d3.select(this)[0][0].nextSibling.innerHTML = "";
                if(surePwd.length > 7 && surePwd.length < 21 && passwordCheckout(surePwd))
                {
                    checkFlag = false;
                    d3.select(this)[0][0].nextSibling.innerHTML = "";
                }else{
                    checkFlag = true;
                    d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>至少包含一个字母、数字及特殊字符，长度为8-20位！</span>";
                }
            }
        });
        d3.select("#input2").on('blur',function(){
            var currentPwd = d3.select("#input3")[0][0].value;
            var surePwd = d3.select(this)[0][0].value;
            if(surePwd != currentPwd)
            {
                d3.select("#input3")[0][0].nextSibling.innerHTML = "<span class='errorTip'>两次密码输入不一致，请确认输入！</span>";
            }else{
                d3.select("#input3")[0][0].nextSibling.innerHTML = "";
                d3.select(this)[0][0].nextSibling.innerHTML = "";
                if(surePwd.length > 7 && surePwd.length < 21 && passwordCheckout(surePwd))
                {
                    d3.select(this)[0][0].nextSibling.innerHTML = "";
                }else{
                    d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>至少包含一个字母、数字及特殊字符，长度为8-20位！</span>";
                }
            }
        });
    }
    if(userRole == '1' && operName == 'Mod')
    {
        d3.select("#input2").on('blur',function(){
            var userPwd = d3.select(this)[0][0].value;
            if(userPwd == curPwd || userPwd == "")
            {
                d3.select(this)[0][0].nextSibling.innerHTML = "";
                if(passwordCheckout(userPwd))
                {
                    //checkFlag = false;
                    d3.select(this)[0][0].nextSibling.innerHTML = "";
                }else{
                    //checkFlag = true;
                    d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>至少包含一个字母、数字及特殊字符，长度为8-20位！</span>";
                }
            }else {
                //checkFlag = true;
                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>输入密码与原密码不相同，请确认输入！</span>";
            }
        });
        d3.select("#input4").on('blur',function(){
            var currentPwd = d3.select("#input3")[0][0].value;
            var surePwd = d3.select(this)[0][0].value;
            if(surePwd != currentPwd)
            {
                //checkFlag = true;
                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>两次密码输入不一致，请确认输入！</span>";
            }else{
                d3.select(this)[0][0].nextSibling.innerHTML = "";
                if(surePwd.length > 7 && surePwd.length < 21 && passwordCheckout(surePwd))
                {
                    //checkFlag = false;
                    d3.select(this)[0][0].nextSibling.innerHTML = "";
                }else{
                    //checkFlag = true;
                    d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>至少包含一个字母、数字及特殊字符，长度为8-20位！</span>";
                }
            }
        });
        d3.select("#input3").on('blur',function(){
            var currentPwd = d3.select("#input4")[0][0].value;
            var surePwd = d3.select(this)[0][0].value;
            if(surePwd.length > 7 && surePwd.length < 21 && passwordCheckout(surePwd))
            {
                d3.select(this)[0][0].nextSibling.innerHTML = "";
                if(surePwd != currentPwd)
                {
                    d3.select("#input4")[0][0].nextSibling.innerHTML = "<span class='errorTip'>两次密码输入不一致，请确认输入！</span>";
                }else{
                    d3.select("#input4")[0][0].nextSibling.innerHTML = "";
                    d3.select(this)[0][0].nextSibling.innerHTML = "";
                }
            }else{
                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>至少包含一个字母、数字及特殊字符，长度为8-20位！</span>";
            }
        });
    }
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("button")
        .attr({
            "id":"sureBtn" + operName,
            "class":"popup-sure-btn btn btn-sm btn-bg-color popUpBtn",
        })
        .html("确&nbsp;&nbsp;&nbsp;&nbsp;定");
    editFromDivBtn
        .append("button")
        .attr("class","btn btn-sm btn-bg-color popUpBtn claseDialogBtn")
        .attr("id","claseDialogBtn" + operName)
        .on("click",function(){
            var operIdStr = d3.select(this)[0][0].id;
            if(operIdStr.indexOf("New") > 0)
            {
                d3.select("#dialogNew").classed("bounceIn",false);
                $('#dialogBgNew').fadeOut(300,function(){
                    $('#dialogNew').addClass('bounceOutUp').fadeOut();
                });
                d3.select("#newUserBtn").classed("admitClick",true);
            }else{
                d3.select("#dialogMod").classed("bounceIn",false);
                $('#dialogBgMod').fadeOut(300,function(){
                    $('#dialogMod').addClass('bounceOutUp').fadeOut();
                });
                d3.select("#modifBtn" + modIndex).classed("modifPsw-white",false);
            }
        })
        .html("取&nbsp;&nbsp;&nbsp;&nbsp;消");
}

