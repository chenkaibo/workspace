/**
 * Created by Administrator on 2017/3/21.
 */

var dbOpt = require('./dboper');
var htmlAnalysis = require('./htmldataanalysis');
var _minInterval  = 30;
var _maxInterval  = 300;
var _interval = 30;
var _duration = 3600;
var _intervalId;
var _dfsProtocol = "http://";

//startDFSMonitor();
//init
function initDFSMonitor(callback){
    if(typeof callback == "undefined"){
        return;
    }
    //empty table
    var DIROpt = dbOpt.DIRDBOper().getInstance();
    var MRCOpt = dbOpt.MRCDBOper().getInstance();
    var OSDOpt = dbOpt.OSDDBOper().getInstance();
    DIROpt.emptyTable(function(retDIR){
        if(retDIR){
            callback(retDIR);
            return;
        }
       MRCOpt.emptyTable(function(retMRC){
           if(retMRC){
               callback(retMRC);
               return;
           }
           OSDOpt.emptyTable(function(retOSD){
               if(retOSD){
                   callback(retOSD);
               }
               callback(null);
           });
       }) ;
    });
}


//getDFSMonitorData
exports.getDFSMonitorData = function(data,callback){
    if(typeof callback != "function" || typeof data.dfsid == "undefined"){
          return;
    }

    var DIROpt = dbOpt.DIRDBOper().getInstance();
    var MRCOpt = dbOpt.MRCDBOper().getInstance();
    var OSDOpt = dbOpt.OSDDBOper().getInstance();
    var dfsid = data.dfsid;
    var retData = {"DIRData":[],"MRCData":[],"OSDData":[]};
    //dir
    DIROpt.getDataByDFSID(dfsid,function(error,DIRData){
        if(error){
            callback(error);
            return;
        }
        retData.DIRData = DIRData;
        MRCOpt.getDataByDFSID(dfsid,function(error,MRCData){
            if(error){
                callback(error);
                return;
            }
            retData.MRCData = MRCData;

            OSDOpt.getDataByDFSID(dfsid,function(error,OSDData){
                if(error){
                    callback(error);
                    return;
                }
                retData.OSDData = OSDData;
                callback(error,retData);
            });
        });
    });

};


//start
exports.startDFSMonitor = startDFSMonitor;
function startDFSMonitor(){
    initDFSMonitor(function(ret){
        if(ret){
            console.log("start DFSMonitor failed !");
            return;
        }
        var collectNum = _duration/_interval;
        if(collectNum > _duration/_minInterval || collectNum < _duration/_maxInterval){
            console.log("collectNum is not correct !");
            return false;
        }
        var setRet = dbOpt.setCollectNum(collectNum);
        if(!setRet){
            return;
        }

        var DFSOpt = dbOpt.DFSDBOper().getInstance();
        DFSOpt.getDIRList(function (error, rst) {
            if (error) {
                console.log("get DIRLIST error !");
                return;
            }
            if(rst.length == 0){
                return;
            }
            _intervalId = setInterval(function () {
                var len = rst.length;
                var index = 0;
                doMonitor(index);

                function doMonitor(newInex){
                    if(newInex >= len){
                        return;
                    }
                    var dirAddress = _dfsProtocol+rst[newInex].dirip + ":"+rst[newInex].dirport;
                    var dfsid = rst[newInex].dfsid;
                    var dirname = rst[newInex].dirname;
                    htmlAnalysis.setDFSID(dfsid);
                    htmlAnalysis.setDIRName(dirname);
                    htmlAnalysis.startMonitor(dirAddress,function(){
                        index++;
                        doMonitor(index);
                    });
                }

            },_interval*1000);
        });

    });

}


//set frequency
exports.setCollectInterval = function(interval){
    if(isNaN(interval)){
        return false;
    }
    if(interval < _minInterval || interval > _maxInterval){
       return false;
    }

    //write configure file
    //........

    //set value
    _interval = interval;
    clearInterval(_intervalId);
    startDFSMonitor();

    return true;

};
