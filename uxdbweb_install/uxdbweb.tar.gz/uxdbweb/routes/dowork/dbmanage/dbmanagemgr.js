var protocolMgr = require('../../protocolunit/protocolmgr');
var api = require('../../common/api');
var uxdb = require('uxdb');
var myDbOpt = require('../../common/dbopt');
var clConfig = require('../../../uxwebconfig').dbmanage;
var dbMgr = (function () {
    return {
        disConnectByInst: disConnectByInstMgr
    }
})();
exports.dbMgr = dbMgr;
var dbmanageMgr = (function () {
    var _inst;
    var dbmanageOpt = function () {
        return {
            enumDbListMgr: enumDbListMgr,
            connectDbMgr: connectDbMgr,
            disConnDbMgr: disConnDbMgr,
            queryDbOptMgr: queryDbOptMgr,
            execDbOptMgr: execDbOptMgr,
            getAllConnectedDbMgr: getAllConnectedDbMgr,
            getAllCondbByInstanceMgr: getAllCondbByInstanceMgr,
            getThisInstConnectedDbMgr: getThisInstConnectedDbMgr,
            getDbHomePageInfoMgr: getDbHomePageInfoMgr,
            dbMonitorMgr: dbMonitorMgr,
        }
    }
    return {
        getInstance: function () {
            if (_inst === undefined) {
                _inst = new dbmanageOpt();
            }
            return _inst;
        }
    }
})();
exports.dbmanageMgr = dbmanageMgr;

function enumDbListMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 2,
        'subcmd': 8,
        'dbnum': 1,
        'data': reqDb.data
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
    return 0;
}
function reqHostCpuUsage(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 4,
        'subcmd': 1,
        'dbnum': 1,
        'data': ""
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
}
function reqHostMemUsage(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 4,
        'subcmd': 2,
        'dbnum': 1,
        'data': ""
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
}
function reqHostDiskUsage(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    var reqJson = {
        'hostip': reqDb.ip,
        'hostport': reqDb.port,
        'type': 'sync',
        'maincmd': 4,
        'subcmd': 3,
        'dbnum': 1,
        'data': ""
    }
    protocolMgr.execProtocol(reqJson, function (isErr, resJson) {
        if (isErr) {
            callback(isErr, resJson);
            return;
        }
        if (resJson.maincmd == 0 && resJson.subcmd == 0) {
            callback(true, resJson);
            return;
        }
        callback(isErr, resJson);
    });
}

var clObject = {};
function connectDbMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    var webusername = trim(reqDb.webusername);
    var instanceid = trim(reqDb.instid);
    var dbname = trim(reqDb.dbname);

    var maxConnectNum = 10;

    if (webusername in clObject) {
        if (instanceid in clObject[webusername]) {
            var len = 0;
            for (var item in clObject[webusername][instanceid]) {
                len++;
            }
            if (!(len < maxConnectNum)) {
                callback(true, "您同时最多可连接10个数据库!");
                return;
            }
        }
    }

    var conStr = "uxdb://" + reqDb.dbusername + ":" + reqDb.pwd + "@" + reqDb.ip + ":" + reqDb.port + "/" + reqDb.dbname;
    console.log("[conStr]:" + conStr);
    var cl = new uxdb.Client(conStr);

    cl.connect(function (isErr) {
        if (isErr) {
            callback(isErr, "连接失败！");
            cl.end();
        } else {

            if (!(webusername in clObject)) {
                clObject[webusername] = {};
            }
            if (!(instanceid in clObject[webusername])) {
                clObject[webusername][instanceid] = {};
            }

            var curData = new Date().getTime();
            var clObj = {
                cl: cl,
                ip: reqDb.ip,
                port: reqDb.port,
                username: reqDb.dbusername,
                dbname: reqDb.dbname,
                pwd: reqDb.pwd,
                instname: reqDb.instname,
                conntime: curData,
                lastopttm: curData,
            }
            clObject[webusername][instanceid][dbname] = clObj;
            callback(false);
            reqDbMonitor();
        }
    });
}
function disConnDbMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    var webusername = trim(reqDb.webusername);
    var instanceid = trim(reqDb.instid);
    var dbname = trim(reqDb.dbname);

    if (!(webusername in clObject)) {
        callback(true, "connect_out");
        return;
    }

    if (!(instanceid in clObject[webusername])) {
        callback(true, "connect_out");
        return;
    }

    if (!(dbname in clObject[webusername][instanceid])) {
        callback(true, "connect_out");
        return;
    }
    var clObj = clObject[webusername][instanceid][dbname];
    var dbmonitorid = webusername + ":" + clObj.ip + ":" + clObj.port + ":" + clObj.dbname;
    emptyDbMonitorInfo(dbmonitorid);
    clObject[webusername][instanceid][dbname].cl.end();
    delete clObject[webusername][instanceid][dbname];

    callback(false);
}
function disConnectByInstMgr(instid) {
    if (typeof instid == "undefined" || instid == "") {
        return;
    }

    for (var item1 in clObject) {//webusername
        for (var item2 in clObject[item1]) {//instanceid
            for (var item3 in clObject[item1][item2]) {//dbname
                clObject[item1][item2][item3].cl.end();
            }
            delete clObject[item1][item2];
        }
    }
}
function queryDbOptMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    var webusername = trim(reqDb.webusername);
    var instanceid = trim(reqDb.instid);
    var dbname = trim(reqDb.dbname);

    if (!(webusername in clObject)) {
        callback(true, "connect_out");
        return;
    }
    if (!(instanceid in clObject[webusername])) {
        callback(true, "connect_out");
        return;
    }
    if (!(dbname in clObject[webusername][instanceid])) {
        callback(true, "connect_out");
        return;
    }

    clObject[webusername][instanceid][dbname].lastopttm = new Date().getTime();

    var sqlText = reqDb.sqlText;
    var sqlValue = reqDb.sqlValue;
    if (typeof sqlText != "string" || typeof sqlValue != "object") {
        callback(true, "dbinfo_error");
        return;
    }
    clObject[webusername][instanceid][dbname].cl.query(sqlText, sqlValue, function (isErr, rst) {
        if (isErr) {
            callback(isErr, "query_error");
            return;
        }
        callback(isErr, rst.rows);
    });
}
function execDbOptMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    var webusername = trim(reqDb.webusername);
    var instanceid = trim(reqDb.instid);
    var dbname = trim(reqDb.dbname);

    if (!(webusername in clObject)) {
        callback(true, "connect_out");
        return;
    }
    if (!(instanceid in clObject[webusername])) {
        callback(true, "connect_out");
        return;
    }
    if (!(dbname in clObject[webusername][instanceid])) {
        callback(true, "connect_out");
        return;
    }

    clObject[webusername][instanceid][dbname].lastopttm = new Date().getTime();

    var sqlText = reqDb.sqlText;
    var sqlValue = reqDb.sqlValue;
    if (typeof sqlText != "string" || typeof sqlValue != "object") {
        callback(true, "dbinfo_error");
        return;
    }
    clObject[webusername][instanceid][dbname].cl.query(sqlText, sqlValue, function (isErr, rst) {
        if (isErr) {
            callback(isErr, "exec_error");
            return;
        }
        callback(isErr, rst);
    });
}

function getAllConnectedDbMgr(reqDb, callback) {

    var webusername = trim(reqDb.webusername);

    if (!(webusername in clObject)) {
        callback(true, "connect_out");
        return;
    }

    var dataArr = [];
    var curDate = new Date().getTime();
    for (var instid in clObject[webusername]) {
        var instObj = {instanceid: instid, instancename: "", dbarr: []};
        for (var dbname in clObject[webusername][instid]) {
            instObj.instancename = clObject[webusername][instid][dbname].instname;
            instObj.dbarr.push(dbname);
            clObject[webusername][instid][dbname].lastopttm = curDate;
        }
        dataArr.push(instObj);
    }
    callback(false, dataArr);
    return;
}

function getAllCondbByInstanceMgr(reqDb, callback) {
    var webusername = trim(reqDb.webusername);
    var instanceid = trim(reqDb.instanceid);

    if (!(webusername in clObject)) {
        callback(true, "connect_out");
        return;
    }

    if (!(instanceid in clObject[webusername])) {
        callback(true, "connect_out");
        return;
    }

    var condbData = [];

    var condbObj = clObject[webusername][instanceid];

    var curDate = new Date().getTime();

    for (var item in condbObj) {
        var dbObj = {
            ip: condbObj[item].ip,
            port: condbObj[item].port,
            dbname: condbObj[item].dbname,
            encoding: condbObj[item].cl.encoding,
            webusername: webusername,
            instanceid: instanceid,
        }
        condbData.push(dbObj);
        clObject[webusername][instanceid][item].lastopttm = curDate;
    }
    callback(false, condbData);
}
function getThisInstConnectedDbMgr(dbData, callback) {
    if (typeof callback != "function") {
        return 1;
    }

    var webusername = trim(dbData.webusername);
    var instanceid = trim(dbData.instanceid);

    if (!(webusername in clObject)) {
        callback(true);
        return;
    }
    if (!(instanceid in clObject[webusername])) {
        callback(true);
        return;
    }
    callback(false, clObject[webusername][instanceid]);
}

function getDbHomePageInfoMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }
    var webusername = trim(reqDb.webusername);
    var instanceid = trim(reqDb.instanceid);
    var dbname = trim(reqDb.dbname);

    if (!(webusername in clObject)) {
        callback(true, "connect_out");
        return;
    }
    if (!(instanceid in clObject[webusername])) {
        callback(true, "connect_out");
        return;
    }
    if (!(dbname in clObject[webusername][instanceid])) {
        callback(true, "connect_out");
        return;
    }

    clObject[webusername][instanceid][dbname].lastopttm = new Date().getTime();

    var dbObj = clObject[webusername][instanceid][dbname];

    var dbmonitorid = webusername + ":" + dbObj.ip + ":" + dbObj.port + ":" + dbObj.dbname;

    var dbOpt = new myDbOpt();
    var sqlText = "select a.sessionnum,a.loginnum,a.cpuusage,a.memeryusage,a.diskusage,b.version,b.type,b.clsname," +
        "b.clspath,b.dfsurl,b.dfsdb from tbl_dbmonitor a,tbl_instance b where a.id = $1 and b.id = $2;";
    var sqlValue = [dbmonitorid, instanceid];
    dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
        if (isErr) {
            callback(isErr, "query_error");
            return;
        }

        if (count == 0) {
            sqlText = "select * from tbl_instance where id = $1;";
            sqlValue = [instanceid];
            dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
                if (isErr) {
                    callback(isErr, "query_error");
                    return;
                }
                if (count == 0) {
                    callback(false, []);
                    return;
                }
                rst[0].dbname = dbObj.dbname;
                rst[0].conntime = dbObj.conntime;
                rst[0].isNull = true;
                callback(isErr, rst);
            })
        } else {
            rst[0].dbname = dbObj.dbname;
            rst[0].conntime = dbObj.conntime;
            rst[0].isNull = false;
            callback(isErr, rst);
        }
    })
}

function dbMonitorMgr(reqDb, callback) {
    if (typeof callback != "function") {
        return 1;
    }
    var webusername = trim(reqDb.webusername);
    var instanceid = trim(reqDb.instanceid);
    var dbname = trim(reqDb.dbname);

    if (!(webusername in clObject)) {
        callback(true, "connect_out");
        return;
    }
    if (!(instanceid in clObject[webusername])) {
        callback(true, "connect_out");
        return;
    }
    if (!(dbname in clObject[webusername][instanceid])) {
        callback(true, "connect_out");
        return;
    }

    var dbObj = clObject[webusername][instanceid][dbname];
    var dbmonitorid = webusername + ":" + dbObj.ip + ":" + dbObj.port + ":" + dbObj.dbname;

    clObject[webusername][instanceid][dbname].lastopttm = new Date().getTime();

    var dbOpt = new myDbOpt();
    var sqlText = "select * from tbl_dbmonitor where id = $1;";
    var sqlValue = [dbmonitorid];
    dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
        if (isErr) {
            callback(isErr, "query_error");
            return;
        }
        if (count == 0) {
            callback(isErr, []);
            return;
        }
        callback(isErr, rst);
    })
}
function reqDbMonitorText() {
    reqDbMonitor();
    setTimeout(reqDbMonitorText, 1000)
}
var monitorDataInfo = {};
function reqDbMonitor() {
    for (var webuser in clObject) {
        for (var instid in clObject[webuser]) {
            for (var dbname in clObject[webuser][instid]) {
                var dbObj = clObject[webuser][instid][dbname];
                var dbmonitorid = webuser + ":" + dbObj.ip + ":" + dbObj.port + ":" + dbObj.dbname;
                monitorDataInfo[dbmonitorid] = {flag: 0, id: dbmonitorid};
                var clObj = dbObj.cl;
                reqAllSessionNum(clObj, dbmonitorid);
                reqAllLoginNum(clObj, dbmonitorid);
                reqOtherDbInfo(clObj, dbmonitorid);
                reqHostInfo(dbObj, dbmonitorid);
            }
        }
    }
}

function reqAllSessionNum(clObj, dbmonitorid) {
    var sqlText = "select count(1) from ux_stat_activity;";
    var sqlValue = [];
    clObj.query(sqlText, sqlValue, function (isErr, rst) {
        if (isErr) {
            console.log("query all session num faild!");
            monitorDataInfo[dbmonitorid].flag++;
            updateDbMonitorInfo(dbmonitorid);
        } else {
            monitorDataInfo[dbmonitorid].sessionnum = rst.rows[0].count;
            monitorDataInfo[dbmonitorid].flag++;
            updateDbMonitorInfo(dbmonitorid);
        }
    })
}

function reqAllLoginNum(clObj, dbmonitorid) {
    var sqlText = "select count(uid) from (select distinct usesysid as uid from ux_stat_activity) as userlist;";
    var sqlValue = [];
    clObj.query(sqlText, sqlValue, function (isErr, rst) {
        if (isErr) {
            console.log("query all login num faild!");
            monitorDataInfo[dbmonitorid].flag++;
            updateDbMonitorInfo(dbmonitorid);
        } else {
            monitorDataInfo[dbmonitorid].loginnum = rst.rows[0].count;
            monitorDataInfo[dbmonitorid].flag++;
            updateDbMonitorInfo(dbmonitorid);
        }
    })
}

function reqOtherDbInfo(clObj, dbmonitorid) {
    var sqlText = "select sum(blks_read) readblks , sum(blks_hit) hitblks , " +
        "sum(tup_inserted) insertnum , sum(tup_deleted) deletenum , sum(tup_updated) updatenum , " +
        "sum(tup_fetched) fetchnum , sum(tup_returned) returnnum , " +
        "sum(xact_commit) commitnum , sum(xact_rollback) rollbacknum from ux_stat_database;";
    var sqlValue = [];
    clObj.query(sqlText, sqlValue, function (isErr, rst) {
        if (isErr) {
            console.log("query other db info num faild!");
            monitorDataInfo[dbmonitorid].flag++;
            updateDbMonitorInfo(dbmonitorid);
        } else {
            if (rst.rowCount == 0) {
                console.log("error!");
                return;
            }
            var dataInfo = rst.rows[0];
            monitorDataInfo[dbmonitorid].readblks = dataInfo.readblks;
            monitorDataInfo[dbmonitorid].hitblks = dataInfo.hitblks;
            monitorDataInfo[dbmonitorid].insertnum = dataInfo.insertnum;
            monitorDataInfo[dbmonitorid].deletenum = dataInfo.deletenum;
            monitorDataInfo[dbmonitorid].updatenum = dataInfo.updatenum;
            monitorDataInfo[dbmonitorid].fetchnum = dataInfo.fetchnum;
            monitorDataInfo[dbmonitorid].returnnum = dataInfo.returnnum;
            monitorDataInfo[dbmonitorid].commitnum = dataInfo.commitnum;
            monitorDataInfo[dbmonitorid].rollbacknum = dataInfo.rollbacknum;
            monitorDataInfo[dbmonitorid].flag++;
            updateDbMonitorInfo(dbmonitorid);
        }
    })
}
function reqHostInfo(dbObj, dbmonitorid) {
    var ip = dbObj.ip;
    var dbOpt = new myDbOpt();
    var sqlText = "select ip,port,state from tbl_siteinfo where ip = $1;";
    var sqlValue = [ip];
    dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
        if (isErr || count == 0) {
            console.log("not find host info by db ip!");
            monitorDataInfo[dbmonitorid].flag++;
            updateDbMonitorInfo(dbmonitorid);
            return;
        }
        var dataInfo = rst[0];
        if (dataInfo.state != 1) {
            console.log("site " + dataInfo.ip + " is fault!");
            monitorDataInfo[dbmonitorid].flag++;
            updateDbMonitorInfo(dbmonitorid);
            return;
        }
        reqHostCpuUsage(dataInfo, function (isErr, hostInfo) {
            if (isErr) {
                console.log("req host " + dataInfo.ip + " cpuusage faild!");
                monitorDataInfo[dbmonitorid].flag++;
                updateDbMonitorInfo(dbmonitorid);
                return;
            }
            if (hostInfo.data.retcode == 0) {
                monitorDataInfo[dbmonitorid].cpuusage = hostInfo.data.cpusage;
            }
            reqHostMemUsage(dataInfo, function (isErr, hostInfo) {
                if (isErr) {
                    console.log("req host " + dataInfo.ip + " memeryusage faild!");
                    monitorDataInfo[dbmonitorid].flag++;
                    updateDbMonitorInfo(dbmonitorid);
                    return;
                }
                if (hostInfo.data.retcode == 0) {
                    monitorDataInfo[dbmonitorid].memeryusage = hostInfo.data.memusage;
                }
                reqHostDiskUsage(dataInfo, function (isErr, hostInfo) {
                    if (isErr) {
                        console.log("req host " + dataInfo.ip + " diskusage faild!");
                        monitorDataInfo[dbmonitorid].flag++;
                        updateDbMonitorInfo(dbmonitorid);
                        return;
                    }
                    if (hostInfo.data.retcode == 0) {
                        monitorDataInfo[dbmonitorid].diskusage = hostInfo.data.totalusage;
                    }
                    monitorDataInfo[dbmonitorid].flag++;
                    updateDbMonitorInfo(dbmonitorid);
                });
            });
        });
    })
}
function updateDbMonitorInfo(item) {
    var monitorPartNum = 4;
    if (monitorDataInfo[item].flag < monitorPartNum) {
        return;
    }
    var num = 0;
    for (var obj in monitorDataInfo[item]) {
        num++;
    }
    var allMonitorInfoFieldNum = 16;
    if (num < allMonitorInfoFieldNum) {
        console.log("db " + item + " monitor info is error!");
        delete monitorDataInfo[item];
        return;
    }
    var dbOpt = new myDbOpt();
    var sqlText = "select * from tbl_dbmonitor where id = $1;";
    var sqlValue = [item];
    dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
        if (isErr) {
            console.log("query db info from localdb faild!");
            delete monitorDataInfo[item];
            return;
        }

        sqlText = "";
        sqlValue = [];

        if (count == 0) {
            sqlText = "insert into tbl_dbmonitor values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15);"

            sqlValue.push(monitorDataInfo[item].id);
            sqlValue.push(monitorDataInfo[item].sessionnum);
            sqlValue.push(monitorDataInfo[item].loginnum);
            sqlValue.push(monitorDataInfo[item].readblks);
            sqlValue.push(monitorDataInfo[item].hitblks);
            sqlValue.push(monitorDataInfo[item].insertnum);
            sqlValue.push(monitorDataInfo[item].deletenum);
            sqlValue.push(monitorDataInfo[item].updatenum);
            sqlValue.push(monitorDataInfo[item].fetchnum);
            sqlValue.push(monitorDataInfo[item].returnnum);
            sqlValue.push(monitorDataInfo[item].commitnum);
            sqlValue.push(monitorDataInfo[item].rollbacknum);
            sqlValue.push(monitorDataInfo[item].cpuusage);
            sqlValue.push(monitorDataInfo[item].memeryusage);
            sqlValue.push(monitorDataInfo[item].diskusage);

        } else {
            sqlText = "update tbl_dbmonitor set sessionnum = $2,loginnum = $3,readblks = $4,hitblks = $5,insertnum = $6," +
                "deletenum = $7,updatenum = $8,fetchnum = $9,returnnum = $10,commitnum = $11,rollbacknum = $12,cpuusage = $13," +
                "memeryusage = $14,diskusage = $15 where id = $1;";

            var newData = restructureDbMonitorData(rst[0], monitorDataInfo[item]);

            sqlValue.push(newData.id);
            sqlValue.push(newData.sessionnum);
            sqlValue.push(newData.loginnum);
            sqlValue.push(newData.readblks);
            sqlValue.push(newData.hitblks);
            sqlValue.push(newData.insertnum);
            sqlValue.push(newData.deletenum);
            sqlValue.push(newData.updatenum);
            sqlValue.push(newData.fetchnum);
            sqlValue.push(newData.returnnum);
            sqlValue.push(newData.commitnum);
            sqlValue.push(newData.rollbacknum);
            sqlValue.push(newData.cpuusage);
            sqlValue.push(newData.memeryusage);
            sqlValue.push(newData.diskusage);

        }
        dbOpt.execSql(sqlText, sqlValue, function (isErr) {
            if (isErr) {
                console.log("update db monitor info faild!");
                return;
            }
            delete monitorDataInfo[item];
            console.log("update db info finshed!");
        })
    })
}
function restructureDbMonitorData(dbData, monitorInfo) {
    var arr = dbData.sessionnum.split(":");
    console.log("record length:" + arr.length);
    var dataValue = {};
    dataValue.id = dbData.id;
    dataValue.sessionnum = mergeJsonData(dbData.sessionnum, monitorInfo.sessionnum);
    dataValue.loginnum = mergeJsonData(dbData.loginnum, monitorInfo.loginnum);
    dataValue.readblks = mergeJsonData(dbData.readblks, monitorInfo.readblks);
    dataValue.hitblks = mergeJsonData(dbData.hitblks, monitorInfo.hitblks);
    dataValue.insertnum = mergeJsonData(dbData.insertnum, monitorInfo.insertnum);
    dataValue.deletenum = mergeJsonData(dbData.deletenum, monitorInfo.deletenum);
    dataValue.updatenum = mergeJsonData(dbData.updatenum, monitorInfo.updatenum);
    dataValue.fetchnum = mergeJsonData(dbData.fetchnum, monitorInfo.fetchnum);
    dataValue.returnnum = mergeJsonData(dbData.returnnum, monitorInfo.returnnum);
    dataValue.commitnum = mergeJsonData(dbData.commitnum, monitorInfo.commitnum);
    dataValue.rollbacknum = mergeJsonData(dbData.rollbacknum, monitorInfo.rollbacknum);
    dataValue.cpuusage = mergeJsonData(dbData.cpuusage, monitorInfo.cpuusage);
    dataValue.memeryusage = mergeJsonData(dbData.memeryusage, monitorInfo.memeryusage);
    dataValue.diskusage = mergeJsonData(dbData.diskusage, monitorInfo.diskusage);
    return dataValue;
}
function mergeJsonData(data, newData) {
    var dataArr = data.split(":");
    var maxRecordNum = 120;
    if (dataArr.length >= maxRecordNum) {
        dataArr.shift();
    }
    dataArr.push(newData);
    var dataStr = dataArr.join(":");
    return dataStr;
}

function emptyDbMonitorInfo(item) {
    var dbOpt = new myDbOpt();
    var sqlText = "";
    var sqlValue = [];
    if (typeof item == "undefined") {
        sqlText = "delete from tbl_dbmonitor;";
    } else {
        sqlText = "delete from tbl_dbmonitor where id = $1;";
        sqlValue = [item];
    }
    dbOpt.execSql(sqlText, sqlValue, function (isErr) {
        if (isErr) {
            console.log("empty dbmonitor data faild!");
        }
    })
}

function checkIsEmpty(dataObj) {
    if (typeof dataObj != "object") {
        console.log("check connected db error!");
        return false;
    }
    var isEmpty = true;
    for (var item in dataObj) {
        isEmpty = false;
        break;
    }
    if (isEmpty) {
        return true;
    } else {
        return false;
    }
}

function updateConnectedDb() {
    var curTime = new Date().getTime();
    console.log("This time:" + new Date().toLocaleString());

    for (var webuser in clObject) {
        for (var instid in clObject[webuser]) {
            for (var dbname in clObject[webuser][instid]) {
                var dbObj = clObject[webuser][instid][dbname];
                console.log("connecting dbuser:" + webuser + ":" + dbObj.instname + ":" + dbObj.ip + ":" + dbObj.port + ":" + dbname);
                var outTime = curTime - dbObj.lastopttm;
                if (outTime > clConfig.clTimeout) {
                    var dbmonitorid = webuser + ":" + dbObj.ip + ":" + dbObj.port + ":" + dbObj.dbname;
                    emptyDbMonitorInfo(dbmonitorid);
                    clObject[webuser][instid][dbname].cl.end();
                    delete clObject[webuser][instid][dbname];
                }
            }
            if (checkIsEmpty(clObject[webuser][instid])) {
                delete clObject[webuser][instid];
            }
        }
        if (checkIsEmpty(clObject[webuser])) {
            delete clObject[webuser];
        }
    }
    if (checkIsEmpty(clObject)) {
        clObject = {};
    }
}

var reqDbMonitorFlag = 0;
var clObjInterval = setInterval(function () {

    if (reqDbMonitorFlag > 1) {
        reqDbMonitor();
        reqDbMonitorFlag = 0;
    } else {
        reqDbMonitorFlag++;
    }
    updateConnectedDb();
}, clConfig.clCheckTime)

function trim(str) {
    if (typeof str != "string") {
        return "";
    } else {
        return str.replace(/(^\s+)|(\s+$)/g, "");
    }
}

//clearInterval(clObjInterval);

emptyDbMonitorInfo();

function startListen() {
    var listen = require('../../listenandsendrequest');
    var listenObj = new listen();
    listenObj.startServer(reqDbMonitorText, "12302");
}
//startListen();