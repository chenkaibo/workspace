﻿var MyDbOpt = require('../common/dbopt');

/** DB用户管理模块...**/
var _dbOpt;
var sysUserMgr = (function()
{
    var _inst;
    function sysUserOpt()
    {
        _dbOpt = new MyDbOpt();
        return{
            newUserMgr:newUserMgr,
            delUserMgr:delUserMgr,
            modUserMgr:modUserMgr,
            queryUserMgr:queryUserMgr,
            verifyUserMgr:verifyUserMgr,
        }
    }
    return{
        getInstance: function()
        {
            if(_inst === undefined)
            {
                _inst = new sysUserOpt();
            }
            return _inst;
        }
    }
})();
function newUserMgr(newUser,callback){
    if(typeof callback !== "function")
    {
        return 0;
    }
    var sqlInsert = "INSERT INTO tbl_user " +
        "(username,usertype,password,createtime,lastmodtime) VALUES ($1,$2,$3,$4,$5);";
    var sqlValue = new Array();
    sqlValue[0] = newUser.username;
    sqlValue[1] = newUser.userrole || "0";
    sqlValue[2] = newUser.userpwd;
    sqlValue[3] = newUser.time;
    sqlValue[4] = newUser.time;

    _dbOpt.execSql(sqlInsert,sqlValue,function(error)
    {
        callback(error);
    });
    return 1;
}
function delUserMgr(userArr,callback){
    if(typeof callback !== "function")
    {
        return 0;
    }
    var sqlText = "DELETE FROM tbl_user WHERE username in(" + userArr + ");";
    var sqlValue = [];
    _dbOpt.execSql(sqlText,sqlValue,function(error)
    {
        callback(error);
    });
    return 1;
}
function modUserMgr(userinfo,callback){
    if(typeof callback !== "function")
    {
        return 0;
    }

    var sqlText = "UPDATE tbl_user SET password = $1,lastmodtime = $2 WHERE username = $3";
    var sqlValue = new Array();
    sqlValue.push(userinfo.userpwd);
    sqlValue.push(userinfo.time);
    sqlValue.push(userinfo.username);

    _dbOpt.execSql(sqlText,sqlValue,function(error)
    {
        callback(error);
    });
    return 1;
}
function queryUserMgr(userInfo,callback){
    if(typeof callback !== "function")
    {
        return 0;
    }

    var sqlText = "SELECT * FROM tbl_user where 1=1";
    var sqlValue = [];

    var num = 1;
    if(userInfo.role == 1){//普通用户
        sqlText += " and username = $" + (num++);
        sqlValue.push(userInfo.name);
    }else{//管理员
        if(userInfo.userNameFlag){
            sqlText += " and username like $" + (num++);
            sqlValue.push("%" + userInfo.userName + "%");
        }
        if(userInfo.userRoleFlag){
            sqlText += " and usertype = $" + (num++);
            sqlValue.push(userInfo.userRole);
        }
    }
    sqlText += " ORDER BY username;";

    console.log("sqlText:" + sqlText);
    console.log("sqlValue:" + sqlValue);

    _dbOpt.querySql(sqlText,sqlValue,function(error,count,rst)
    {
        if(error)
        {
            callback(error);
            return;
        }
        if(count == 0){
            callback(error,[]);
            return;
        }
        callback(error,rst);
    });
}

function verifyUserMgr(userInfo,callback){
    if(typeof callback != "function"){
        return 1;
    }
    var sqlText = "select * from tbl_user where username = $1 and password = $2;";
    var sqlValue = [userInfo.name,userInfo.pwd];
    _dbOpt.querySql(sqlText,sqlValue,function(isErr,count,rst){
        if(isErr){
            callback(isErr);
            return;
        }
        if(count == 0 ){
            callback(false,[]);
            return;
        }
        callback(false,rst);
    })
}

module.exports = sysUserMgr;

/*
 unit test
 */
if(0){
    _dbOpt = new MyDbOpt();
    function addUser_test()
    {
        var userInfo = {};
        userInfo.name = "security";
        userInfo.role = "1";
        userInfo.pwd = "123456";
        userInfo.time = new Date().toLocaleString();
        addUserMgr(userInfo,function(error){
            if(error){
                console.log("add user failed!");
                console.log("[add user]:"+error.detail);
            }else{
                console.log("add user success!");
            }
        });
    }
    function modifyUser_test()
    {
        var userInfo = {};
        userInfo.name = "admin";
        userInfo.pwd = "666666";
        userInfo.time = new Date().toLocaleString();

        modUserMgr(userInfo,function(error){
            if(error){
                console.log("modify passwd failed!")
                console.log(error.detail);
            }else{
                console.log("modify passwd success!");
            }
        })
    }
    function queryUser_test()
    {
        var userInfo = {
            name: "admin",
            type: "1"
        }
        queryUserMgr(userInfo,function(error,rows){
            if(error){
                console.log("query user failed!");
                console.log("[query user]:"+error.detail);
            }else{
                console.log("query user success!");
                console.log("userInfo:"+JSON.stringify(rows));
            }
        });
    }
    function delUser_test()
    {
        var userInfo = ["\'admin\'","\'security\'"];
        delUserMgr(userInfo,function(error){
            if(error){
                console.log("delete user failed!");
                console.log("[del user]:"+error.detail);
            }else{
                console.log("delete user success!");
            }
        })
    }
    addUser_test();
    //modifyUser_test();
    //queryUser_test();
    //delUser_test();
}