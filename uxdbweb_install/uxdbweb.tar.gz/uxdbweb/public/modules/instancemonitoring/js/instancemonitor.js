'use strict';
var sessionData = {
    "data_arr": [],
    "host_name_map":{
        "sessionCount":"会话总数",
        "inlineCount":"在线用户数"
    },
    "maxValueUnit":"个",
    "maxFlag":false
};
var blockData = {
    "data_arr": [],
    "host_name_map":{
        "bliks_hit":"bliks_hit",
        "bliks_read":"bliks_read"
    },
    "maxValueUnit":"个",
    "maxFlag":false
};
var tableData = {
    "data_arr": [],
    "host_name_map":{
        "Inserted":"Inserted",
        "Delete":"Delete",
        "Updated":"Updated",
        "Fetched":"Fetched",
        "Returned":"Returned"
    },
    "maxValueUnit":"个",
    "maxFlag":false
};
var affairData = {
    "data_arr": [],
    "host_name_map":{
        "Rollback":"Rollback",
        "Commit":"Commit"
    },
    "maxValueUnit":"个",
    "maxFlag":false
};
var cpuData = {
    "data_arr":[],
    "host_name_map":{
        "cpu":"cpu"
    },
    "maxFlag":false
};
var memoryData = {
    "data_arr":[],
    "host_name_map":{
        "memory":"memory"
    },
    "maxFlag":false
};
var diskData = {
    "data_arr":[],
    "host_name_map":{
        "disk":"disk"
    },
    "maxFlag":false
};
var reflashTime = 30,setReflashFun;
window.onload = function(){
    //window.parent.menuOperFun();
    top.d3.select("#leftDivId").classed("no-display",true);
    top.d3.select("#topMenuLi4").classed("top-del-menu",true); //去掉顶部数据库选择菜单
    /**会话监控元素**/
    initInsMonitorData();
    getInstantMonitorElem("#insMonitor");
};
function initInsMonitorData()
{
    for(var k = 0;k < 60 ; k++)
    {
        var sessionInfo = {
            "day":k,
            "sessionCount":0,
            'inlineCount':0
        };
        sessionData.data_arr.push(sessionInfo);
        var blockInfo = {
            "day":k,
            "bliks_hit":0,
            'bliks_read':0
        };
        blockData.data_arr.push(blockInfo);
        var tableInfo = {
            "day":k,
            "Inserted":0,
            'Delete':0,
            'Updated':0,
            'Fetched':0,
            'Returned':0
        };
        tableData.data_arr.push(tableInfo);
        var affairInfo = {
            "day":k,
            "Rollback":0,
            'Commit':0
        };
        affairData.data_arr.push(affairInfo);
        var cpuInfo = {
            "day":k,
            "cpu":0
        };
        cpuData.data_arr.push(cpuInfo);
        var diskInfo = {
            "day":k,
            "memory":0
        };
        memoryData.data_arr.push(diskInfo);
        var memInfo = {
            "day":k,
            "disk":0
        };
        diskData.data_arr.push(memInfo);
    }
}
/**获取监控实例的数据**/
function getInstanceMonitorData()
{
    /*
     * 请求的命令
     * */
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbmanage",
        request :{"mainRequest":"dbMonitor","subRequest":"","ssubRequest":""},
        data    :{
            webusername: window.sessionStorage.ux_curUserName,
            instanceid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,getInstanceMonitorDataCallback);
}
function getInstanceMonitorDataCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        /**session数据**/
        var sessionInfo = [retJsonStr.data.sessionNum,retJsonStr.data.loginNum];
        var sessionDataUnit = tempFun(sessionInfo,120);
        var sessionUnitStr = sessionDataUnit.unitStr;
        var sessionUnitValue = sessionDataUnit.unitValue;
        sessionData.maxValueUnit = sessionUnitStr;
        sessionData.maxFlag = sessionDataUnit.maxFlag;
        /**block数据**/
        var blockInfo = [retJsonStr.data.hitBlks,retJsonStr.data.readBlks];
        var blockDataUnit = tempFun(blockInfo,120);
        var unitStr = blockDataUnit.unitStr;
        var unitValue = blockDataUnit.unitValue;
        blockData.maxValueUnit = unitStr;
        blockData.maxFlag = blockDataUnit.maxFlag;
        /**事务数据**/
        var affairInfo = [retJsonStr.data.rollbackNum,retJsonStr.data.commitNum];
        var affairDataUnit = tempFun(affairInfo,120);
        var affairUnitStr = affairDataUnit.unitStr;
        var affairUnitValue = affairDataUnit.unitValue;
        affairData.maxValueUnit = affairUnitStr;
        affairData.maxFlag = affairDataUnit.maxFlag;
        /**表数据**/
        var tableInfo = [retJsonStr.data.insertNum,retJsonStr.data.deleteNum,retJsonStr.data.updateNum,retJsonStr.data.fetchNum,retJsonStr.data.returnNum];
        var tableDataUnit = tempFun(tableInfo,120);
        var tableUnitStr = tableDataUnit.unitStr;
        var tableUnitValue = tableDataUnit.unitValue;
        tableData.maxValueUnit = tableUnitStr;
        tableData.maxFlag = affairDataUnit.maxFlag;

        /**cpu数据**/
        var cpuInfo = [retJsonStr.data.cpuUsage];
        var cpuDataUnit = tempFun(cpuInfo,100);
        cpuData.maxFlag = cpuDataUnit.maxFlag;
        /**内存数据**/
        var memInfo = [retJsonStr.data.memeryUsage];
        var memDataUnit = tempFun(memInfo,100);
        memoryData.maxFlag = memDataUnit.maxFlag;
        /**磁盘数据**/
        var diskInfo = [retJsonStr.data.diskUsage];
        var diskDataUnit = tempFun(diskInfo,100);
        diskData.maxFlag = diskDataUnit.maxFlag;
       //会话控制数据
       for(var  k = 0 ;k<retJsonStr.data.sessionNum.length ; k++)
       {
           sessionData.data_arr[k].sessionCount = retJsonStr.data.sessionNum[k]/sessionUnitValue;
           sessionData.data_arr[k].inlineCount = retJsonStr.data.loginNum[k]/sessionUnitValue;
           blockData.data_arr[k].bliks_hit = retJsonStr.data.hitBlks[k]/unitValue;
           blockData.data_arr[k].bliks_read = retJsonStr.data.readBlks[k]/unitValue;
           tableData.data_arr[k].Inserted = retJsonStr.data.insertNum[k]/tableUnitValue;
           tableData.data_arr[k].Delete = retJsonStr.data.deleteNum[k]/tableUnitValue;
           tableData.data_arr[k].Updated = retJsonStr.data.updateNum[k]/tableUnitValue;
           tableData.data_arr[k].Fetched = retJsonStr.data.fetchNum[k]/tableUnitValue;
           tableData.data_arr[k].Returned = retJsonStr.data.returnNum[k]/tableUnitValue;
           affairData.data_arr[k].Rollback = retJsonStr.data.rollbackNum[k]/affairUnitValue;
           affairData.data_arr[k].Commit = retJsonStr.data.commitNum[k]/affairUnitValue;
           cpuData.data_arr[k].cpu = retJsonStr.data.cpuUsage[k];
           memoryData.data_arr[k].memory = retJsonStr.data.memeryUsage[k];
           diskData.data_arr[k].disk = retJsonStr.data.diskUsage[k];
       }
        clearInterval(setReflashFun);
        setReflashFun = setInterval(getInstanceMonitorData,reflashTime * 1000);
    }else{
        clearInterval(setReflashFun);
        if(retJsonStr.desc == "connect_out")
        {
            uxAlert("数据库已断开，请重新连接！",true);
        }else{
            uxAlert("实例监控获取失败！");
        }
    }
    linePartElem("#mainContainDiv");
}
/**
 * 功能说明：得到每个数组的最大值，并且相应缩小所显示的数值
 * **/
function tempFun(dataArr,defaultData)
{
    var maxValue =  d3.max(dataArr[0],function(a){
        return +a;
    });
    for(var k = 0 ;k <dataArr.length; k++)
    {
        var maxValueOne = d3.max(dataArr[k],function(a){
             return +a;
        });
        maxValue = (maxValue > maxValueOne) ? (maxValue):(maxValueOne);
    }
    var blockDataUnit = getMaxData(maxValue,defaultData);
    return blockDataUnit;
}
function getMaxData(data,defaultData)
{
    var unitInfo = {
        'unitStr':'',
        'unitValue':1,
        'maxFlag':false
    };
    unitInfo.maxFlag = (data > defaultData) ? (true):(false);
    var dataStr = data.toString();
    var dataStrLength = dataStr.length;
    var n = dataStrLength - 3;//图形Y轴显示数值最大为3位数
    if(n <= 0)
    {
        unitInfo.unitStr = "";
        unitInfo.unitValue = 1;
    }else{
        if(n == 1)
        {
            unitInfo.unitStr = "<tspan>/10</tspan>";
        }else{
            unitInfo.unitStr = "<tspan>/10<tspan baseline-shift='super'>" + n + "</tspan></tspan>";
        }
        unitInfo.unitValue = Math.pow(10,n);
    }
    return unitInfo;
}
/*获取界面元素*/
function getInstantMonitorElem(contain)
{
    window.focus();
    window.sessionStorage.ux_pagePath = "monitor,insMonitor";
    changePath("监控->实例监控");
    d3.select("#mainContainDiv").remove();
    var insMonitor = d3.select(contain)
        .append("div")
        .attr({
            'id':'mainContainDiv',
            'class':'siteList-content db-manage-div'
        });

    /**刷新按钮**/
    var buttonDiv = insMonitor.append("div").attr({"class":"button-div"});
    buttonDiv.append("button")
        .attr({"class":"btn btn-default admitClick choice-btn"})
        .on("click",function(){
            //d3.select("#mainContainDiv").style("overflow","hidden");
            getChoiceInsTable();
        })
        .html("选择实例");
    var refrashSelect = buttonDiv.append("select")
         .attr({
            'id':'reflashTimeId',
            "class":"select-type"
        });
    var timeArry = ["30s刷新一次","60s刷新一次","300s刷新一次"];
    for(var k = 0;k<timeArry.length; k++)
    {
        refrashSelect.append("option")
            .attr({"class":"option-all"})
            .html(timeArry[k]);
    }
    buttonDiv.append("button")
        .attr({
            "id":"executeBtn",
            "class":"btn btn-default admitClick"
        })
        .on("click",function(){
            var timeArr = [30,60,300];
            var selectedTimeIndex = d3.select("#reflashTimeId")[0][0].selectedIndex;
            reflashTime = timeArr[selectedTimeIndex];
            getInstanceMonitorData();
        })
        .html("刷&nbsp;&nbsp;新");
    getInstanceMonitorData();
    linePartElem("#mainContainDiv");
}
function linePartElem(contain)
{
    d3.select("#session-div-id").remove();
    d3.select("#databaseId").remove();
    d3.select("#capabilityId").remove();
    /**会话监控**/
    var sessionDiv = d3.select(contain).append("div")
        .attr({
            'id':'session-div-id',
            "class":"session-div"
        });
    var sessionFieldset = sessionDiv.append("fieldset")
        .attr({"class":"sessionFieldset"});
    sessionFieldset.append("legend").html("会&nbsp;话&nbsp;控&nbsp;制");
    sessionFieldset.append("button")
        .attr({
            "class":"session-ctl-icon sessionFlagShow"
        })
        .on("click",function(){
            if(d3.select(this).classed("sessionFlagShow"))
            {
                d3.select("#sessionContainId").classed("sessionHide",true);
                d3.select("#sessionContainId").classed("sessionShow",false);
                d3.select("#session-div-id").classed("session-div-hide",true);
                d3.select("#session-div-id").classed("session-div-show",false);
                //d3.select("#sessionTitle").classed("session-title-hide",true);
                //d3.select("#sessionTitle").classed("session-title-show",false);
                d3.select(this).classed("control-btn-hide sessionFlagHide",true);
                d3.select(this).classed("sessionFlagShow control-btn-show",false);
            }else {
                d3.select("#sessionContainId").classed("sessionHide",false);
                d3.select("#sessionContainId").classed("sessionShow",true);
                d3.select("#session-div-id").classed("session-div-hide",false);
                d3.select("#session-div-id").classed("session-div-show",true);
                //d3.select("#sessionTitle").classed("session-title-hide",false);
                //d3.select("#sessionTitle").classed("session-title-show",true);
                d3.select(this).classed("control-btn-hide sessionFlagHide",false);
                d3.select(this).classed("sessionFlagShow control-btn-show",true);
            }
        });
    sessionFieldset.append("div")
        .attr({
            "id":"sessionContainId",
            "class":"session-contain-div"
        });
    getSessionElem(".session-contain-div");
    /**数据库监控**/
    var databaseDiv = d3.select(contain).append("div")
        .attr({
            'id':'databaseId',
            "class":"database-div"
        });
    var databaseFieldset = databaseDiv.append("fieldset").attr({"class":"databaseFieldset"});
    databaseFieldset.append("legend").html("数据库监控");
    databaseFieldset.append("button")
        .attr({
            "class":"session-ctl-icon sessionFlagShow"
        })
        .on("click",function(){
            if(d3.select(this).classed("sessionFlagShow"))
            {
                d3.select("#databaseContainId").classed("sessionHide",true);
                d3.select("#databaseContainId").classed("sessionShow",false);
                d3.select("#databaseId").classed("session-div-hide",true);
                d3.select("#databaseId").classed("session-div-show",false);
                d3.select("#capabilityId").classed("capability-margin-hide",true);
                d3.select("#capabilityId").classed("capability-margin-show",false);
                d3.select("#blockLineChartCon").classed("line-hide",true);
                d3.select("#blockLineChartCon").classed("line-show",false);
                d3.select("#tableLineChartCon").classed("line-hide",true);
                d3.select("#tableLineChartCon").classed("line-show",false);
                d3.select("#affairLineChartCon").classed("line-hide",true);
                d3.select("#affairLineChartCon").classed("line-show",false);
                d3.select(this).classed("control-btn-hide sessionFlagHide",true);
                d3.select(this).classed("sessionFlagShow control-btn-show",false);
            }else {
                d3.select("#databaseContainId").classed("sessionHide",false);
                d3.select("#databaseContainId").classed("sessionShow",true);
                d3.select("#databaseId").classed("session-div-hide",false);
                d3.select("#databaseId").classed("session-div-show",true);
                d3.select("#capabilityId").classed("capability-margin-hide",false);
                d3.select("#capabilityId").classed("capability-margin-show",true);
                d3.select("#blockLineChartCon").classed("line-hide",false);
                d3.select("#blockLineChartCon").classed("line-show",true);
                d3.select("#tableLineChartCon").classed("line-hide",false);
                d3.select("#tableLineChartCon").classed("line-show",true);
                d3.select("#affairLineChartCon").classed("line-hide",false);
                d3.select("#affairLineChartCon").classed("line-show",true);
                d3.select(this).classed("control-btn-hide sessionFlagHide",false);
                d3.select(this).classed("sessionFlagShow control-btn-show",true);
            }
        });
    databaseFieldset.append("div")
        .attr({
            "id":"databaseContainId",
            "class":"database-contain-div"
        });
    getDatabaseElem(".database-contain-div");
    getTableElem(".database-contain-div");
    getAffairElem(".database-contain-div");

    /**性能监控**/
    var capabilityDiv = d3.select(contain).append("div")
        .attr({
            "id":"capabilityId",
            "class":"capability-div"
        });
    var capabilityFieldset = capabilityDiv.append("fieldset").attr({"class":"capabilityFieldset"});
    capabilityFieldset.append("legend").html("性&nbsp;能&nbsp;监&nbsp;控");
    capabilityFieldset.append("button")
        .attr({
            "class":"session-ctl-icon sessionFlagShow"
        })
        .on("click",function(){
            if(d3.select(this).classed("sessionFlagShow"))
            {
                d3.select("#capabilityContainId").classed("sessionHide",true);
                d3.select("#capabilityContainId").classed("sessionShow",false);
                d3.select("#capabilityId").classed("session-div-hide",true);
                d3.select("#capabilityId").classed("session-div-show",false);
                d3.select("#cpuLineChartCon").classed("line-hide",true);
                d3.select("#cpuLineChartCon").classed("line-show",false);
                d3.select("#memoryLineChartCon").classed("line-hide",true);
                d3.select("#memoryLineChartCon").classed("line-show",false);
                d3.select("#diskLineChartCon").classed("line-hide",true);
                d3.select("#diskLineChartCon").classed("line-show",false);
                d3.select(this).classed("control-btn-hide sessionFlagHide",true);
                d3.select(this).classed("sessionFlagShow control-btn-show",false);
                d3.select("#capabilityContainId").style({"display":"none"});
                //d3.select("#capabilityId").classed("capability-margin-hide",false);
                //d3.select("#capabilityId").classed("capability-margin-show",true);
            }else {
                d3.select("#capabilityContainId").classed("sessionHide",false);
                d3.select("#capabilityContainId").classed("sessionShow",true);
                d3.select("#capabilityId").classed("session-div-hide",false);
                d3.select("#capabilityId").classed("session-div-show",true);
                d3.select("#cpuLineChartCon").classed("line-hide",false);
                d3.select("#cpuLineChartCon").classed("line-show",true);
                d3.select("#memoryLineChartCon").classed("line-hide",false);
                d3.select("#memoryLineChartCon").classed("line-show",true);
                d3.select("#diskLineChartCon").classed("line-hide",false);
                d3.select("#diskLineChartCon").classed("line-show",true);
                d3.select(this).classed("control-btn-hide sessionFlagHide",false);
                d3.select(this).classed("sessionFlagShow control-btn-show",true);
                d3.select("#capabilityContainId").style({"display":"block"});
                //d3.select("#capabilityId").classed("capability-margin-hide",false);
                //d3.select("#capabilityId").classed("capability-margin-show",true);
            }
        });
    capabilityFieldset.append("div")
        .attr({
            "id":"capabilityContainId",
            "class":"capability-contain-div"
        });
    getCpuRateElem(".capability-contain-div");
    getMemoryRateElem(".capability-contain-div");
    getDiskRateElem(".capability-contain-div");
}
function getSessionElem(contain)
{
    d3.select(contain).append('div')
        .attr({
            //'id':'sessionTitle',
            'class':'db-per-head db-manage-head'
        })
        .text('会话监控');
    d3.select(contain).append('div')
        .attr({
            'class':'line-chart-div',
            'id':'lineChartCon'
        });
    var DataOptions = {
        'containerId':'lineChartCon',
        'data':sessionData,
        'colorArr':["#99CC33","#FF6600"],
        //'margin':{top: 30, right: 30, bottom: 30, left: 30},
        'margin':{top: 30, right: 30, bottom: 30, left: 30},
        'legendWidth':'10',
        'axisName' : ["个数" + sessionData.maxValueUnit,"min"],
        'legendPosition':false,//右侧图示
        'leftPosition':'1520',
        'topPosition':'-90',
        //'titleContent':'测试测试',
        'titleHeight':'20',
        'hasMaxY':sessionData.maxFlag,
        'unit':"个",
        'order':sessionData.maxValueUnit,
        'defaultY':120,
        'hasArea':true,
        'hasPoint':true,
        'hasOddNum':false,
        'hasTitleIcon':true,
        'topTipX':20,
        'xDomain':[0,60],//默认的x的比例尺的自变量
        'yDomain':[1,100]//默认的y比例尺的自变量
    };
    drawBlockLineChart(DataOptions);
}
/**数据库监控**/
function getDatabaseElem(contain)
{
    window.focus();
    d3.select(contain).append('div')
        .attr({
            'class':'db-per-head db-manage-head'
        })
        .text('block使用情况');
    d3.select(contain).append('div')
        .attr({
            'class':'line-chart-div',
            'id':'blockLineChartCon'
        });
    var blockDataOptions = {
        'containerId':'blockLineChartCon',
        'data':blockData,
        'colorArr':["#D2AA82","#036FCF"],
        'margin':{top: 50, right: 30, bottom: 40, left: 30},
        'legendWidth':'10',
        'axisName' : ["个数"+blockData.maxValueUnit,"min"],
        'legendPosition':false,//右侧图示
        'leftPosition':'1510',
        'topPosition':'-90',
        //'titleContent':'测试测试',
        'titleHeight':'0',
        'hasMaxY':blockData.maxFlag,
        'defaultY':120,
        'unit':"个",
        'order':blockData.maxValueUnit,
        'hasArea':true,
        'hasPoint':true,
        'hasOddNum':false,
        'hasTitleIcon':true,
        'topTipX':20,
        'xDomain':[0,60],//默认的x的比例尺的自变量
        'yDomain':[1,100]//默认的y比例尺的自变量
    };
    drawBlockLineChart(blockDataOptions);
}
function getTableElem(contain)
{
    d3.select(contain).append('div')
        .attr({
            'class':'db-per-head db-manage-head'
        })
        .text('表数据监控');
    d3.select(contain).append('div')
        .attr({
            'class':'line-chart-div',
            'id':'tableLineChartCon'
        });
    var tableDataOptions = {
        'containerId':'tableLineChartCon',
        'data':tableData,
        'colorArr':["#8B65FF","#FFCC99","#0088FF","#339966","#76E5FF"],
        //'margin':{top: 30, right: 30, bottom: 30, left: 30},
        'margin':{top: 50, right: 30, bottom: 40, left: 30},
        'legendWidth':'10',
        'axisName' : ["个数"+tableData.maxValueUnit+"","min"],
        'legendPosition':false,//右侧图示
        'leftPosition':'1250',
        'topPosition':'-90',
        'titleHeight':'0',
        'unit':"个",
        'order':tableData.maxValueUnit,
        'hasMaxY':tableData.maxFlag,
        'defaultY':120,
        'hasArea':true,
        'hasPoint':false,
        'hasOddNum':false,
        'hasTitleIcon':true,
        'topTipX':20,
        'xDomain':[1,60],//默认的x的比例尺的自变量
        'yDomain':[1,100]//默认的y比例尺的自变量
    };
    drawBlockLineChart(tableDataOptions);
}
function getAffairElem(contain)
{
    d3.select(contain).append('div')
        .attr({
            'class':'db-per-head db-manage-head'
        })
        .text('事务监控');
    d3.select(contain).append('div')
        .attr({
            'class':'line-chart-div',
            'id':'affairLineChartCon'
        });
    var affairDataOptions = {
        'containerId':'affairLineChartCon',
        'data':affairData,
        'colorArr':["#339966","#FF99FF"],
        //'margin':{top: 30, right: 30, bottom: 30, left: 30},
        'margin':{top: 50, right: 30, bottom: 40, left: 30},
        'legendWidth':'10',
        'axisName' : ["个数"+affairData.maxValueUnit+"","min"],
        'legendPosition':false,//右侧图示
        'leftPosition':'1510',
        'topPosition':'-90',
        //'titleContent':'测试测试',
        'titleHeight':'0',
        'unit':"个",
        'order':affairData.maxValueUnit,
        'hasMaxY':affairData.maxFlag,
        'defaultY':120,
        'hasArea':true,
        'hasPoint':true,
        'hasOddNum':false,
        'hasTitleIcon':true,
        'topTipX':20,
        'xDomain':[0,60],//默认的x的比例尺的自变量
        'yDomain':[1,100]//默认的y比例尺的自变量
    };
    drawBlockLineChart(affairDataOptions);
}
/**性能监控**/
function getCpuRateElem(contain)
{
    d3.select(contain).append('div')
        .attr({
            'class':'db-per-head db-manage-head'
        })
        .text('cpu使用率');
    d3.select(contain).append('div')
        .attr({
            'class':'line-chart-div',
            'id':'cpuLineChartCon'
        });
    var cpuOptions = {
        'containerId':'cpuLineChartCon',
        'data':cpuData,
        'colorArr':["#9900CC"],
        //'margin':{top: 30, right: 30, bottom: 30, left: 30},
        'margin':{top: 60, right: 30, bottom: 60, left: 30},
        'legendWidth':'10',
        'axisName' : ["利用率/%","min"],
        'legendPosition':false,//右侧图示
        'leftPosition':'1400',
        'topPosition':'-90',
        //'titleContent':'测试测试',
        //'titleHeight':'20',
        'titleHeight':'-10',
        'hasMaxY':cpuData.maxFlag,
        'unit':"%",
        'order':"",
        'defaultY':100,
        'hasArea':true,
        'hasPoint':true,
        'hasOddNum':false,
        'hasTitleIcon':false,
        'topTipX':20,
        'xDomain':[1,60],//默认的x的比例尺的自变量
        'yDomain':[1,100]//默认的y比例尺的自变量
    };
    drawBlockLineChart(cpuOptions);
}
function getMemoryRateElem(contain)
{
    d3.select(contain).append('div')
        .attr({
            'class':'db-per-head db-manage-head'
        })
        .text('内存使用率');
    d3.select(contain).append('div')
        .attr({
            'class':'line-chart-div',
            'id':'memoryLineChartCon'
        });
    var memoryOptions = {
        'containerId':'memoryLineChartCon',
        'data':memoryData,
        'colorArr':["#57D1F7"],
        'margin':{top: 60, right: 30, bottom: 60, left: 30},
        'legendWidth':'10',
        'axisName' : ["利用率/%","min"],
        'legendPosition':false,//右侧图示
        'leftPosition':'1400',
        'topPosition':'-90',
        'unit':"%",
        'order':"",
        'titleHeight':'-10',
        'hasMaxY':memoryData.maxFlag,
        'defaultY':100,
        'hasArea':true,
        'hasPoint':true,
        'hasOddNum':false,
        'hasTitleIcon':false,
        'topTipX':20,
        'xDomain':[1,60],//默认的x的比例尺的自变量
        'yDomain':[1,100]//默认的y比例尺的自变量
    };
    drawBlockLineChart(memoryOptions);
}
function getDiskRateElem(contain)
{
    d3.select(contain).append('div')
        .attr({
            'class':'db-per-head db-manage-head'
        })
        .text('磁盘使用率');
    d3.select(contain).append('div')
        .attr({
            'class':'line-chart-div',
            'id':'diskLineChartCon'
        });
    var diskOptions = {
        'containerId':'diskLineChartCon',
        'data':diskData,
        'colorArr':["#795AE1"],
        'margin':{top: 60, right: 30, bottom: 60, left: 30},
        'legendWidth':'10',
        'axisName' : ["利用率/%","min"],
        'legendPosition':false,//右侧图示
        'leftPosition':'1400',
        'topPosition':'-90',
        'unit':"%",
        'order':"",
        'titleHeight':'-10',
        'hasMaxY':diskData.maxFlag,
        'defaultY':100,
        'hasArea':true,
        'hasPoint':true,
        'hasOddNum':false,
        'hasTitleIcon':false,
        'topTipX':20,
        'xDomain':[1,60],//默认的x的比例尺的自变量
        'yDomain':[1,100]//默认的y比例尺的自变量
    };
    drawBlockLineChart(diskOptions);
}
function drawBlockLineChart (DataOptions){
    lineChartFun(DataOptions,function(){});
}
/**********************************实例监控表格******************************************/
function getChoiceInsTable()
{
    var className;
    getChoiceInsTableElem();
    if(d3.select("#dialogInsChoice").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgInsChoice').fadeIn(300);
    $('#dialogInsChoice').removeAttr('class').addClass('animated '+className+'').fadeIn();
}
function getChoiceInsTableElem()
{
    d3.select("#dialogBgInsChoice").remove();
    d3.select("#dialogInsChoice").remove();
    d3.select("#mainContainDiv").append("div")
        .attr("id","dialogBgInsChoice");
    var outPage = d3.select("#mainContainDiv").append("div")
        .attr("id","dialogInsChoice");
    var editFrom = outPage.append("div")
        .attr("id","editFromInsChoice");
    var newUserItemSpan = editFrom.append("span")
        .attr("id","newUserItemSpanInsChoice")
        .html("请选择实例：");
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos");
    var queryDiv = editFormUl
        .append("div")
        .attr({
            "class":'query-choice-ins'
        });
    //queryDiv.append("span")
    //    .html("实例名称：");
    var selectItem = queryDiv.append("select")
        .attr({
            'id':'choiceSelectItem',
            'class':'selectStyle insInputClass',
            'onchange':'changeOper()'
        });
    var item = ['实例名称','实例ID'];
    for(var k = 0;k <item.length; k++)
    {
        selectItem.append("option")
            .html(item[k]);
    }
    queryDiv.append("input")
        .attr({
            'id':'queryName',
            'type':'text',
            'class':'ipt'
        });
    queryDiv.append("button")
        .attr("class","btn btn-sm btn-bg-color searchSite-btn")
        .on("click",function(){
            queryInstance();
        })
        .attr("title","查找");

    editFormUl.append("div")
        .attr("class","ins-choice-table-div")
        .append("table")
        .attr("id","insChoiceTable")
        .attr("color","#57D1F7");
    initInsChoiceTableReq();
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("button")
        .attr({
            "class":"popup-sure-btn btn btn-sm btn-bg-color popUpBtn",
        })
        .on("click",function(){
            choiceInsFun();
        })
        .html("确&nbsp;&nbsp;&nbsp;&nbsp;定");
    editFromDivBtn
        .append("button")
        .attr("class","btn btn-sm btn-bg-color popUpBtn claseDialogBtn")
        //.attr("id","claseDialogBtn" + operName)
        .on("click",function(){
            d3.select("#dialogInsChoice").classed("bounceIn",false);
            $('#dialogBgInsChoice').fadeOut(300,function(){
                $('#dialogInsChoice').addClass('bounceOutUp').fadeOut();
            });
        })
        .html("取&nbsp;&nbsp;&nbsp;&nbsp;消");
}
function changeOper()
{
   var selectObj = d3.select("#choiceSelectItem");
    return selectObj[0][0].selectedIndex;
}
function initInsChoiceTable()
{
    var par = [{field: 'instance_radio' , radio: true ,align: 'center' },
        {field: 'instance_number' ,title: '序&nbsp;&nbsp;&nbsp;&nbsp;号' ,align: 'center' },
        {field: 'instance_name' ,title: '实例名称' ,align: 'center' },
        {field: 'instance_ID' ,title: '实例ID' ,align: 'center' }
    ];
    $('#insChoiceTable').bootstrapTable({
        classes:"table table-no-bordered",
        toolbar:"#toolbar",
        height:400,
        columns: par,
        idField:"index"
    });
}
function initInsChoiceTableReq()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"enumInstList","subRequest":"","ssubRequest":""},
        data    :{}
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,initInsChoiceTableReqCallback);
}
function initInsChoiceTableReqCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        var dataJson =  getNewJson(jsonObj.data);
        initInsChoiceTable();
        $("#insChoiceTable").bootstrapTable('load',dataJson);
        listenTable();
    }else{
        uxAlert("选择实例列表加载失败！");
    }
}
function listenTable()
{
    var $table = $("#insChoiceTable");
    $table.on('check.bs.table page-change.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table',function(arg){

    });
}
//重组数据格式
function getNewJson(data)
{
    var newJson = [];
    for(var i = 0;i < data.length;i++)
    {
        var info = {};
        info.instance_number = (i + 1);
        info.instance_name = data[i].clsname;
        info.instance_ID = data[i].id;
        info.instance_state = data[i].state;
        info.creat_time = data[i].inittm;
        info.cluster_path = data[i].clspath;
        info.instance_type = (data[i].type == 1) ? ("本地实例"):("云实例"); //1:本地实例，2:云实例
        info.DFSId = data[i].dfsid;
        info.db_version = data[i].version;
        newJson.push(info);
    }
    return newJson;
}
function choiceInsFun()
{
    var ids = getIdSelections("insChoiceTable");
    window.sessionStorage.ux_currentChoiceInsId = ids[0].instance_ID;
    getInstanceMonitorData();
    d3.select("#dialogInsChoice").classed("bounceIn",false);
    $('#dialogBgInsChoice').fadeOut(300,function(){
        $('#dialogInsChoice').addClass('bounceOutUp').fadeOut();
    });
}
function queryInstance()
{
    /*
     * 修改查询按钮的颜色*/
    var queryItem = {
        'insNameFlag':0,
        'insName':'',
        'insTypeFlag':0,
        'insIdFlag':0,
        'insId':'',
        'insType':'',
        'insStatusFlag':0,
        'insStatus':''
    };
    var choiceItem = changeOper();
    var strVlalue = trim(d3.select("#queryName")[0][0].value);
    if(strVlalue != "")
    {
        if(choiceItem == 0)
        {
            queryItem.insNameFlag = 1;
            queryItem.insName = strVlalue;
        }else{
            queryItem.insIdFlag = 1;
            queryItem.insId = strVlalue;
        }

    }
    /*
     * 发送的查询数据*/
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"queryInstance","subRequest":"","ssubRequest":""},
        data    :queryItem
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,queryInsCallback);
}
function queryInsCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        var dataJson =  getNewJson(jsonObj.data);
        $("#insChoiceTable").bootstrapTable('load',dataJson);
    }else{
        uxAlert("实例列表加载失败！");
    }
}