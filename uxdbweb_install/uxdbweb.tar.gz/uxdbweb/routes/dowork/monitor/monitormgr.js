var myDbOpt = require('../../common/dbopt');
var monitorMgr = (function () {
    var _inst;
    var monitorOpt = function () {
        var _dbOpt = new myDbOpt();
        return {
            getFirstDFSId: function (reqDb, callback) {
                var sqlText = "select id from tbl_dfslist where state = '1' order by id limit 1;";
                var sqlValue = [];
                _dbOpt.querySql(sqlText, sqlValue, function (isErr, count, rst) {
                    if (isErr) {
                        callback(isErr);
                        return;
                    }
                    if (count == 0) {
                        callback(false, []);
                        return;
                    }
                    callback(false, rst)
                })
            },
        }
    }
    return {
        getInstance: function () {
            if (_inst === undefined) {
                _inst = new monitorOpt();
            }
            return _inst;
        }
    }
})();
module.exports = monitorMgr;