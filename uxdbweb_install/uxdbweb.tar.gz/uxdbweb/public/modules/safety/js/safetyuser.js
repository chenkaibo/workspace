/**
 * Created by 17726 on 2017/3/7.
 */
'use strict';
window.onload = function ()
{
    //window.parent.menuOperFun();
    safetyUserObjectElem("#safetyUserId");
    top.d3.select("#leftDivId").classed("no-display",false);
};
var OwnerDataArr = [],modIndex;
/*
 * 获取界面元素
 * */
function safetyUserObjectElem(contain)
{
    window.focus();
    window.sessionStorage.ux_pagePath = "dbSafetyUser,main";
    var currentRole = window.sessionStorage.ux_curUserRole;
    d3.select("#mainContainDiv").remove();
    d3.select(contain)
        .append("div")
        .attr({
            'id':'mainContainDiv',
            'class':'siteList-content db-manage-div'
        });
    d3.select(".siteList-content")
        .append("div")
        .attr({
            'id':'toolbar',
            'class':'toolbar box'
        });

    d3.select(".siteList-content #toolbar")
        .append("button")
        .attr({
            'id':'newSafetyUserBtn',
            'class':'btn btn-default admitClick bounceIn disabledElem'
        })
        .on("click",function(){
            createSafetyUserElem();
        })
        .html("新&nbsp;&nbsp;建");
    d3.select(".siteList-content #toolbar")
        .append("button")
        .attr({
            'id':'delSafetyUserInfo',
            'class':'disabledElem delBtnClass',
            'disabled':'disabled',
            'onClick':'delSafetyUserInfo()'
        })
        .html("删&nbsp;&nbsp;除");
    var operTypeSelect = d3.select(".siteList-content #toolbar")
        .append("select")
        .attr({
            'class':'select-type select-disabled',
            'id':'opterSelectItem',
            'disabled':'disabled'
        });
    var optionItem = ['操作类型','Rename','DeleteUserObject','ModifyUserObjectOwner'];
    for(var k = 0;k < optionItem.length; k++)
    {
        if(k == 0)
        {
            operTypeSelect.append("option")
                .attr({
                    'name':optionItem[k],
                    'selected':'selected',
                    'class':'title-option option-all'
                })
                .html(optionItem[k]);
        }else{
            operTypeSelect.append("option")
                .attr({
                    'class':'option-all',
                    'name':optionItem[k]
                })
                .html(optionItem[k]);
        }

    }
    d3.select(".siteList-content #toolbar")
        .append("button")
        .attr({
            "class":"delBtnClass disabledElem",
            "id":"executeBtnId",
            "disabled":'disabled'
        })
        .on("click",function(){
            var opterStr = d3.select("#opterSelectItem")[0][0].value;
            if(opterStr == "操作类型")
            {
                uxAlert("请正确选择需要执行的操作！");
                return;
            }
            executeOper(opterStr);
        })
        .html("执&nbsp;&nbsp;行");
    d3.select(".siteList-content")
        .append("div")
        .attr("id","safetyUserQuery");
    d3.select("#safetyUserQuery").append("span")
        .html("用户名：");
    d3.select("#safetyUserQuery").append("input")
        .attr("id","querySafetyUserName")
        .style("color","#57D1F7");
    d3.select("#safetyUserQuery").append("button")
        .attr("class","searchSite-btn searchSite btn btn-bg-color")
        .on("click",function(){
            querySafetyUserObj();
        });
    d3.select(".siteList-content")
        .append("div")
        .attr("class","safetyUser-table-div")
        .append("table")
        .attr("id","safetyUserTableId")
        .attr("color","#57D1F7");
    if(currentRole == 1)
    {
        d3.selectAll(".disabledElem").style('display','none');
        d3.select("#searchSite-form").style('opacity','0');
    }
    reqInitTableData();
}
/****************************执行操作函数处理区***********************************/
function executeOper(opterStr)
{
    switch (opterStr)
    {
        case "Rename": renameFun();break;
        case "DeleteUserObject":delUserObjectFun();break;
        case "ModifyUserObjectOwner":modifUserObjectOwnerFun();break;
        default :break;
    }
}
function renameFun()
{
    var className;
    var ids = getIdSelections("safetyUserTableId");
    renameFunElem("#mainContainDiv",ids[0].userName);
    if(d3.select("#dialogSafetyUser").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgSafetyUser').fadeIn(300);
    $('#dialogSafetyUser').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function renameFunElem(contain,userName)
{
    d3.select("#dialogBgSafetyUser").remove();
    d3.select("#dialogSafetyUser").remove();
    var pupUpItem = "Rename用户";
    d3.select(contain).append("div")
        .attr("id","dialogBgSafetyUser");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogSafetyUser")
        .style("height","200px");
    var editFrom = outPage.append("div")
        .attr("id","renameFromSafetyUser");
    editFrom.append("span")
        .attr({
            "class":"rename-safetyUser-title"
        })
        .html(pupUpItem);
    editFrom.append("span")
        .attr({
            "id":"renameItemSpanSafetyUser",
            "class":"renameSafetyUserTitle"
        })
        .html(userName);
    var selectTypeDiv = d3.select("#dialogSafetyUser").append("div").attr({"class":"select-oper-type editUl"});
    selectTypeDiv.append("span")
        .attr({
            "class":"rename-safetyUser-span"
        })
        .html("请输入新用户名：");
    selectTypeDiv.append("input")
        .attr({
            'id':'newUserName',
            'class':'ipt rename-safetyUser',
            "placeholder":"字母开头，字母、数字、特殊字符组成，小于64位"
        })
        .on('blur',function(){
            var userName = d3.select(this)[0][0].value;
            if(instanceName(userName) && userName.length < 65 && userName.length > 0)
            {
                d3.select(this)[0][0].nextSibling.innerHTML = "";
            }else{
                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>字母开头，特殊字符可以包括下划线，长度不超过64！</span>";
                d3.select(".errorTip").style("margin-left","30%");
            }
        });
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });
    var editFromDivBtn = d3.select("#dialogSafetyUser").append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop getSafetyUser rename-btn-div")
        .append("button")
        .attr("id","sureBtnSafetyUser")
        .on("click",function(){
            renameDealFun(userName);
        })
        .attr("class","btn btn-default admitClick")
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnSafetyUser")
        .on("click",function(){
            d3.select("#dialogSafetyUser").classed("bounceIn",false);
            $('#dialogBgSafetyUser').fadeOut(300,function(){
                $('#dialogSafetyUser').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#executeBtnId").classed("admitClick",true);
            d3.select("#executeBtnId").classed("white",false);
        })
        .html("取&nbsp;&nbsp;消");
}
function renameDealFun(oldUserName)
{
    var newUserName = d3.select("#newUserName")[0][0].value;
    var userNameFlag = false;
    if(instanceName(newUserName) && newUserName.length < 65 && newUserName.length > 0)
    {
        userNameFlag = true;
    }else{
        userNameFlag = false;
    }
    if(!userNameFlag)
    {
        uxAlert("请输入正确的用户名！");
        return;
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"searchUserInfo","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            userName:oldUserName,
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_safetyUserInterface.ajaxRequest(false,jsonDataStr,getUserInfoCallback);
}
function getUserInfoCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success"){
        //console.log("retJsonStr.data = " + retJsonStr.data);
        var oldUserName = retJsonStr.data.username;
        var userId = retJsonStr.data.userid;
        var newUserName = d3.select("#newUserName")[0][0].value;
        var superUserFlag = (retJsonStr.data.superuser == false) ? (0):(1);
        var createDbFlag = (retJsonStr.data.createdb == false) ? (0):(1);
        var createRoleFlag = (retJsonStr.data.createrole == false) ? (0):(1);
        var validUntilValue = retJsonStr.data.validitytime;
        var jsonDataObj = {
            ip: "",
            port: "",
            router: "dbopt",
            request: {"mainRequest": "exceUserOp", "subRequest": "", "ssubRequest": ""},
            data: {
                webusername: window.sessionStorage.ux_curUserName,
                instid: window.sessionStorage.ux_currentChoiceInsId,
                dbname: window.sessionStorage.ux_currentChoiceDataName,
                opType:"rename",
                oldName:oldUserName,
                newName: newUserName,
                userid:userId,
                //passWord: userpwd,
                //passWord:hex_md5(userpwd),
                superUser: superUserFlag,
                createDb: createDbFlag,
                createRole: createRoleFlag,
                //setValidUntil: setValidUntilFlag,
                validUntil: validUntilValue
            }
        }
        console.log("猪八戒 = "+JSON.stringify(jsonDataObj.data));
        console.log("送悟空 = "+JSON.stringify(retJsonStr.data));
        var jsonDataStr = JSON.stringify(jsonDataObj);
        ux_safetyUserInterface.ajaxRequest(false,jsonDataStr,exceUserOperCallback);
    }

}
//function setRenameDealFun(oldUserName)
//{
//    var jsonDataObj = {
//        ip      :"",
//        port    :"",
//        router  :"dbopt",
//        request :{"mainRequest":"searchUserInfo","subRequest":"","ssubRequest":""},
//        data    :{
//            webusername : window.sessionStorage.ux_curUserName,
//            instid : window.sessionStorage.ux_currentChoiceInsId,
//            dbname : window.sessionStorage.ux_currentChoiceDataName,
//            opType:"rename",
//            oldName:oldUserName,
//            newName:newUserName
//        }
//    };
//    var jsonDataStr = JSON.stringify(jsonDataObj);
//    ux_safetyUserInterface.ajaxRequest(false,jsonDataStr,exceUserOperCallback);
//}
function exceUserOperCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    console.log("安全用户所有者 = "+retJsonStr.data);
    if(retJsonStr.rstcode == "success")
    {
        reqInitTableData();
        var selectItem = d3.select("#opterSelectItem");
        selectItem[0][0].selectedIndex = 0;
        selectItem[0][0].options[selectItem[0][0].selectedIndex].innerHTML = "操作类型";
        d3.select('#delSafetyUserInfo').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
        d3.select('#executeBtnId').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
        d3.select('#opterSelectItem').classed("select-disabled",true).attr("disabled",true);
        uxAlert("执行操作成功！");
    }else{
        uxAlert("执行操作失败！");
    }
    d3.select("#executeBtnId").classed("white",false);
    d3.select("#dialogSafetyUser").classed("bounceIn",false);
    $('#dialogBgSafetyUser').fadeOut(300,function(){
        $('#dialogSafetyUser').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#dialogModSafetyUserOwner").classed("bounceIn",false);
    $('#dialogBgModSafetyUserOwner').fadeOut(300,function(){
        $('#dialogModSafetyUserOwner').addClass('bounceOutUp').fadeOut();
    });
}
function modifUserObjectOwnerFun()
{
    var className;
    var ids = getIdSelections("safetyUserTableId");
    modifUserObjectOwnerFunElem("#mainContainDiv",ids[0].userName);
    if(d3.select("#dialogModSafetyUserOwner").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgModSafetyUserOwner').fadeIn(300);
    $('#dialogModSafetyUserOwner').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function modifUserObjectOwnerFunElem(contain,userName)
{
    d3.select("#dialogBgModSafetyUserOwner").remove();
    d3.select("#dialogModSafetyUserOwner").remove();
    var pupUpItem = "修改用户所有者";
    d3.select(contain).append("div")
        .attr("id","dialogBgModSafetyUserOwner");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogModSafetyUserOwner")
        .style("height","200px");
    var editFrom = outPage.append("div")
        .attr("id","modifFromSafetyUserOwner");
    editFrom.append("span")
        .attr({
            "class":"modif-safetyUserOwner-title"
        })
        .html(pupUpItem);
    editFrom.append("span")
        .attr({
            "id":"modifItemSpanSafetyUserOwner",
            "class":"modifSafetyUserOwnerTitle"
        })
        .html(userName);
    var selectTypeDiv = d3.select("#dialogModSafetyUserOwner").append("div").attr({"class":"select-oper-type"});
    selectTypeDiv.append("span")
        .attr({
            "class":"modif-safetyUserOwner-span"
        })
        .html("请选择所有者：");
    var choiceElem = selectTypeDiv.append("select")
        .attr({
            'id':'modifSelectOwner',
            'class':'modifSelectOwner oper-type-item'
        });
    var choiceTypeItem = OwnerDataArr;
    for(var k = 0;k <choiceTypeItem.length; k++)
    {
        choiceElem.append("option")
            .html(choiceTypeItem[k]);
    }
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop getModifSafetyUserOwner")
        .append("button")
        .attr("id","sureBtnSafetyUser")
        .on("click",function(){
            modifUserObjectOwnerDealFun(userName);
        })
        .attr("class","btn btn-default admitClick")
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnSafetyUser")
        .on("click",function(){
            d3.select("#dialogModSafetyUserOwner").classed("bounceIn",false);
            $('#dialogBgModSafetyUserOwner').fadeOut(300,function(){
                $('#dialogModSafetyUserOwner').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#executeBtnId").classed("admitClick",true);
            d3.select("#executeBtnId").classed("white",false);
        })
        .html("取&nbsp;&nbsp;消");
}
function modifUserObjectOwnerDealFun(userName)
{
    var newRole = d3.select("#modifSelectOwner")[0][0].value;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"exceUserOp","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            opType:"modify userobject owner",
            oldRole:userName,
            newRole:newRole
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);

    ux_safetyUserInterface.ajaxRequest(false,jsonDataStr,exceUserOperCallback);
}
function delUserObjectFun()
{
    var className;
    var ids = getIdSelections("safetyUserTableId");
    delUserObjectFunElem("#mainContainDiv",ids[0].userName);
    if(d3.select("#dialogSafetyUser").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgSafetyUser').fadeIn(300);
    $('#dialogSafetyUser').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function delUserObjectFunElem(contain,userName)
{
    d3.select("#dialogBgSafetyUser").remove();
    d3.select("#dialogSafetyUser").remove();
    var pupUpItem = "删除用户对象";
    d3.select(contain).append("div")
        .attr("id","dialogBgSafetyUser");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogSafetyUser")
        .style("height","200px");
    var editFrom = outPage.append("div")
        .attr("id","delFromSafetyUser");
    editFrom.append("span")
        .attr({
            "class":"del-safetyUser-title"
        })
        .html(pupUpItem);
    editFrom.append("span")
        .attr({
            "id":"delItemSpanSafetyUser",
            "class":"delSafetyUserTitle"
        })
        .html(userName);
    var selectTypeDiv = d3.select("#dialogSafetyUser").append("div").attr({"class":"select-oper-type"});
    selectTypeDiv.append("span")
        .attr({
            "class":"del-safetyUser-span"
        })
        .html("请选择删除用户：");
    var choiceElem = selectTypeDiv.append("select")
        .attr({
            'id':'delTypeSelect',
            'class':'deleteSelectStye oper-type-item'
        });
    var choiceTypeItem = ['RESTRICT','CASECADE'];
    for(var k = 0;k <choiceTypeItem.length; k++)
    {
        choiceElem.append("option")
            .html(choiceTypeItem[k]);
    }
    var editFromDivBtn = d3.select("#dialogSafetyUser").append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop getSafetyUser rename-btn-div")
        .append("button")
        .attr("id","sureBtnSafetyUser")
        .on("click",function(){
            delUserObjDealFun(userName);
        })
        .attr("class","btn btn-default admitClick")
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnSafetyUser")
        .on("click",function(){
            d3.select("#dialogSafetyUser").classed("bounceIn",false);
            $('#dialogBgSafetyUser').fadeOut(300,function(){
                $('#dialogSafetyUser').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#executeBtnId").classed("admitClick",true);
            d3.select("#executeBtnId").classed("white",false);
        })
        .html("取&nbsp;&nbsp;消");
}
function delUserObjDealFun(userName)
{
    var delTypeSelect = d3.select("#delTypeSelect")[0][0].value;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"exceUserOp","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            opType:"delete userobject",
            userName:userName,
            deleteType:delTypeSelect
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_safetyUserInterface.ajaxRequest(false,jsonDataStr,exceUserOperCallback);
}
/******************************数据库表格实现************************************/
function initSafetyUserTable()
{
    var par = [{field: 'checkBox' , radio: true ,align: 'center' },
        {field: 'index' ,title: '序&nbsp;&nbsp;&nbsp;&nbsp;号' ,align: 'center',formatter:function(value,row,index){
            return index+1;
        }},
        {field: 'userName' ,title: '用户名' ,align: 'center' },
        {field: 'systemRoot' ,title: '系统权限' ,align: 'center' },
        {field: 'pswExpDate' , title: '密码有效期' ,align: 'center' },
        {field: 'userId' , title: '用户ID' ,align: 'center' },
        {field: 'operate' , title: '操&nbsp;&nbsp作' ,align: 'center' , formatter:function(value,row,index){
            var par = row.userName + "," + row.systemRootArray + "," + row.pswExpDate + "," + index;
            var modifUserPwdOper = '<a title = "修改">' + '<button id = "modifBtn'+ index +'" class = "modifPsw bounceIn" onclick = "modfiSafetyUserInfo(\''+ par+ '\')"'+'></button>' + '</a>';
            return modifUserPwdOper;
        }}
    ];
    $('#safetyUserTableId').bootstrapTable({
        classes:"table table-no-bordered",
        //toolbar:"#toolbar",
        height:606,
        columns: par,
        idField:"index",
    });
}
function reqInitTableData()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"getAllUserList","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_safetyUserInterface.ajaxRequest(false,jsonDataStr,reqInitTableDataCallback);
}
function reqInitTableDataCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    //console.log("修改成功后重新获取数据 = "+retJson);
    if(retJsonStr.rstcode == "success")
    {
        initSafetyUserTable();
        listenSafetyUserTable();
        var data = getUserNewJson(JSON.parse(retJsonStr.data));
        var selectItem = d3.select("#opterSelectItem");
        selectItem[0][0].selectedIndex = 0;
        selectItem[0][0].options[selectItem[0][0].selectedIndex].innerHTML = "操作类型";
        d3.select('#delSafetyUserInfo').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
        d3.select('#executeBtnId').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
        d3.select('#opterSelectItem').classed("select-disabled",true).attr("disabled",true);
        $("#safetyUserTableId").bootstrapTable('load',data);
    }else{
        uxAlert("用户列表初始化失败！");
    }
}
//重组数据格式
function getUserNewJson(data)
{
    var newJson = [];
    //OwnerDataArr.push(data[0].username);
    for(var i = 0;i < data.length;i++)
    {
        var info = {};
        info.userName = data[i].username;
        //for(var k = 0;k<OwnerDataArr.length; k++)
        //{
        //    if(data[i].username != OwnerDataArr[k])
        //    {
        //        OwnerDataArr.push(data[i].username);
        //        break;
        //    }else{
        //        break;
        //    }
        //}
        OwnerDataArr[i] = data[i].username;
        info.userId = data[i].userid;
        if(data[i].validitytime != null)
        {
            var overtime = data[i].validitytime.split(" ");
        }
        info.pswExpDate = (data[i].validitytime == null) ? (""):(overtime[0]);
        var root = [];
        if(data[i].superuser == 1){
            root.push("超级管理员")
        }
        if(data[i].createdb == 1){
            root.push("创建数据库")
        }
        if(data[i].createrole == 1){
            root.push("创建角色")
        }
        info.systemRoot = root.join(",");
        info.systemRootArray = [data[i].superuser,data[i].createdb,data[i].createrole];
        newJson.push(info);
    }
    return newJson;
}
/******************************新建用户**************************************/
function createSafetyUserElem()
{
    var className;
    d3.select("#newSafetyUserBtn").classed("admitClick",false);
    createSafetyUserDataInfoElem("#mainContainDiv");
    if(d3.select("#dialogSafetyUser").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgSafetyUser').fadeIn(300);
    $('#dialogSafetyUser').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
function createSafetyUserDataInfoElem(contain)
{
    d3.select("#dialogBgModSafetyUser").remove();
    d3.select("#dialogModSafetyUser").remove();
    d3.select("#dialogBgSafetyUser").remove();
    d3.select("#dialogSafetyUser").remove();
    d3.selectAll(".data-picker-con").remove();
    var pupUpItem = "新建用户";
    var popUpInputArray = ["&nbsp;&nbsp;用户名&nbsp;&nbsp;","新建密码","确认密码"];
    var editTile = ["基本信息"];
    d3.select(contain).append("div")
        .attr("id","dialogBgSafetyUser");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogSafetyUser");
    outPage.append("div")
        .attr({
            "id":"createItemSpanSafetyUser",
            "class":"createSafetyUserTitle"
        })
        .html(pupUpItem);
    var editFrom = outPage.append("div")
        .attr("id","editFromSafetyUser");
    var editTileUl = editFrom.append("div")
        .attr("class","asideEditTitle")
        .append("ul")
        .attr("class","editTile");
    for(var i = 0;i < editTile.length;i++){
        editTileUl.append("li")
            .classed("editTitleLi", true)
            .html(editTile[i]);
    }
    var editFormWrap = editFrom.append("div")
        .attr("class","createEditFormWrap");
    for(var i = 0;i < editTile.length;i++){
        editFormWrap.append("div")
            .attr({
                "class":"editFormCon",
                "id":"editFormCon"+i
            })
    }
    var editFormUl = d3.select("#editFormCon0")
        .append("ul")
        .attr("class","editInfos");
    for(var i = 0;i < popUpInputArray.length;i++)
    {
        var editFromLi = editFormUl.append("li")
            .attr({
                "class":"editUl",
                "id":"userFormIpt" + i
            });
        editFromLi.append("label")
            .attr({
                "class":"editFromLiSpanRole",
                "for":"input"+i
            })
            .html(popUpInputArray[i]);
        editFromLi.append("input").attr({
            'class':'ipt',
            'id':'input' + i
        });
        if(i == 0){
            d3.select("#input0").attr("placeholder","字母开头，字母、数字、特殊字符组成，小于64位")
                .on('blur',function(){
                var userName = d3.select(this)[0][0].value;
                if(instanceName(userName) && userName.length < 65 && userName.length > 0)
                {
                    d3.select(this)[0][0].nextSibling.innerHTML = "";
                }else{
                    d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>字母开头，特殊字符可以包括下划线，长度不超过64！</span>";
                }
            })
        }
        if(i == 1){
            d3.select("#input1").attr({
                "placeholder":"至少包含一个字母、数字及特殊字符，8-20位",
                "type":"password"
            }).on('blur',function(){
                var userPswd = d3.select(this)[0][0].value;
                if(!passwordCheckout(userPswd)) {
                    d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>至少包含一个字母、数字及特殊字符，长度为8-20位</span>";
                }else{
                    d3.select(this)[0][0].nextSibling.innerHTML = "";
                }
            })
        }
        if(i == 2){
            d3.select("#input2").attr({
                "placeholder":"至少包含一个字母、数字及特殊字符，8-20位",
                "type":"password"
            }).on('blur',function(){
                var userPswd = d3.select("#input1")[0][0].value;
                var confirmPswd = d3.select(this)[0][0].value;
                if(userPswd != confirmPswd) {
                    d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>两次输入密码不同</span>";
                }else{
                    d3.select(this)[0][0].nextSibling.innerHTML = "";
                }
            })
        }

    }
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });
    d3.select("#editFormCon0")
        .append("div")
        .attr("class","pswExpDate1")
        . html("密码有效期：")
        .append("input")
        .attr({
            "type":"checkbox",
            "id":"setValidUntilFlag",
            'checked':true
        })
        .on("click",function(){
            if(d3.select(this)[0][0].checked)
            {
               d3.select("#expDateValue")[0][0].disabled = false;
               d3.select("#expDateValue").classed("no-allow-show",false);
            }else{
               d3.select("#expDateValue")[0][0].disabled = true;
               d3.select("#expDateValue").classed("no-allow-show",true);
            }
        });
    d3.select(".pswExpDate1")
        .append("span")
        .html("是否设置有效期");
    d3.select(".pswExpDate1")
        .append("input")
        .attr({
            'class':'expDate',
            'type':'text',
            'id':'expDateValue',
            'readonly':'readonly',
            'value' : getCurrentDate()  //初始时间值
        })
        .style({
            'width':'265px',
            'height':'30px',
            'left': '20px',
            'top': '20px'
        });
    timeSelect();
    d3.select("#expDateValue").on("click",function(e){
        actionDatePicker("expDateValue",false,"bottom",e);
        d3.select(".data-picker-con").style({
            "top":"530.5px",
            "left":"955.5px"
        })
    });
    d3.select("#editFormCon0")
        .append("div")
        .attr("class","systemRoot1")
        .html("系统权限：");
    var systemRole = ["超级管理员","创建数据库","创建角色"];
    var systemRoot1 = d3.select(".systemRoot1");
        for(var i = 0;i < 3 ; i++){
            systemRoot1.append("input")
                .attr({
                    "type":"checkbox",
                    "id":"systemRole"+i
                });
            systemRoot1.append("lable")
                .attr("for","systemRole"+i)
                .html(systemRole[i]);
        }

    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop dialog-btn-div")
        .append("button")
        .attr("id","sureBtnSafetyUser")
        .on("click",function(){
            createSafetyUserData();
        })
        .attr("class","btn btn-default admitClick")
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnSafetyUser")
        .on("click",function(){
            d3.select("#dialogSafetyUser").classed("bounceIn",false);
            $('#dialogBgSafetyUser').fadeOut(300,function(){
                $('#dialogSafetyUser').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#newSafetyUserBtn").classed("admitClick",true);
        })
        .html("取&nbsp;&nbsp;消");
}
function getCurrentDate()
{
    var currentData = new Date();
    var year = currentData.getFullYear();
    var month = currentData.getMonth()+1;
    month = (month > 9) ? (month):("0"+month);
    var date = currentData.getDate();
    date = (date > 9) ? (date):("0"+date);
    return (year + "-" + month + "-" +date);
}
function createSafetyUserData()
{
    var username = d3.select("#input" + 0)[0][0].value;
    var userpwd = trim(d3.select("#input" + 1)[0][0].value);
    var confirmpwd = trim(d3.select("#input" + 2)[0][0].value);
    var sureUserFlag = false,surePwdFlag = false;
    if(instanceName(username) && username.length < 65 && username.length > 0)
    {
        sureUserFlag = true;
    }else{
        sureUserFlag = false;
    }
    if(!passwordCheckout(userpwd)) {
        surePwdFlag = false;
    }else{
        surePwdFlag = true;
    }
    if(sureUserFlag && surePwdFlag && (username == "" || userpwd == "" || confirmpwd == ""))
    {
        uxAlert("请正确输入需新建用户的信息！");
        return;
    }

    var formDataArray = d3.selectAll(".systemRoot1 input[type = checkbox]");
    var superUserFlag = (formDataArray[0][0].checked == false) ? (0):(1);
    var createDbFlag = (formDataArray[0][1].checked == false) ? (0):(1);
    var createRoleFlag = (formDataArray[0][2].checked == false) ? (0):(1);
    var setValidUntilFlag = (d3.select("#setValidUntilFlag")[0][0].checked) ? (1):(0);
    var validUntilValue = d3.select("#expDateValue")[0][0].value;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"createUser","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            userName:username,
            passWord:userpwd,
            //passWord:hex_md5(userpwd),
            superUser:superUserFlag,
            createDb:createDbFlag,
            createRole:createRoleFlag,
            setValidUntil:setValidUntilFlag,
            validUntil:validUntilValue
        }
    };
    console.log("webusername = "+jsonDataObj.data.webusername);
    console.log("dbname = "+jsonDataObj.data.dbname);
    console.log("userName = "+jsonDataObj.data.userName);

    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_safetyUserInterface.ajaxRequest(false,jsonDataStr,newSafetyUserCallback);
}
function newSafetyUserCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    console.log("新建安全用户后台返回数据 = "+retJsonStr.rstcode)
    if(retJsonStr.rstcode == "success")
    {
        reqInitTableData();
        uxAlert("新建用户成功！");
    }else{
        uxAlert("新建用户失败！");
    }
    d3.select("#dialogSafetyUser").classed("bounceIn",false);
    $('#dialogBgSafetyUser').fadeOut(300,function(){
        $('#dialogSafetyUser').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#newSafetyUserBtn").classed("admitClick",true);
}
/*****************************删除操作***************************************/
function delSafetyUserInfo()
{
    d3.select("#delSafetyUserInfo").classed("admitClick",false);
    uxConfirm("是否确认删除该数据库用户？",function(rst)
    {
        if(!rst)
        {
            d3.select("#delSafetyUserInfo").classed("admitClick",true);
            return;
        }
        var isd = getIdSelections("safetyUserTableId");
        var delUsername = isd[0].userName;
        var jsonDataObj = {
            ip      :"",
            port    :"",
            router  :"dbopt",
            request :{"mainRequest":"deleteUser","subRequest":"","ssubRequest":""},
            data    :{
                webusername : window.sessionStorage.ux_curUserName,
                instid : window.sessionStorage.ux_currentChoiceInsId,
                dbname : window.sessionStorage.ux_currentChoiceDataName,
                userName:delUsername
            }
        };
        var jsonDataStr = JSON.stringify(jsonDataObj);
        ux_safetyUserInterface.ajaxRequest(false,jsonDataStr,delSafetyUserCallback);
    });
}
function delSafetyUserCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success"){
        reqInitTableData();
        uxAlert("删除用户成功！");
    }else{
        uxAlert("删除用户失败！");
        reqInitTableData();
    }
    d3.select("#delSafetyUserInfo").classed("delBtnClass",true);
}
/*****************************查询操作*****************************************/
function querySafetyUserObj()
{
    var safetyUserName = d3.select("#querySafetyUserName")[0][0].value;
    if(safetyUserName == "")
    {
        reqInitTableData();
        return;
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"searchUserInfo","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            userName:safetyUserName
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_safetyUserInterface.ajaxRequest(false,jsonDataStr,querySafetyUserObjCallback);
}
function querySafetyUserObjCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        var data = getUserNewJson(JSON.parse(retJsonStr.data));
        $("#safetyUserTableId").bootstrapTable('load',data);
    }else{
        uxAlert("用户列表查询失败！");
    }
}
/****************************修改操作****************************************/
function modfiSafetyUserInfo(str1)
{
    var className;
    var itemArray = str1.split(",");
    var selectUserName = itemArray[0];
    var systemRoot = [itemArray[1],itemArray[2],itemArray[3]];
    modIndex = parseInt(itemArray[5]);
    console.log("modIndex = "+modIndex);
    d3.select("#modifBtn" + modIndex).classed("modifPsw-white",true);
    modifSafetyUserInfoElem("#mainContainDiv",selectUserName,systemRoot,itemArray[4]);
    if(d3.select("#dialogModSafetyUser").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgModSafetyUser').fadeIn(300);
    $('#dialogModSafetyUser').removeAttr('class').addClass('animated '+className+'').fadeIn();
}
function modifSafetyUserInfoElem(contain,modSafetyUserName,systemRootArr,pswExpDate)
{
    var modfiPwd = 0;
    d3.select("#dialogBgSafetyUser").remove();
    d3.select("#dialogSafetyUser").remove();
    d3.select("#dialogBgModSafetyUser").remove();
    d3.select("#dialogModSafetyUser").remove();
    d3.selectAll(".data-picker-con").remove();
    var pupUpItem = "修改用户";
    var username = "用户名";
    var editTile = ["基本信息"];
    var popUpInputArray = ["新建密码","确认密码"];
    d3.select(contain).append("div")
        .attr("id","dialogBgModSafetyUser");
    var outPage = d3.select(contain).append("div")
        .attr("id","dialogModSafetyUser");
    var editFrom = outPage.append("div")
        .attr("id","editFromSafetyUser");
    editFrom.append("span")
        .attr({
            "class":"modifyTitle"
        })
        .html(pupUpItem);
    editFrom.append("span")
        .attr({
            "id":"modItemSpanSafety",
            "class":"modifyTitle"
        })
        .html(modSafetyUserName);
    var editTileUl = editFrom.append("div")
        .attr("class","asideEditTitle")
        .append("ul")
        .attr("class","editTile");
    for(var i = 0;i < editTile.length;i++){
        editTileUl.append("li")
            .classed("editTitleLi", true)
            .html(editTile[i]);
    }
    var editFormWrap = editFrom.append("div")
        .attr("class","modfiEditFormWrap");
    editFormWrap.append("span")
        .attr("class","username")
        .html(username+"  :  ");
    editFormWrap.append("span")
        .attr({
            "id":"modItemSpanSafetyUser",
            "class":"modifyUser"
        })
        .html(modSafetyUserName);
    for(var i = 0;i < editTile.length;i++){
        editFormWrap.append("div")
            .attr({
                "class":"editFormCon",
                "id":"editFormCon"+i
            })
    }
    var editFormUl = d3.select("#editFormCon0")
        .append("ul")
        .attr("class","modfiEditInfos editInfos");
    for(var i = 0;i < popUpInputArray.length;i++)
    {
        var editFromLi = editFormUl.append("li")
            .attr({
                "class":"editUl",
                "id":"userFormIpt" + i
            });
        editFromLi.append("label")
            .attr({
                "class":"editFromLiSpan",
                "for":"input"+i
            })
            .html(popUpInputArray[i]);
        editFromLi.append("input").attr({
            'class':'ipt modfiUserPwd',
            'id':'input' + i,
            'type':'password'
        });
        if(i == 0){
            d3.select("#input0")
                .on('blur',function(){
                    var userPswd = d3.select(this)[0][0].value;
                    modfiPwd = 1;
                    if(!passwordCheckout(userPswd)) {
                        d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>至少包含一个字母、数字及特殊字符，长度为8-20位</span>";
                    }else{
                        d3.select(this)[0][0].nextSibling.innerHTML = "";
                    }
                })
        }else{
            d3.select("#input1")
                .on('blur',function(){
                    modfiPwd = 1;
                    var userPswd = d3.select("#input1")[0][0].value;
                    var confirmPswd = d3.select(this)[0][0].value;
                    if(userPswd != confirmPswd) {
                        d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>两次输入密码不同</span>";
                    }else{
                        d3.select(this)[0][0].nextSibling.innerHTML = "";
                    }
                })
        }
    }
    d3.selectAll(".modfiUserPwd").each(function(d,i){
       d3.select(this).attr({
           value:function(d){return "........";}
       });
    });
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });
    d3.select("#editFormCon0")
        .append("div")
        .attr("class","pswExpDate")
        . html("密码有效期：")
        .append("input")
        .attr({
            "type":"checkbox",
            "id":"setValidUntilFlag",
            "checked":false
        })
        .on("click",function(){
            if(d3.select(this)[0][0].checked)
            {
                d3.select("#expDateValue")[0][0].disabled = false;
                d3.select("#expDateValue").classed("no-allow-show",false);
            }else{
                d3.select("#expDateValue")[0][0].disabled = true;
                d3.select("#expDateValue").classed("no-allow-show",true);
            }
        });
    d3.select(".pswExpDate")
        .append("span")
        .html("是否设置有效期");
    d3.select(".pswExpDate")
        .append("input")
        .attr({
            'class':'expDate',
            'type':'text',
            'id':'expDateValue',
            'value' : function(){
                var dateValue;
                if(pswExpDate == "")
                {
                    dateValue = getCurrentDate();
                }else{
                    dateValue = pswExpDate;
                }
                return dateValue;
            }
        })
        .style({
            'width':'265px',
            'height':'30px',
            'left': '20px',
            'top': '20px'
        });
    if(pswExpDate == "")
    {
        //d3.select("#setValidUntilFlag")[0][0].checked = false;
        d3.select("#expDateValue")[0][0].disabled = true;
        d3.select("#expDateValue").classed("no-allow-show",true);
    }else{

        d3.select("#setValidUntilFlag")[0][0].checked = true;
        //d3.select("#setValidUntilFlag")[0][0].disabled = true;
        //d3.select("#setValidUntilFlag").classed("no-allow-show",true);
        d3.select("#expDateValue")[0][0].disabled = false;
        d3.select("#expDateValue").classed("no-allow-show",false);
    }
    timeSelect();
    d3.select("#expDateValue").on("click",function(e){
        actionDatePicker("expDateValue",false,"bottom",e);
        d3.select(".data-picker-con").style({
                "top":"485.5px",
                "left":"937.5px"
            })
    });

    d3.select("#editFormCon0")
        .append("div")
        .attr("class","systemRoot")
        .html("系统权限：");
    var systemRole = ["超级管理员","创建数据库","创建角色"];
    var systemRoot = d3.select(".systemRoot");
    for(var i = 0;i < 3 ; i++){
        systemRoot.append("input")
            .attr({
                "type":"checkbox",
                "id":"systemUser"+i
            });

        systemRoot.append("lable")
            .attr("for","systemUser"+i)
            .html(systemRole[i]);
    }
    d3.select(".systemRoot").selectAll("input[type = 'checkbox']").each(function(d,i){
        if(systemRootArr[i] == "false")
        {
            d3.select(this)[0][0].checked = false;
        }else{
            d3.select(this)[0][0].checked = true;
        }
    });
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop")
        .append("button")
        .attr("id","sureBtnSafetyUser")
        .attr("class","btn btn-default admitClick")
        .on("click",function(){
            modifSafetyUser(modSafetyUserName,modfiPwd);
        })
        .html("确&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-default admitClick")
        .attr("id","claseDialogBtnSafetyUser")
        .on("click",function(){
            d3.select("#dialogModSafetyUser").classed("bounceIn",false);
            $('#dialogBgModSafetyUser').fadeOut(300,function(){
                $('#dialogModSafetyUser').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#modifBtn" + modIndex).classed("modifPsw-white",false);
        })
        .html("取&nbsp;&nbsp;消");
}
function modifSafetyUser(userName,setPassword)
{
    var userpwd = trim(d3.select("#input" + 0)[0][0].value);
    var formDataArray = d3.selectAll(".systemRoot input[type = checkbox]");
    var superUserFlag = (formDataArray[0][0].checked == false) ? (0):(1);
    var createDbFlag = (formDataArray[0][1].checked == false) ? (0):(1);
    var createRoleFlag = (formDataArray[0][2].checked == false) ? (0):(1);
    var setValidUntilFlag = (d3.select("#setValidUntilFlag")[0][0].checked) ? (1):(0);
    var validUntilValue = d3.select("#expDateValue")[0][0].value;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dbopt",
        request :{"mainRequest":"modifyUser","subRequest":"","ssubRequest":""},
        data    :{
            webusername : window.sessionStorage.ux_curUserName,
            instid : window.sessionStorage.ux_currentChoiceInsId,
            dbname : window.sessionStorage.ux_currentChoiceDataName,
            userName:userName,
            setPassword:setPassword,
            passWord:userpwd,
            superUser:superUserFlag,
            createDb:createDbFlag,
            createRole:createRoleFlag,
            setValidUntil:setValidUntilFlag,
            validUntil:validUntilValue
        }
    };
    console.log("修改有效期flag = "+jsonDataObj.data.setValidUntil+";时间 = "+jsonDataObj.data.validUntil);
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_safetyUserInterface.ajaxRequest(false,jsonDataStr,modifSafetyUserCallback);
}
function modifSafetyUserCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    console.log("修改数据库用户的retJson = "+retJson)
    if(retJsonStr.rstcode == "success")
    {
        reqInitTableData();
        uxAlert("修改用户成功！");
    }else{
        uxAlert("修改用户失败！");
    }
    d3.select("#dialogModSafetyUser").classed("bounceIn",false);
    $('#dialogBgModSafetyUser').fadeOut(300,function(){
        $('#dialogModSafetyUser').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#modifBtn" + modIndex).classed("modifPsw-white",false);
}
function listenSafetyUserTable()
{
    var $table = $("#safetyUserTableId");
    $table.on('check.bs.table page-change.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table', function (arg) {
        var selected = $("#safetyUserTableId").bootstrapTable('getSelections');
        if (selected.length > 0) {
            d3.select('#delSafetyUserInfo').classed("delBtnClass",false).classed("btn admitClick",true).attr("disabled",null);
            d3.select('#opterSelectItem').classed("select-disabled",false).attr("disabled",null);
            d3.select('#executeBtnId').classed("delBtnClass",false).classed("btn admitClick",true).attr("disabled",null);
        }
        else {
            d3.select('#delSafetyUserInfo').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
            d3.select('#executeBtnId').classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
            d3.select('#opterSelectItem').classed("select-disabled",true).attr("disabled",true);
        }
    });
}
