var dirConfgJson;//dirConfg从后台获取的全部数据
function getDirHandle(operDFSInfo)
{
    refeshDfsStateFlag = false;
    window.focus();
    clearTimerFun();
    changePath("云数据库管理->DFS管理->DFS操作->DIR配置");
    window.sessionStorage.ux_pagePath = "dfsManage,DirConfig";
    var currentRole = window.sessionStorage.ux_curUserRole;
    d3.select("#mainContainDiv").remove();
    setParameterData(operDFSInfo);
    dirContainDiv = d3.select("#dfsBodyId")
        .append("div")
        .classed("siteList-content container",true)
        .attr("id","mainContainDiv");
    d3.select(".siteList-content")
        .append("div")
        .classed("revers","true")
        .append("a")
        .attr("class","dfs-reverse")
        .append("button")
        .classed("btn admitClick",true)
        .attr("id","dfs-reverseBtn")
        .on("click",function(){
            returnDfsHandle(parameterData)
        })

        .html("返回上一级");
    d3.select(".siteList-content")
        .append("fieldset")
        .classed("dfsList-content",true)
        .style("height","692px")
        .append("legend")
        .html("配置DIR");
    d3.select(".dfsList-content")
        .append("div")
        .classed("dfsconfg-content",true)
        .append("div")
        .classed("dirList",true)
        .attr("id","dirList")
        .append("div")
        .classed("toolbar volumeToolbar",true)
        .attr("id","dfsConfgToolbar")
        .append("button")
        .classed("del-btn-position delBtnClass disabledElem",true)
        .attr("id","setupDir")
        .on("click",function(){
            d3.select(this).classed("admitClick",false);
            setupDir();
        })
        .html("设&nbsp;&nbsp;置");
    d3.select(".dirList")
        .append("div")
        .classed("pull-right searchSite",true)
        .style("margin-top","-2px")
        .attr("id","searchDir");
    for(var i = 0; i < 2; i++){
        d3.select("#searchDir").append("div").classed("searchSite-content",true);
    };
    d3.selectAll(".searchSite-content")
        .append("input")
        .attr("type","checkbox")
        .each(function(d,i){
            d3.select(this).attr({
                id:"checkboxId" + i
            });
        })
        .on("click",function(d,i){
            checkBoxFun(i);
        })
        .attr("class","siteCheck");
    var searchSite_content= d3.selectAll(".searchSite-content");
    d3.select(searchSite_content[0][0])
        .insert("span",":nth-child(2)")
        .attr({
            'class':'searchTypeName',
            'id':'selectElemId0',
            'disabled':""
        })
        .html("已修改");
    d3.select(searchSite_content[0][1])
        .insert("span",":nth-child(2)")
        .attr("class","searchTypeName")
        .html("名称:");
    d3.select(searchSite_content[0][1])
        .insert("input",":nth-child(3)")
        .attr({
            'type':'text',
            'id':'selectElemId1',
            'disabled':""
        });
    d3.select("#searchDir")
        .append("button")
        .classed("btn searchSite-btn",true)
        .style("margin","4px 4px")
        .on("click",function(){
            queryDirConfg();
        })
        .attr("title","查找");
    d3.select(".dirList")
        .append("table")
        .attr({
            "id":"dirConfgTable",
            "data-toggle":"table",
            "color":"#57D1F7"
        });
    //d3.select(".siteList-content")
    //    .append("div")
    //    .classed("dfsconfg-line",true)
    //    .attr("id","dfsconfg_line");
    if(currentRole == 1)
    {
        d3.selectAll(".disabledElem").style('display','none');
    };
    initDirConfg();
    listenTable("dirConfgTable","setupDir");
}
/*返回DFS操作界面*/
function returnDfsHandle(operDFSInfo)
{
    getDfsHandle(operDFSInfo);
    //返回到DFS操作页面的左侧菜单栏样式
    var reference = window.sessionStorage.ux_dfsHandleReference;
    d3.selectAll(".dfsList-catalogli").remove();
    d3.selectAll(".dfsList-catalogul a").style("color","#57D1F7");
    var as = d3.selectAll(".dfsList-catalogul a");
    d3.select(as[0][reference]).style("color","white").append("div").classed("dfsList-catalogli",true);
    d3.selectAll(".dfsmodule-inner").classed("show",false);
    var inner = d3.selectAll(".dfsmodule-inner");
    d3.select(inner[0][reference]).classed("show",true);
    updateDfsStatus(currDfsStatus);
    if(reference == 1){
        getDirData();
        dirTimer = setInterval("getDirData()",10*1000);
    }else if(reference == 2){
        getMrcData();
        mrcTimer = setInterval("getMrcData()",10*1000);
    }else if(reference == 3){
        getOsdData();
        osdTimer = setInterval("getOsdData()",10*1000);
    }
}
//初始化DIR配置表格
function initDirConfg()
{
    var par = [{field: 'radio', radio: true,align: 'center'},
        {field:'dir_number',title:'序&nbsp;&nbsp;&nbsp;&nbsp;号',align: 'center'},
        {field:'dir_name',title:'名&nbsp;&nbsp;&nbsp;&nbsp;称',align: 'center'},
        {field:'dir_type',title:'类&nbsp;&nbsp;&nbsp;&nbsp;型',align: 'center',formatter:function(value,row,index){
            var typeValue;//1:整型,2:布尔,3:枚举,4:字符串
            if(row.dir_type == 1)
            {
                typeValue = "整型";
            }else if(row.dir_type == 2)
            {
                typeValue = "布尔类型";
            }else if(row.dir_type == 3)
            {
                typeValue = "枚举类型";
            }else if(row.dir_type == 4)
            {
                typeValue = "字符串型";
            }else{
                typeValue = "未知类型";
            }
            return typeValue;
        }},
        {field:'dir_currvalue',title:'当前值',align: 'center'},
        {field:'dir_modify',title:'已修改',align: 'center',formatter:function(value,row,index){
            if(row.dir_modify == 0) {
                var constr = '<a title="未修改">' + '<button class="no-modify"></button>' + '</a>';
                return constr;
            }else{
                var discon = '<a title="已修改">' + '<button class="modified-btn"></button>' + '</a>';
                return discon;
            }
        }},
        {field:'dir_sort',title:'类&nbsp;&nbsp;&nbsp;&nbsp;别',align: 'center',formatter:function(value,row,index){
            if(row.dir_sort == "classless"){
                return "";
            }else{
                return row.dir_sort;
            }
        }},
        {field:'dir_illustrate',title:'说&nbsp;&nbsp;&nbsp;&nbsp;明',align: 'center',width:'1000'}
    ];
    $('#dirConfgTable').bootstrapTable({
        classes:"table table-no-bordered",
        toolbar:"#dfsConfgToolbar",
        height:540,
        columns: par,
        idField:"dir_number",
    });
    getDirConfgData();
}
//获取dir配置数据
function getDirConfgData()
{
    var dir_id = dirCurrId;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"getDirMrcOsdCfgList","subRequest":"dir","ssubRequest":""},
        data    :{
            dir_id:dir_id
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,dirConfgCallback);
}
//dir回调函数
function dirConfgCallback(retJson)
{
    var data = JSON.parse(retJson);
    if(data.rstcode == "success")
    {
        dirConfgJson = dirConfgGetNewJson(data.data);
        $("#dirConfgTable").bootstrapTable('load',dirConfgJson);
        listenTable("dirConfgTable","setupDir");
        //if(dataJson.length >= 14){
        //    $("#dfsconfg_line").css("display","block");
        //}else{
        //    $("#dfsconfg_line").css("display","none");
        //}
    }else{
        uxAlert(data.desc);
    }
}

//获取dir更新的数据
function dirConfgGetNewJson(data)
{
    var newJson = [];
    for(var i = 0;i<data.length;i++)
    {
        var info = {};
        info.dir_number = (i+1);
        info.dir_name = data[i].pname;
        info.dir_type = data[i].ptype;
        info.dir_value = data[i].pvalue;
        info.dir_currvalue = data[i].pvalue;
        info.dir_modify = data[i].ismodify;
        info.vlist = data[i].vlist;
        info.dir_sort = trim(data[i].pclass);
        info.dir_illustrate = data[i].description;
        newJson.push(info);
    }
    return newJson;
}
function trim(str)
{
    return str.replace(/(^\s*)|(\s*$)/g, "");
}
//DIR设置页面
function setupDir()
{
    var className;
    var dirDataItem = getIdSelections("dirConfgTable")[0];
    newDirInfoElem(dirDataItem.dir_currvalue,dirDataItem.vlist,dirDataItem.dir_type,dirDataItem.dir_illustrate);
    d3.select("#dirNameTitle")
        .classed("dirNameTitle",true)
        .html(dirDataItem.dir_name);
    d3.select("#describe")
        .html(dirDataItem.dir_name+" 描述");
    d3.select("#newUserItemSpanNew").classed("newTitle",true);//(\''+dirDataItem.dir_value+'\')
    d3.select("#sureBtnNew").on("click",function(){
        newDirInfo(dirDataItem);
    });
    if(d3.select("#dialogNew").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgNew').fadeIn(300);
    $('#dialogNew').removeAttr('class').addClass('animated ' + className + '').fadeIn();


}
//Dir设置弹出框实现
function newDirInfoElem(currentData,optionalItem,type,areaDescription)
{
    d3.select("#dialogBgNew").remove();
    d3.select("#dialogNew").remove();
    var popUpInputArray = ["&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"];
    var opertionItemArray,typeFlag,sureFlag = false;
    if(type == 1) //整型有两界值 intValue
    {
        opertionItemArray = optionalItem;
        typeFlag = 1;
    }else if(type == 4){//字符串有最大长度
        opertionItemArray = optionalItem;
        typeFlag = 4;
    }else if(type == 2){//布尔值
        opertionItemArray = ["true","false"];
        typeFlag = 2;
    }else if(type == 3){//枚举值选择 emumValue
        opertionItemArray = optionalItem;
        typeFlag = 3;
    }
    dirContainDiv.append("div")
        .attr("id","dialogBgNew");
    var outPage = dirContainDiv.append("div")
        .attr("id","dialogNew" )
        .style({
            "width":"445px",
            "height":"340px"
        });
    var editFrom = outPage.append("div")
        .attr("id","editFromNew");
    var newUserItemSpan = editFrom.append("span")
        .attr("id","newUserItemSpanNew")
        .html("设置 ")
        .append("span")
        .attr("id","dirNameTitle");
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos");
    for(var i = 0;i < popUpInputArray.length;i++)
    {
        var editFromLi = editFormUl.append("li").attr("class","editUl");
        editFromLi.append("label")
            .attr("class","editFromLiSpan")
            .html(popUpInputArray[i]);
        if(typeFlag == 1)
        {
            editFromLi.append("input")
                .attr({
                    'id':'inputValue',
                    'type':"text",
                    'class':'ipt'
                })
                .on("blur",function(){
                    var value = d3.select(this)[0][0].value;
                    if(optionalItem != " ")
                    {
                        var minValue = optionalItem[1].minvalue;
                        var maxValue = optionalItem[0].maxvalue;
                        if(minValue == " " && maxValue == " ")
                        {
                            //不用校验
                            if(isNumber(value) && value != "")
                            {
                                d3.select(this)[0][0].nextSibling.innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入一个正确的整型值！</span>";
                                sureFlag = false;
                            }
                        }else if(minValue != " " && maxValue == " ")
                        {
                            //校验最小值
                            if(parseInt(value) >= parseInt(minValue))
                            {
                                d3.select(this)[0][0].nextSibling.innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入大于" +minValue+ "的整型值！</span>";
                                sureFlag = false;
                            }
                        }else if(minValue == " " && maxValue != " ")
                        {
                            //校验最大值
                            if(parseInt(value) <= parseInt(maxValue))
                            {
                                d3.select(this)[0][0].nextSibling.innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入小于" +maxValue+ "的整型值！</span>";
                                sureFlag = false;
                            }
                        }else if(minValue != " " && maxValue != " ")
                        {
                            //校验区间
                            if(parseInt(value) >= parseInt(minValue) && parseInt(value) <= parseInt(maxValue))
                            {
                                d3.select(this)[0][0].nextSibling.innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入"+minValue+"-" +maxValue+ "之前的整型值！</span>";
                                sureFlag = false;
                            }
                        }
                    }else{
                        //不用校验
                        if(isNumber(value) && value != "")
                        {
                            d3.select(this)[0][0].nextSibling.innerHTML = "";
                            sureFlag = true;
                        }else{
                            d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入一个正确的整型值！</span>";
                            sureFlag = false;
                        }
                    }
                });
            d3.select("#inputValue")[0][0].value = currentData;
        }else if(typeFlag == 2)
        {
            sureFlag = true;
            var selectElem = editFromLi.append("select")
                .attr({
                    'id':'inputValue',
                    'class':'ipt selectClass'
                });
            for(var operIndex = 0; operIndex < opertionItemArray.length; operIndex++)
            {
                selectElem.append("option")
                    .attr({
                        'id':'opertion' + operIndex
                    }).text(opertionItemArray[operIndex]);
            }
            var selectObj = d3.select("#inputValue");
            selectObj[0][0].selectedIndex = (currentData == "true") ? (0):(1);
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = currentData;
        }else if(typeFlag == 3)
        {
            sureFlag = true;
            var selectElem = editFromLi.append("select")
                .attr({
                    //'id':'input' + i,
                    'id':'inputValue',
                    'class':'ipt selectClass'
                });
            for(var operIndex = 0; operIndex < opertionItemArray.length; operIndex++)
            {
                selectElem.append("option")
                    .attr({
                        'id':'opertion' + operIndex
                    }).text(opertionItemArray[operIndex].vlist);
            }
            var selectObj = d3.select("#inputValue");
            for(var k = 0;k < opertionItemArray.length; k++)
            {
                if(currentData == opertionItemArray[k].vlist)
                {
                    selectObj[0][0].selectedIndex = k;
                    break;
                }
            }
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = currentData;
        }else if(typeFlag == 4)
        {
            editFromLi.append("input")
                .attr({
                    'id':'inputValue',
                    'type':"text",
                    'class':'ipt'
                })
                .on("blur",function(){
                    var value = d3.select(this)[0][0].value;
                    if(optionalItem != " ")
                    {
                        var maxLength = optionalItem[0].maxlength;
                        if(value.length < parseInt(maxLength))
                        {
                            d3.select(this)[0][0].nextSibling.innerHTML = "";
                            sureFlag = true;
                        }else{
                            d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入长度小于"+maxLength+"的字符串！</span>";
                            sureFlag = false;
                        }
                    }else{
                        d3.select(this)[0][0].nextSibling.innerHTML = "";
                        sureFlag = true;
                    }
                });
            d3.select("#inputValue")[0][0].value = currentData;
        }

    }
    var describe = editFrom.append("div")
        .classed("describe",true);
    describe.append("p")
        .attr({
            'id': "describe",
            'class': 'newTitle'
        });
    describe.append("textarea")
        .attr({
            'id': "describeText",
            'class': 'describeText',
            'disabled':true
        });
    d3.select("#describeText")[0][0].value = areaDescription;
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn").style({"bottom":"30px","right":"25.5%"});
    editFromDivBtn.append("button")
        .attr("id","sureBtnNew")
        .attr("class","btn btn-sm btn-bg-color popUpBtn")
        .html("确定");
    editFromDivBtn.append("button")
        .attr("class","btn btn-sm btn-bg-color popUpBtn claseDialogBtn")
        .attr("id","claseDialogBtnNew")
        .on("click",function(){
            d3.select("#dialogNew").classed("bounceIn",false);
            $('#dialogBgNew').fadeOut(300,function(){
                $('#dialogNew').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#setupDir").classed("btn admitClick",true);
        })
        .html("取消");
}
//设置前后值没有发生改变，点击确定
function dirConfgCancel(){
    uxAlert("设置DIR成功");
    d3.select("#dialogNew").classed("bounceIn",false);
    $('#dialogBgNew').fadeOut(600,function(){
        $('#dialogNew').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#setupDir").classed("btn admitClick",true);
}
//DIR设置页面与后台交互
function newDirInfo(dirCurrDataItem)
{
    //var dir_value = d3.select("#inputValue" + 0)[0][0].value;
    var dir_value = d3.select("#inputValue")[0][0].value;
    console.log("DIR-config = "+dir_value);
    var dir_currvalue = dirCurrDataItem.dir_currvalue;
    if(dir_value == dir_currvalue){
        dirConfgCancel();
        return;
    };

    var dir_id = dirCurrId;
    var dir_name = dirCurrDataItem.dir_name;
    var type = dirCurrDataItem.dir_type;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"setDirMrcOsdConfig","subRequest":"dir","ssubRequest":""},
        data    :{
            dir_id:dir_id,
            pname:dir_name,
            pvalue:dir_value,
            ptype:type
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,newDirInfoCallback);
}
function newDirInfoCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    console.log("DIR点击设置后台返回数据 = "+retJson);
    if(retJsonStr.rstcode == "success")
    {
        getDirConfgData();
    }
    uxAlert(retJsonStr.desc);
    d3.select("#dialogNew").classed("bounceIn",false);
    $('#dialogBgNew').fadeOut(300,function(){
        $('#dialogNew').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#setupDir").classed("btn admitClick",false).classed("delBtnClass",true);
}
/*DIR配置界面查询数据*/
function queryDirConfg()
{
    var queryJsonData = {
        'dirModifiedFlag':0,
        'dirNameFlag':0,
        'dirName':'',
    };
    var formDataArray = d3.selectAll(".siteCheck");
    queryJsonData.dirModifiedFlag = (formDataArray[0][0].checked == true) ? (1):(0);
    queryJsonData.dirNameFlag = (formDataArray[0][1].checked == true) ? (1):(0);
    queryJsonData.dirName = d3.select("#selectElemId1")[0][0].value;
    var dirConfgNewArr = [];
    if((queryJsonData.dirModifiedFlag == 0) && (queryJsonData.dirNameFlag == 0))
    {
        $("#dirConfgTable").bootstrapTable('load',dirConfgJson);
        return;
    }else if((queryJsonData.dirModifiedFlag == 0) && (queryJsonData.dirNameFlag == 1))
    {
        if(queryJsonData.dirName != ""){
            for (var i = 0; i < dirConfgJson.length; i++) {
                if (dirConfgJson[i].dir_name.indexOf(queryJsonData.dirName) != -1) {
                    dirConfgNewArr.push(dirConfgJson[i]);
                }
            }
            $("#dirConfgTable").bootstrapTable('load',dirConfgNewArr);
        }else{
            uxAlert("请完善查询条件！")
        }
    }else if((queryJsonData.dirModifiedFlag == 1) && (queryJsonData.dirNameFlag == 0)){
        for (var i = 0; i < dirConfgJson.length; i++) {
            if (dirConfgJson[i].dir_modify == 1) {
                dirConfgNewArr.push(dirConfgJson[i]);
            }
        }
        $("#dirConfgTable").bootstrapTable('load',dirConfgNewArr);
    }else if((queryJsonData.dirModifiedFlag == 1) && (queryJsonData.dirNameFlag == 1)){
        for (var i = 0; i < dirConfgJson.length; i++) {
            if ((dirConfgJson[i].dir_modify == 1) && (dirConfgJson[i].dir_name.indexOf(queryJsonData.dirName) != -1)) {
                dirConfgNewArr.push(dirConfgJson[i]);
            }
        }
        $("#dirConfgTable").bootstrapTable('load',dirConfgNewArr);
    }

}
