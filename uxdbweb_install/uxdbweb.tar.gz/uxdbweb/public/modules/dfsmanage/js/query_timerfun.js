/*DFS信息*/
/*dfsmanage全局变量*/
var refreshDfslistTimer = null,refreshCurrDfsTimer = null,refrQueryDfsTimer = null;//dfsList列表刷新、查询、获取当前dfsState定时器
var dfsLoadResult , getDfsStateLoading = null//启停DFS获取返回状态加载进度result
var volumeTimer = null, dirTimer = null ,mrcTimer = null ,osdTimer = null,volumeQueryTimer = null,dirQueryTimer = null ,mrcQueryTimer = null ,osdQueryTimer = null//dir、mrc、osd列表定时器
var dirName , mrcName ,osdName;//DFS操作页面dir、mrc、osd查询输入值；
var volumeContainDiv ,dirContainDiv ,mrcContainDiv ,osdContainDiv;//volume界面、dir、mrc、osd配置界面container
var dirCurrId , mrcCurrId ,osdCurrId;//dir,mrc,osd从后台读取的当前点击数据的ID；
var volumeDataJson;//从后台获取的全部volume数据

var DFSInfo = {
    ID:"",
    status:""
};
function clearTimerFun(){
    clearInterval(refrQueryDfsTimer);
    clearInterval(refreshDfslistTimer);
    clearTimeout(refreshCurrDfsTimer);
    clearTimeout(volumeTimer);
    clearInterval(dirTimer);
    clearInterval(mrcTimer);
    clearInterval(osdTimer);
    clearInterval(volumeQueryTimer);
    clearInterval(dirQueryTimer);
    clearInterval(mrcQueryTimer);
    clearInterval(osdQueryTimer);
}
/*volume查询*/
function queryVolume()
{
    clearTimeout(volumeTimer);
    clearTimeout(refreshCurrDfsTimer);
    clearInterval(volumeQueryTimer);
    var formDataArray = d3.select("#volumeSearchIpt")[0][0].value;
    if(formDataArray == "")
    {
        clearInterval(volumeQueryTimer);
        $("#volumeTable").bootstrapTable('load',volumeDataJson);
        return;
    }else
    {
        getqueryVolumeData(formDataArray);
        volumeQueryTimer = setInterval(function(){
            getqueryVolumeData(formDataArray);
        },10*1000);
    }
}
//页面保存查询匹配的Volume
function getqueryVolumeData(volumeSearchValue){
    var volumeNameArr = [];
    for(var i = 0; i < volumeDataJson.length; i++){
        var volumeName = volumeDataJson[i].volume_name;
        if(volumeName.indexOf(volumeSearchValue) != -1){
            volumeNameArr.push(volumeDataJson[i]);
        }
    };
    $("#volumeTable").bootstrapTable('load',volumeNameArr);
}
/*dir查询*/
function queryDir()
{
    var currentDfsId = window.sessionStorage.ux_dfsid;
    dirName = d3.select("#dirSearchIpt")[0][0].value;
    if(dirName == "")
    {
        getDirData();
        clearInterval(dirQueryTimer);
        dirTimer = setInterval("getDirData()",10*1000);
        return;
    }else{
        clearInterval(dirTimer);
        getqueryDirData(currentDfsId,dirName);
        dirQueryTimer = setInterval(function(){getqueryDirData(currentDfsId,dirName)},10*1000);
    }

}
function getqueryDirData(currentDfsId,dirName)
{
    console.log("dir查询 = "+dirName);
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"queryDirMrcOsd","subRequest":"dir","ssubRequest":""},
        data    :{
            "name":dirName,
            "dfsid":currentDfsId
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,queryDirCallback);
}
/*DIR查询数据重载*/
function queryDirCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        var dataJson =  dirGetNewJson(jsonObj.data);
        $("#dirTable").bootstrapTable('load',dataJson);
    }else{
        uxAlert(jsonObj.desc);
    }
}
/*mrc查询*/
function queryMrc()
{
    var currentDfsId = window.sessionStorage.ux_dfsid;
    mrcName = d3.select("#mrcSearchIpt")[0][0].value;
    if(mrcName == "")
    {
        getMrcData();
        clearInterval(mrcQueryTimer);
        mrcTimer = setInterval("getMrcData()",10*1000);
        return;
    }else{
        clearInterval(mrcTimer);
        getqueryMrcData(currentDfsId,mrcName);
        mrcQueryTimer = setInterval(function(){getqueryMrcData(currentDfsId,mrcName)},10*1000);
    }
}
function getqueryMrcData(currentDfsId,mrcName)
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"queryDirMrcOsd","subRequest":"mrc","ssubRequest":""},
        data    :{
            "name":mrcName,
            "dfsid":currentDfsId
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,queryMrcCallback);

}
function queryMrcCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        var dataJson =  mrcGetNewJson(jsonObj.data);
        $("#mrcTable").bootstrapTable('load',dataJson);
    }else{
        //uxAlert(jsonObj.desc);
    }
}
/*osd查询*/
function queryOsd()
{
    var currentDfsId = window.sessionStorage.ux_dfsid;
    osdName = d3.select("#osdSearchIpt")[0][0].value;
    if(osdName == "")
    {
        getOsdData();
        clearInterval(osdQueryTimer);
        osdTimer = setInterval("getOsdData()",10*1000);
        return;
    }else{
        clearInterval(osdTimer);
        getqueryOsdData(currentDfsId,osdName);
        osdQueryTimer = setInterval(function(){getqueryOsdData(currentDfsId,osdName)},10*1000);


    }
}
function getqueryOsdData(currentDfsId,osdName)
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"queryDirMrcOsd","subRequest":"osd","ssubRequest":""},
        data    :{
            "name":osdName,
            "dfsid":currentDfsId
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,queryOsdCallback);
}
function queryOsdCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    if(jsonObj.rstcode == "success"){
        var dataJson =  osdGetNewJson(jsonObj.data);
        $("#osdTable").bootstrapTable('load',dataJson);
    }else{
        //uxAlert(jsonObj.desc);
    }
}
/*===========DFS、DIR、MRC、OSD列表定时刷新状态==========*/

//定时刷新dfs_handle操作页面当前DFS-state状态，从后台获取状态
function intervalRefreshCurrDfs()
{
    var currentDfsId = window.sessionStorage.ux_dfsid;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"getDFSStateFromLocalDb","subRequest":"","ssubRequest":""},
        data    :{
            dfsid:currentDfsId
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,getCurrDfsStateCallback);
}
function getCurrDfsStateCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    //console.log("后台获取的DFS状态"+retJson);
    if(retJsonStr.rstcode == "success")
    {
        currDfsStatus = retJsonStr.data.dfsState;
        if(currDfsStatus == 1){
            volumeTimer = setTimeout(getVolumeData,2*1000);
        }
        updateDfsStatus(currDfsStatus);
    }else{
        uxAlert("获取DFS状态失败");
    }
}

//DIR定时刷新从后台获取状态
function intervalRefreshDir()
{
    var currentDfsId = window.sessionStorage.ux_dfsid;
    /*=====模拟数据=====*/
    //var jsonDataObj = [
    //    {dirState:1}
    //];
    //var jsonDataStr = JSON.stringify(jsonDataObj);
    //getDirStateCallback(jsonDataStr);
}
function getDirStateCallback(retJson)
{
    var dataJson = JSON.parse(retJson);
    for(var i = 0;  i < dataJson.length;i++){
        $("#dirTable").bootstrapTable('updateCell', {
            index: i,
            field: "dir_state",
            value:dataJson[i].dirState
        });
    }
}

//MRC定时刷新从后台获取状态
function intervalRefreshMrc()
{
    var currentDfsId = window.sessionStorage.ux_dfsid;
}
function getMrcStateCallback(retJson)
{
    var dataJson = JSON.parse(retJson);
    for(var i = 0;  i < dataJson.length;i++){
        $("#mrcTable").bootstrapTable('updateCell', {
            index: i,
            field: "mrc_state",
            value:dataJson[i].mrcState
        });
    }
}
//OSD定时刷新从后台获取状态
function intervalRefreshOsd()
{
    var currentDfsId = window.sessionStorage.ux_dfsid;
}
function getOsdStateCallback(retJson)
{
    var dataJson = JSON.parse(retJson);
    for(var i = 0;  i < dataJson.length;i++){
        $("#osdTable").bootstrapTable('updateCell', {
            index: i,
            field: "osd_state",
            value:dataJson[i].osdState
        });
    }
}
//启停DFS
/*   DFS操作 statusId 1:开启操作 2:停止操作 */
function dfsSwitch(statusId,parameterData)
{
    clearTimeout(refreshCurrDfsTimer);
    var currentRole = window.sessionStorage.ux_curUserRole;
    if(currentRole == 1)
    {
        uxAlert("您目前没有操作权限！");
        return;
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"optDFS","subRequest":"","ssubRequest":""},
        data    :{
            opertype:statusId,
            dfsid :parameterData[1],
            dfspath:parameterData[6]
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,dfsSwitchCallback);

}
//获取DFS状态加载进度
function currDfsStateLoad(data){
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"getOptDFSState","subRequest":"","ssubRequest":""},
        data    :data
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,dfsStateLoadCallback);
}
//更具后台返回的获取DFS状态进度判断是否继续发送请求
function dfsStateLoadCallback(retJson){
    var jsonObj = JSON.parse(retJson);
    console.log("后台获取的DFS状态返回信息"+jsonObj.data.result);
    if(jsonObj.rstcode == "success") {
        //0:未启动，1:启动中，2:启动成功，3:启动失败
        //0:未停止，1:停止中，2:停止成功，3:停止失败
        dfsLoadResult = jsonObj.data.result;
        if(jsonObj.data.result == 2 || jsonObj.data.result == 3){
            d3.select("#dialogBgNew").remove();
            d3.select("#dialogNew").remove();
            if(jsonObj.data.opertype == 1){
                if(jsonObj.data.result == 2){
                    currDfsStatus = jsonObj.data.opertype;
                    updateDfsStatus(currDfsStatus);
                    d3.select("#delVolume").classed("disabledElem delBtnClass",true).attr("disabled",true);
                    d3.select("#newVolumeBtn").classed("delBtnClass disabledElem",true).attr("disabled",true);
                    uxAlert("DFS启动成功！")
                }else if(jsonObj.data.result == 3){
                    uxAlert("DFS启动失败！")
                }
            }else{
                if(jsonObj.data.result == 2){
                    currDfsStatus = jsonObj.data.opertype;
                    updateDfsStatus(currDfsStatus);
                    listenTable("volumeTable","delVolume");
                    d3.select("#newVolumeBtn").attr("class",null).classed("btn btn-default admitClick bounceIn disabledElem",true);
                    uxAlert("DFS停止成功！")
                }else if(jsonObj.data.result == 3){
                    uxAlert("DFS停止失败！")
                }
            }
            return;
        } else{
            getDfsStateLoading = setTimeout(function(){currDfsStateLoad(jsonObj.data)},2*1000);
        }
    }else{
        uxAlert(jsonObj.desc);
    }
}
function dfsSwitchCallback(retJson)
{
    var jsonObj = JSON.parse(retJson);
    console.log("后台获取的启停DFS返回信息"+jsonObj.rstcode);
    if(jsonObj.rstcode == "success"){
        dfsStateLoading(volumeContainDiv,'New');
        currDfsStateLoad(jsonObj.data);
    }else{
       uxAlert(jsonObj.desc);
    }
}
function dfsStateLoading(containDiv,operName)
{
    d3.select("#dialogBgNew").remove();
    d3.select("#dialogNew").remove();
    var pupUpItem = "";
    var popUpInputArray;
    containDiv.append("div")
        .attr("id","dialogBg" + operName);
    var outPage = containDiv.append("div")
        .attr("id","dialog" + operName)
        .style({
            "height":"103px",
            "width":"367px"
        });
    var editFrom = outPage.append("div")
        .attr("id","editFrom" + operName);
    editFrom.append("span")
        .attr("title","加载中......")
        .classed("loading",true);
    if(d3.select("#dialogNew").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgNew').fadeIn(300);
    $('#dialogNew').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
//点击DFS启停按钮后改变DFS启停状态显示
function updateDfsStatus(status)
{
    if(status != 1) {
        d3.select("#dfsStopBtn").classed("dfsStopBtn-blue",false).classed("dfsStopBtn-grey",true).attr("disabled","disabled");
        d3.select("#dfsRunBtn").classed("dfsRunBtn-blue",true).classed("dfsRunBtn-grey",false).attr("disabled",null);
        d3.select("#dfsRunIcon").classed("dfsRunIcon-green",false).classed("dfsRunIcon-red",true);

    }else{
        d3.select("#dfsRunBtn").classed("dfsRunBtn-blue",false).classed("dfsRunBtn-grey",true).attr("disabled","disabled");
        d3.select("#dfsStopBtn").classed("dfsStopBtn-blue",true).classed("dfsStopBtn-grey",false).attr("disabled",null);
        d3.select("#dfsRunIcon").classed("dfsRunIcon-green",true).classed("dfsRunIcon-red",false);
    }
}