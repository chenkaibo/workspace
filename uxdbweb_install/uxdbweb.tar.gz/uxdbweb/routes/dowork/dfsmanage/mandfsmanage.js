var dfsmanageMgr = require("./dfsmanagemgr");
var errorCode = require("../../common/errorcode");
var udpServer = require("../../workserver/udpheartbeatserver").udpServer;
exports.dfsmanage = function () {
    this.getDFSState = getDFSState;
}
exports.triggerFunction = triggerFunction;
var mainRequestProcFuncs = {
    "enumDFSList": enumDFSList,
    "queryDFS": queryDFS,
    "getDFSStateFromLocalDb": getDFSStateFromLocalDb,
    "getDFSState": getDFSState,
    "getDFSInfo": getDFSInfo,
    "enumVolumeList": enumVolumeList,
    "enumDIRList": enumDIRList,
    "enumMRCList": enumMRCList,
    "enumOSDList": enumOSDList,
    "queryDirMrcOsd": queryDirMrcOsd,
    "getDirMrcOsdCfgList": getDirMrcOsdConfigList,
    "setDirMrcOsdConfig": setDirMrcOsdConfig,
    "createVolume": createVolume,
    "deleteVolume": deleteVolume,
    "deleteDFS": deleteDFS,
    "optDFS": optDFS,
    "getOptDFSState": getOptDFSState,
    "getVolumePath": getVolumePath,
    "modifyAliasname":modifyAliasname
}

function triggerFunction(postData, gResponseFunction) {
    if (postData.length <= 0) {
        return;
    }
    if (typeof gResponseFunction != "function") {
        return;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: ""
    };
    var jsonObj = JSON.parse(postData);
    var mainRequest = jsonObj.request.mainRequest;
    var procFunc = mainRequestProcFuncs[mainRequest];
    if (typeof procFunc != "function") {
        gResponseFunction(JSON.stringify(rtRes));
    }
    else {
        procFunc(jsonObj, gResponseFunction);
    }
}
function enumDFSList(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }
    function callback(isErr, resJson) {
        var rtRes = {
            rstcode: "error",
            desc: "",
            data: ""
        }
        if (isErr) {
            rtRes.desc = "数据获取失败！";
        } else {
            rtRes.rstcode = "success";
            rtRes.data = resJson;
        }
        gResponseFunction(JSON.stringify(rtRes));
    }

    var dataValue = jsonObj.data;//data重构
    jsonObj.data = dataValue;
    //dfsmanageMgr.getInstance().getDFSFromAgent(jsonObj,callback);
    dfsmanageMgr.getInstance().enumDFSListMgr(jsonObj, callback);
}
function queryDFS(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    function callback(isErr, rst) {
        if (isErr) {
            rtRes.desc = "DFS信息查询失败！";
        } else {
            rtRes.rstcode = "success";
            rtRes.data = rst;
        }
        gResponseFunction(JSON.stringify(rtRes));
    }

    console.log("\nquery DFS data:" + JSON.stringify(jsonObj.data) + "\n");

    dfsmanageMgr.getInstance().queryDFSMgr(jsonObj.data, callback);
}
function getDFSInfo(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: {}
    }

    var queryData = {
        sqlText: "select a.id,a.aliasname,a.inittm,a.dfspath,b.ip from tbl_dfslist a left join tbl_mrclist b on a.id = b.dfsid where a.id = $1;",
        sqlValue: [jsonObj.data.dfsid],
    }

    function callback(isErr, retData) {
        if (isErr || retData.length == 0) {
            rtRes.desc = "DFS信息获取失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var dataInfo = retData[0];

        rtRes.rstcode = "success";
        rtRes.data = {
            dfsid: dataInfo.id,
            dfsip: dataInfo.ip,
            dfsname: dataInfo.aliasname,
            dfspath: dataInfo.dfspath,
            copy: "1", //0:否,1:是
            copyState: "1", //0:异常,1:正常
            version: "1.5",
            inittime: dataInfo.inittm,
        };

        gResponseFunction(JSON.stringify(rtRes))
    }

    dfsmanageMgr.getInstance().queryDbTableMgr(queryData, callback);
}
function getDFSStateFromLocalDb(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: jsonObj.data
    }

    function callback(isErr, rst) {
        if (isErr || rst.length == 0) {
            rtRes.desc = "DFS状态获取失败！";
        } else {
            rtRes.rstcode = "success";
            rtRes.data.dfsState = rst[0].state;
        }
        gResponseFunction(JSON.stringify(rtRes));
        getDFSState(jsonObj);
    }

    dfsmanageMgr.getInstance().getDFSStateFromLocalDbMgr(jsonObj.data, callback);
}
function dealwithDFSModules(dfsid, callback) {
    if (typeof callback != "function") {
        return 1;
    }
    if (typeof dfsid == "undefined" || dfsid == "") {
        callback(true, "dfsid is null");
        return;
    }
    var dfsid = dfsid;
    var dirModulesInfo = [];
    var mrcModulesInfo = [];
    var osdModulesInfo = [];
    var sqlData = {
        sqlText: "select id,cfgpath,siteid,state from tbl_dirlist where dfsid = $1;",
        sqlValue: [dfsid]
    }
    dfsmanageMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, dir) {
        if (isErr) {
            callback(true, "query dir_info error!");
            return;
        }
        dirModulesInfo = dir;
        sqlData.sqlText = "select id,cfgpath,siteid,state from tbl_mrclist where dfsid = $1;";
        dfsmanageMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, mrc) {
            if (isErr) {
                callback(true, "query mrc_info error!")
                return;
            }
            mrcModulesInfo = mrc;
            sqlData.sqlText = "select id,cfgpath,siteid,state from tbl_osdlist where dfsid = $1;";
            dfsmanageMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, osd) {
                if (isErr) {
                    callback(true, "query osd_info error!")
                    return;
                }
                osdModulesInfo = osd;
                analysisDFSModules();
            })
        })
    });

    /*
     * dfsDiffSite = {
     *   siteid:{
     *       ip: "",
     *       port: "",
     *       dirArr: [],
     *       mrcArr: [],
     *       osdArr: []
     *   },...
     * }
     * */
    var dfsDiffSite = {}

    function analysisDFSModules() {
        for (var i = 0; i < dirModulesInfo.length; i++) {
            var dirObj = {module_id: dirModulesInfo[i].id, config_file: dirModulesInfo[i].cfgpath};
            dealModuleData(dirModulesInfo[i].siteid, "dirArr", dirObj);
        }
        for (var i = 0; i < mrcModulesInfo.length; i++) {
            var mrcObj = {module_id: mrcModulesInfo[i].id, config_file: mrcModulesInfo[i].cfgpath};
            dealModuleData(mrcModulesInfo[i].siteid, "mrcArr", mrcObj);
        }
        for (var i = 0; i < osdModulesInfo.length; i++) {
            var osdObj = {module_id: osdModulesInfo[i].id, config_file: osdModulesInfo[i].cfgpath};
            dealModuleData(osdModulesInfo[i].siteid, "osdArr", osdObj);
        }
        function dealModuleData(siteid, moduleArr, moduleObj) {
            if (!(siteid in dfsDiffSite)) {
                dfsDiffSite[siteid] = {
                    dirArr: [],
                    mrcArr: [],
                    osdArr: []
                };
            }
            dfsDiffSite[siteid][moduleArr].push(moduleObj);
        }

        var siteArr = [];
        for (var item in dfsDiffSite) {
            siteArr.push(item);
        }
        var siteLen = siteArr.length;
        querySiteInfo();
        function querySiteInfo() {
            siteLen--;
            if (siteLen < 0) {
                callback(false, dfsDiffSite);
                return;
            }
            var siteid = siteArr[siteLen];
            var sqlData = {
                sqlText: "select ip,port,state from tbl_siteinfo where id = $1;",
                sqlValue: [siteid]
            }
            dfsmanageMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
                if (isErr || rst.length == 0) {
                    console.log("query site_info error");
                    return;
                }
                if (rst[0].state != 1) {
                    console.log("site %s is fault!", rst[0].ip);
                    delete dfsDiffSite[siteid];
                    querySiteInfo();
                    return;
                }
                dfsDiffSite[siteid].ip = rst[0].ip
                dfsDiffSite[siteid].port = rst[0].port
                querySiteInfo();
            })
        }
    }
}
function getDFSState(jsonObj, callback) {

    var dfsid = jsonObj.data.dfsid;

    var allDFSModulesNum = 0;
    var updatedDFSModNum = 0;

    dealwithDFSModules(dfsid, dfsModInfoCallback);

    function dfsModInfoCallback(isErr, dfsModuleInfo) {
        if (isErr) {
            console.log(dfsModuleInfo);
            return;
        }
        for (var item in dfsModuleInfo) {
            var moduleValue = dfsModuleInfo[item];
            allDFSModulesNum += (moduleValue.dirArr.length + moduleValue.mrcArr.length + moduleValue.osdArr.length);
            reqDFSState(moduleValue);
        }
        function reqDFSState(moduleInfo) {
            var reqJson = {
                ip: moduleInfo.ip,
                port: moduleInfo.port,
                data: {
                    dfs_id: dfsid,
                    dir_modules: moduleInfo.dirArr,
                    mrc_modules: moduleInfo.mrcArr,
                    osd_modules: moduleInfo.osdArr,
                }
            }

            function callback(isErr, rstJson) {
                if (isErr) {
                    console.log("get dfs state faild!");
                    return;
                }
                if (rstJson.data.ret_code == 0) {
                    var dir_module = rstJson.data.dir_modules;
                    var mrc_module = rstJson.data.mrc_modules;
                    var osd_module = rstJson.data.osd_modules;
                    for (var i = 0; i < dir_module.length; i++) {
                        updateDfsModuleState("tbl_dirlist", dir_module[i]);
                    }
                    for (var i = 0; i < mrc_module.length; i++) {
                        updateDfsModuleState("tbl_mrclist", mrc_module[i]);
                    }
                    for (var i = 0; i < osd_module.length; i++) {
                        updateDfsModuleState("tbl_osdlist", osd_module[i]);
                    }
                } else {
                    console.log("get host %s dfs state faild!", reqJson.ip);
                }
            }

            dfsmanageMgr.getInstance().getDFSStateMgr(reqJson, callback)
        }

        function updateDfsModuleState(tblName, modules) {
            var module_id = modules.module_id;
            var module_state = modules.module_status;
            dfsmanageMgr.getInstance().updateDbByDetailInfoMgr(tblName, "state", module_state, "id", module_id, function (isErr) {
                if (isErr) {
                    console.log("update " + tblName + " state faild!")
                }
                updatedDFSModNum++
                updateDfsState();
            })
        }

        function updateDfsState() {
            if (updatedDFSModNum < allDFSModulesNum) {
                return;
            }
            var udpServerMgr = new udpServer();
            udpServerMgr.timingUpdateDfs(dfsid);
        }
    }
}

function optDFS(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: jsonObj.data
    }

    var opertype = jsonObj.data.opertype;

    if (opertype == 2) {//停止DFS
        var sqlData = {
            sqlText: "select clsname from tbl_instance where state = '1' and dfsid = $1;",
            sqlValue: [jsonObj.data.dfsid]
        }

        dfsmanageMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
            if (isErr) {
                rtRes.desc = "数据库查询失败！";
                gResponseFunction(JSON.stringify(rtRes));
                return;
            }
            if (rst.length > 0) {
                var instArr = [];
                for (var i = 0; i < rst.length; i++) {
                    instArr.push(rst[i].clsname);
                }
                rtRes.desc = "该DFS正在被云实例【" + instArr.toString() + "】使用，不能停止！";
                gResponseFunction(JSON.stringify(rtRes));
                return;
            }
            execOptDFS();
        })
    } else {
        execOptDFS();
    }

    function execOptDFS() {

        var dfsid = jsonObj.data.dfsid;
        var dfspath = jsonObj.data.dfspath;

        dealwithDFSModules(dfsid, dfsModInfoCallback);

        function dfsModInfoCallback(isErr, dfsModuleInfo) {
            if (isErr) {
                rtRes.desc = dfsModuleInfo;
                gResponseFunction(JSON.stringify(rtRes));
                return;
            }

            for (var item in dfsModuleInfo) {
                dfsModuleInfo[item].retcode = "0";
            }
            rtRes.rstcode = "success";
            rtRes.data.dfsModuleInfo = dfsModuleInfo;
            gResponseFunction(JSON.stringify(rtRes));

            for (var item in dfsModuleInfo) {
                reqOptDFS(dfsModuleInfo[item]);
            }
            function reqOptDFS(moduleInfo) {

                var dirArr = [];
                var mrcArr = [];
                var osdArr = [];
                for (var i = 0; i < moduleInfo.dirArr.length; i++) {
                    dirArr.push(moduleInfo.dirArr[i].config_file);
                }
                for (var i = 0; i < moduleInfo.mrcArr.length; i++) {
                    mrcArr.push(moduleInfo.mrcArr[i].config_file);
                }
                for (var i = 0; i < moduleInfo.osdArr.length; i++) {
                    osdArr.push(moduleInfo.osdArr[i].config_file);
                }

                var reqJson = {
                    ip: moduleInfo.ip,
                    port: moduleInfo.port,
                    opertype: opertype,
                    data: {
                        dfsid: dfsid,
                        dfspath: dfspath,
                        dir_name: dirArr,
                        mrc_name: mrcArr,
                        osd_name: osdArr,
                    }
                }
                dfsmanageMgr.getInstance().optDFSMgr(reqJson, function () {
                    console.log("optDFSReqJsonData:" + JSON.stringify(reqJson));
                })
            }
        }
    }
}
function getOptDFSState(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: jsonObj.data
    }

    var opertype = jsonObj.data.opertype;
    var dfsid = jsonObj.data.dfsid;
    var dfspath = jsonObj.data.dfspath;
    var dfsModuleInfoObj = jsonObj.data.dfsModuleInfo;

    var allSiteNum = 0;
    var finishSiteNum = 0;

    var reqFlag = false;
    for (var item in dfsModuleInfoObj) {
        var moduleInfo = dfsModuleInfoObj[item];
        if (moduleInfo.retcode == 2 || moduleInfo.retcode == 3) {
            continue;
        }
        reqFlag = true;
        reqOptDFSState(item);
    }
    if (!reqFlag) { //进度获取完毕
        var optResult = "success";
        for (var item in dfsModuleInfoObj) {
            if (dfsModuleInfoObj[item].retcode != 2) {
                optResult = "error";
                break;
            }
        }
        if (optResult == "success") {
            rtRes.data.result = 2;
        } else {
            rtRes.data.result = 3;
        }
        rtRes.rstcode = "success";
        gResponseFunction(JSON.stringify(rtRes));
        getDFSState({data: {dfsid: dfsid}});
        return;
    }

    function reqOptDFSState(item) {
        allSiteNum++;
        var dfsModInfo = dfsModuleInfoObj[item];
        var dirArr = [];
        var mrcArr = [];
        var osdArr = [];
        for (var i = 0; i < dfsModInfo.dirArr.length; i++) {
            dirArr.push(dfsModInfo.dirArr[i].config_file);
        }
        for (var i = 0; i < dfsModInfo.mrcArr.length; i++) {
            mrcArr.push(dfsModInfo.mrcArr[i].config_file);
        }
        for (var i = 0; i < dfsModInfo.osdArr.length; i++) {
            osdArr.push(dfsModInfo.osdArr[i].config_file);
        }
        var reqJsonObj = {
            ip: dfsModInfo.ip,
            port: dfsModInfo.port,
            opertype: opertype,
            data: {
                dfsid: dfsid,
                dfspath: dfspath,
                dir_name: dirArr,
                mrc_name: mrcArr,
                osd_name: osdArr,
            }
        }
        function callback(isErr, resJson) {
            if (isErr) {
                return;
            }

            var resJsonData = resJson.data;
            var retcode = resJsonData.retcode;//retcode = 0:未启动，1:启动中，2:启动成功，3:启动失败
            if (retcode == 3) {
                if (resJsonData.dirfailurenum == 0 && resJsonData.mrcfailurenum == 0 && resJsonData.osdfailurenum == 0) {
                    retcode = 2;
                }
            }
            dfsModuleInfoObj[item].retcode = retcode;

            finishSiteNum++;
            responseFunction();
        }
        dfsmanageMgr.getInstance().getOptDFSStateMgr(reqJsonObj, callback);
    }

    function responseFunction() {
        if (finishSiteNum < allSiteNum) {
            return;
        }
        rtRes.rstcode = "success";
        rtRes.data.dfsModuleInfo = dfsModuleInfoObj;
        rtRes.data.result = 1;
        gResponseFunction(JSON.stringify(rtRes));
        return;
    }
}


function enumVolumeList(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    //test data=======

    //rtRes.rstcode = "success";
    //for (var i = 0; i < 5; i++) {
    //    var dataValue = {};
    //    dataValue.name = "volume" + i;
    //    dataValue.id = "192.168.1." + i;
    //    rtRes.data.push(dataValue);
    //}
    //gResponseFunction(JSON.stringify(rtRes));
    //return;

    //==========test data


    var queryData = {
        sqlText: "select a.id,a.dfspath,a.state," +
        "b.ip as mrc_ip,b.port as mrc_port," +
        "c.ip as dir_ip,c.port as dir_port," +
        "d.ip as hostip,d.port as hostport " +
        "from tbl_dfslist a left join tbl_mrclist b on a.id = b.dfsid " +
        "left join tbl_dirlist c on a.id = c.dfsid left join tbl_siteinfo d on a.siteid = d.id " +
        "where a.id = $1;",
        sqlValue: [jsonObj.data.dfsid],
    }

    var subRequest = jsonObj.request.subRequest;
    dfsmanageMgr.getInstance().queryDbTableMgr(queryData, function (isErr, retData) {
        if (isErr || retData.length == 0) {
            rtRes.desc = "DFS信息获取失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }
        var dataInfo = retData[0];

        if (dataInfo.state != 1) { //DFS未启动，不能查询volume
            rtRes.rstcode = "success";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var reqJsonObj = {
            ip: dataInfo.hostip,
            port: dataInfo.hostport,
            data: {
                dfs_id: dataInfo.id,
                dfs_path: dataInfo.dfspath,
                mrc_ip: dataInfo.mrc_ip,
                mrc_port: dataInfo.mrc_port,
            }
        }

        function callback(isErr, resJson) {
            if (isErr) {
                rtRes.desc = "volume信息获取失败！";
            } else {
                var volumes = [];

                if (typeof resJson.data.volumes != 'undefined') {
                    rtRes.rstcode = "success";
                    volumes = resJson.data.volumes;
                }

                for (var i = 0; i < volumes.length; i++) {
                    var dataValue = {};
                    dataValue.name = volumes[i].volume_name;
                    dataValue.id = volumes[i].volume_id;
                    rtRes.data.push(dataValue);
                }
                if (subRequest == "dfs") {
                    rtRes.cloudInsInfo = {
                        dirip: dataInfo.dir_ip,
                        dirport: dataInfo.dir_port,
                        hostip: dataInfo.hostip,
                        hostport: dataInfo.hostport,
                    }
                }
            }
            gResponseFunction(JSON.stringify(rtRes));
        }

        dfsmanageMgr.getInstance().enumVolumeListMgr(reqJsonObj, callback);
    })
}
function enumDIRList(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }
    function callback(isErr, resJson) {
        var rtRes = {
            rstcode: "error",
            desc: "",
            data: ""
        }
        if (isErr) {
            console.log("DIR列表获取失败！");
            rtRes.desc = "数据获取失败！";
        } else {
            rtRes.rstcode = "success";
            //rtRes.data = resJson.data;
            rtRes.data = resJson;
        }
        gResponseFunction(JSON.stringify(rtRes));
    }

    var dataValue = jsonObj.data;//data重构
    jsonObj.data = dataValue;
    dfsmanageMgr.getInstance().enumDIRListMgr(jsonObj, callback);
}

function enumMRCList(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }
    function callback(isErr, resJson) {
        var rtRes = {
            rstcode: "error",
            desc: "",
            data: ""
        }
        if (isErr) {
            rtRes.desc = "数据获取失败！";
        } else {
            rtRes.rstcode = "success";
            //rtRes.data = resJson.data;
            rtRes.data = resJson;
        }
        gResponseFunction(JSON.stringify(rtRes));
    }

    var dataValue = jsonObj.data;//data重构
    jsonObj.data = dataValue;
    dfsmanageMgr.getInstance().enumMRCListMgr(jsonObj, callback);
}

function enumOSDList(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }
    function callback(isErr, resJson) {
        var rtRes = {
            rstcode: "error",
            desc: "",
            data: ""
        }
        if (isErr) {
            rtRes.desc = "数据获取失败！";
        } else {
            rtRes.rstcode = "success";
            //rtRes.data = resJson.data;
            rtRes.data = resJson;
        }
        gResponseFunction(JSON.stringify(rtRes));
    }

    var dataValue = jsonObj.data;//data重构
    jsonObj.data = dataValue;
    dfsmanageMgr.getInstance().enumOSDListMgr(jsonObj, callback);
}
function queryDirMrcOsd(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }
    var subRequest = jsonObj.request.subRequest;
    var sqlData = {
        sqlText: "",
        sqlValue: [],
    };
    sqlData.sqlValue[0] = "%" + jsonObj.data.name + "%";
    sqlData.sqlValue[1] = jsonObj.data.dfsid;
    if (subRequest == "dir") {
        sqlData.sqlText = "select * from tbl_dirlist where dirname like $1 and dfsid = $2;";
    } else if (subRequest == "mrc") {
        sqlData.sqlText = "select * from tbl_mrclist where mrcname like $1 and dfsid = $2;";
    } else if (subRequest == "osd") {
        sqlData.sqlText = "select * from tbl_osdlist where osdname like $1 and dfsid = $2;";
    } else {
        rtRes.desc = "请求参数错误！";
        gResponseFunction(JSON.stringify(rtRes));
        return;
    }
    dfsmanageMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
        if (isErr) {
            console.log(subRequest + " info query faild!");
            rtRes.desc = subRequest.toUpperCase() + "查询失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }
        rtRes.rstcode = "success";
        rtRes.data = rst;
        gResponseFunction(JSON.stringify(rtRes));
    })
}
function getDirMrcOsdConfigList(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    var subRequest = jsonObj.request.subRequest;

    //查询DIR、MRC、OSD信息
    var queryData = {};
    if (subRequest == "dir") {
        queryData.sqlText = "select a.cfgpath,b.ip as hostip,b.port as hostport,b.state as sitestate " +
            "from tbl_dirlist a " +
            "left join tbl_siteinfo b on a.siteid = b.id " +
            "where a.id = $1;";
        queryData.sqlValue = [jsonObj.data.dir_id];
    } else if (subRequest == "mrc") {
        queryData.sqlText = "select a.cfgpath,b.ip as hostip,b.port as hostport,b.state as sitestate " +
            "from tbl_mrclist a " +
            "left join tbl_siteinfo b on a.siteid = b.id " +
            "where a.id = $1;";
        queryData.sqlValue = [jsonObj.data.mrc_id];
    } else if (subRequest == "osd") {
        queryData.sqlText = "select a.cfgpath,b.ip as hostip,b.port as hostport,b.state as sitestate " +
            "from tbl_osdlist a " +
            "left join tbl_siteinfo b on a.siteid = b.id " +
            "where a.id = $1;";
        queryData.sqlValue = [jsonObj.data.osd_id];
    } else {
        console.log("[get " + subRequest + "ConfigList]:请求参数有误！");
        rtRes.desc = "请求参数有误！";
        gResponseFunction(JSON.stringify(rtRes));
        return;
    }
    dfsmanageMgr.getInstance().queryDbTableMgr(queryData, function (isErr, rst) {
        if (isErr || rst.length == 0) {
            console.log("[get " + subRequest + "ConfigList]:get " + subRequest + " info faild!");
            rtRes.desc = subRequest.toUpperCase() + "信息获取失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var dataInfo = rst[0];

        if (dataInfo.sitestate != 1) {
            console.log("[getConfigList]:this site has crashed!");
            rtRes.desc = "站点故障！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }
        var cfgpath = dataInfo.cfgpath;
        var reqJsonObj = {
            ip: dataInfo.hostip,
            port: dataInfo.hostport,
            data: {
                cfgname: cfgpath.substring(cfgpath.lastIndexOf("/") + 1),
                path: cfgpath.substring(0, cfgpath.lastIndexOf("/")),
                //cfgname: "dirconfig.properties",
                //path: "/home/uxdb/uxdbinstall/dfs/etc/xos/xtreemfs",
            }
        }

        function callback(isErr, resJson) {
            if (isErr) {
                rtRes.desc = "请求失败！";
            } else {

                var resData = resJson.data;

                if (resData.retcode == 0) {
                    rtRes.rstcode = "success";
                    var cfgfilename = resData.cfgname;
                    var cfgpath = resData.path;
                    var cfglist = resData.tarray;
                    for (var i = 0; i < cfglist.length; i++) {
                        var pclass = cfglist[i].pclass;
                        var parray = cfglist[i].parray;
                        for (var j = 0; j < parray.length; j++) {
                            var dataValue = {
                                cfgname: cfgfilename,
                                cfgpath: cfgpath,
                                pclass: pclass,
                                pname: parray[j].pname,
                                pvalue: parray[j].pvalue,
                                description: parray[j].description,
                                ismodify: parray[j].ismodify,
                                ptype: parray[j].ptype,
                                vlist: parray[j].vlist,
                            }
                            rtRes.data.push(dataValue);
                        }
                    }
                } else {
                    rtRes.desc = errorCode[resData.retcode] || "其他错误！";
                }
                gResponseFunction(JSON.stringify(rtRes));
            }
        }

        dfsmanageMgr.getInstance().getDirMrcOsdConfigListMgr(reqJsonObj, callback);
    })

}
function setDirMrcOsdConfig(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }
    var subRequest = jsonObj.request.subRequest;

    //查询DIR、MRC、OSD信息
    var queryData = {};
    if (subRequest == "dir") {
        queryData.sqlText = "select a.cfgpath,b.ip as hostip,b.port as hostport,b.state as sitestate " +
            "from tbl_dirlist a " +
            "left join tbl_siteinfo b on a.siteid = b.id " +
            "where a.id = $1;";
        queryData.sqlValue = [jsonObj.data.dir_id];
    } else if (subRequest == "mrc") {
        queryData.sqlText = "select a.cfgpath,b.ip as hostip,b.port as hostport,b.state as sitestate " +
            "from tbl_mrclist a " +
            "left join tbl_siteinfo b on a.siteid = b.id " +
            "where a.id = $1;";
        queryData.sqlValue = [jsonObj.data.mrc_id];
    } else if (subRequest == "osd") {
        queryData.sqlText = "select a.cfgpath,b.ip as hostip,b.port as hostport,b.state as sitestate " +
            "from tbl_osdlist a " +
            "left join tbl_siteinfo b on a.siteid = b.id " +
            "where a.id = $1;";
        queryData.sqlValue = [jsonObj.data.osd_id];
    }

    dfsmanageMgr.getInstance().queryDbTableMgr(queryData, function (isErr, rst) {
        if (isErr || rst.length == 0) {
            console.log("[get" + subRequest + "ConfigList]:get " + subRequest + " info faild!");
            rtRes.desc = subRequest.toUpperCase() + "信息获取失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var dataInfo = rst[0];

        if (dataInfo.sitestate != 1) {
            console.log("[getConfigList]:this site has crashed!");
            rtRes.desc = "站点故障！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }
        var reqJsonObj = {
            ip: dataInfo.hostip,
            port: dataInfo.hostport,
            data: {
                cfgname: dataInfo.cfgname,
                path: dataInfo.cfgpath,
                pname: jsonObj.data.pname,
                pvalue: jsonObj.data.pvalue,
                ptype: jsonObj.data.ptype,
            }
        }

        function callback(isErr, resJson) {
            if (isErr) {
                rtRes.desc = "请求失败！";
            } else {

                var resData = resJson.data;

                if (resData.retcode == 0) {
                    rtRes.rstcode = "success";
                    rtRes.data = reqJsonObj.data;
                } else {
                    rtRes.desc = errorCode[resData.retcode] || "其他错误！";
                }
                gResponseFunction(JSON.stringify(rtRes));
            }
        }

        dfsmanageMgr.getInstance().setDirMrcOsdConfigMgr(reqJsonObj, callback);
    })
}


function createVolume(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    var queryData = {
        sqlText: "select a.id,a.dfspath,a.state,b.ip as mrc_ip,b.port as mrc_port," +
        "c.ip,c.port from tbl_dfslist a left join tbl_mrclist b on a.id = b.dfsid left join tbl_siteinfo c on a.siteid = c.id where a.id = $1;",
        sqlValue: [jsonObj.data.dfsid],
    }
    dfsmanageMgr.getInstance().queryDbTableMgr(queryData, function (isErr, retData) {
        if (isErr || retData.length == 0) {
            rtRes.desc = "Get DFS info Failed！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var dataInfo = retData[0];

        if (dataInfo.state != 1) {
            rtRes.desc = "站点故障！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var reqJsonObj = {
            ip: dataInfo.ip,
            port: dataInfo.port,
            data: {
                mrc_port: dataInfo.mrc_port,
                mrc_ip: dataInfo.mrc_ip,
                volume_name: jsonObj.data.volume_name
            }
        }

        function callback(isErr, resJson) {
            if (isErr) {
                rtRes.desc = "create volume failed！";
            } else {
                rtRes.rstcode = "success";
                rtRes.data = {
                    volume_name: resJson.volume_name,
                    mrc_ip: resJson.mrc_ip,
                    mrc_port: resJson.mrc_port,
                    volume_id: resJson.volume_id,
                };
            }
            gResponseFunction(JSON.stringify(rtRes));
        }

        dfsmanageMgr.getInstance().createVolume(reqJsonObj, callback);
    })
}

function deleteVolume(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    var queryData = {
        sqlText: "select a.id,a.dfspath,a.state,b.ip as mrc_ip,b.port as mrc_port," +
        "c.ip,c.port from tbl_dfslist a left join tbl_mrclist b on a.id = b.dfsid left join tbl_siteinfo c on a.siteid = c.id where a.id = $1;",
        sqlValue: [jsonObj.data.dfsid],
    }
    dfsmanageMgr.getInstance().queryDbTableMgr(queryData, function (isErr, retData) {
        if (isErr || retData.length == 0) {
            rtRes.desc = "Get DFS info Failed！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var dataInfo = retData[0];
        if (dataInfo.state != 1) {
            rtRes.desc = "站点故障！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var reqJsonObj = {
            ip: dataInfo.ip,
            port: dataInfo.port,
            data: {
                mrc_port: dataInfo.mrc_port,
                mrc_ip: dataInfo.mrc_ip,
                volume_name: jsonObj.data.volume_name
            }
        }

        function callback(isErr, resJson) {
            if (isErr) {
                rtRes.desc = "delete volume failed！";
            } else {
                rtRes.rstcode = "success";
                rtRes.data = resJson.ret_code;
            }
            gResponseFunction(JSON.stringify(rtRes));
        }

        dfsmanageMgr.getInstance().deleteVolume(reqJsonObj, callback);
    })
}

function deleteDFS(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    function callback(isErr) {
        if (isErr) {
            rtRes.desc = "delete dfs failed！";
        } else {
            rtRes.rstcode = "success";
        }
        gResponseFunction(JSON.stringify(rtRes));
    }

    dfsmanageMgr.getInstance().deleteDFS(jsonObj, callback);
}
function getVolumePath(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }
    function callback(isErr, resJson) {
        var rtRes = {
            rstcode: "error",
            desc: "",
            data: []
        }
        if (isErr) {
            rtRes.desc = "数据获取失败！";
        } else {
            rtRes.rstcode = "success";
            for (var i = 0; i < resJson.length; i++) {
                var dataValue = resJson[i].ip + ":" + resJson[i].port;
                rtRes.data.push(dataValue);
            }
        }
        console.log("getVolumePathData:" + rtRes.data);
        gResponseFunction(JSON.stringify(rtRes));
    }

    dfsmanageMgr.getInstance().getVolumePathMgr(jsonObj, callback);
}
function modifyAliasname(jsonObj,gResponseFunction) {
    if (typeof gResponseFunction !== "function"){
        return 1
    };
    var rtRes = {
        rstcode:"error",
        desc:"",
        data:jsonObj.data
    };

    dfsmanageMgr.getInstance().modifyAliasnameMgr(jsonObj.data,function (isErr) {
        if (isErr){
            rtRes.desc="数据库操作失败";
        } else {
            rtRes.rstcode="success";
        }
        gResponseFunction(JSON.stringify(rtRes));
    })
}

/*
 *
 *
 * unit test
 * */

if(0)
{
    function newVolume(){
        var jsonObj = {
            ip:"192.168.1.75",
            port:"7000",
            data:{ dfsid: '6473b38e0de74a126c941587facb32ee',
                volume_name:'demmo0'}
        }


        createVolume(jsonObj, function(jsonStr){
            console.log("---------"+jsonStr+"---------");
            var jsonObj = JSON.parse(jsonStr);
            if(jsonObj.rstcode == "success"){
                console.log("====================================^success^=========================================");
            }else{
                console.log("=====================================_error_==========================================");
            }
        });
    }

    newVolume();
}

if(0)
{
    function delVolume(){
        var jsonObj = {
            ip:"192.168.1.75",
            port:"7000",
            data:{ dfsid: '6473b38e0de74a126c941587facb32ee',
                volume_name:'demmo0'}
        }

        deleteVolume(jsonObj, function(jsonStr){
            console.log("---------"+jsonStr+"---------");
            var jsonObj = JSON.parse(jsonStr);
            if(jsonObj.rstcode == "success"){
                console.log("====================================^success^=========================================");
            }else{
                console.log("=====================================_error_==========================================");
            }
        });
    }

    delVolume();
}

if(0)
{
    function delDFS(){
        var jsonObj = {
            ip:"192.168.1.75",
            port:"7000",
            data:{ dfsid: '9dcf030b73aaffe273090c45469b0273',
                volume_name:'demmo0'}
        }

        deleteDFS(jsonObj, function(jsonStr){
            console.log("---------"+jsonStr+"---------");
            var jsonObj = JSON.parse(jsonStr);
            if(jsonObj.rstcode == "success"){
                console.log("====================================^success^=========================================");
            }else{
                console.log("=====================================_error_==========================================");
            }
        });
    }

    delDFS();
}

function getDFSListTest() {
    console.log("=================getDFSListTest================");
    var jsonObj = {
        ip: "192.168.1.249",
        port: "7000",
        data: {}
    }
    enumDFSList(jsonObj, function (jsonStr) {
        console.log("---------" + jsonStr + "---------");
        var jsonObj = JSON.parse(jsonStr);
        if (jsonObj.rstcode == "success") {
            console.log("====================================^success^=========================================");
        } else {
            console.log("=====================================_error_==========================================");
        }
    })
}

function getDFSStateTest() {
    console.log("=================getDFSStateTest================");
    var jsonObj = {
        ip: "192.168.1.116",
        port: "5000",
        data: {
            dfs_id: "hello",
            dir_modules: [
                {
                    module_id: "yyyy",
                    config_file: "dirconfig.properties"
                }
            ],
            mrc_modules: [
                {
                    module_id: "rrrr",
                    config_file: "mrcconfig.properties"
                }
            ],
            osd_modules: [
                {
                    module_id: "rrrr",
                    config_file: "osdconfig2.properties"
                }
            ]
        }
    }
    getDFSState(jsonObj, function (jsonStr) {
        console.log("---------" + jsonStr + "---------");
        var jsonObj = JSON.parse(jsonStr);
        if (jsonObj.rstcode == "success") {
            console.log("====================================^success^=========================================");
        } else {
            console.log("=====================================_error_==========================================");
        }
    })
}
//getVolumeList();
function getVolumeList() {
    console.log("=================getVolumeList================");
    var jsonObj = {
        ip: "192.168.1.137",
        port: "7000",
        data: {
            dfsid: "e7897429469c7198cb9506b4fd443638",
            dfs_path: "",
            mrc_ip: "",
            mrc_port: 32636
        }
    }
    enumVolumeList(jsonObj, function (jsonStr) {
        console.log("---------" + jsonStr + "---------");
        var jsonObj = JSON.parse(jsonStr);
        if (jsonObj.rstcode == "success") {
            console.log("====================================^success^=========================================");
        } else {
            console.log("=====================================_error_==========================================");
        }
    })
}

function startListen() {
    var listenFun = require('../../listenandsendrequest');
    var listenObj = new listenFun();
    listenObj.startServer(getDFSListTest, '12401');
    listenObj.startServer(getDFSStateTest, '12402');
    listenObj.startServer(getVolumeList, '12403');
}
//startListen();
