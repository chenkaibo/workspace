﻿var hostAccess = require('../common/hostaccess');
var dbField = require('./protocoldbfield');
var sms4_crypt = require('../common/crypt/sms4/sms4');
// 协议头结构体
var ProtocolHead = function()
{
    this.version = 0x10;   // 协议版本
    this.BLflag = 1;    // 大小端标记
    this.nextFlag = 0;  // 下一包标记
    this.againSendFlag = 0; // 超时重发标记
    this.revFlag = 0;   // 接收确认标记
    this.dtType = 0;    // 数据类型标记
    this.reserve1 = 0;  // 保留位
    this.reserve2 = 0;
    this.reserve3 = 0;
    this.sysType = 0;   // 操作系统类型
    this.other = 0;     // 其他
    this.timeStamp = 0; // 时间戳
    this.groupId = 0;   // 数据组ID
    this.sGroupId = 0;  // 数据分组ID
    this.dataSize = 0;  // 数据域长度（字节）
    this.headSize = 54; // 协议头长度，固定是54个字节
};

var protocolOptUnit = function()
{
    var _syncFlag =
    {
        sendUse:false,
        revFinish:0
    };
    var _revJson =
    {
        'username':'',
        'userrole':'',
        'hostip':'',
        'hostport':'',
        'type':'sync',       //需要反馈（同步请求）
        'maincmd':0,
        'subcmd':0,
        //'ssubcmd':0,
        'data':[]
    };
    var _hostAccess;        // 主机访问对象
    var _linkInfo;
    var _resJsonCbFun;  // 同步消息的回调函数
    // 得到连接信息
    this.getLinkInfo = function()
    {
        return _linkInfo;
    };
    // 连接代理端主机
    this.linkHost = function(reqJson,callback)
    {
        if(_hostAccess == null || _hostAccess == undefined)
        {
            _hostAccess = new hostAccess();
        }
        _hostAccess.connect(reqJson.hostip,reqJson.hostport,function(err)
        {
            if(err)
            {
                callback(true);
                return;
            }
            _linkInfo = reqJson;
            callback(false);
        });
    };
    // 断开与代理端主机的连接
    this.unlinkHost = function()
    {
        if(_hostAccess == null || _hostAccess == undefined)
        {
            return;
        }
        console.log('[protocolOptUnit] _hostAccess = ',_hostAccess);
        //_hostAccess.disconnect();
        //_hostAccess = null;
        //_linkInfo = null;
    };
    // 发送消息给代理端
    this.sendMsg = function(reqJson,callback)
    {
        if(typeof callback !== 'function')
        {
            return;
        }
        if(_syncFlag.sendUse)
        {
            callback(true,null);
            return;
        }
        _syncFlag.sendUse = true;
        _syncFlag.revFinish = 0;
        _resJsonCbFun = callback;
        var sendDb;

        try
        {
            sendDb = packSendProtocol(reqJson);
        }
        catch (err)
        {
            console.log(err.message);
            callback(true,err.message);
            _hostAccess.disConnect();
            return;
        }
        var sendCryptDb = new Buffer(sendDb.length);
	    var sendData = sendDb.slice(8, sendDb.length);
        var crypt_data = sms4_crypt.sms4_encrypt(sendData);

        for (var i = 0; i < sendDb.slice(0, 8).length; i++)
        {
            sendCryptDb[i] = sendDb.slice(0, 8)[i];
        }
        for (var i = 0; i < crypt_data.length; i++)
        {
            sendCryptDb[i+8] = crypt_data[i];
        }

        if(reqJson.type == 'sync')
        {
            _linkInfo = reqJson;
            _hostAccess.sendSync(sendCryptDb,revMsg);
        }
        else if(reqJson.type == 'asyn')
        {
            _hostAccess.sendAsyn(sendCryptDb);
            _hostAccess.disConnect();
            callback(false,null);
        }
        else
        {
            _hostAccess.disConnect();
            callback(true,null);
            return;
        }
    };
    // 用于接收代理端消息的回调函数
    function revMsg(err,revDb)
    {
        if(err)
        {
            if(typeof _resJsonCbFun === 'function')
            {
                _resJsonCbFun(true,err);
            }
            _syncFlag.revFinish = 0;
            _syncFlag.sendUse = false;
            _resJsonCbFun = null;
            _revJson = null;
            _linkInfo = null;
            return;
        }

        var recvCryptDb = new Buffer(revDb.length);
        var crypt_buff = sms4_crypt.sms4_decrypt(revDb.slice(8, revDb.length));
        for (var i = 0; i < 8; i++)
        {
            recvCryptDb[i] = revDb[i];
        }
        for (var i = 0; i < crypt_buff.length; i++)
        {
            recvCryptDb[i+8] = crypt_buff[i];
        }

        var isErr;
        try
        {
            isErr = unpackRevProtocol(recvCryptDb);
        }
        catch(err)
        {
            _resJsonCbFun(true,err.message);
            _hostAccess.disConnect();
            return;
        }

        if(_syncFlag.revFinish == 1)
        {
            _resJsonCbFun(isErr,_revJson);
            _syncFlag.revFinish = 0;
            _syncFlag.sendUse = false;
            _resJsonCbFun = null;
            _revJson = null;
			_hostAccess.disConnect();
        }
        else if (_syncFlag.revFinish == 2)
        {
            _resJsonCbFun(isErr,_revJson);
            _syncFlag.revFinish = 0;
            //_revJson = null;
            _revJson.data = [];
        }
    };
    // 打包要发送的数据
    function packSendProtocol(reqJson)
    {
        var reqDb;
        // 打包数据域
        var reqDataValue = dbField.packDbField(reqJson);

        // 打包协议包头
        var head = new ProtocolHead();
        head.dataSize = reqDataValue.length;
        var reqHead = packProtocolHead(head);

        // 打包质量戳
        var crc = crcValue(reqDataValue);

        // 生成协议包
        reqDb = buildPack(reqHead,reqDataValue,crc);
        return reqDb;

    };
    // 解包协议头
    function unpackHeadProtocol(revDb)
    {
        var head = new ProtocolHead();
        var flag = 0;
        var offset = 8;
        head.version = revDb.readUInt8(offset);
        offset = offset + 1;
        flag = revDb.readUInt8(offset);
        offset = offset + 1;
        head.BLflag = flag & 0x80;
        head.nextFlag = flag & 0x40;
        head.reserve3 = flag & 0x4;
        head.reserve2 = flag & 0x2;
        head.reserve1 = flag & 0x1;
        offset = offset + 8;

        // 时间戳
        if(!head.BLflag)
        {
            head.timeStamp = revDb.readDoubleLE(offset);
        }
        else
        {
            head.timeStamp = revDb.readDoubleBE(offset);
        }
        offset = offset + 8;

        // 数据组ID
        offset = offset + 16;
        // 数据分组ID
        offset = offset + 16;
        // 数据长度
        if(!head.BLflag)
        {
            head.dataSize = revDb.readUInt32LE(offset);
        }
        else
        {
            head.dataSize = revDb.readUInt32BE(offset);
        }
        offset = offset + 4;

        return head;
    }
    // 解包接收到的数据
    function unpackRevProtocol(revDb)
    {
        // 验证是不是有效的数据包
        if(!isValidPackage(revDb))
        {
            _revJson = null;
            _syncFlag.revFinish = 1;
            return true;
        }
        // 解包协议头
        var head = unpackHeadProtocol(revDb);
        // 解包数据区
        var ret = dbField.unPackDbField(head,revDb);
        if(ret == null)
        {
            return true;
        }
        //console.log("*****revDb=%s******",JSON.stringify(head));
		if(_revJson === null)
        {
            return true;
        }
        if(ret.finish)
        {
            _revJson.username = _linkInfo.username;
            _revJson.userrole = _linkInfo.userrole;
            _revJson.maincmd = ret.maincmd;
            _revJson.subcmd = ret.subcmd;
            //_revJson.ssubcmd = ret.ssubcmd;
            _revJson.hostip = _linkInfo.hostip;
            _revJson.hostport = _linkInfo.hostport;

            if(_revJson.data.length == 0)
            {
                _revJson.data = ret.data;
            }
            else
            {
                _revJson.data = _revJson.data.concat(ret.data);
            }
            if (head.reserve1 == 1)
            {
                _syncFlag.revFinish = 2;
            }
            else
            {
                _syncFlag.revFinish = 1;
            }

        }
        else
        {
            if(_revJson.data.length == 0)
            {
                _revJson.data = ret.data;
            }
            else
            {
                _revJson.data = _revJson.data.concat(ret.data);
                
            }
        }
        return false;
    }

    // 验证是不是有效的数据包
    function isValidPackage(revDb)
    {
        // todo
        return true;
    }
    /*
     功能：生成协议头
     参数：head ProtocolHead类型
     返回值：协议头Buffer
     */
    function packProtocolHead(head)
    {
        var rt;
        var buf = new Buffer(128);
        buf.fill(0);
        var offset = 0;
        var totalSize = head.headSize + head.dataSize + 8;

        buf.write(totalSize.toString(),offset,8);
        offset = offset + 8;
        buf.writeUInt8(head.version,offset);
        offset = offset + 1;

        var flag = 0x00;
        flag = flag | head.BLflag;
        flag = flag<<1;
        flag = flag | head.nextFlag;
        flag = flag<<1;
        flag = flag | head.againSendFlag;
        flag = flag<<1;
        flag = flag | head.revFlag;
        flag = flag<<1;
        flag = flag | head.dtType;
        flag = flag<<1;
        flag = flag | head.reserve1;
        flag = flag<<1;
        flag = flag | head.reserve2;
        flag = flag<<1;
        flag = flag | head.reserve3;
        buf.writeUInt8(flag,offset);
        offset = offset + 1;


        buf.writeUInt8(head.sysType,offset);
        offset = offset+1;
        buf.fill(0,offset,offset+7);
        offset = offset + 7;

        buf.writeDoubleBE(head.timeStamp,offset);
        offset = offset + 8;
        buf.fill(0,offset,offset + 16);
        offset = offset + 16;
        buf.fill(0,offset,offset + 16);
        offset = offset + 16;
        buf.writeUInt32BE(head.dataSize,offset);
        offset = offset + 4;

        rt = buf.slice(0,offset);
        return rt;
    }
    /*
     功能：生成质量戳
     参数：reqData 数据域数据
     返回值：质量戳值
     */
    function crcValue(reqData)
    {
        // todo
        var buf = new Buffer(8);
        buf.fill(0);
        return buf;
    }
    /*
     功能：生成完整协议包
     参数：reqHead 包头 reqDb 数据域 crc 质量戳
     返回值：完整协议包
     */
    function buildPack(reqHead,reqDb,crc)
    {
        var bufArray = new Array(reqHead,reqDb,crc);
        var len = 0;
        len = reqHead.length + reqDb.length + crc.length;
        var pack = Buffer.concat(bufArray,len);
        return pack;
    }

}

module.exports = protocolOptUnit;
