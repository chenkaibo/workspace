var instmanageMgr = require("./instmanagemgr");
var dfsmanage = require("../dfsmanage/mandfsmanage").dfsmanage;
var myDbMgr = require("../dbmanage/dbmanagemgr").dbMgr;
var errorCode = require("../../common/errorcode");
exports.triggerFunction = triggerFunction;
var mainRequestProcFuncs = {
    "enumInstList": enumInstList,
    "getInstState": getInstState,
    "optInst": optInst,
    "getInstConfigList": getInstanceConfigList,
    "setInstConfig": setInstanceConfig,
    "getAllActiveSiteInfo": getAllActiveSiteInfo,
    "getAllActiveDFSInfo": getAllActiveDFSInfo,
    "createInstance": createInstance,
    "getCreateInstState": getCreateInstState,
    "deleteInstance": deleteInstance,
    "queryInstance": queryInstance,
    "modifyAliasname":modifyAliasname,
}

function triggerFunction(postData, gResponseFunction) {
    if (postData.length <= 0) {
        return;
    }
    if (typeof gResponseFunction != "function") {
        return;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: ""
    };
    var jsonObj = JSON.parse(postData);
    var mainRequest = jsonObj.request.mainRequest;
    var procFunc = mainRequestProcFuncs[mainRequest];
    if (typeof procFunc != "function") {
        gResponseFunction(JSON.stringify(rtRes));
    } else {
        procFunc(jsonObj, gResponseFunction);
    }
}

function enumInstList(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }
    function callback(isErr, resJson) {
        var rtRes = {
            rstcode: "error",
            desc: "",
            data: ""
        }
        if (isErr) {
            rtRes.desc = "数据获取失败！";
        } else {
            rtRes.rstcode = "success";
            rtRes.data = resJson;
        }
        gResponseFunction(JSON.stringify(rtRes));
    }

    instmanageMgr.getInstance().enumInstListMgr(jsonObj, callback);
}
function getInstState(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var retData = {
        rstcode: "error",
        desc: "",
        data: {}
    }

    instmanageMgr.getInstance().getStateFromLocalDbMgr(jsonObj, function (isErr, ret) {
        if (isErr) {
            retData.desc = "实例状态获取失败";
            gResponseFunction(JSON.stringify(retData));
        } else {
            retData.rstcode = "success";
            retData.data.instState = ret[0].inststate;
            retData.data.dfsName = ret[0].aliasname || "";
            retData.data.dfsState = ret[0].dfsstate || "";
            retData.data.dfspath = ret[0].dfspath || "";
            gResponseFunction(JSON.stringify(retData));
        }

        getInstStateFromAgent(jsonObj);

    });
}

function getInstStateFromAgent(jsonObj) {
    console.log("getInstanceState:" + JSON.stringify(jsonObj));

    var reqData = jsonObj.data;

    var queryData = {
        sqlText: "select a.id,a.clsname,a.clspath,a.type,a.state,a.dfsid,b.ip,b.port,b.state as sitestate from " +
        "tbl_instance a inner join tbl_siteinfo b on a.siteid=b.id where a.id = $1;",
        sqlValue: [reqData.instid],
    }
    instmanageMgr.getInstance().queryDbTableMgr(queryData, function (isErr, retData) {
        if (isErr || retData.length == 0) {
            return;
        }

        var dataInfo = retData[0];

        if(dataInfo.sitestate != 1){
            console.log("site %s is fault,get instance state faild!",dataInfo.ip);
            return 1;
        }

        var reqJsonObj = {
            ip: dataInfo.ip,
            port: dataInfo.port,
            data: {
                instancename: dataInfo.clsname,
                instancepath: dataInfo.clspath,
                instanceid: dataInfo.id,
                type: parseInt(dataInfo.type)
            }
        }

        function callback(isErr, ret) {
            if (isErr) {
                console.log("request of get instance state has faild!");
                return;
            } else {
                if (ret.data.ret == 0) {
                    console.log("\n获取到的实例状态：" + ret.data.state + "\n");
                    if (dataInfo.state != ret.data.state) {
                        var data = {
                            sqlText: "update tbl_instance set state = $1 where id = $2;",
                            sqlValue: [ret.data.state, ret.data.instanceid],
                        }
                        instmanageMgr.getInstance().updateDbTableMgr(data, function (isErr, ret) {
                            if (isErr) {
                                console.log("update instance state to local db faild!");
                            } else {

                            }
                        })
                    }
                    if(ret.data.state != 1){
                        myDbMgr.disConnectByInst(dataInfo.id);
                    }
                } else {
                    //var errCode = errorCode[ret.data.ret] || "未知错误！";
                    //console.log("[error]:" + errCode);
                    console.log("get instance state from agent faild!");
                }
            }

            if (reqData.type == 2) { //云实例，需要获取DFS状态
                var sqlData = {
                    sqlText:"select dfsid from tbl_instance where id = $1;",
                    sqlValue:[reqData.instid]
                }
                instmanageMgr.getInstance().queryDbTableMgr(sqlData,function(isErr,rst){
                    if(isErr || rst.length == 0){
                        console.log("not found dfsid of cloud instance!");
                        return;
                    }
                    var dfsObj = {
                        data:{
                            dfsid:rst[0].dfsid
                        }
                    }
                    var dfsmanageMgr = new dfsmanage();
                    dfsmanageMgr.getDFSState(dfsObj, function(dfsState){
                        console.log("dfs state:" + dfsState);
                    })
                })
            }
        }
        instmanageMgr.getInstance().getInstStateFromAgentMgr(reqJsonObj, callback);
    })
}
function optInst(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var opertype = jsonObj.data.opertype; //1:开启实例，2关闭实例

    //查询实例信息
    var queryData = {
        sqlText: "select a.id,a.clsname,a.clspath,a.type,a.state,a.voluname," +
        "b.ip as dirip,b.port as dirport," +
        "c.ip as hostip,c.port as hostport,c.state as sitestate " +
        "from tbl_instance a left join tbl_dirlist b on a.dfsid = b.dfsid left join tbl_siteinfo c on a.siteid = c.id where a.id = $1;",
        sqlValue: [jsonObj.data.instid],
    }

    instmanageMgr.getInstance().queryDbTableMgr(queryData, function (isErr, retData) {
        if (isErr || retData.length == 0) {
            return;
        }
        var rtRes = {
            rstcode: "error",
            desc: "",
            data: {}
        }

        var dataInfo = retData[0];

        if (dataInfo.sitestate != 1) {
            console.log("[optInst]:this site has crashed!!");
            rtRes.desc = "站点故障！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var reqJsonObj = {
            ip: dataInfo.hostip,
            port: dataInfo.hostport,
            data: {
                instancename: dataInfo.clsname,
                instancepath: dataInfo.clspath,
                instanceid: dataInfo.id,
                type: parseInt(dataInfo.type),
            },
            opertype: opertype
        }
        if (opertype == "2") {
            myDbMgr.disConnectByInst(dataInfo.id);//断开该实例所连接的所有数据库
            reqJsonObj.data.mode = jsonObj.data.mode || "fast";
        }
        if (reqJsonObj.data.type == 2) {
            if (dataInfo.dirip == "" || dataInfo.dirport == "") {
                console.log("[optInst]:dirip or dirport is null!");
                rtRes.desc = "DIR信息有误！";
                gResponseFunction(JSON.stringify(rtRes));
                return;
            }
            reqJsonObj.data.dirip = dataInfo.dirip;
            reqJsonObj.data.dirport = dataInfo.dirport;
            reqJsonObj.data.volumename = dataInfo.voluname;
        }
        function callback(isErr, resJson) {
            if (isErr) {
                console.log("实例操作请求失败！");
                rtRes.desc = "请求失败！";
            } else {
                console.log("\n实例操作结果：" + JSON.stringify(resJson) + "\n");
                if (resJson.data.ret == 0) {
                    rtRes.rstcode = "success";
                    rtRes.data.instanStatus = (opertype == 1 ? 1 : 2);
                    rtRes.data.oper = "inst";
                    var data = {
                        sqlText: "",
                        sqlValue: [],
                    }
                    data.sqlValue[0] = (opertype == 1 ? 1 : 2);
                    if("port" in resJson.data){
                        data.sqlText = "update tbl_instance set state = $1,port = $2 where id = $3;"
                        data.sqlValue[1] = resJson.data.port;
                        data.sqlValue[2] = resJson.data.instanceid;
                    }else{
                        data.sqlText = "update tbl_instance set state = $1 where id = $2;"
                        data.sqlValue[1] = resJson.data.instanceid;
                    }
                    instmanageMgr.getInstance().updateDbTableMgr(data, function (isErr, ret) {
                        if (isErr) {
                            console.log("update instance state to local db faild!");
                        } else {

                        }
                    })
                } else {
                    if (opertype == "1") {
                        rtRes.desc = "实例启动失败！";
                    } else {
                        rtRes.desc = "实例停止失败！";
                    }
                }
            }
            gResponseFunction(JSON.stringify(rtRes));
        }

        instmanageMgr.getInstance().optInstMgr(reqJsonObj, callback);
    });
}

function getInstanceConfigList(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction !== "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    //查询实例信息
    var queryData = {
        sqlText: "select a.clsname,a.clspath,a.type,a.voluname,b.id as dfsid,c.ip as dirip,c.port as dirport," +
        "d.ip as hostip,d.port as hostport,d.state as sitestate " +
        "from tbl_instance a " +
        "left join tbl_dfslist b on b.id = a.dfsid " +
        "left join tbl_dirlist c on c.dfsid = b.id " +
        "left join tbl_siteinfo d on d.id = a.siteid " +
        "where a.id = $1;",
        sqlValue: [jsonObj.data.instid],
    }

    instmanageMgr.getInstance().queryDbTableMgr(queryData, function (isErr, retData) {
        if (isErr || retData.length == 0) {
            console.log("[getInstanceConfigList]:get instance info faild!");
            rtRes.desc = "实例信息获取失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var dataInfo = retData[0];

        if (dataInfo.sitestate != 1) {
            console.log("[getInstanceConfigList]:this site has crashed!");
            rtRes.desc = "站点故障！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var reqJsonObj = {
            ip: dataInfo.hostip,
            port: dataInfo.hostport,
            data: {
                instancename: dataInfo.clsname,
                type: parseInt(dataInfo.type),
            },
        }

        if (dataInfo.type == 1) {
            reqJsonObj.data.path = dataInfo.clspath;
        } else {
            if (dataInfo.dirip == "" || dataInfo.dirport == "") {
                console.log("[getInstanceConfigList]:dirip or dirport is null!");
                rtRes.desc = "DIR信息有误！";
                gResponseFunction(JSON.stringify(rtRes));
                return;
            }
            reqJsonObj.data.dirip = dataInfo.dirip;
            reqJsonObj.data.dirport = dataInfo.dirport;
            reqJsonObj.data.volumename = dataInfo.voluname;
        }

        function callback(isErr, resJson) {

            if (isErr) {
                console.log("get instance config list faild!");
                rtRes.desc = "请求失败！";
            } else {

                var resData = resJson.data;

                if (resData.retcode == 0) {
                    rtRes.rstcode = "success";
                    if (dataInfo.type == 2) {//云实例
                        var dfsurl = resData.dfsurl;
                        var dfsdb = resData.dfsdb;
                    }

                    var cfgfilename = resData.cfgname;

                    var tarray = resData.tarray;

                    for (var i = 0; i < tarray.length; i++) {
                        var arrayValue = tarray[i].tarrayValue;
                        var pclass = tarray[i].pclass;
                        for (var j = 0; j < pclass.length; j++) {
                            var pclassValue = pclass[j].pclassValue;
                            var parray = pclass[j].parray;
                            for (var k = 0; k < parray.length; k++) {
                                var dataValue = {};
                                dataValue.cfgname = cfgfilename;
                                dataValue.instance = dataInfo.clsname;
                                dataValue.pclass = pclassValue;
                                dataValue.pname = parray[k].pname;
                                dataValue.pvalue = parray[k].pvalue;
                                dataValue.punit = parray[k].punit;
                                dataValue.description = parray[k].description;
                                dataValue.ismodify = parray[k].ismodify;
                                dataValue.ptype = parray[k].ptype;
                                dataValue.vlist = parray[k].vlist;
                                rtRes.data.push(dataValue);
                            }
                        }
                    }
                } else {
                    //rtRes.desc = errorCode[resData.retcode] || "未知错误！";
                    rtRes.desc = "获取实例配置列表失败！";
                }
            }
            console.log("\n===instance config data:" + JSON.stringify(rtRes));
            gResponseFunction(JSON.stringify(rtRes));
        }

        instmanageMgr.getInstance().getInstanceConfigListMgr(reqJsonObj, callback);
    });
}

function setInstanceConfig(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    //查询实例信息
    var queryData = {
        sqlText: "select a.clsname,a.clspath,a.type,a.voluname,b.id as dfsid,c.ip as dirip,c.port as dirport," +
        "d.ip as hostip,d.port as hostport,d.state as sitestate " +
        "from tbl_instance a " +
        "left join tbl_dfslist b on b.id = a.dfsid " +
        "left join tbl_dirlist c on c.dfsid = b.id " +
        "left join tbl_siteinfo d on d.id = a.siteid " +
        "where a.id = $1;",
        sqlValue: [jsonObj.data.instid],
    }

    instmanageMgr.getInstance().queryDbTableMgr(queryData, function (isErr, rst) {
        if (isErr || rst.length == 0) {
            console.log("[setInstanceConfig]:get instance info faild!");
            rtRes.desc = "获取实例信息失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var dataInfo = rst[0];

        if (dataInfo.sitestate != 1) {
            console.log("[setInstanceConfig]:this site has crashed!");
            rtRes.desc = "站点故障！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var reqJsonObj = {
            ip: dataInfo.hostip,
            port: dataInfo.hostport,
            data: {
                instancename: dataInfo.clsname,
                type: parseInt(dataInfo.type),
                pname: jsonObj.data.pname,
                pvalue: jsonObj.data.pvalue,
                ptype: jsonObj.data.type,//1:整型,2:布尔,3:枚举,4:字符串
            },
        }

        if (dataInfo.type == 1) {
            reqJsonObj.data.path = dataInfo.clspath;
        } else {
            if (dataInfo.dirip == "" || dataInfo.dirport == "") {
                console.log("[setInstanceConfig]:dirip or dirport is null!");
                rtRes.desc = "DIR信息有误！";
                gResponseFunction(JSON.stringify(rtRes));
                return;
            }
            reqJsonObj.data.volumename = dataInfo.voluname;
            reqJsonObj.data.dirip = dataInfo.dirip;
            reqJsonObj.data.dirport = dataInfo.dirport;
        }

        function callback(isErr, resJson) {
            if (isErr) {
                rtRes.desc = "请求失败！";
            } else {

                var resData = resJson.data;

                if (resData.ret_code == 0) {
                    rtRes.rstcode = "success";
                    rtRes.data = reqJsonObj.data;
                } else {
                    rtRes.desc = errorCode[resData.retcode] || "未知错误";
                }
                gResponseFunction(JSON.stringify(rtRes));
            }
        }
        instmanageMgr.getInstance().setInstanceConfigMgr(reqJsonObj, callback);
    })
}
function getAllActiveSiteInfo(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    var sqlData = {
        sqlText: "select * from tbl_siteinfo where state = '1';",
        sqlValue: []
    }
    instmanageMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
        if (isErr) {
            console.log("get site info error!");
            rtRes.desc = "站点信息获取失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }
        if (rst.length == 0) {
            console.log("no active site now!");
            rtRes.desc = "未找到正常运行的站点信息！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        rtRes.rstcode = "success";
        for (var i = 0; i < rst.length; i++) {
            var siteStr = rst[i].ip + ":" + rst[i].port;
            rtRes.data.push(siteStr);
        }
        gResponseFunction(JSON.stringify(rtRes));
    });
}
function getAllActiveDFSInfo(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    var sqlData = {
        sqlText: "select * from tbl_dfslist where state = '1';",
        sqlValue: []
    }
    instmanageMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
        if (isErr) {
            console.log("get DFS info error!");
            rtRes.desc = "获取启动状态的DFS信息失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        if (rst.length == 0) {
            console.log("no active DFS now!");
            rtRes.desc = "目前没有正在运行的DFS！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        rtRes.rstcode = "success";

        for (var i = 0; i < rst.length; i++) {
            var dataObj = {};
            dataObj.name = rst[i].dfsname;
            dataObj.id = rst[i].id;
            rtRes.data.push(dataObj);
        }

        gResponseFunction(JSON.stringify(rtRes));
    });
}

function createInstance(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }

    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    var reqJson = {
        ip: jsonObj.data.ip,
        port: jsonObj.data.port,
        data: {
            instancename: jsonObj.data.instancename,
            type: parseInt(jsonObj.data.type),
            pw: jsonObj.data.pwd,
            encoding: jsonObj.data.encoding,
            pagecheck: jsonObj.data.pagecheck,
        }
    }

    if (reqJson.data.type == 2) {//dfsdb
        var volumename = jsonObj.data.path
        reqJson.data.volumename = volumename.substring(volumename.lastIndexOf(",") + 1);
        reqJson.data.dirip = jsonObj.data.dirip;
        reqJson.data.dirport = jsonObj.data.dirport;
        execCreateInstance();
    } else {
        reqJson.data.path = jsonObj.data.path;
        execCreateInstance();
    }
    function execCreateInstance() {

        //function callback(isErr, rst) {
        //    if (isErr) {
        //        rtRes.desc = "实例创建失败！";
        //        gResponseFunction(JSON.stringify(rtRes));
        //        return;
        //    }
        //    if (rst.data.retcode == 0) {
        //        rtRes.rstcode = "success";
        //    } else {
        //        var errorDesc = errorCode[rst.data.retcode] || "未知错误！";
        //        console.log(errorDesc);
        //        rtRes.desc = errorDesc;
        //    }
        //    gResponseFunction(JSON.stringify(rtRes));
        //}

        console.log("==========creating instance " + reqJson.data.instancename + "......");
        instmanageMgr.getInstance().createInstanceMgr(reqJson, function () {});
        rtRes.rstcode = "success";
        gResponseFunction(JSON.stringify(rtRes));
    }
}
function getCreateInstState(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }
    var reqJson = {
        ip: jsonObj.data.ip,
        port: jsonObj.data.port,
        data: {
            instancename: jsonObj.data.instancename,
            path: jsonObj.data.path,
            type: parseInt(jsonObj.data.type),
        }
    }

    function callback(isErr, rst) {
        if (isErr) {
            rtRes.desc = "获取实例创建进度失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        rtRes.rstcode = "success";
        rtRes.data = rst.data.progress;

        if (rst.data.retcode != 0) {
            rtRes.desc = "over";
        }

        gResponseFunction(JSON.stringify(rtRes));
    }

    instmanageMgr.getInstance().getCreateInstStateMgr(reqJson, callback);
}
function deleteInstance(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: ""
    }

    var sqlData = {
        sqlText: "select a.id,a.clsname,a.clspath,a.type,a.state as inststate,a.voluname," +
        "b.ip as dirip,b.port as dirport," +
        "c.ip as hostip,c.port as hostport,c.state as sitestate " +
        "from tbl_instance a left join tbl_dirlist b on a.dfsid = b.dfsid " +
        "left join tbl_siteinfo c on a.siteid = c.id where a.id = $1;",
        sqlValue: [jsonObj.data.instid]
    }

    instmanageMgr.getInstance().queryDbTableMgr(sqlData, function (isErr, rst) {
        if (isErr || rst.length == 0) {
            console.log("get instance info faild!");
            rtRes.desc = "获取实例信息失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var dataInfo = rst[0];

        if (dataInfo.inststate == 1) {
            rtRes.desc = "该实例正在运行，禁止删除！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        if (dataInfo.inststate == 0) {
            var sqlData = {
                sqlText: "delete from tbl_instance where id = $1;",
                sqlValue: [dataInfo.id]
            }
            instmanageMgr.getInstance().execDbTableMgr(sqlData, function (isErr) {
                if(isErr){
                    console.log("delete instance error!");
                    rtRes.desc = "删除实例失败！";
                }else{
                    rtRes.rstcode = "success";
                }
                gResponseFunction(JSON.stringify(rtRes));
            })
            return;
        }

        if (dataInfo.sitestate != 1) {
            rtRes.desc = "站点故障！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }

        var reqJson = {
            ip: dataInfo.hostip,
            port: dataInfo.hostport,
            data: {
                instancename: dataInfo.clsname,
                type: parseInt(dataInfo.type)
            }
        }
        if (reqJson.data.type == 1) { //local db
            reqJson.data.path = dataInfo.clspath;
        } else { //cloud db
            reqJson.data.dirip = dataInfo.dirip;
            reqJson.data.dirport = dataInfo.dirport;
            reqJson.data.volumename = dataInfo.voluname;
        }

        function callback(isErr, rst) {
            if (isErr) {
                console.log("[deleteInstance]:request faild!");
                rtRes.desc = "请求失败！";
                gResponseFunction(JSON.stringify(rtRes));
                return;
            }
            if (rst.data.retcode == 0) {
                rtRes.rstcode = "success";
                var sqlData = {
                    sqlText: "delete from tbl_instance where id = $1;",
                    sqlValue: [dataInfo.id]
                }
                instmanageMgr.getInstance().execDbTableMgr(sqlData, function (isErr) {
                    if(isErr){
                        console.log("delete instance from localdb faild!");
                    }
                    gResponseFunction(JSON.stringify(rtRes));
                })
            } else {
                rtRes.desc = "删除实例失败！";
                gResponseFunction(JSON.stringify(rtRes));
            }
        }

        instmanageMgr.getInstance().deleteInstanceMgr(reqJson, callback);
    })
}
function queryInstance(jsonObj, gResponseFunction) {
    if (typeof gResponseFunction != "function") {
        return 1;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: []
    }

    function callback(isErr, rst) {
        if (isErr) {
            rtRes.desc = "查询失败！";
            gResponseFunction(JSON.stringify(rtRes));
            return;
        }
        rtRes.rstcode = "success";
        rtRes.data = rst;
        gResponseFunction(JSON.stringify(rtRes));
    }

    instmanageMgr.getInstance().queryInstanceMgr(jsonObj.data, callback);
}
function modifyAliasname(jsonObj,gResponseFunction) {
    if (typeof  gResponseFunction != "function"){
        return 1;
    };
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: jsonObj.data
    }

    instmanageMgr.getInstance().modifyAliasnameMgr(jsonObj.data,function (isErr) {
        if (isErr){
            rtRes.desc="数据库操作失败";
        }else {
            rtRes.rstcode="success";
        }
        gResponseFunction(JSON.stringify(rtRes));
    });
}

//unit test

function startInst(){
    console.log("=================startInst================");
    var jsonObj = {
        ip:"192.168.1.137",
        port:"5000",
        data:{
            instname:"uxdbtest",
            instpath:"/home/uxdb/uxdbtest/",
            instid:"ce4bc17ad94c95af3456d7070f073000",
            type:0, //isDFS
            opertype:0
        },
    }
    optInst(jsonObj,function(jsonStr){
        console.log(jsonStr);
        var jsonObj = JSON.parse(jsonStr)
        if(jsonObj.rstcode == "success"){
            console.log("====================================^success^=========================================");
        }else{
            console.log("=====================================_error_==========================================");
        }
    })
}
function stopInst(){
    console.log("=================stopInst================");
    var jsonObj = {
        ip:"192.168.1.137",
        port:"5000",
        data:{
            instname:"uxdbtest",
            instpath:"/home/uxdb/uxdbtest/",
            instid:"ce4bc17ad94c95af3456d7070f073111",
            type:0, //isDFS
            mode:"smart",
            opertype:1
        },
    }
    optInst(jsonObj,function(jsonStr){
        console.log(jsonStr);
        var jsonObj = JSON.parse(jsonStr)
        if(jsonObj.rstcode == "success"){
            console.log("====================================^success^=========================================");
        }else{
            console.log("=====================================_error_==========================================");
        }
    })
}
function getInstStateFunc(){
    console.log("=================getInstStateFunc================");
    var jsonObj = {
        ip:"192.168.1.116",
        port:"5000",
        data:{
            instname:"uxdb04",
            instpath:"uxdb04",
            instid:"ce4bc17ad94c95af3456d7070f073167",
            type:2, //isDFS
        },
    }
    getInstState(jsonObj,function(jsonStr){
        console.log(jsonStr);
        var jsonObj = JSON.parse(jsonStr)
        if(jsonObj.rstcode == "success"){
            console.log("====================================^success^=========================================");
        }else{
            console.log("=====================================_error_==========================================");
        }
    })
}
//unit test
//startDFS();
function startDFS(){
    console.log("=================startDFS================");
    var jsonObj = {
        ip:"192.168.1.137",
        port:"5000",
        data:{
            dfspath:"/home/uxdb/uxdb/XtreemFS-1.5",
            dir_name:["dirconfig.properties"],
            mrc_name:["mrcconfig.properties"],
            osd_name:["osdconfig.properties"],
            dfsid:"fa934f9179688ccebe1f3d29febc1051",
            opertype:0
        },
    }
    optDFS(jsonObj,function(jsonStr){
        console.log(jsonStr);
        var jsonObj = JSON.parse(jsonStr)
        if(jsonObj.rstcode == "success"){
            console.log("====================================^success^=========================================");
        }else{
            console.log("=====================================_error_==========================================");
        }
    })
}
function stopDFS(){
    console.log("=================stopDFS================");
    var jsonObj = {
        ip:"192.168.1.137",
        port:"5000",
        data:{
            dfspath:"/home/uxdb/uxdb/XtreemFS-1.5",
            dir_name:["dirconfig.properties"],
            mrc_name:["mrcconfig.properties"],
            osd_name:["osdconfig.properties"],
            dfsid:"ce4bc17ad94c95af3456d7070f073111",
            opertype:1
        },
    }
    optDFS(jsonObj,function(jsonStr){
        console.log(jsonStr);
        var jsonObj = JSON.parse(jsonStr)
        if(jsonObj.rstcode == "success"){
            console.log("====================================^success^=========================================");
        }else{
            console.log("=====================================_error_==========================================");
        }
    })
}
//getInstList();
function getInstList(){
    console.log("=================getInstList================");
    var jsonObj = {
        ip:"192.168.1.249",
        port:"7000",
        data:{}
    }
    enumInstList(jsonObj,function(jsonStr){
        console.log("---------"+jsonStr+"---------");
        var jsonObj = JSON.parse(jsonStr);
        if(jsonObj.rstcode == "success"){
            console.log("====================================^success^=========================================");
        }else{
            console.log("=====================================_error_==========================================");
        }
    })
}
function getDbList(){
    console.log("=================getDbList================");
    var jsonObj = {
        ip:"192.168.1.137",
        port:"5000",
        data:{
            name:"uxdb11111",  //dbname
            password:"123456"  //dbpassword
        }
    }
    enumDbList(jsonObj,function(jsonStr){
        console.log("---------"+jsonStr+"---------");
        var jsonObj = JSON.parse(jsonStr);
        if(jsonObj.rstcode == "success"){
            console.log("====================================^success^=========================================");
        }else{
            console.log("=====================================_error_==========================================");
        }
    })
}
function startListen(){
    var listenFun = require('../../listenandsendrequest');
    var listenObj = new listenFun();
    listenObj.startServer(startInst,'12301');
    listenObj.startServer(stopInst,'12302');
    listenObj.startServer(getDbList,'12303');
    listenObj.startServer(getInstList,'12304');
    listenObj.startServer(startDFS,'12305');
    listenObj.startServer(stopDFS,'12306');
    listenObj.startServer(getInstStateFunc,'12307');
}
//startListen();

