/**
 * Created by 17726 on 2017/1/19.
 */
//监听表格，同时单选按钮选中时修改指定按钮的style
function listenTable(tableid,btid) {
    var $table = $("#" + tableid);
    $table.on('check.bs.table page-change.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table', function (arg) {
        if (btid == "") {
            return;
        }
        var selected = $("#" + tableid).bootstrapTable('getSelections');
        if (selected.length > 0) {
            d3.select('#'+btid).classed("delBtnClass",false).classed("btn admitClick",true).attr("disabled",null);
        }
        else {
            d3.select('#'+btid).classed("delBtnClass",true).classed("btn admitClick",false).attr("disabled",true);
        }
    });
}
//返回选中行
function getIdSelections(tableId) {
    return $.map($("#"+tableId).bootstrapTable('getSelections'), function (row) {
        return row;
    });
}
/*
 * 判断单选按钮是否选中
 * */
function changeButtonStatus(elemId,btid)
{
    if(btid == "")
    {
        return;
    }
    var selected = $("#"+elemId).bootstrapTable('getSelections');
    if(selected.length > 0)
    {
        d3.select("#" + btid)[0][0].disabled = false;
        d3.select("#" + btid).classed("delBtnClass",false).classed("btn admitClick",true);
    }
    else
    {
        d3.select("#" + btid)[0][0].disabled = true;
        d3.select("#" + btid).classed("delBtnClass",true).classed("btn admitClick",false);
    }
}