CREATE TABLE tbl_dbmonitor
(
  id VARCHAR(255) NOT NULL,
  sessionnum text,
  loginnum text,
  readblks text,
  hitblks text,
  insertnum text,
  deletenum text,
  updatenum text,
  fetchnum text,
  returnnum text,
  commitnum text,
  rollbacknum text,
  cpuusage text,
  memeryusage text,
  diskusage text,
  CONSTRAINT tbl_dbmonitor_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tbl_dbmonitor
  OWNER TO uxdbwebuser;

