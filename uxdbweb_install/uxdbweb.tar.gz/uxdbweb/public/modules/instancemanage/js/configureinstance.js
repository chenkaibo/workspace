'use strict';
var containDiv,configDataFirstFlag = true;
window.onresize = function()
{
    screenConfigShow();
    /**定时刷新配置界面的数据**/
    //setInterval(initConfigTable,30 * 1000);
};
/*
* 实例配置元素
* */
var insId;
function getConfigureInstanElem(data)
{
    window.focus();
    changePath("云数据库管理->实例管理->实例操作->实例配置");
    window.sessionStorage.ux_pagePath = "instanManage,insConfiguration";
    insId = data;
    setParameterData(data);
    var currentRole = window.sessionStorage.ux_curUserRole;
    d3.select("#mainContainDiv").remove();
    containDiv = d3.select("#instanaceBodyId")
        .append("div")
        .attr({
            'id':'mainContainDiv',
            'class':'siteList-content container'
        })
        .append("div")
        .attr("id","contain-div-id")
        .style("padding","70px 0px 0px 32px");
    containDiv.append("button")
        .attr("class","btn btn-default admitClick backBtn")
        .attr("onClick","goConfigureBack()")
        .html("返回上一级");
    /*
     * 配置元素
    * */
    d3.select(".siteList-content")
        .append("fieldset")
        .classed("inslist-content",true)
        .style("height","692px")
        .append("legend")
        .html("配置实例");
    var configureContainDiv = d3.select(".inslist-content").append("div")
        .attr({
            'id':'configureInstanDivId'
        });
    configureContainDiv.append("button")
        .attr({
            'id':'configInstanId',
            'class':'delBtnClass disabledElem',
            'disabled':'disabled'
        })
        .on("click",function(){
            d3.select(this).classed("admitClick",false);
            configInsFun();
        })
        .html("配&nbsp;&nbsp;&nbsp;&nbsp;置");
    /*
     * 查询条件部分*/
    getQueryConfigCondition("#configureInstanDivId");
    configureContainDiv.append("div")
        .attr("id","configTabDiv")
        .append("table")
        .attr("id","configTableId");
    if(currentRole == 1)
    {
        d3.selectAll(".disabledElem").style('display','none');
    }
    configTableInit();
    initConfigTable();
    screenConfigShow();
}
/*
 * 选择条件查询元素
 * */
function getQueryConfigCondition(contain)
{
    d3.select(contain)
        .append("div")
        .attr("id","searchSite-form")
        .attr("class","pull-right searchSite")
        .append("div")
        .attr("id","instanceName")
        .attr("class","searchSite-content");
    d3.select("#searchSite-form")
        .append("div")
        .attr("id","instanceType")
        .attr("class","searchSite-content");
    d3.select("#searchSite-form")
        .append("div")
        .attr("id","instanceStatus")
        .attr("class","searchSite-content");
    d3.selectAll(".searchSite-content")
        .append("input")
        .attr("type","checkbox")
        .each(function(d,i){
            d3.select(this).attr({
                id:"checkboxId" + i
            });
        })
        .on("click",function(d,i){
            checkBoxFun(i);
        })
        .attr("class","siteCheck");
    var searchSite_content= d3.selectAll(".searchSite-content");
    d3.select(searchSite_content[0][0])
        .insert("span",":nth-child(2)")
        .attr("class","searchTypeName")
        .html("已修改");
    d3.select(searchSite_content[0][1])
        .insert("span",":nth-child(2)")
        .attr("class","searchTypeName")
        .html("名&nbsp;&nbsp;称：");
    d3.select(searchSite_content[0][1])
        .insert("input",":nth-child(3)")
        .attr({
            'type':'text',
            'id':'selectElemId1',
            'disabled':""
        });
    d3.select(searchSite_content[0][2])
        .insert("span",":nth-child(2)")
        .attr("class","searchTypeName")
        .html("实&nbsp;&nbsp;例：");
    d3.select(searchSite_content[0][2])
        .insert("input",":nth-child(3)")
        .attr({
            'type':'text',
            'id':'selectElemId2',
            'disabled':""
        });
    d3.select("#searchSite-form")
        .append("button")
        .attr("class","btn btn-sm btn-bg-color searchSite-btn")
        .on("click",function(){
            /*
             * 修改查询按钮的颜色*/
            d3.select("#searchSite-form button").classed("searchSite-btn",false);
            d3.select("#searchSite-form button").classed("searchSite-btn-backWhite",true);
            queryConfigInstance();
        })
        .attr("title","查找")
        .style("margin","4px 29px 0 4px");
    d3.select(".siteList-content")
        .append("div")
        .attr("class","instance-list")
        .append("table")
        .attr("id","table");
}
/*
 * 界面适应性
 * */
function screenConfigShow()
{
    var minWidth = 1921;
    var minHeight = 953;
    if(innerHeight < minHeight)
    {
        d3.select("#configureInstanDivId").style({
            "background-size":"100% 94%",
        });
    }else{
        d3.select("#configureInstanDivId").style({
            "background-size":"100% 100%",
        });
    }
    if(innerWidth < minWidth)
    {
        d3.select("#configureInstanDivId").style({
            "background-size":"100% 94%",
        });
    }else{
        d3.select("#configureInstanDivId").style({
            "background-size":"100% 100%",
        });
    }
}
/******************************配置界面表格相关函数******************************/
function configTableInit()
{
    var par = [{field: 'boxStatus' ,radio: true ,align: 'center' },
        {field: 'index' ,title: '序&nbsp;&nbsp;号' ,align: 'center' },
        {field: 'name' ,title: '名&nbsp;&nbsp;称' ,align: 'center' },
        {field: 'type' ,title: '类&nbsp;&nbsp;型' ,algin: 'center' ,formatter:function(value,row,index){
            var typeValue;//1:整型,2:布尔,3:枚举,4:字符串
            if(row.type == 1)
            {
                typeValue = "整型";
            }else if(row.type == 2)
            {
                typeValue = "布尔类型";
            }else if(row.type == 3)
            {
                typeValue = "枚举类型";
            }else if(row.type == 4)
            {
                typeValue = "字符串型";
            }else{
                typeValue = "未知类型";
            }
            return typeValue;
        }},
        {field: 'currentData' ,title: '当前值' ,align: 'center',formatter:function(value,row,index){
            var currentData = (row.currentData < 0) ? (row.currentData):(row.currentData + row.punit);
            return row.currentData;
        }},
        {field: 'isMod' ,title: '已修改' ,align: 'center' ,formatter:function(value,row,index){
            if(row.isMod == 0) {
               var constr = '<a title = "未修改">' + '<button class = "no-modfi"></button>' + '</a>';
               return constr;
            }else{
               var discon = '<a title = "已修改">' + '<button class = "CheckMark"></button>' + '</a>';
               return discon;
            }
         }},
        {field: 'dynamic' ,title: '动&nbsp;&nbsp;态' ,align: 'center' ,formatter:function(value,row,index){
            if(row.dynamic == 0) {
                var constr = '<a title = "未更新">' + '<button class = "no-modfi"></button>' + '</a>';
                return constr;
            }else{
                var discon = '<a title = "已更新">' + '<button class = "CheckMark"></button>' + '</a>';
                return discon;
            }
        }},
        {field: 'instance' ,title: '实&nbsp;&nbsp;例' ,align: 'center'},
        {field: 'sort' ,title: '类&nbsp;&nbsp;别' ,align: 'center' ,formatter:function(value,row,index){
            var insSort;
            if(row.sort == "classless")
            {
                insSort = "";
            }else{
                insSort = row.sort;
            }
            return insSort;
        }},
        {field: 'state' ,title: '说&nbsp;&nbsp;明' ,align: 'center' }
    ];
    $('#configTableId').bootstrapTable({
        classes:"table table-no-bordered",
        //toolbar:"#configureInstanDivId",
        height:500,
        columns: par,
        idField:"index"
    });
}
function initConfigTable()
{
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"getInstConfigList","subRequest":"","ssubRequest":""},
        data    :{
            instid:insId,
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,initConfigTableCallback);
}
function initConfigTableCallback(retJson)
{
    var jsonData = JSON.parse(retJson);
    if(jsonData.rstcode == "success")
    {
        var configData = getNewJsonData(jsonData.data);
        $("#configTableId").bootstrapTable('load',configData);
        listenConfigTable();
    }else{
        uxAlert(jsonData.desc);
    }
}
/*******************************辅助函数区***********************/
//监听表格
function listenConfigTable()
{
    var $table = $("#configTableId");
    $table.on('check.bs.table page-change.bs.table uncheck.bs.table check-all.bs.table uncheck-all.bs.table',function(arg){
        setConfigButtonStatus("configInstanId");
    });
}
//判断单选框是否选中
function setConfigButtonStatus(btid)
{
    if(btid == "")
    {
        return;
    }
    var selected = $("#configTableId").bootstrapTable('getSelections');
    if(selected.length > 0)
    {
        d3.select("#" + btid)[0][0].disabled = false;
        d3.select("#" + btid).classed("delBtnClass",false);
        d3.select("#" + btid).classed("btn admitClick",true);
    }
    else
    {
        d3.select("#" + btid)[0][0].disabled = true;
        d3.select("#" + btid).classed("delBtnClass",true);
        d3.select("#" + btid).classed("btn admitClick",false);
    }
}
//返回选中行
function getConfigIdSelections()
{
    return $.map($("#configTableId").bootstrapTable('getSelections'), function (row) {
        return row;
    });
}
/*
 * 数据格式重组
 * */
var newJsonData = [];
function getNewJsonData(data)
{
    newJsonData = [];
    for(var i = 0;i < data.length; i++)
    {
        var info = {};
        info.index = i + 1 ;
        info.name = data[i].pname;
        info.type = data[i].ptype;
        info.currentData = data[i].pvalue ;
        info.isMod = data[i].ismodify;
        info.dynamic = 1;
        info.punit = data[i].punit;
        info.instance = data[i].instance;
        info.sort = data[i].pclass;
        info.optionalItem = data[i].vlist;
        //info.optionalItem = data[i].optionalItem;
        info.state = data[i].description;
        newJsonData.push(info);
    }
    return newJsonData;
}
/***************************配置实例查询******************************************/
function queryConfigInstance()
{
    var queryItem = {
        'isModfiFlag':0,
        'configNameFlag':0,
        'configName':'',
        'insFlag':0,
        'ins':''
    };
    var formDataArray = d3.selectAll(".siteCheck");
    queryItem.isModfiFlag = (formDataArray[0][0].checked == false) ? (0):(1);
    queryItem.configNameFlag = (formDataArray[0][1].checked == false) ? (0):(1);
    queryItem.insFlag = (formDataArray[0][2].checked == false) ? (0):(1);
    if(queryItem.configNameFlag)
    {
        queryItem.configName = trim(d3.select("#selectElemId1")[0][0].value);
    }
    if(queryItem.insFlag)
    {
        queryItem.ins = trim(d3.select("#selectElemId2")[0][0].value);
    }
    if((!queryItem.isModfiFlag) && (!queryItem.configNameFlag) && (!queryItem.insFlag))
    {
        initConfigTable();
        d3.select("#searchSite-form button").classed("searchSite-btn",true);
        d3.select("#searchSite-form button").classed("searchSite-btn-backWhite",false);
        return;
    }
    var modfiJsonData = newJsonData;
    if(queryItem.isModfiFlag)
    {
        modfiJsonData = modfiJsonData.filter(function (value, index, self) {
            return (value.isMod == 1);
        });
    }
    if(queryItem.configNameFlag)
    {
        modfiJsonData = modfiJsonData.filter(function (value, index, self) {
            return (value.name.indexOf(queryItem.configName) > -1);
        });
    }
    if(queryItem.insFlag)
    {
        modfiJsonData = modfiJsonData.filter(function (value, index, self) {
            return (value.instance.indexOf(queryItem.ins) > -1 );
        });
    }
    $("#configTableId").bootstrapTable("load",modfiJsonData);
    d3.select("#searchSite-form button").classed("searchSite-btn",true);
    d3.select("#searchSite-form button").classed("searchSite-btn-backWhite",false);

}
/*****************************返回上一级*********************************/
function goConfigureBack()
{
    instanceOperElem(instanceOperData);
}
/******************************修改配置操作**********************************/
function configInsFun()
{
    var className;
    var conifgName = getConfigIdSelections();
    configInsElem(conifgName[0].name,conifgName[0].type,conifgName[0].optionalItem,conifgName[0].currentData,conifgName[0].state,conifgName[0].punit);
    d3.select("#ItemSpanConfig")
        .classed("configTitle",true)
        .append("label")
        .text("设置");
    d3.select("#ItemSpanConfig")
        .append("span")
        .attr("class","titleSpan")
        .text(conifgName[0].name);
    //d3.select("#input0")[0][0].value = conifgName[0].currentData;
    d3.select("#dialogConfig").style({
        "height":"375px",
        "width": "445px"
    });
    if(d3.select("#dialogConfig").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgConfig').fadeIn(300);
    $('#dialogConfig').removeAttr('class').addClass('animated ' + className + '').fadeIn();
}
/*
 * 弹出框实现
 * typeFlag : 0 表示无限 1表示有限集合
 * opertionItem ：:如果是有限集合，则表示选择项的字符串
 * */
function configInsElem(operName,type,optionalItem,currentData,areaDescription,punit)
{
    d3.select("#dialogBgConfig").remove();
    d3.select("#dialogConfig").remove();
    var pupUpItem = "";
    var popUpInputArray = ["&nbsp;&nbsp;&nbsp;&nbsp;值&nbsp;&nbsp;&nbsp;&nbsp;",operName+"描述"];
    var opertionItemArray,typeFlag,sureFlag = false;
    if(type == 1) //整型有两界值 intValue
    {
        opertionItemArray = optionalItem;
        typeFlag = 1;
    }else if(type == 4){//字符串有最大长度
        opertionItemArray = optionalItem;
        typeFlag = 4;
    }else if(type == 2){//布尔值
        opertionItemArray = ["true","false"];
        typeFlag = 2;
    }else if(type == 3){//枚举值选择 emumValue
        opertionItemArray = optionalItem;
        typeFlag = 3;
    }
    containDiv.append("div")
        .attr("id","dialogBgConfig");
    var outPage = containDiv.append("div")
        .attr("id","dialogConfig");
    var editFrom = outPage.append("div")
        .attr("id","editFromConfig");
    var newUserItemSpan = editFrom.append("span")
        .attr("id","ItemSpanConfig")
        .html(pupUpItem);
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos");
    for(var i = 0;i < popUpInputArray.length - 1;i++)
    {
        var editFromLi = editFormUl.append("li").attr("class","editUl");
        editFromLi.append("label").append("span")
            .attr("class","editFromLiSpan")
            .html(popUpInputArray[i]);
        if(typeFlag == 1)
        {
            editFromLi.append("input")
                .attr({
                    'id':'inputValue',
                    'type':"text",
                    'class':'ipt'
                })
                .on("blur",function(){
                    var value = d3.select(this)[0][0].value;
                    var minValue = optionalItem[0].intValue;
                    var maxValue = optionalItem[1].intValue;
                    var cuurentUnit,changeNum,valueNum,timeArrItem = ["s","ms","min"];
                    if(minValue == " " && maxValue == " ")
                    {
                        //不用校验
                        if(isNumber(value) && value != "")
                        {
                            d3.select("#errorSpan0")[0][0].innerHTML = "";
                            sureFlag = true;
                        }else{
                            d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入一个正确的整型值！</span>";
                            sureFlag = false;
                        }
                    }else if(minValue != " " && maxValue == " ")
                    {
                        if(punit == " ")
                        {
                            if(parseFloat(value) >= parseInt(minValue))
                            {
                                d3.select("#errorSpan0")[0][0].innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入大于" +minValue+ "的值！</span>";
                                sureFlag = false;
                            }
                        }else{
                            cuurentUnit = d3.select("#selectUnit")[0][0].value;
                            if(isHasValue(cuurentUnit))
                            {
                                changeNum = getTimeUnit(punit,cuurentUnit);
                            }else{
                                changeNum = getUnit(punit,cuurentUnit);
                            }
                            valueNum = parseFloat(value)/changeNum;
                            //校验最小值
                            if(valueNum >= parseInt(minValue))
                            {
                                d3.select("#errorSpan0")[0][0].innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入大于" +minValue+punit+ "的值！</span>";
                                sureFlag = false;
                            }
                        }

                    }else if(minValue == " " && maxValue != " ")
                    {
                        if(punit == " ")
                        {
                            //校验最大值
                            if(parseInt(value) <= parseInt(maxValue))
                            {
                                d3.select("#errorSpan0")[0][0].innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入小于" +maxValue+ "的值！</span>";
                                sureFlag = false;
                            }
                        }else{
                            cuurentUnit = d3.select("#selectUnit")[0][0].value;
                            if(isHasValue(cuurentUnit))
                            {
                                changeNum = getTimeUnit(punit,cuurentUnit);
                            }else{
                                changeNum = getUnit(punit,cuurentUnit);
                            }
                            valueNum = parseFloat(value)/changeNum;
                            //校验最小值
                            if(valueNum <= parseInt(maxValue))
                            {
                                d3.select("#errorSpan0")[0][0].innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入小于" +maxValue+punit+ "的值！</span>";
                                sureFlag = false;
                            }
                        }
                    }else if(minValue != " " && maxValue != " ")
                    {
                        if(punit == " ")
                        {
                            //校验区间
                            if(parseInt(value) >= parseInt(minValue) && parseInt(value) <= parseInt(maxValue))
                            {
                                d3.select("#errorSpan0")[0][0].innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入"+minValue+"-" +maxValue+ "之间的值！</span>";
                                sureFlag = false;
                            }
                        }else{
                            cuurentUnit = d3.select("#selectUnit")[0][0].value;
                            if(isHasValue(cuurentUnit))
                            {
                                changeNum = getTimeUnit(punit,cuurentUnit);
                            }else{
                                changeNum = getUnit(punit,cuurentUnit);
                            }
                            valueNum = parseFloat(value)/changeNum;
                            //校验最小值
                            if(valueNum >= parseInt(minValue) && valueNum <= parseInt(maxValue))
                            {
                                d3.select("#errorSpan0")[0][0].innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入"+minValue +punit+"-" +maxValue+punit+ "之间的值！</span>";
                                sureFlag = false;
                            }
                        }
                    }
                });
            var currentValue = parseInt(trim(currentData));
            if(punit != " " && currentValue > 0)
            {
                var currentStrIndex= (currentValue.toString()).length;
                var unitStr = currentData.substring(currentStrIndex,currentData.length);
                d3.selectAll(".ipt").classed("single-ipt",false);
                d3.selectAll(".editInfos li").style("margin","30px 0px 0px 24px");
                d3.select("#inputValue")[0][0].value = parseInt(trim(currentData));
                if(punit == "kB" || punit == "MB" || punit == "GB")
                {
                    var selectUnitItem = ["kB","MB","GB"];
                    var selectElem = editFromLi.append("select")
                        .attr({
                            "id":'selectUnit',
                            "class":'select-unit'
                        })
                        .on("change",function(){
                            var value = d3.select("#inputValue").property("value");
                            var minValue = optionalItem[0].intValue;
                            var maxValue = optionalItem[1].intValue;
                            var cuurentUnit,changeNum,valueNum;
                            if(minValue != " " && maxValue == " ")
                            {
                                cuurentUnit = d3.select("#selectUnit")[0][0].value;
                                changeNum = getUnit(punit,cuurentUnit);
                                valueNum = parseFloat(value)/changeNum;
                                //校验最小值
                                if(valueNum >= parseInt(minValue))
                                {
                                    d3.select("#errorSpan0")[0][0].innerHTML = "";
                                    sureFlag = true;
                                }else{
                                    d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入大于" +minValue+punit+ "的值！</span>";
                                    sureFlag = false;
                                }
                            }else if(minValue == " " && maxValue != " ")
                            {
                                cuurentUnit = d3.select("#selectUnit")[0][0].value;
                                changeNum = getUnit(punit,cuurentUnit);
                                valueNum = parseFloat(value)/changeNum;
                                //校验最小值
                                if(valueNum <= parseInt(maxValue))
                                {
                                    d3.select("#errorSpan0")[0][0].innerHTML = "";
                                    sureFlag = true;
                                }else{
                                    d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入小于" +maxValue+punit+ "的值！</span>";
                                    sureFlag = false;
                                }
                            }else if(minValue != " " && maxValue != " ")
                            {
                                cuurentUnit = d3.select("#selectUnit")[0][0].value;
                                changeNum = getUnit(punit,cuurentUnit);
                                valueNum = parseFloat(value)/changeNum;
                                //校验最小值
                                if(valueNum >= parseInt(minValue) && valueNum <= parseInt(maxValue))
                                {
                                    d3.select("#errorSpan0")[0][0].innerHTML = "";
                                    sureFlag = true;
                                }else{
                                    d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入"+minValue +punit+"-" +maxValue+punit+ "之间的值！</span>";
                                    sureFlag = false;
                                }
                            }
                        });
                    for(var k = 0;k<selectUnitItem.length; k++)
                    {
                        selectElem.append("option")
                            .html(selectUnitItem[k]);
                    }
                  var selectObj = d3.select("#selectUnit");
                    for(var j = 0;j<selectUnitItem.length; j++)
                    {
                        if(unitStr == selectUnitItem[j])
                        {
                            selectObj[0][0].selectedIndex = j;
                            break;
                        }
                    }
                    selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = unitStr;
                }else if(punit == "s" || punit == "ms" || punit == "min" )
                {
                    var selectUnitItem = ["s","ms","min"];
                    var selectElem = editFromLi.append("select")
                        .attr({
                            "id":'selectUnit',
                            "class":'select-unit'
                        })
                        .on("change",function(){
                            var value = d3.select("#inputValue").property("value");
                            var minValue = optionalItem[0].intValue;
                            var maxValue = optionalItem[1].intValue;
                            var cuurentUnit,changeNum,valueNum;
                            if(minValue != " " && maxValue == " ")
                            {
                                cuurentUnit = d3.select("#selectUnit")[0][0].value;
                                changeNum = getTimeUnit(punit,cuurentUnit);
                                valueNum = parseFloat(value)/changeNum;
                                //校验最小值
                                if(valueNum >= parseInt(minValue))
                                {
                                    d3.select("#errorSpan0")[0][0].innerHTML = "";
                                    sureFlag = true;
                                }else{
                                    d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入大于" +minValue+punit+ "的值！</span>";
                                    sureFlag = false;
                                }

                            }else if(minValue == " " && maxValue != " ")
                            {
                                cuurentUnit = d3.select("#selectUnit")[0][0].value;
                                changeNum = getTimeUnit(punit,cuurentUnit);
                                valueNum = parseFloat(value)/changeNum;
                                //校验最小值
                                if(valueNum <= parseInt(maxValue))
                                {
                                    d3.select("#errorSpan0")[0][0].innerHTML = "";
                                    sureFlag = true;
                                }else{
                                    d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入小于" +maxValue+punit+ "的值！</span>";
                                    sureFlag = false;
                                }
                            }else if(minValue != " " && maxValue != " ")
                            {
                                cuurentUnit = d3.select("#selectUnit")[0][0].value;
                                changeNum = getTimeUnit(punit,cuurentUnit);
                                valueNum = parseFloat(value)/changeNum;
                                //校验最小值
                                if(valueNum >= parseInt(minValue) && valueNum <= parseInt(maxValue))
                                {
                                    d3.select("#errorSpan0")[0][0].innerHTML = "";
                                    sureFlag = true;
                                }else{
                                    d3.select("#errorSpan0")[0][0].innerHTML = "<span class='errorTip'>请输入"+minValue +punit+"-" +maxValue+punit+ "之间的值！</span>";
                                    sureFlag = false;
                                }
                            }
                        });
                    for(var k = 0;k<selectUnitItem.length; k++)
                    {
                        selectElem.append("option")
                            .html(selectUnitItem[k]);
                    }
                    var selectObj = d3.select("#selectUnit");
                    for(var j = 0;j<selectUnitItem.length; j++)
                    {
                        if(unitStr == selectUnitItem[j])
                        {
                            selectObj[0][0].selectedIndex = j;
                            break;
                        }
                    }
                    selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = unitStr;
                }
            }else{
                d3.select("#inputValue")[0][0].value =trim(currentData);
                d3.selectAll(".ipt").classed("single-ipt",true);
                d3.selectAll(".editInfos li").style("margin","30px 0px 0px 65px");
            }
        }else if(typeFlag == 2)
        {
            sureFlag = true;
            var selectElem = editFromLi.append("select")
                .attr({
                    'id':'inputValue',
                    'class':'ipt selectStyle insInputClass'
                });
            for(var operIndex = 0; operIndex < opertionItemArray.length; operIndex++)
            {
                selectElem.append("option")
                    .attr({
                        'id':'opertion' + operIndex
                    }).text(opertionItemArray[operIndex]);
            }
            var selectObj = d3.select("#inputValue");
            selectObj[0][0].selectedIndex = (currentData) ? (0):(1);
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = currentData;
            d3.selectAll(".ipt").classed("single-ipt",true);
            d3.selectAll(".editInfos li").style("margin","30px 0px 0px 65px");
        }else if(typeFlag == 3)
        {
            sureFlag = true;
            var selectElem = editFromLi.append("select")
                .attr({
                    //'id':'input' + i,
                    'id':'inputValue',
                    'class':'ipt selectStyle insInputClass'
                });
            for(var operIndex = 0; operIndex < opertionItemArray.length; operIndex++)
            {
                selectElem.append("option")
                    .attr({
                        'id':'opertion' + operIndex
                    }).text(opertionItemArray[operIndex].enumValue);
            }
            var selectObj = d3.select("#inputValue");
            for(var k = 0;k<opertionItemArray.length; k++)
            {
                if(currentData == opertionItemArray[k].enumValue)
                {
                    selectObj[0][0].selectedIndex = k;
                    break;
                }
            }
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = currentData;
            d3.selectAll(".ipt").classed("single-ipt",true);
            d3.selectAll(".editInfos li").style("margin","30px 0px 0px 65px");
        }else if(typeFlag == 4)
        {
            editFromLi.append("input")
                .attr({
                    'id':'inputValue',
                    'type':"text",
                    'class':'ipt'
                })
                .on("blur",function(){
                    var value = d3.select(this)[0][0].value;
                    if(optionalItem == "*,localhost")
                    {
                       if(value != "" &&( value == "localhost" || (isValidIP(value)) || value == "*"))
                       {
                           d3.select(this)[0][0].nextSibling.innerHTML = "";
                           sureFlag = true;
                       }else{
                           d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入一个正确的IP值或直接输入\"localhost\"！</span>";
                           sureFlag = false;
                       }
                    }else{
                        d3.select(this)[0][0].nextSibling.innerHTML = "";
                        sureFlag = true;
                    }
                });
            d3.select("#inputValue")[0][0].value = currentData;
            d3.selectAll(".ipt").classed("single-ipt",true);
            d3.selectAll(".editInfos li").style("margin","30px 0px 0px 65px");
        }
    }
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan0'
            });
        });
    editFormUl.append("p")
        .attr({
            'id':'descPId'
        })
        .append("span")
        .attr({
            'id':'descSpanId'
        })
        .html(operName + "描述");
    editFormUl.append("textarea").attr({
        'id':'textAreaId',
        'class':"describeText",
        'disabled':'disabled'
    })
        .html(areaDescription);
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn");
    editFromDivBtn.append("div")
        .attr("class","dialogTop config-dialogtop")
        .append("button")
        .attr("id","sureBtn")
        .attr("class","btn btn-sm btn-bg-color popUpBtn")
        .on("click",function(){
            if(sureFlag)
            {
                configModfi();
            }else{
                uxAlert("请输入正确的配置信息！");
            }
        })
        .html("确&nbsp;&nbsp;&nbsp;&nbsp;定");
    editFromDivBtn.select(".dialogTop")
        .append("button")
        .attr("class","btn btn-sm btn-bg-color popUpBtn claseDialogBtn")
        .attr("id","claseDialogBtn")
        .on("click",function(){
            d3.select("#dialogConfig").classed("bounceIn",false);
            $('#dialogBgConfig').fadeOut(300,function(){
                $('#dialogConfig').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#configInstanId").classed("admitClick",true);
        })
        .html("取&nbsp;&nbsp;&nbsp;&nbsp;消");
}
function isHasValue(value)
{
    var timeArrItem = ["s","ms","min"],isHasValueFlag = false;
    for(var k = 0; k< timeArrItem.length; k++)
    {
        if(timeArrItem[k] == value)
        {
            isHasValueFlag = true;
            break;
        }else{
            isHasValueFlag = false;
        }
    }
    return isHasValueFlag;
}
function getUnit(punit,cuurentUnit)
{
    var punitNum = 1,flag = true;
    var flagNumPunit = (punit == "kB") ?(0):((punit == "MB") ? (1):(2)); //用数字标记单位的顺序
    var flagNumCurrunit = (cuurentUnit == "kB") ?(0):((cuurentUnit == "MB") ? (1):(2)); //用数字标记单位的顺序
    var unitTemp = (flagNumPunit > flagNumCurrunit) ? (1024):(1/1024);
    var unitItem = ["kB",'MB','GB'];
    var k = (punit == "kB") ?(0):((punit == "MB") ? (1):(2));
    var initFlag = k;
    while(flag)
    {
        if(cuurentUnit != unitItem[k])
        {
            punitNum = punitNum * unitTemp;
        }else{
            flag = false;
        }
        if(initFlag > 0)
        {
            k = (flagNumPunit > flagNumCurrunit) ? (k-1):(k+1);
        }else{
            k++;
        }
    }
    return punitNum;

}
function getTimeUnit(punit,curentUnit)
{
    var punitNum = 1,flag = true;
    var flagNumPunit = (punit == "ms") ?(0):((punit == "s") ? (1):(2)); //用数字标记单位的顺序
    var flagNumCurrunit = (curentUnit == "ms") ?(0):((curentUnit == "s") ? (1):(2)); //用数字标记单位的顺序
    var unitTemp = (flagNumPunit > flagNumCurrunit) ? (60):(1/60);
    var unitItem = ["ms",'s','min'];
    var k = (punit == "ms") ?(0):((punit == "s") ? (1):(2));
    var initFlag = k;
    while(flag)
    {
        if(curentUnit != unitItem[k])
        {
            punitNum = punitNum * unitTemp;
        }else{
            flag = false;
        }
        if(initFlag > 0)
        {
            k = (flagNumPunit > flagNumCurrunit) ? (k-1):(k+1);
        }else{
            k++;
        }
    }
    return punitNum;
}
function configModfi()
{
    var conifgName = getConfigIdSelections();
    var newValue = d3.select("#inputValue")[0][0].value;
    if(conifgName[0].punit != " ")
    {
        var unitValue = d3.select("#selectUnit").property("value");
        newValue = newValue + unitValue;
    }
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"instmanage",
        request :{"mainRequest":"setInstConfig","subRequest":"","ssubRequest":""},
        data    :{
            instid:insId,
            pname:conifgName[0].name,
            pvalue:newValue,
            type:conifgName[0].type //1:整型,2:布尔,3:枚举,4:字符串
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,configModfiCallback);
}
function configModfiCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        initConfigTable();
        uxAlert("设置配置成功！");
        setConfigButtonStatus("configInstanId");
    }else{
        uxAlert("设置配置失败！");
    }
    d3.select("#dialogConfig").classed("bounceIn",false);
    $('#dialogBgConfig').fadeOut(300,function(){
        $('#dialogConfig').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#configInstanId").classed("admitClick",true);
}
