/**
 * Created by zhigao.yang on 2017/3/1 0001.
 */

var dbMgr = require('../dbmanage/dbmanagemgr').dbmanageMgr;

exports.triggerFunction = triggerFunction;
var mainRequestProcFuncs = {
    "createDatabase" : createDatabase,
    "deleteDatabase" : deleteDatabase,
    "modifyDatabase" : modifyDatabase,
    "searchDatabaseInfo" : searchDatabaseInfo,
    "exceDatabaseOp" : exceDatabaseOp,
    "getAllDatabaseList" : getAllDatabaseList,
    "createUser" : createUser,
    "deleteUser" : deleteUser,
    "modifyUser" : modifyUser,
    "searchUserInfo" : searchUserInfo,
    "exceUserOp" : exceUserOp,
    "getAllUserList" : getAllUserList,
    "createRole" : createRole,
    "deleteRole" : deleteRole,
    "modifyRole" : modifyRole,
    "searchRoleInfo" : searchRoleInfo,
    "exceRoleOp" : exceRoleOp,
    "getAllRoleList" : getAllRoleList,
}

function triggerFunction(postData, gResponseFunction) {
    if (postData.length <= 0) {
        return;
    }
    if (typeof gResponseFunction != "function") {
        return;
    }
    var rtRes = {
        rstcode: "error",
        desc: "",
        data: ""
    };
    var jsonObj = JSON.parse(postData);
    var mainRequest = jsonObj.request.mainRequest;
    var procFunc = mainRequestProcFuncs[mainRequest];
    if (typeof procFunc != "function") {
        gResponseFunction(JSON.stringify(rtRes));
    }
    else {
        procFunc(jsonObj, gResponseFunction);
    }
}

function createDatabase(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }
    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    obj.sqlText = "CREATE DATABASE " + reqDb.data.dbnewName + " WITH OWNER = " +
        reqDb.data.owner + " ENCODING = '"+ reqDb.data.encoding + "'" + " TEMPLATE template0;";
    obj.sqlValue = [];

    console.log(obj.sqlText);

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            'rstcode': 'error',
            'desc': ''
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
        }
        callback(JSON.stringify(rtRes));
    });
}

function deleteDatabase(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }
    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    obj.sqlText = "DROP DATABASE IF EXISTS " + reqDb.data.delDbName + ";";
    obj.sqlValue = [];

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
        }
        callback(JSON.stringify(rtRes));
    });
}

function modifyDatabase(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    obj.sqlText = "ALTER DATABASE " + reqDb.data.modDbName + " OWNER TO " + reqDb.data.newOwner + ";";
    obj.sqlValue = [];

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
        }
        callback(JSON.stringify(rtRes));
    });
}

function searchDatabaseInfo(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }
    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    obj.sqlText = "select d.datname as Name , ux_get_userbyid(d.datdba) as Owner ," +
        " ux_encoding_to_char(d.encoding) as Encoding from ux_database d where " +
        "d.datname = '" + reqDb.data.searchName + "';";

    obj.sqlValue = [];
    console.log(obj.sqlText);
    dbMgr.getInstance().queryDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
            data:[]
        }

        if (err) {
            rtRes.desc = rst
        }
        else{
            rtRes.rstcode = "success";
            rtRes.data = JSON.stringify(rst);

        }
        callback(JSON.stringify(rtRes));
    });
}

function exceDatabaseOp(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }
    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    if(reqDb.data.opType == "Analysis"){
        obj.sqlText = "VACUUM ANALYZE;";
    }
    else if(reqDb.data.opType == "Clean-up"){
        obj.sqlText = "VACUUM " + reqDb.data.Cleanup + ";";
    }
    else if(reqDb.data.opType == "RebuildIndex"){
        obj.sqlText = "REINDEX DATABASE " + reqDb.data.reidxDbName + ";";
    }
    else if(reqDb.data.opType == "Rename"){
        obj.sqlText = "ALTER DATABASE " + reqDb.data.oldDbName + " RENAME TO " + reqDb.data.newDbName + ";";
    }

    console.log(obj.sqlText);
    obj.sqlValue = [];

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
            data:[]
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
            rtRes.data = JSON.stringify(rst);

        }
        callback(JSON.stringify(rtRes));
    });

}

function getAllDatabaseList(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    if (typeof callback != "function") {
        return 1;
    }
    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }
    obj.sqlText = "select d.datname as Name , ux_get_userbyid(d.datdba) as Owner ," +
        " ux_encoding_to_char(d.encoding) as Encoding from ux_database d;";
    obj.sqlValue = [];

    console.log(obj.sqlText);
    dbMgr.getInstance().queryDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
            data:[]
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
            rtRes.data = rst;

        }
        callback(JSON.stringify(rtRes));
    });
}

function createUser(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    var option = "";
    if(1 == reqDb.data.superUser){
        option += " SUPERUSER ";
    }
    else{
        option += " NOSUPERUSER ";
    }

    if(1 == reqDb.data.createDb){
        option += " CREATEDB ";
    }
    else{
        option += " NOCREATEDB ";
    }

    if(1 == reqDb.data.createRole){
        option += " CREATEROLE ";
    }
    else{
        option += "NOCREATEROLE ";
    }

    var validUntil = "";
    if(1 == reqDb.data.setValidUntil) {
        validUntil = "VALID UNTIL '" + reqDb.data.validUntil + "'";
    }

    obj.sqlText = "CREATE USER " + reqDb.data.userName + " WITH " +
        option + validUntil + " PASSWORD '" + reqDb.data.passWord + "';";
    obj.sqlValue = [];

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
        }
        callback(JSON.stringify(rtRes));
    });
}

function deleteUser(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

   obj.sqlText = "DROP USER IF EXISTS " + reqDb.data.userName + ";";
    obj.sqlValue = [];

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
        }

        if (err) {
            rtRes.desc = rst
        }
        else{
            rtRes.rstcode = "success";
        }
        callback(JSON.stringify(rtRes));
    });
}

function modifyUser(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    var option = "";
    if(1 == reqDb.data.superUser){
        option += " SUPERUSER ";
    }
    else{
        option += " NOSUPERUSER ";
    }

    if(1 == reqDb.data.createDb){
        option += " CREATEDB ";
    }
    else{
        option += " NOCREATEDB ";
    }

    if(1 == reqDb.data.createRole){
        option += " CREATEROLE ";
    }
    else{
        option += "NOCREATEROLE ";
    }

    var validUntil = "";
    if(1 == reqDb.data.setValidUntil) {
        validUntil = "VALID UNTIL '" + reqDb.data.validUntil + "'";
    }else{
        validUntil = "VALID UNTIL 'infinity'";
    }

    var password = "";
    if(1 == reqDb.data.setPassword) {
        password = " PASSWORD '" + reqDb.data.passWord + "'"
    }
    obj.sqlText = "ALTER USER " + reqDb.data.userName + " WITH " +
        option + validUntil + password + ";";
    obj.sqlValue = [];

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
        }
        callback(JSON.stringify(rtRes));
    });
}

function searchUserInfo(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    obj.sqlText = "SELECT a.usename AS UserName, a.usesysid AS UserID, " +
        "a.valuntil AS validitytime, a.usesuper AS superuser,a.usecreatedb AS createdb," +
        "b.rolcreaterole AS createrole FROM ux_user a, ux_roles b WHERE a.usename = '"+
        reqDb.data.userName + "' AND b.rolname = '" + reqDb.data.userName + "';";

    obj.sqlValue = [];
    console.log(obj.sqlText);

    dbMgr.getInstance().queryDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
            data:[]
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
            rtRes.data = JSON.stringify(rst);

        }
        callback(JSON.stringify(rtRes));
    });
}

function exceUserOp(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }
    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    if(reqDb.data.opType == "rename"){
        obj.sqlText = "ALTER USER " + reqDb.data.oldName + " RENAME TO " + reqDb.data.newName + ";";
    }
    else if(reqDb.data.opType == "modify userobject owner"){
        obj.sqlText = "REASSIGN OWNED BY " + reqDb.data.oldRole + " TO " + reqDb.data.newRole + ";";
    }
    else if(reqDb.data.opType == "delete userobject"){
        obj.sqlText = "DROP OWNED BY " + reqDb.data.userName + " " + reqDb.data.deleteType + ";";
    }

    obj.sqlValue = [];
    console.log(obj.sqlText);

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
            data:[]
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
            rtRes.data = JSON.stringify(rst);

        }
        callback(JSON.stringify(rtRes));
    });
}

function getAllUserList(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    obj.sqlText = "select a.usename as UserName, a.usesysid as UserID, " +
        "a.valuntil as validitytime, a.usesuper as superuser,a.usecreatedb as createdb," +
        "b.rolcreaterole as createrole from ux_user a, ux_roles b WHERE a.usename = b.rolname;";

    obj.sqlValue = [];

    dbMgr.getInstance().queryDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
            data:[]
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
            rtRes.data = JSON.stringify(rst);

        }
        callback(JSON.stringify(rtRes));
    });
}

function createRole(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    var option = "";
    if(1 == reqDb.data.superUser){
        option += " SUPERUSER ";
    }
    else{
        option += " NOSUPERUSER ";
    }

    if(1 == reqDb.data.createDb){
        option += " CREATEDB ";
    }
    else{
        option += " NOCREATEDB ";
    }

    if(1 == reqDb.data.createRole){
        option += " CREATEROLE ";

    }
    else{
        option += "NOCREATEROLE ";
    }

    obj.sqlText = "CREATE ROLE " + reqDb.data.roleName + " WITH " + option + ";";
    obj.sqlValue = [];

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
        }
        callback(JSON.stringify(rtRes));
    });
}
function deleteRole(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    obj.sqlText = "DROP ROLE IF EXISTS " + reqDb.data.roleName + ";";
    obj.sqlValue = [];

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
        }
        callback(JSON.stringify(rtRes));
    });
}

function modifyRole(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    var option = "";
    if(1 == reqDb.data.superUser){
        option += " SUPERUSER ";
    }
    else{
        option += " NOSUPERUSER ";
    }

    if(1 == reqDb.data.createDb){
        option += " CREATEDB ";
    }
    else{
        option += " NOCREATEDB ";
    }

    if(1 == reqDb.data.createRole){
        option += " CREATEROLE ";
    }
    else{
        option += "NOCREATEROLE ";
    }

    obj.sqlText = "ALTER ROLE " + reqDb.data.roleName +
        " WITH " + option + ";";
    obj.sqlValue = [];

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
        }
        callback(JSON.stringify(rtRes));
    });
}

function searchRoleInfo(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    obj.sqlText = "SELECT a.rolname, a.oid, a.rolsuper,a.rolcreaterole,a.rolcreatedb FROM ux_roles a where a.rolname = $1;";

    obj.sqlValue = [reqDb.data.roleName];

    dbMgr.getInstance().queryDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
            data:[]
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
            rtRes.data = JSON.stringify(rst);

        }
        callback(JSON.stringify(rtRes));
    });
}

function exceRoleOp(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }
    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    if(reqDb.data.opType == "rename"){
        obj.sqlText = "ALTER ROLE " + reqDb.data.oldName + " RENAME TO " + reqDb.data.newName + ";";
    }

    obj.sqlValue = [];

    dbMgr.getInstance().execDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
            data:[]
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
            rtRes.data = JSON.stringify(rst);

        }
        callback(JSON.stringify(rtRes));
    });
}

function getAllRoleList(reqDb, callback){
    if (typeof callback != "function") {
        return 1;
    }

    var obj = {
        'webusername': reqDb.data.webusername,
        'instid' : reqDb.data.instid,
        'dbname' : reqDb.data.dbname,
        'sqlText' : '',
        'sqlValue' : []
    }

    obj.sqlText = "SELECT a.rolname, a.oid, a.rolsuper,a.rolcreaterole,a.rolcreatedb FROM ux_roles a;";

    obj.sqlValue = [];

    dbMgr.getInstance().queryDbOptMgr(obj, function(err, rst){
        var rtRes = {
            rstcode: "error",
            desc: "",
            data:[]
        }

        if (err) {
            rtRes.desc = rst;
        }
        else{
            rtRes.rstcode = "success";
            rtRes.data = JSON.stringify(rst);

        }
        callback(JSON.stringify(rtRes));
    });
}

if(0)
{
    var obj = {
        webusername:"test",
        instid:"12341234",
        dbname:"aaa",
        dbusername:"yangzhigao",
        pwd:"123456",
        ip:"192.168.1.220",
        port:"5432"
    }
    dbMgr.getInstance().connectDbMgr(obj,function(){
        if(0){//create database
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'dbnewName':'yaaae',
                'owner' : 'yangzhigao',
                'encoding' : 'UTF8'
            }

            createDatabase(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//drop database
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'delDbName':'yaaab'
            }

            deleteDatabase(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//modify owner
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'modDbName':'yaaad',
                'newOwner':'yangzgzg'
            }

            modifyDatabase(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//search database
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'searchName':'sccc'
            }

            searchDatabaseInfo(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//search all database info list;
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'searchName':'sccc'
            }

            getAllDatabaseList(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//database op
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'opType' : 'Rename',
                'Cleanup' : 'FULL FREEZE',
                'reidxDbName' : 'bbb',
                'oldDbName' : 'bbb',
                'newDbName': 'fsffbb',
                'searchName':'sccc'
            }

            exceDatabaseOp(obj, function(rst){
                console.log(rst);
            });
        }

        //role test code
        if(0){//create role
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'superUser': 0,
                'createDb': 0,
                'createRole': 0,
                'roleName' : 'yzg3003'
            }

            createRole(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//drop role
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'roleName':'yzg3003'
            }

            deleteRole(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//modify role
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'superUser': 0,
                'createDb': 0,
                'createRole': 0,
                'roleName' : 'yzg3002'
            }

            modifyRole(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//search role
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'userName':'yzg300'
            }

            searchUserInfo(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//search all role info list;
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'searchName':'sccc'
            }

            getAllUserList(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//role op
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'opType' : 'delete userobject',
                'oldRole' : 'yangzhigao',
                'newRole' : 'yangzgzg',
                'oldName' : 'yzg003',
                'newName': 'yzg300',
                'userName':'yangzgzg',
                'deleteType':'CASCADE'
            }

            exceUserOp(obj, function(rst){
                console.log(rst);
            });
        }


        //user test code
        if(0){//create user
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'superUser': 0,
                'createDb': 0,
                'createRole': 0,
                'setValidUntil': 0,
                'validUntil': '2017-03-20',
                'passWord':'123456',
                'userName' : 'yzg006',
                'encoding' : 'UTF8'
            }

            createUser(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//drop database
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'userName':'yzg006'
            }

            deleteUser(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//modify role
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'superUser': 1,
                'createDb': 1,
                'createRole': 1,
                'roleName' : 'yzg3002',
                'encoding' : 'UTF8'
            }

            modifyRole(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//search role
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'roleName':'yzg3001'
            }

            searchRoleInfo(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//search all role info list;
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'searchName':'sccc'
            }

            getAllRoleList(obj, function(rst){
                console.log(rst);
            });
        }

        if(0){//role op
            var obj = {
                'webusername': 'test',
                'instid' : '12341234',
                'dbname' : 'aaa',
                'opType' : 'rename',
                'oldRole' : 'yangzhigao',
                'newRole' : 'yangzgzg',
                'oldName' : 'yzg3002',
                'newName': 'yzg3010',
            }
            exceRoleOp(obj, function(rst){
                console.log(rst);
            });
        }
    });
}