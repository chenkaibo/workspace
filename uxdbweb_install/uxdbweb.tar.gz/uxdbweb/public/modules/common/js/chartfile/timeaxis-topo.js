/**
 * Created by Thinkpad5 on 2016/9/5.
 */
/**
 * 创建时间轴
 * @param containerId
 */
function createAxis(containerId) {
    var container = d3.select("#"+containerId),width = "",heigth = "";
    var svgId = "timeaxisSvg",
        smallCircleId = "smallCircle",
        bigCircleId = "bigCircle",
        smallCircleR = 2,
        bigCircleR = 10,
        dHour = "",
        dMinute = "",
        hourContentId = "hourContent",
        minuteContentId = "minuteContent",
        dateContentId = "dateContent",
        dateY = 0,
        dateHeight = 30,
        hourBgY = dateHeight,
        hourY = hourBgY+25,
        hourHeight = 37,
        minuteY = hourBgY+57,
        logicTimeY = hourBgY + 37,
        minuteBgY = hourBgY+40,
        minuteHeight = 37;
    var svg = container.append("svg").attr({
        id:svgId,
    });
    var slide_prev = container.append("div")//切换上一天的时间轴
        .attr({"class":"slide_g slide_prev"});

    var slide_next = container.append("div")//切换下一天的时间轴
        .attr({"class":"slide_g slide_next"});

    slide_prev.append("svg")
        .attr({
            "width":"13px",
            "height":"80px"
        })
        .append("polygon")
        .attr({
            "points":"0,38 13,28 13,48",
            "fill":"rgba(37,126,192,0.4)"
        });
    slide_next.append("svg").append("polygon")
        .attr({
            "points":"1,28 14,38 1,48",
            "fill":"rgba(37,126,192,0.4)"
        });

    var dateContent = svg.append("g").attr("id",dateContentId);
    var hourContent = svg.append("g").attr("id",hourContentId);
    var logicTime = svg.append("g").attr("id","logicTime");

    var minuteContent = svg.append("g").attr("id",minuteContentId);

    var defs = svg.append("defs");
    var hourFilter = defs.append("filter").attr({
        "id":"hourFilter"
    });
    hourFilter.append("feGaussianBlur").attr({
        stdDeviation:5,
        in:"SourceGraphic",
        result:"Gau1"
    });
    hourFilter.append("feComposite").attr({
        in:"Gau1",
        in2:"Gau1",
        operator:"in",
        result:"Com1"
    });
    hourFilter.append("feComposite").attr({
        in:"Com1",
        in2:"Gau1",
        operator:"in",
        result:"Com2"
    });
    var hourFilterSmall = defs.append("filter").attr({
        "id":"hourFilterSmall",
    });
    hourFilterSmall.append("feGaussianBlur").attr({
        stdDeviation:1,
        in:"SourceGraphic",
        result:"Gau1"
    });
    hourFilterSmall.append("feComposite").attr({
        in:"Gau1",
        in2:"Gau1",
        operator:"in",
        result:"Com1"
    });
    hourFilterSmall.append("feComposite").attr({
        in:"Com1",
        in2:"Gau1",
        operator:"in",
        result:"Com2"
    });
    var minuteFilter = defs.append("filter").attr("id","minuteFilter");
    minuteFilter.append("feGaussianBlur").attr({
        stdDeviation:1,
        in:"SourceGraphic",
        result:"GauMinute"
    });
    minuteFilter.append("feColorMatrix").attr({
        in:"GauMinute",
        type:"matrix",
        values:
        "0.5 0.8 0.5 0.5 0 " +
        "0 0.1 0 0 0 " +
        "0 0 0 0 0 " +
        "0 0 0 1 0",
        result:"MatrixMinute"
    });
    minuteFilter.append("feComposite").attr({
        in2:"SourceGraphic",
        in:"MatrixMinute",
        operator:"over"
    });
    var minuteFilterH = defs.append("filter").attr("id","minuteFilterH");
    minuteFilterH.append("feGaussianBlur").attr({
        stdDeviation:3,
        in:"SourceGraphic",
        result:"GauMinuteH"
    });
    minuteFilterH.append("feColorMatrix").attr({
        in:"GauMinuteH",
        type:"matrix",
        values:
        "1 1 1 1 0 " +
        "1 1 1 1 0 " +
        "0 0 0 0 0 " +
        "0 0 0 0 1",
        result:"MatrixMinuteH"
    });
    minuteFilterH.append("feComposite").attr({
        in2:"SourceGraphic",
        in:"MatrixMinuteH",
        operator:"in"
    });
    var smallCircle = defs.append("g").attr("id",smallCircleId);
    var bigCircle = defs.append("g").attr("id",bigCircleId);
    dateContent.append("rect").attr({
        width:"100%",
        height:dateHeight,
        id:"dateBg",
        y:dateY,
        x:0
    });
    var dateYear = dateContent.append("g").attr({
        id:"dateYear"
    });
    var dateMonth = dateContent.append("g").attr({
        id:"dateMonth"
    });
    var dateDate = dateContent.append("g").attr({
        id:"dateDate"
    });
    hourContent.append("rect").attr({
        x:0,
        y:hourBgY,
        width:"100%",
        height:hourHeight,
        id:"hourBg",
        "class":"rect-a"
    });
    minuteContent.append("rect").attr({
        x:0,
        y:minuteBgY,
        width:"100%",
        height:minuteHeight,
        id:"minuteBg",
        "class":"rect-a"
    });
    logicTime.append("rect").attr({
        x:0,
        y:logicTimeY,
        width:"100%",
        height:3,
        id:"logicTimeBg",
        "class":"rect-a"
    });
    resize();
    smallCircle.append("circle").attr({
        class:smallCircleId,
        r:smallCircleR
    });
    bigCircle.append("circle").attr({
        class:bigCircleId,
        r:bigCircleR
    });
    var dateSelect = container.insert("div",":first-child").attr({
        id:"dateSelect"
    });
    dateSelect.append("input").attr({
        id:"selectYear",
        type:"text",
        "readonly":true
    });

    dateSelect.append("img")
        .attr({
            "class":"reset-img",
            //"src":STATIC_URL+ "img/cbms-img/v403index/reset.svg",
            "title":"回到最新状态"
        });

    for (var i = 1;i<61;i++){
        var minuteGroup = minuteContent.append("g").attr({
            class:"minuteGroup"
        });
        minuteGroup.append("rect").attr({
            x:(i)*dMinute-dMinute/2,
            y:minuteY*3/4 + 5,
            "class":"minuteRect",
            width:dMinute,
            height:minuteHeight
        });
        if((i-1)%5==0){
            minuteGroup.append("circle").attr({
                cx: i * dMinute,
                cy: minuteY +3,
                r:16,
                fill:"transparent",
                filter:"url(#hourFilter)",
                overflow:"visiabe",
                "class": "minu-point"
            });
            minuteGroup.append("text").attr({
                class:"minutePointText",
                x: i * dMinute-(i<10?4:8.3),
                y: minuteY+8
            }).html((i-1));
        } else {
            minuteGroup.classed("minu-hover",true);
            minuteGroup.append("circle").attr({
                cx: i * dMinute,
                cy: minuteY + 3,
                r:16,
                fill:"transparent",
                filter:"url(#hourFilter)",
                overflow:"visiabe",
                "class": "min-or-hide"
            })
                .classed("display-none",true);
            minuteGroup.append("circle").attr({
                cx: i * dMinute,
                cy: minuteY +3,
                r:3,
                fill:"#00ceb9",
                filter:"url(#hourFilterSmall)",
                "class": "minu-point"
            });
            minuteGroup.append("text").attr({
                class:"minutePointText",
                x: i * dMinute-(i<10?4:8.3),
                y: minuteY+8
            })
                .classed("display-none",true)
                .html((i-1));
        }
    }

    for(var i=0;i<24;i++){
        var hourGroup = hourContent.append("g").attr("class","hourGroup");
        hourGroup.append("circle").attr({
            cx:i*dHour+(i<10?25:29),
            cy:hourY - 7,
            r:16,
            class:"hour-point",
            fill:"transparent",
            filter:"url(#hourFilter)"
        });
        hourGroup.append("text").attr({
            x:i*dHour+20,
            y:hourY,
            class:"hourText"
        }).html(i);
    }

    function resize(){
        width = container.property("offsetWidth");
        heigth = container.property("offsetHeight");

        dHour = width/24;
        dMinute = width/61;

        svg.style({
            "width":width,
            "height":heigth
        }).attr("viewBox", "0 0 "+width+" "+heigth);

        d3.selectAll(".minuteRect").each(function(d,i){
            var minu_i = i+1;
            d3.select(this)
                .attr({
                    x:(minu_i)*dMinute-dMinute/2,
                    y:minuteY*3/4 + 5,
                    width:dMinute
                });

            d3.select(d3.selectAll(".minu-point")[0][i])
                .attr({
                    cx: minu_i * dMinute,
                    cy: minuteY +3
                });
            d3.select(d3.selectAll(".minutePointText")[0][i])
                .attr({
                    x: minu_i * dMinute-(minu_i<10?4:8.3),
                    y: minuteY+8
                });
        });

        d3.selectAll(".min-or-hide").each(function(d,key){
            var min_cx = d3.select(d3.select(this)[0][0].parentNode).select(".minu-point").attr("cx");
            d3.select(this)
                .attr({
                    cx:min_cx,
                    cy: minuteY + 3
                });
        });

        d3.selectAll(".hour-point").each(function(d_hour,i_hour){
            d3.select(this)
                .attr({
                    cx:i_hour*dHour+(i_hour<10?25:29),
                    cy:hourY - 7
                });
            d3.select(d3.selectAll(".hourText")[0][(i_hour)])
                .attr({
                    x:i_hour*dHour+20,
                    y:hourY
                })
                .text(i_hour)
        });
        var box = svg[0][0].getBBox();
        svg.attr("viewBox",box.x + " " + box.y + " " + box.width + " " + box.height);
    }
    window.addEventListener('resize', resize);

    /**时间选择器插件的初始化和使用**/
    timeSelect();
    d3.select("#selectYear").on("click",function(){
        actionDatePicker("selectYear",false,"top");
        cancel_bubble();
    });

    app_name = window.location.pathname.split("/")[2];

    var ts_start = location.search;//获取当前url中参数，如有参数，则是从告警页面跳转至此。
    if(ts_start){
        is_axis_cycle = false;
        var ts_start_2 = ts_start.split("=")[1];
        time_ajax(ts_start_2);
        showdatapath(app_name,ts_start_2);
        d3.select("#selectYear").property("value",ts2str(ts_start_2).split(" ")[0]);

        var date_time = ts2str(ts_start_2);
        d3.select("#selectYear").property("value",date_time.split(" ")[0]);

        var time_str = date_time.split(" ")[1];

        d3.select(d3.selectAll("#minuteContent .minuteGroup")[0][time_str.split(":")[1].replace(/\b(0)/i,"")]).classed("clicked-g",true);
        d3.select(d3.selectAll("#hourContent .hourGroup")[0][time_str.split(":")[0].replace(/\b(0)/i,"")]).classed("clicked-g",true);

    }else{
        is_axis_cycle = true;
        initTimeAxis();
    }

    /**切换日期的方法**/
    d3.select("#selectYear").on("onchange",function(){
        changeDate(this);
        cancel_bubble();
    });

    //关于分钟的时间
    d3.selectAll(".minuteGroup").on({
        "click":function(){
            minuClick(this);
        }
    });
    d3.selectAll(".hourGroup").on({
        "click":function(){
            hourClick(this);
        }
    });
    d3.select(".reset-img").on("click",function(){
        restart();
        initTimeAxis();
        is_axis_cycle = true;
        cancel_bubble();
        d3.select(".slide_next").classed("disabled_slide",true);
        showdatapath(app_name,"");
    });

    /**点击切换上一天时间轴的事件**/
    d3.select(".slide_prev").on("click",function(){
        slideFun(true);
    });

    /**点击切换上一天时间轴的事件**/
    d3.select(".slide_next").on("click",function(){
        slideFun(false);
    });
    d3.select(".slide_next").classed("disabled_slide",true);
}

/**
 * 点击切换时间轴的上下两天触发的方法
 * @flag -- 当flag为true时，为切换上一天，否则为切换下一天
 */
function slideFun(flag){
    var select_date = d3.select("#selectYear")[0][0].value;
    var now_date = get_common_time(true).server_date;

    if(flag){//当为true时，为切换上一天，减去24小时
        var prev_minu = getWantTime(select_date + " 0:0:0") - 86400;
    }else{
        var prev_minu = getWantTime(select_date + " 0:0:0") + 86400;
    }

    var prev_date = getWantTime(prev_minu+'').split(" ")[0];
    restart();
    d3.select("#selectYear")[0][0].value = prev_date;

    if(now_date == prev_date.split("-").join("/")){//当切换到的日期等于服务器的日期时，时间轴和拓扑图回到最新状态
        is_axis_cycle = true;
        d3.select(".slide_next").classed("disabled_slide",true);
        initTimeAxis();//使时间轴回到最新的状态
        showdatapath(app_name,"");
    }else if(now_date < prev_date.split("-").join("/")){
        is_axis_cycle = false;
        d3.selectAll(".hourGroup").classed("f-time",true);
        d3.selectAll(".minuteGroup").classed("f-time",true);
    }else{
        is_axis_cycle = false;
        showdatapath(app_name,prev_minu);
        time_ajax(prev_minu);
        d3.select(".slide_next").classed("disabled_slide",false);
    }
}

var is_now_hour = "";
var is_axis_cycle = "";
var app_name = "";

/**
 * 还原时间轴到初始状态
 */
function restart(){
    d3.select("#hourBg")
        .attr({
            "stroke":"none",
            "height":40
        });
    d3.selectAll(".clicked-g").classed("clicked-g",false);
    d3.selectAll(".hourGroup ").classed("has-alert has-data has-warn f-time",false);
    d3.selectAll(".minuteGroup ").classed("has-alert has-data has-warn f-time",false);
    d3.selectAll(".now_time").classed("now_time",false);

}

/**
 * 初始化时间轴为当前时间
 */
function initTimeAxis(){
    //d3.json("/"+LANGUAGE_CODE+"/systime")
    //    .header("Content-Type", "application/x-www-form-urlencoded")
    //    .get(function(e,data){
    //        now_time(data.systime);
            now_time("2017-03-10 16:36:29");
            time_ajax(getWantTime("2017-03-10 16:36:29"));
            //time_ajax(getWantTime(data.systime));
        //});
}

/**
 * 时间轴的刷新函数
 * @param server_time
 * @private
 */
//function stop_now_(server_time){
//    time_ajax(server_time);
//    now_time(ts2str(server_time));
//    showdatapath(app_name,"");
//}

/**
 * 切换日期的时候触发的函数
 */
function changeDate(this_){
    restart();
    var server_hour = get_common_time(true).server_date;
    var selected_hour = d3.select(this_).property("value").trim().split("-").join("/");
    if(server_hour == selected_hour){
        initTimeAxis();
        /* 刷新拓扑图数据 */
        showdatapath(app_name,"");
        is_axis_cycle = true;
        d3.select(".slide_next").classed("disabled_slide",true);
    }else if(server_hour < selected_hour){
        is_axis_cycle = false;
        d3.selectAll(".hourGroup").classed("f-time",true);
        d3.selectAll(".minuteGroup").classed("f-time",true);
        d3.select("#logicTime").selectAll(".logic_g").remove();
        d3.select(".slide_next").classed("disabled_slide",true);
    }else{
        var date = selected_hour + " 00:00:00";
        var timeSeconds = new Date(date).getTime() / 1000;
        time_ajax(timeSeconds);
        /* 刷新拓扑图数据 */
        showdatapath(app_name,timeSeconds);
        is_axis_cycle = false;
        d3.select(".slide_next").classed("disabled_slide",false);
    }
}

/**
 * 点击小时时触发的函数
 * @param this_hour -- 事件源
 */
function hourClick(this_hour){
    d3.select("#hourBg")
        .attr({
            "stroke":"none",
            "height":40
        });
    d3.selectAll(".hourGroup").classed("clicked-g",false);
    d3.select(this_hour).classed("clicked-g",true);
    d3.select(".minuteGroup.clicked-g").classed("clicked-g",false);

    var server_hour = get_common_time(true).server_hour;
    var sever_date = get_common_time(true).server_date;

    var selected_hour = parseInt(d3.select(this_hour).select("text").text());
    var date_data = d3.select("#selectYear")[0][0].value.split("-").join("/");//取得选择的日期
    var date_string = date_data + " " + selected_hour + ":00:00";
    var date_seconds = new Date(date_string).getTime() / 1000;

    if(sever_date == date_data){
        if(selected_hour == server_hour){
            future_time(ts2str(get_common_time(false)));
            is_axis_cycle = true;
        }else if(selected_hour < server_hour){
            d3.selectAll(".minuteGroup").classed("f-time",false);
            is_axis_cycle = false;
            d3.selectAll(".now_time").classed("now_time",false);
        }else{
            d3.selectAll(".minuteGroup").classed("f-time",true);
            is_axis_cycle = false;
            d3.selectAll(".now_time").classed("now_time",false);
        }
    }else if(sever_date > date_data){
        d3.selectAll(".minuteGroup").classed("f-time",false);
        is_axis_cycle = false;
        d3.selectAll(".now_time").classed("now_time",false);
    }else{
        d3.selectAll(".minuteGroup").classed("f-time",true);
        is_axis_cycle = false;
        d3.selectAll(".now_time").classed("now_time",false);
    }
    time_ajax(date_seconds);

    /* 刷新拓扑图数据 */
    showdatapath(app_name,date_seconds);
    cancel_bubble();
}

/**
 * 点击分钟时触发的函数
 * @param this_minu
 */
function minuClick(this_minu){
    if(!(d3.select(".hourGroup.clicked-g").empty())){

        d3.selectAll(".minuteGroup").classed("clicked-g",false);
        d3.select(this_minu).classed("clicked-g",true);

        var server_time = get_common_time(true);
        var selected_date = d3.select("#selectYear")[0][0].value.split("-").join("/");
        var selected_hour = d3.select(".hourGroup.clicked-g").select("text").text();
        var selected_minu = d3.select(".minuteGroup.clicked-g").select("text").text();

        if(server_time.server_date ==  selected_date && server_time.server_hour == selected_hour && server_time.server_minu == selected_minu){
            is_axis_cycle = true;
        }else{
            is_axis_cycle = false;
        }
        /* 刷新拓扑图数据 */
        var date_second = new Date(selected_date + " " + selected_hour + ":" + selected_minu + ":00").getTime() / 1000 ;
        showdatapath(app_name,date_second);

    }else{
        error_tips("#hourBg");
    }
    cancel_bubble();
}

/**
 * 当用户未选择业务时，高亮显示边框，达到提示效果
 */
function error_tips(input_this){
    d3.select("#hourBg").attr("height",39);
    d3.select(input_this)
        .transition()
        .attr("stroke","#E83B1C")
        .duration(100)
        .attr("stroke","#465F7D")
        .duration(100)
        .attr("stroke","#E83B1C")
        .duration(100);
}

/**
 * 时间轴数据请求
 * @param app_name
 * @param timeSeconds
 * @param is_update_min
 */
function time_ajax(timeSeconds){
    d3.json("/"+"zh-cn"+"/timeaxis/" + app_name + "/timeline/?ts="+timeSeconds+";csrfmiddlewaretoken="+csrf_token)
        .header("Content-Type", "application/x-www-form-urlencoded")
        .get(function(e,data){
            if(!e){
                var minute = data.minute;
                var hour = data.hour;
                $.each(minute, function (index, value) {
                    change_style(value, "#minuteContent", index);
                });
                $.each(hour, function (index, value) {
                    change_style(value, "#hourContent", index);
                });
            }
        });
    /**
     * 初始化业务逻辑时间数据
     * app_name -- 当前选择到的app
     */
    logicTime(timeSeconds,app_name);
}

/**
 * 初始化业务逻辑时间数据
 * app_name -- 当前选择到的app
 * timeSeconds -- 选择到的时间
 */
function logicTime(timeSeconds,app_name){
    var logic_bg_width = d3.select("#logicTime")[0][0].getBoundingClientRect().width;
    var linear = d3.scale.linear() //新建的比例尺。
        .domain([0,23]) // 定义域，即是0到23，一天的24小时
        .range([0,logic_bg_width]); //对应的宽度，
    var colors = ["rgba(78,85,56,.5)","rgba(25,55,132,.5)","rgba(36,110,72,.5)","rgba(72,41,111,.5)","rgba(122,53,32,.5)","rgba(100,64,55,.5)","rgba(69,90,90,.5)","rgba(31,82,140,.5)"];
    d3.select("#logicTime").selectAll(".logic_g").remove();
    /**
     * 初始化业务逻辑时间数据
     */
    d3.json('/'+ LANGUAGE_CODE  +'/'+  app_name + '/logictime/')
        .header("Content-Type", "application/x-www-form-urlencoded")
        .get('csrfmiddlewaretoken=' + csrf_token, function(e, logic_data) {
            if(!e){
                var start_time = []; //各个逻辑时间的开始时间
                var end_time = []; // 各个逻辑时间的结束时间
                var logic_name = []; // 各个逻辑时间的名称

                var logicArr = logic_data.logic_time_docs;
                var week_day = "",
                    week_day_2 = "",
                    is_show = false;

                if(timeSeconds){
                    week_day_2= new Date(timeSeconds * 1000).getDay();
                }else{
                    week_day_2= new Date(get_common_time(false) * 1000).getDay();
                }
                switch (week_day_2){  // 将当前的日期的周几与后台数据项匹配
                    case 0: week_day = "";
                        break;
                    case 1:week_day = "week_mon";
                        break;
                    case 2:week_day = "week_tue";
                        break;
                    case 3:week_day = "week_wed";
                        break;
                    case 4:week_day = "week_thu";
                        break;
                    case 5:week_day = "week_fri";
                        break;
                    case 6:week_day = "";
                        break;
                }

                logicArr.forEach(function(value,key){
                    is_show = false;
                    value.week.forEach(function(week,week_key){
                        if(week_day == week){
                            is_show = true;
                        }
                    });
                    if(is_show){
                        start_time.push(value.start_time.join("."));
                        end_time.push(value.end_time.join("."));
                        logic_name.push(value.name);
                    }
                });

                d3.select("#logicTime").selectAll("g")
                    .data(start_time)
                    .enter()
                    .append("g")
                    .attr({
                        "class":"logic_g",
                        "data-logic-name":function(d,i){
                            return logic_name[i];
                        }
                    })
                    .append("polygon")
                    .attr({
                        "points":function(d,i){
                            return linear(d)+",67 "+ linear(end_time[i]) + ",67 " + linear(end_time[i]) +",70 " + linear(d) + ",70";
                        },
                        "fill":function(d,i){
                            return colors[i];
                        },
                        "stroke":function(d,i) {
                            return colors[i];
                        }
                    });
                d3.selectAll(".logic_g").each(function(d,i){
                    var show_message = d3.select(this).attr("data-logic-name");
                    show_msgs(d3.select(this),show_message,"top",true);
                })

            }
        });
}

/**
 * 按要求修改不同状态下的演示，包括h-block和m-block的样式。有警告，数据，报错三个状态
 * @param value
 * @param className
 * @param index
 */
function change_style(value, className, index) {
    var has_located_alert = value.has_located_alert;
    var has_alert = value.has_alert;
    var has_data = value.has_data;
    var minute_bar_div = d3.select(className).selectAll("g")[0][index];
    d3.select(minute_bar_div).classed("has-alert has-warn has-data",false);
    if(value.start > get_common_time()){
        d3.select(minute_bar_div).classed("f-time",true);
    }
    if (has_data) {
        d3.select(minute_bar_div).classed({"has-data":true});
    }
    if (has_alert) {
        d3.select(minute_bar_div).classed({"has-alert":true});
    }
    if (has_located_alert) {
        d3.select(minute_bar_div).classed({"has-warn":true});
    }
}

/**
 * 当click，hover的时候按要求修改m-block中显示的值
 */
function change_m_block(this_block){
    for (var i = 0; i <= 60; i += 5) {//设置选中的div显示其中的text
        var mine_block = d3.select("#minuteContent").selectAll("g")[0];
        for(var j = 1; j<=4; j++){
            d3.select(mine_block[i+j]).select("text").classed({
                "display-none":true,
                "display-block":false
            });
            d3.select(mine_block[i+j]).select(".min-or-hide").classed({
                "display-none":true,
                "display-block":true
            });
            d3.select(mine_block[i+j]).select(".minu-point").classed({
                "display-block":true,
                "display-none":false
            });
        }
    }
    d3.select(this_block).select("text").classed({
        "display-block":true,
        "display-none":false
    });
    d3.select(this_block).select(".min-or-hide").style({
        "display-block":true,
        "display-none":false
    });
}

/**
 * 在时间轴上显示当前时间。
 */
function now_time(server_time) {
    d3.select(".minuteGroup").classed("now_time",false);
    d3.select(".hourGroup").classed("now_time",false);
    future_time(server_time);
}

/**
 * 设置当前时间之后的钢琴键颜色。
 */
function future_time(server_time) {
    d3.selectAll(".minuteGroup,.hourGroup").classed("now_time f-time",false);
    d3.select("#selectYear").property("value",server_time.split(" ")[0]);

    var hours = parseInt(server_time.split(" ")[1].split(":")[0]);
    var minute = parseInt(server_time.split(" ")[1].split(":")[1]);

    //将最新的分钟不添加now_time样式（需求来至任干支）
    d3.select(d3.selectAll("#minuteContent .minuteGroup")[0][minute]).classed({"now_time":true,"f-time":true});
    d3.select(d3.selectAll("#hourContent .hourGroup")[0][hours]).classed({"now_time":true,"f-time":false});

    //d3.select(d3.selectAll("#hourContent .hourGroup")[0][hours]).classed({"now_time":true,"f-time":false});
    //d3.select(d3.selectAll("#minuteContent .minuteGroup")[0][minute]).classed({"now_time":true,"f-time":false});

    if (!(d3.select(".hourGroup.now_time").empty())) {
        var h_now = $(".hourGroup.now_time").index();
        d3.selectAll('.hourGroup')[0].forEach(function(d,key){
            if(key >= h_now){
                d3.select(d).classed("f-time",true);
            }
        })
    } else {
        d3.selectAll('.hourGroup').classed("f-time",false);
    }
    if (!(d3.select(".minuteGroup.now_time").empty())) {
        var m_now = $(".minuteGroup.now_time").index();
        d3.selectAll('.minuteGroup')[0].forEach(function(d,key){
            if(key >= m_now){
                d3.select(d).classed("f-time",true);
            }
        })
    } else {
        d3.selectAll(".minuteGroup").classed({"now_time f-time":false});
    }
}
