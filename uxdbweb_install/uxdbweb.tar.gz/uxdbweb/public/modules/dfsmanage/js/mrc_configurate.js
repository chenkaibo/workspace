var mrcConfgJson;//mrcConfg从后台获取的全部数据
function getMrcHandle(operDFSInfo)
{
    refeshDfsStateFlag = false;
    window.focus();
    clearTimerFun();
    changePath("云数据库管理->DFS管理->DFS操作->MRC配置");
    window.sessionStorage.ux_pagePath = "dfsManage,mrcConfig";
    var currentRole = window.sessionStorage.ux_curUserRole;
    d3.select("#mainContainDiv").remove();
    setParameterData(operDFSInfo);
    console.log("MRCMRCMRMCMRCMRC = "+parameterData);
    mrcContainDiv = d3.select("#dfsBodyId")
        .append("div")
        .classed("siteList-content container",true)
        .attr("id","mainContainDiv");
    d3.select(".siteList-content")
        .append("div")
        .classed("revers","true")
        .append("a")
        .attr("class","dfs-reverse")
        .append("button")
        .classed("btn admitClick",true)
        .attr("id","dfs-reverseBtn")
        .on("click",function(){
            returnDfsHandle(parameterData)
        })
        .html("返回上一级");
    d3.select(".siteList-content")
        .append("fieldset")
        .classed("dfsList-content",true)
        .style("height","692px")
        .append("legend")
        .html("配置MRC");
    d3.select(".dfsList-content")
        .append("div")
        .classed("dfsconfg-content",true)
        .append("div")
        .classed("mrcList",true)
        .attr("id","mrcList")
        .append("div")
        .classed("toolbar volumeToolbar",true)
        .attr("id","dfsConfgToolbar")
        .append("button")
        .classed("del-btn-position delBtnClass disabledElem",true)
        .attr("id","setupMrc")
        .on("click",function(){
            d3.select(this).classed("admitClick",false);
            setupMrc();
        })
        .html("设&nbsp;&nbsp;置");
    d3.select(".mrcList")
        .append("div")
        .classed("pull-right searchSite",true)
        .style("margin-top","-2px")
        .attr("id","searchMrc");
    for(var i = 0; i < 2; i++){
        d3.select("#searchMrc").append("div").classed("searchSite-content",true);
    };
    d3.selectAll(".searchSite-content")
        .append("input")
        .attr("type","checkbox")
        .each(function(d,i){
            d3.select(this).attr({
                id:"checkboxId" + i
            });
        })
        .on("click",function(d,i){
            checkBoxFun(i);
        })
        .attr("class","siteCheck");
    var searchSite_content= d3.selectAll(".searchSite-content");
    d3.select(searchSite_content[0][0])
        .insert("span",":nth-child(2)")
        .attr("class","searchTypeName")
        .attr({
            'class':'searchTypeName',
            'id':'selectElemId0',
            'disabled':""
        })
        .html("已修改");
    d3.select(searchSite_content[0][1])
        .insert("span",":nth-child(2)")
        .attr("class","searchTypeName")
        .html("名称:");
    d3.select(searchSite_content[0][1])
        .insert("input",":nth-child(3)")
        .attr({
            'type':'text',
            'id':'selectElemId1',
            'disabled':""
        });
    d3.select("#searchMrc")
        .append("button")
        .classed("btn searchSite-btn",true)
        .style("margin","4px 4px")
        .on("click",function(){
            queryMrcConfg();
        })
        .attr("title","查找");
    d3.select(".mrcList")
        .append("table")
        .attr({
            "id":"mrcConfgTable",
            "data-toggle":"table",
            "color":"#57D1F7"
        });
    //d3.select(".siteList-content")
    //    .append("div")
    //    .classed("dfsconfg-line",true)
    //    .attr("id","dfsconfg_line");
    if(currentRole == 1)
    {
        d3.selectAll(".disabledElem").style('display','none');
    }
    initMrcConfg();
    listenTable("mrcConfgTable","setupMrc");
}
//初始化MRC表格
function initMrcConfg()
{
    var par = [{field: 'radio', radio: true,align: 'center'},
        {field:'mrc_number',title:'序&nbsp;&nbsp;&nbsp;&nbsp;号',align: 'center'},
        {field:'mrc_name',title:'名&nbsp;&nbsp;&nbsp;&nbsp;称',align: 'center'},
        {field:'mrc_type',title:'类&nbsp;&nbsp;&nbsp;&nbsp;型',align: 'center',formatter:function(value,row,index){
            var typeValue;//1:整型,2:布尔,3:枚举,4:字符串
            if(row.mrc_type == 1)
            {
                typeValue = "整型";
            }else if(row.mrc_type == 2)
            {
                typeValue = "布尔类型";
            }else if(row.mrc_type == 3)
            {
                typeValue = "枚举类型";
            }else if(row.mrc_type == 4)
            {
                typeValue = "字符串型";
            }else{
                typeValue = "未知类型";
            }
            return typeValue;
        }},
        {field:'mrc_currvalue',title:'当前值',align: 'center'},
        {field:'mrc_modify',title:'已修改',align: 'center',formatter:function(value,row,index){
            if(row.mrc_modify == 0) {
                var constr = '<a title="未修改">' + '<button class="no-modify"></button>' + '</a>';
                return constr;
            }else{
                var discon = '<a title="已修改">' + '<button class="modified-btn"></button>' + '</a>';
                return discon;
            }
        }},
        {field:'mrc_sort',title:'类&nbsp;&nbsp;&nbsp;&nbsp;别',align: 'center',formatter:function(value,row,index){
            if(row.mrc_sort == "classless"){
               return "";
            }else{
                return row.mrc_sort;
            }
        }},
        {field:'mrc_illustrate',title:'说&nbsp;&nbsp;&nbsp;&nbsp;明',align: 'center',width:'1000'}
    ];
    $('#mrcConfgTable').bootstrapTable({
        classes:"table table-no-bordered",
        toolbar:"#dfsConfgToolbar",
        height:540,
        columns: par,
        idField:"mrc_number",
    });
    getMrcConfgData();
}
//mrc回调函数
function mrcConfgCallback(retJson)
{
    var data = JSON.parse(retJson);
    if(data.rstcode == "success")
    {
        mrcConfgJson = mrcConfgGetNewJson(data.data);
        $("#mrcConfgTable").bootstrapTable('load',mrcConfgJson);
        listenTable("mrcConfgTable","setupMrc");
        //if(dataJson.length >= 14){
        //    $("#dfsconfg_line").css("display","block");
        //}else{
        //    $("#dfsconfg_line").css("display","none");
        //}
    }else {
        uxAlert(data.desc);
    }
}
//获取mrc配置数据
function getMrcConfgData()
{
    var mrc_id = mrcCurrId;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"getDirMrcOsdCfgList","subRequest":"mrc","ssubRequest":""},
        data    :{
            mrc_id:mrc_id
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,mrcConfgCallback);
}
//获取mrc更新的数据
function mrcConfgGetNewJson(data)
{
    console.log("MRC后台返回数据 = "+JSON.stringify(data));
    var newJson = [];
    for(var i = 0;i<data.length;i++)
    {
        var info = {};
        info.mrc_number = (i+1);
        info.mrc_name = data[i].pname;
        info.mrc_path = data[i].cfgpath;
        info.mrc_type = data[i].ptype;
        info.mrc_value = data[i].pvalue;
        info.mrc_currvalue = data[i].pvalue;
        info.mrc_modify = data[i].ismodify;
        info.mrc_illustrate = data[i].description;
        info.mrc_sort = trim(data[i].pclass);
        info.vlist = data[i].vlist || " ";
        newJson.push(info);
    }
    return newJson;
}
//MRC设置页面
function setupMrc()
{
    var className;
    var mrcDataItem = getIdSelections("mrcConfgTable")[0];
    newMrcInfoElem(mrcDataItem.mrc_currvalue,mrcDataItem.vlist,mrcDataItem.mrc_type,mrcDataItem.mrc_illustrate);
    d3.select("#mrcNameTitle")
        .classed("dirNameTitle",true)
        .html(mrcDataItem.mrc_name);
    d3.select("#describe")
        .html(mrcDataItem.mrc_name+" 描述");
    d3.select("#newUserItemSpanNew").classed("newTitle",true);
    //d3.select("#sureBtnNew")
    if(d3.select("#dialogNew").classed("bounceIn"))
    {
        className = "bounceOutUp";
    }else{
        className = "bounceIn";
    }
    $('#dialogBgNew').fadeIn(300);
    $('#dialogNew').removeAttr('class').addClass('animated ' + className + '').fadeIn();

}
//Mrc设置弹出框实现
function newMrcInfoElem(currentData,optionalItem,type,areaDescription)
{
    d3.select("#dialogBgNew").remove();
    d3.select("#dialogNew").remove();
    var popUpInputArray = ["&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"];
    var opertionItemArray,typeFlag,sureFlag = false;
    if(type == 1) //整型有两界值 intValue
    {
        opertionItemArray = optionalItem;
        typeFlag = 1;
    }else if(type == 4){//字符串有最大长度
        opertionItemArray = optionalItem;
        typeFlag = 4;
    }else if(type == 2){//布尔值
        opertionItemArray = ["true","false"];
        typeFlag = 2;
    }else if(type == 3){//枚举值选择 emumValue
        opertionItemArray = optionalItem;
        typeFlag = 3;
    }
    mrcContainDiv.append("div")
        .attr("id","dialogBgNew");
    var outPage = mrcContainDiv.append("div")
        .attr("id","dialogNew")
        .style({
            "width":"445px",
            "height":"340px"
        });
    var editFrom = outPage.append("div")
        .attr("id","editFromNew");
    var newUserItemSpan = editFrom.append("span")
        .attr("id","newUserItemSpanNew")
        .html("设置 ")
        .append("span")
        .attr("id","mrcNameTitle");
    var editFormUl = editFrom.append("ul")
        .attr("class","editInfos");
    for(var i = 0;i < popUpInputArray.length;i++)
    {
        var editFromLi = editFormUl.append("li").attr("class","editUl");
        editFromLi.append("label")
            .attr("class","editFromLiSpan")
            .html(popUpInputArray[i]);
        if(typeFlag == 1)
        {
            editFromLi.append("input")
                .attr({
                    'id':'inputValue',
                    'type':"text",
                    'class':'ipt'
                })
                .on("blur",function(){
                    var value = d3.select(this)[0][0].value;
                    if(optionalItem != " ")
                    {
                        var minValue = optionalItem[1].minvalue;
                        var maxValue = optionalItem[0].maxvalue;
                        if(minValue == " " && maxValue == " ")
                        {
                            //不用校验
                            if(isNumber(value) && value != "")
                            {
                                d3.select(this)[0][0].nextSibling.innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入一个正确的整型值！</span>";
                                sureFlag = false;
                            }
                        }else if(minValue != " " && maxValue == " ")
                        {
                            //校验最小值
                            if(parseInt(value) >= parseInt(minValue))
                            {
                                d3.select(this)[0][0].nextSibling.innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入大于" +minValue+ "的整型值！</span>";
                                sureFlag = false;
                            }
                        }else if(minValue == " " && maxValue != " ")
                        {
                            //校验最大值
                            if(parseInt(value) <= parseInt(maxValue))
                            {
                                d3.select(this)[0][0].nextSibling.innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入小于" +maxValue+ "的整型值！</span>";
                                sureFlag = false;
                            }
                        }else if(minValue != " " && maxValue != " ")
                        {
                            //校验区间
                            if(parseInt(value) >= parseInt(minValue) && parseInt(value) <= parseInt(maxValue))
                            {
                                d3.select(this)[0][0].nextSibling.innerHTML = "";
                                sureFlag = true;
                            }else{
                                d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入"+minValue+"-" +maxValue+ "之前的整型值！</span>";
                                sureFlag = false;
                            }
                        }
                    }else{
                        //不用校验
                        if(isNumber(value) && value != "")
                        {
                            d3.select(this)[0][0].nextSibling.innerHTML = "";
                            sureFlag = true;
                        }else{
                            d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入一个正确的整型值！</span>";
                            sureFlag = false;
                        }
                    }
                });
            d3.select("#inputValue")[0][0].value = currentData;
        }else if(typeFlag == 2)
        {
            sureFlag = true;
            var selectElem = editFromLi.append("select")
                .attr({
                    'id':'inputValue',
                    'class':'ipt selectClass'
                });
            for(var operIndex = 0; operIndex < opertionItemArray.length; operIndex++)
            {
                selectElem.append("option")
                    .attr({
                        'id':'opertion' + operIndex
                    }).text(opertionItemArray[operIndex]);
            }
            var selectObj = d3.select("#inputValue");
            selectObj[0][0].selectedIndex = (currentData == "true") ? (0):(1);
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = currentData;
        }else if(typeFlag == 3)
        {
            sureFlag = true;
            var selectElem = editFromLi.append("select")
                .attr({
                    //'id':'input' + i,
                    'id':'inputValue',
                    'class':'ipt selectClass'
                });
            for(var operIndex = 0; operIndex < opertionItemArray.length; operIndex++)
            {
                selectElem.append("option")
                    .attr({
                        'id':'opertion' + operIndex
                    }).text(opertionItemArray[operIndex].vlist);
            }
            var selectObj = d3.select("#inputValue");
            for(var k = 0;k<opertionItemArray.length; k++)
            {
                if(currentData == opertionItemArray[k].vlist)
                {
                    selectObj[0][0].selectedIndex = k;
                    break;
                }
            }
            selectObj[0][0].options[selectObj[0][0].selectedIndex].innerHTML = currentData;
        }else if(typeFlag == 4)
        {
            editFromLi.append("input")
                .attr({
                    'id':'inputValue',
                    'type':"text",
                    'class':'ipt'
                })
                .on("blur",function(){
                    var value = d3.select(this)[0][0].value;
                    if(optionalItem != " ")
                    {
                        var maxLength = optionalItem[0].maxlength;
                        if(value.length < parseInt(maxLength))
                        {
                            d3.select(this)[0][0].nextSibling.innerHTML = "";
                            sureFlag = true;
                        }else{
                            d3.select(this)[0][0].nextSibling.innerHTML = "<span class='errorTip'>请输入长度小于"+maxLength+"的字符串！</span>";
                            sureFlag = false;
                        }
                    }else{
                        d3.select(this)[0][0].nextSibling.innerHTML = "";
                        sureFlag = true;
                    }
                });
            d3.select("#inputValue")[0][0].value = currentData;
        }
    }
    var describe = editFrom.append("div")
        .classed("describe",true);
    describe.append("p")
        .attr({
            'id': "describe",
            'class': 'newTitle'
        });
    describe.append("textarea")
        .attr({
            'id': "describeText",
            'class': 'describeText',
            'disabled':true
        });
    d3.select("#describeText")[0][0].value = areaDescription;
    d3.selectAll(".editUl")
        .append("span")
        .each(function(d,i){
            d3.select(this).attr({
                'id':'errorSpan' + i
            });
        });
    var editFromDivBtn = editFrom.append("div").attr("class","editFromDivBtn").style({"bottom":"30px","right":"25.5%"});
    editFromDivBtn.append("button")
        .attr("id","sureBtnNew")
        .attr("class","btn btn-sm btn-bg-color popUpBtn")
        .on('click',function(){
            if(sureFlag)
            {
                var mrcDataItem = getIdSelections("mrcConfgTable")[0];
                newMrcInfo(mrcDataItem);
            }else{
                uxAlert("请输入正确的配置信息！");
            }
        })
        .html("确定");
    editFromDivBtn.append("button")
        .attr("class","btn btn-sm btn-bg-color popUpBtn claseDialogBtn")
        .attr("id","claseDialogBtnNew")
        .on("click",function(){
            d3.select("#dialogNew").classed("bounceIn",false);
            $('#dialogBgNew').fadeOut(300,function(){
                $('#dialogNew').addClass('bounceOutUp').fadeOut();
            });
            d3.select("#setupMrc").classed("btn admitClick",true);
        })
        .html("取消");
}
//设置前后值没有发生改变，点击确定
function mrcConfgCancel(){
    uxAlert("设置MRC成功");
    d3.select("#dialogNew").classed("bounceIn",false);
    $('#dialogBgNew').fadeOut(600,function(){
        $('#dialogNew').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#setupMrc").classed("btn admitClick",true);
}
//Mrc设置页面与后台交互
function newMrcInfo(mrcCurrDataItem)
{
    var mrc_value = d3.select("#inputValue")[0][0].value;
    var mrc_currvalue = mrcCurrDataItem.mrc_currvalue;
    if(mrc_value == mrc_currvalue){
        mrcConfgCancel();
        return;
    }

    var mrc_id = mrcCurrId;
    var mrc_name = mrcCurrDataItem.mrc_name;
    var mrc_type = mrcCurrDataItem.mrc_type;
    //var type;
    //if(mrc_type == "整型"){
    //    type = 1;
    //}else if(mrc_type == "布尔型"){
    //    type = 2;
    //}else if(mrc_type == "枚举型"){
    //    type = 3;
    //}else if(mrc_type == "字符型"){
    //    type = 4;
    //};
    //var mrcDescribe = d3.select("#describeText")[0][0].value;
    var jsonDataObj = {
        ip      :"",
        port    :"",
        router  :"dfsmanage",
        request :{"mainRequest":"setDirMrcOsdConfig","subRequest":"mrc","ssubRequest":""},
        data    :{
            mrc_id:mrc_id,
            pname:mrc_name,
            pvalue:mrc_value,
            ptype:mrc_type
        }
    };
    var jsonDataStr = JSON.stringify(jsonDataObj);
    ux_reqInterface.ajaxRequest(false,jsonDataStr,newMrcInfoCallback);
}
function newMrcInfoCallback(retJson)
{
    var retJsonStr = JSON.parse(retJson);
    if(retJsonStr.rstcode == "success")
    {
        getMrcConfgData();
    }
    uxAlert(retJsonStr.desc);
    d3.select("#dialogNew").classed("bounceIn",false);
    $('#dialogBgNew').fadeOut(300,function(){
        $('#dialogNew').addClass('bounceOutUp').fadeOut();
    });
    d3.select("#setupMrc").classed("btn admitClick",false).classed("delBtnClass",true);
}
/*MRC配置界面查询数据*/
function queryMrcConfg()
{
    var queryJsonData = {
        'mrcModifiedFlag':0,
        'mrcNameFlag':0,
        'mrcName':'',
    };
    var formDataArray = d3.selectAll(".siteCheck");
    queryJsonData.mrcModifiedFlag = (formDataArray[0][0].checked == false) ? (0):(1);
    queryJsonData.mrcNameFlag = (formDataArray[0][1].checked == false) ? (0):(1);
    queryJsonData.mrcName = d3.select("#selectElemId1")[0][0].value;
    var mrcConfgNewArr = [];
    if((queryJsonData.mrcModifiedFlag == 0) && (queryJsonData.mrcNameFlag == 0))
    {
        $("#mrcConfgTable").bootstrapTable('load',mrcConfgJson);
        return;
    }else if((queryJsonData.mrcNameFlag == 1) && (queryJsonData.mrcModifiedFlag == 0))
    {
        if(queryJsonData.mrcName != ""){
            for (var i = 0; i < mrcConfgJson.length; i++) {
                if (mrcConfgJson[i].mrc_name.indexOf(queryJsonData.mrcName) != -1) {
                    mrcConfgNewArr.push(mrcConfgJson[i]);
                }
            }
            $("#mrcConfgTable").bootstrapTable('load',mrcConfgNewArr);
        }else{
            uxAlert("请完善查询条件！")
        }
    }else if((queryJsonData.mrcNameFlag == 0) && (queryJsonData.mrcModifiedFlag == 1)){
        for (var i = 0; i < mrcConfgJson.length; i++) {
            if (mrcConfgJson[i].mrc_modify == 1) {
                mrcConfgNewArr.push(mrcConfgJson[i]);
            }
        }
        $("#mrcConfgTable").bootstrapTable('load',mrcConfgNewArr);
    }else if((queryJsonData.mrcModifiedFlag == 1) && (queryJsonData.mrcNameFlag == 1)){
        for (var i = 0; i < mrcConfgJson.length; i++) {
            if ((mrcConfgJson[i].mrc_modify == 1) && (mrcConfgJson[i].mrc_name.indexOf(queryJsonData.mrcName) != -1)) {
                mrcConfgNewArr.push(mrcConfgJson[i]);
            }
        }
        $("#mrcConfgTable").bootstrapTable('load',mrcConfgNewArr);
    }
}
