CREATE TABLE tbl_osdlist
(
  id varchar(64) NOT NULL,
  dfsid varchar(64),
  siteid varchar(64),
  osdname varchar(64),
  ip varchar(32),
  port varchar(10),
  httpport varchar(10),
  state char,
  dirip1 varchar(32),
  dirport1 varchar(10),
  dirip2 varchar(32),
  dirport2 varchar(10),
  dirip3 varchar(32),
  dirport3 varchar(10),
  dirip4 varchar(32),
  dirport4 varchar(10),
  dirip5 varchar(32),
  dirport5 varchar(10),
  dirip6 varchar(32),
  dirport6 varchar(10),
  maintype char,
  cfgpath varchar(255),
  inittm varchar(32),
  latesttm varchar(32),

  CONSTRAINT tbl_osdlist_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE tbl_osdlist
  OWNER TO uxdbwebuser;
COMMENT ON COLUMN tbl_osdlist.id IS 'DIR ID';
COMMENT ON COLUMN tbl_osdlist.dfsid IS 'DIR所属DFS的ID';
COMMENT ON COLUMN tbl_osdlist.siteid IS '所在站点ID';
COMMENT ON COLUMN tbl_osdlist.osdname IS 'OSD名称';
COMMENT ON COLUMN tbl_osdlist.ip IS 'IP地址';
COMMENT ON COLUMN tbl_osdlist.port IS '端口号';
COMMENT ON COLUMN tbl_osdlist.state IS '启动状态，1:启动，2:停止';
COMMENT ON COLUMN tbl_mrclist.dirip1 IS 'DIR1 ip';
COMMENT ON COLUMN tbl_mrclist.dirport1 IS 'DIR1 port';
COMMENT ON COLUMN tbl_mrclist.dirip2 IS 'DIR2 ip';
COMMENT ON COLUMN tbl_mrclist.dirport2 IS 'DIR2 port';
COMMENT ON COLUMN tbl_mrclist.dirip3 IS 'DIR3 ip';
COMMENT ON COLUMN tbl_mrclist.dirport3 IS 'DIR3 port';
COMMENT ON COLUMN tbl_mrclist.dirip4 IS 'DIR4 ip';
COMMENT ON COLUMN tbl_mrclist.dirport4 IS 'DIR4 port';
COMMENT ON COLUMN tbl_mrclist.dirip5 IS 'DIR5 ip';
COMMENT ON COLUMN tbl_mrclist.dirport5 IS 'DIR5 port';
COMMENT ON COLUMN tbl_mrclist.dirip6 IS 'DIR6 ip';
COMMENT ON COLUMN tbl_mrclist.dirport6 IS 'DIR6 port';
COMMENT ON COLUMN tbl_osdlist.maintype IS '主备类型';
COMMENT ON COLUMN tbl_osdlist.cfgpath IS '配置文件路径';
COMMENT ON COLUMN tbl_osdlist.inittm IS '首次记录时间';
COMMENT ON COLUMN tbl_osdlist.latesttm IS '最近更新时间';