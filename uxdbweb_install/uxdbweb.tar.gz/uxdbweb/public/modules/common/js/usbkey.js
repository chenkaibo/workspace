/**
 * Created by Administrator on 2016/3/4.
 */

function UXKEY() {}
UXKEY.prototype.Ry = {};
UXKEY.prototype.domID = "";
UXKEY.prototype.pid = "";
UXKEY.prototype.initKey = function(domID,pid)
{
    this.domID = domID;
    this.pid = pid;

}
UXKEY.prototype.enum = function()
{
    var ret;
    this.Ry = document.getElementById(this.domID);
    this.Ry.pid = this.pid;
    ret = this.Ry.Don_FindToken();
    if (ret == 0)
    {

        if(this.Ry.index == -1)
        {
            alert("the index.html: "+this.Ry.index+" 没有找到指定PID的锁");

        }
        else
        {
            //alert("找到 pid= "+Ry.pid.toString(16)+" 的锁！");
            //alert("hid= "+Ry.hid+" 的锁！");
        }

    }
    else
    {
        //alert("Find ret: "+parseInt(ret, 10).toString(16));
        return parseInt(ret, 10).toString(16);
    }
    return ret;
}

UXKEY.prototype.open = function()
{

    var ret = this.Ry.Don_OpenToken();
    if (ret == 0)
    {
        //alert("Open successful");
    }
    else
    {
        //alert("Open ret: "+parseInt(ret, 10).toString(16));

    }

    return ret;
}

UXKEY.prototype.close = function()
{
    var ret;
    ret = this.Ry.Don_CloseToken();
    if (ret == 0)
    {
        //alert("Close successful");
    }
    else
    {
        //alert("Close ret: "+parseInt(ret, 10).toString(16));
    }
}

UXKEY.prototype.writeFile = function(infoStr)
{

    if(infoStr.length > 64)
    {
        return -1;
    }
    var ret;
    ret = this.enum();
    if(ret != 0)
    {
        return ret;
    }
    ret = this.open();
    if(ret != 0)
    {
        return ret;
    }

    this.Ry.Flag = 1;
    this.Ry.FileID = 0x0001;
    this.Ry.Offset = 0;
    this.Ry.InDataLen = 64;
    var inforLen = infoStr.length;
    for(var i = 0; i < 64 - inforLen; i++)
    {
        infoStr += '0';
    }
    this.Ry.InData = infoStr;
    ret = this.Ry.Don_WriteFile();
    if (ret == 0)
    {
        //alert("WriteFile successful");
    }
    else
    {
        //alert("WriteFile ret: "+parseInt(ret, 10).toString(16));

    }

    this.close();
    return ret;
}

UXKEY.prototype.readFile = function()
{
    var retVal;
    var ret;
    ret = this.enum();
    if(ret != 0)
    {
        retVal =  "error";
        return retVal;
    }
    ret = this.open();
    if(ret != 0)
    {
        retVal =  "error";
        return retVal;
    }

    this.Ry.FileID = 0x0001;
    this.Ry.Offset = 0;
    this.Ry.OutDataLen = 64;
    this.Ry.OutData = 0;
    ret = this.Ry.Don_ReadFile();
    if (ret == 0)
    {
        //alert("ReadFile successful:"+Ry.OutData);
        retVal =  this.Ry.OutData;
    }
    else
    {
        //alert("ReadFile ret: "+parseInt(ret, 10).toString(16));
        retVal =  "error";
    }

    this.close();
    return retVal;
}




